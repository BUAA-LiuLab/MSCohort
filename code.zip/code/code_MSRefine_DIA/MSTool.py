from MSLogging import logGetError


def toolFindNeighborFromSortedList0(inputList, start, end, number,):

    if number <= inputList[start]:
        return start

    if number >= inputList[end]:
        return end

    neighbor = soldierBinarySearch(inputList, start, end, number)  # 通常是落在了左边那个索引上

    disLeft = abs(inputList[neighbor] - number)
    disRight = abs(inputList[neighbor+1] - number)

    if disLeft < disRight:
        return neighbor
    else:
        return neighbor + 1


def soldierBinarySearch(inputList, start, end, number):

    # check
    if end >= len(inputList):
        logGetError("MSTool, MK311: The length of inputList is " + str(len(inputList)) + ", but you want to get " + str(end) + "?")

    if start < 0:
        logGetError(
            "MSTool, MK315: start is " + str(start) + "?")

    if number == inputList[end]:  # 最后一个有问题

        return end

    # find
    while start < end:
        mid = (start + end) // 2
        if number < inputList[mid]:
            end = mid
        elif number > inputList[mid]:
            start = mid + 1
        else:
            return mid

    start = start - 1

    return start


def toolFindNeighborFromSortedList1(inputList, number):

    return toolFindNeighborFromSortedList0(inputList, 0, len(inputList)-1, number)  # 长度必须-1，保证是个数字


def toolGetNextLine(input_str, input_index):

    line = ''

    len_str = len(input_str)

    i_str = input_index

    while i_str < len_str:

        tmpChar = input_str[i_str]
        i_str = i_str + 1

        if '\n' == tmpChar:
            break
        else:
            line = line + tmpChar

    return line


def toolMass2MZ(inputMH, input_charge):

    MASS_PROTON_MONO = 1.00727645224  # 1.00782503214-0.0005485799
    return (inputMH + (input_charge - 1) * MASS_PROTON_MONO) / input_charge


def toolCountInList(input_list, data):

    n = 0

    for e in input_list:

        if data == e:
            n = n + 1

    return n


def toolCopyList(list1):

    n = len(list1)
    list2 = []

    for i in range(n):
        list2.append(list1[i])

    return list2



def toolGetWord(str, index, d):
    
    str = d + str + d
    
    result = ''
    
    p_d = []
    
    i = 0
    for c in str:
        
        if c == d:
            
            p_d.append(i)
        
        i = i+1
        
    result = str[p_d[index]+1:p_d[index+1]]
        
    return result


def toolGetIndexByWord(line, word, delimiter):

    index = line.find(word)

    if -1 == index:

        logGetError('can not find '+word+' from: '+line)

    else:

        return toolCountCharInString(line[0:index], delimiter)


def toolCountCharInString(inputStr, inputChar):

    result = 0

    for c in inputStr:
        if c == inputChar:
            result = result + 1

    return result


def toolGetMaxIndexFromList(inputList):

    vMax = inputList[0]
    iMax = 0

    for i in range(len(inputList)):

        if inputList[i] > vMax:

            iMax = i
            vMax = inputList[i]

    return iMax


def toolGetMinIndexFromList(inputList):

    vMin = inputList[0]
    iMin = 0

    for i in range(len(inputList)):

        if inputList[i] < vMin:

            iMin = i
            vMin = inputList[i]

    return iMin


def toolGetMinValueFromList(inputList):

    vMin = inputList[0]
    iMin = 0

    for i in range(len(inputList)):

        if inputList[i] < vMin:

            iMin = i
            vMin = inputList[i]

    return vMin







# a = np.array([[2, 7, 4, 2],
#               [35, 9, 1, 5],
#               [22, 12, 3, 2]])
# print('a:')
# print(a)
#
# # 1按最后一列顺序排序
# print('按最后一列顺序排序:')
# print(a[np.lexsort(a.T)])
# print('')

# 2按最后一列逆序排序
# print('按最后一列逆序排序:')
# print(a[np.lexsort(-a.T)])
# print('')
#
# # 3按第一列顺序排序
# print('按第一列顺序排序:')
# print(a[np.lexsort(a[:, ::-1].T)])
# print('')
#
# # 4按最后一行顺序排序
# print('按最后一行顺序排序:')
# print(a.T[np.lexsort(a)].T)
# print('')
#
# # 5按第行顺序排序
# print('按第一行顺序排序:')
# print(a.T[np.lexsort(a[::-1, :])].T)
# # 输出结果：
