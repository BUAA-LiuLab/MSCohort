
import os
import pickle
import numpy as np
from MSLogging import logGetWarning, INFO_TO_USER_MSFunction
from MSTool import toolGetWord, toolGetIndexByWord, toolCopyList, toolFindNeighborFromSortedList1, toolMass2MZ, toolGetMinValueFromList
from MSData import CFileMS1, CFileMS2
from MSSystem import EXPIRATION_TIME, CFG_TYPE_DATA
from MSOperator import op_INIT_CFILE_MS1, op_INIT_CFILE_MS2, opGetStartAndEnd, opGetStartAndEnd_FWHM,op_INIT_CFILE_FEATURE
from MSOperator import feature_INFO, Meaning_INFO, Thermo_radar_info, Bruker_radar_info, SCIEX_radar_info
from MSSystem import IO_FILENAME_EXPORT, VALUE_ILLEGAL, CFG_TYPE_IDENTIFICATION_RESULT, IO_NAME_FILE_EXPORT
from time import gmtime, strftime
from os import path
from MSRawFileReader import RawFileReader
from MSLogging import logToUser


class FunctionConfig:

    def config2file(self, path, config):

        with open(path, 'w') as f:
            f.write('# [RAW file]'), f.write('\n')
            f.write('TYPE_DATA=' + config.A1_TYPE_DATA), f.write('\n')  
            f.write('PATH_RAW=' + config.A0_PATH_RAW), f.write('\n')  

            f.write('\n'), f.write('# [Analysis results]'), f.write('\n')
            f.write('PATH_RESULT=' + config.B2_PATH_IDENTIFICATION_RESULT), f.write('\n')  
            f.write('TYPE_RESULT=' + str(config.B3_TYPE_IDENTIFICATION_RESULT)), f.write('\n')  
            f.write('THRESHOLD_FDR=' + str(config.B4_THRESHOLD_FDR)), f.write('\n')  

            f.write('\n'), f.write('# [Setting]'), f.write('\n')
            f.write('THRESHOLD_PEAK_WIDTH_TAILING=' + str(config.C5_THRESHOLD_PEAK_WIDTH_TAILING)), f.write('\n')
            f.write('THRESHOLD_INVALID_ACQUIRING_SCAN=' + str(config.C6_THRESHOLD_INVALID_ACQUIRING_SCAN)), f.write('\n')
            f.write('FLAG_ANALYZE_FEATURE=' + str(config.E3_FLAG_ANALYZE_FEATURE)), f.write('\n')

            f.write('\n'), f.write('# [Export]'), f.write('\n')
            f.write('PATH_EXPORT=' + config.E1_PATH_EXPORT),f.write('\n')

        with open("ini/ThermoScore.ini", 'w') as f1:
            f1.write('[Sample Preparation]\n')
            f1.write('bottomS1, topS1=' + str(Thermo_radar_info.bottomS1) + ', ' + str(Thermo_radar_info.topS1)), f1.write(
                '#'), f1.write(Meaning_INFO.S1), f1.write('\n')
            f1.write('bottomS2, topS2=' + str(Thermo_radar_info.bottomS2) + ', ' + str(Thermo_radar_info.topS2)), f1.write(
                '#'), f1.write(Meaning_INFO.S2), f1.write('\n')
            f1.write('bottomS3, topS3=' + str(Thermo_radar_info.bottomS3) + ', ' + str(Thermo_radar_info.topS3)), f1.write(
                '#'), f1.write(Meaning_INFO.S3), f1.write('\n')

            f1.write('[Chromatography]\n')
            f1.write('bottomC1, topC1=' + str(Thermo_radar_info.bottomC1) + ', ' + str(Thermo_radar_info.topC1)), f1.write(
                '#'), f1.write(Meaning_INFO.C1), f1.write('\n')
            f1.write('bottomC2, topC2=' + str(Thermo_radar_info.bottomC2) + ', ' + str(Thermo_radar_info.topC2)), f1.write(
                '#'), f1.write(Meaning_INFO.C2), f1.write('\n')
            f1.write('bottomC3, topC3=' + str(Thermo_radar_info.bottomC3) + ', ' + str(Thermo_radar_info.topC3)), f1.write(
                '#'), f1.write(Meaning_INFO.C3), f1.write('\n')
            f1.write('bottomC4, topC4=' + str(Thermo_radar_info.bottomC4) + ', ' + str(Thermo_radar_info.topC4)), f1.write(
                '#'), f1.write(Meaning_INFO.C4), f1.write('\n')
            f1.write('bottomC5, topC5=' + str(Thermo_radar_info.bottomC5) + ', ' + str(Thermo_radar_info.topC5)), f1.write(
                '#'), f1.write(Meaning_INFO.C5), f1.write('\n')
            f1.write('bottomC6, topC6=' + str(Thermo_radar_info.bottomC6) + ', ' + str(Thermo_radar_info.topC6)), f1.write(
                '#'), f1.write(Meaning_INFO.C6), f1.write('\n')

            f1.write('[DIA Windows]\n')
            f1.write('bottomW1, topW1=' + str(Thermo_radar_info.bottomW1) + ', ' + str(Thermo_radar_info.topW1)), f1.write(
                '#'), f1.write(Meaning_INFO.W1), f1.write('\n')
            f1.write('bottomW2, topW2=' + str(Thermo_radar_info.bottomW2) + ', ' + str(Thermo_radar_info.topW2)), f1.write(
                '#'), f1.write(Meaning_INFO.W2), f1.write('\n')
            f1.write('bottomW3, topW3=' + str(Thermo_radar_info.bottomW3) + ', ' + str(Thermo_radar_info.topW3)), f1.write(
                '#'), f1.write(Meaning_INFO.W3), f1.write('\n')
            f1.write('bottomW4, topW4=' + str(Thermo_radar_info.bottomW4) + ', ' + str(Thermo_radar_info.topW4)), f1.write(
                '#'), f1.write(Meaning_INFO.W4), f1.write('\n')
            f1.write('bottomW5, topW5=' + str(Thermo_radar_info.bottomW5) + ', ' + str(Thermo_radar_info.topW5)), f1.write(
                '#'), f1.write(Meaning_INFO.W5), f1.write('\n')
            f1.write('bottomW6, topW6=' + str(Thermo_radar_info.bottomW6) + ', ' + str(Thermo_radar_info.topW6)), f1.write(
                '#'), f1.write(Meaning_INFO.W6), f1.write('\n')
            f1.write('bottomW7, topW7=' + str(Thermo_radar_info.bottomW7) + ', ' + str(Thermo_radar_info.topW7)), f1.write(
                '#'), f1.write(Meaning_INFO.W6), f1.write('\n')

            f1.write('[Ion Source]\n')
            f1.write('bottomIS1, topIS1=' + str(Thermo_radar_info.bottomIS1) + ', ' + str(Thermo_radar_info.topIS1)), f1.write(
                '#'), f1.write(Meaning_INFO.IS1), f1.write('\n')
            f1.write('bottomIS2, topIS2=' + str(Thermo_radar_info.bottomIS2) + ', ' + str(Thermo_radar_info.topIS2)), f1.write(
                '#'), f1.write(Meaning_INFO.IS2), f1.write('\n')
            f1.write('bottomIS3, topIS3=' + str(Thermo_radar_info.bottomIS3) + ', ' + str(Thermo_radar_info.topIS3)), f1.write(
                '#'), f1.write(Meaning_INFO.IS3), f1.write('\n')
            f1.write('bottomIS4, topIS4=' + str(Thermo_radar_info.bottomIS4) + ', ' + str(Thermo_radar_info.topIS4)), f1.write(
                '#'), f1.write(Meaning_INFO.IS4), f1.write('\n')
            
            

            f1.write('[MS1 and MS2 Signal]\n')
            f1.write('bottomM1, topM1=' + str(Thermo_radar_info.bottomM1) + ', ' + str(Thermo_radar_info.topM1)), f1.write(
                '#'), f1.write(Meaning_INFO.M1), f1.write('\n')
            f1.write('bottomM2, topM2=' + str(Thermo_radar_info.bottomM2) + ', ' + str(Thermo_radar_info.topM2)), f1.write(
                '#'), f1.write(Meaning_INFO.M2), f1.write('\n')
            f1.write('bottomM3, topM3=' + str(Thermo_radar_info.bottomM3) + ', ' + str(Thermo_radar_info.topM3)), f1.write(
                '#'), f1.write(Meaning_INFO.M3), f1.write('\n')
            f1.write('bottomM4, topM4=' + str(Thermo_radar_info.bottomM4) + ', ' + str(Thermo_radar_info.topM4)), f1.write(
                '#'), f1.write(Meaning_INFO.M4), f1.write('\n')
            f1.write('bottomM5, topM5=' + str(Thermo_radar_info.bottomM5) + ', ' + str(Thermo_radar_info.topM5)), f1.write(
                '#'), f1.write(Meaning_INFO.M5), f1.write('\n')
            f1.write('bottomM6, topM6=' + str(Thermo_radar_info.bottomM6) + ', ' + str(Thermo_radar_info.topM6)), f1.write(
                '#'), f1.write(Meaning_INFO.M6), f1.write('\n')
            f1.write('bottomM7, topM7=' + str(Thermo_radar_info.bottomM7) + ', ' + str(Thermo_radar_info.topM7)), f1.write(
                '#'), f1.write(Meaning_INFO.M7), f1.write('\n')
            f1.write('bottomM8, topM8=' + str(Thermo_radar_info.bottomM8) + ', ' + str(Thermo_radar_info.topM8)), f1.write(
                '#'), f1.write(Meaning_INFO.M8), f1.write('\n')
            f1.write('bottomM9, topM9=' + str(Thermo_radar_info.bottomM9) + ', ' + str(Thermo_radar_info.topM9)), f1.write(
                '#'), f1.write(Meaning_INFO.M9), f1.write('\n')
            f1.write('bottomM10, topM10=' + str(Thermo_radar_info.bottomM10) + ', ' + str(
                Thermo_radar_info.topM10)), f1.write('#'), f1.write(Meaning_INFO.M10), f1.write('\n')
            f1.write('bottomM11, topM11=' + str(Thermo_radar_info.bottomM11) + ', ' + str(
                Thermo_radar_info.topM11)), f1.write('#'), f1.write(Meaning_INFO.M11), f1.write('\n')
            f1.write('bottomM12, topM12=' + str(Thermo_radar_info.bottomM12) + ', ' + str(
                Thermo_radar_info.topM12)), f1.write('#'), f1.write(Meaning_INFO.M12), f1.write('\n')
            f1.write('bottomM13, topM13=' + str(Thermo_radar_info.bottomM13) + ', ' + str(
                Thermo_radar_info.topM13)), f1.write('#'), f1.write(Meaning_INFO.M13), f1.write('\n')
            f1.write('bottomM14, topM14=' + str(Thermo_radar_info.bottomM14) + ', ' + str(
                Thermo_radar_info.topM14)), f1.write('#'), f1.write(Meaning_INFO.M14), f1.write('\n')
            f1.write('bottomM15, topM15=' + str(Thermo_radar_info.bottomM15) + ', ' + str(
                Thermo_radar_info.topM15)), f1.write('#'), f1.write(Meaning_INFO.M15), f1.write('\n')
            f1.write('bottomM16, topM16=' + str(Thermo_radar_info.bottomM16) + ', ' + str(
                Thermo_radar_info.topM16)), f1.write('#'), f1.write(Meaning_INFO.M16), f1.write('\n')
            f1.write('bottomM17, topM17=' + str(Thermo_radar_info.bottomM17) + ', ' + str(
                Thermo_radar_info.topM17)), f1.write('#'), f1.write(Meaning_INFO.M17), f1.write('\n')
            f1.write('bottomM18, topM18=' + str(Thermo_radar_info.bottomM18) + ', ' + str(
                Thermo_radar_info.topM18)), f1.write('#'), f1.write(Meaning_INFO.M18), f1.write('\n')
            f1.write('bottomM19, topM19=' + str(Thermo_radar_info.bottomM19) + ', ' + str(
                Thermo_radar_info.topM19)), f1.write('#'), f1.write(Meaning_INFO.M19), f1.write('\n')
            f1.write('bottomM20, topM20=' + str(Thermo_radar_info.bottomM20) + ', ' + str(
                Thermo_radar_info.topM20)), f1.write('#'), f1.write(Meaning_INFO.M20), f1.write('\n')

            f1.write('[Identification Result]\n')
            f1.write('bottomID1, topID1=' + str(Thermo_radar_info.bottomID1) + ', ' + str(
                Thermo_radar_info.topID1)), f1.write('#'), f1.write(Meaning_INFO.ID1), f1.write('\n')
            f1.write('bottomID2, topID2=' + str(Thermo_radar_info.bottomID2) + ', ' + str(
                Thermo_radar_info.topID2)), f1.write('#'), f1.write(Meaning_INFO.ID2), f1.write('\n')
            f1.write('bottomID3, topID3=' + str(Thermo_radar_info.bottomID3) + ', ' + str(
                Thermo_radar_info.topID3)), f1.write('#'), f1.write(Meaning_INFO.ID3), f1.write('\n')
            f1.write('bottomID4, topID4=' + str(Thermo_radar_info.bottomID4) + ', ' + str(
                Thermo_radar_info.topID4)), f1.write('#'), f1.write(Meaning_INFO.ID4), f1.write('\n')
            f1.write('bottomID5, topID5=' + str(Thermo_radar_info.bottomID5) + ', ' + str(
                Thermo_radar_info.topID5)), f1.write('#'), f1.write(Meaning_INFO.ID5), f1.write('\n')
            f1.write('bottomID6, topID6=' + str(Thermo_radar_info.bottomID6) + ', ' + str(
                Thermo_radar_info.topID6)), f1.write('#'), f1.write(Meaning_INFO.ID6), f1.write('\n')
            f1.write('bottomID7, topID7=' + str(Thermo_radar_info.bottomID7) + ', ' + str(
                Thermo_radar_info.topID7)), f1.write('#'), f1.write(Meaning_INFO.ID7), f1.write('\n')

        with open("ini/BrukerScore.ini", 'w') as f2:
            f2.write('[Sample Preparation]\n')
            f2.write('bottomS1, topS1=' + str(Bruker_radar_info.bottomS1) + ', ' + str(Bruker_radar_info.topS1)), f2.write(
                '#'), f2.write(Meaning_INFO.S1), f2.write('\n')
            f2.write('bottomS2, topS2=' + str(Bruker_radar_info.bottomS2) + ', ' + str(Bruker_radar_info.topS2)), f2.write(
                '#'), f2.write(Meaning_INFO.S2), f2.write('\n')
            f2.write('bottomS3, topS3=' + str(Bruker_radar_info.bottomS3) + ', ' + str(Bruker_radar_info.topS3)), f2.write(
                '#'), f2.write(Meaning_INFO.S3), f2.write('\n')

            f2.write('[Chromatography]\n')
            f2.write('bottomC1, topC1=' + str(Bruker_radar_info.bottomC1) + ', ' + str(Bruker_radar_info.topC1)), f2.write(
                '#'), f2.write(Meaning_INFO.C1), f2.write('\n')
            f2.write('bottomC2, topC2=' + str(Bruker_radar_info.bottomC2) + ', ' + str(Bruker_radar_info.topC2)), f2.write(
                '#'), f2.write(Meaning_INFO.C2), f2.write('\n')
            f2.write('bottomC3, topC3=' + str(Bruker_radar_info.bottomC3) + ', ' + str(Bruker_radar_info.topC3)), f2.write(
                '#'), f2.write(Meaning_INFO.C3), f2.write('\n')
            f2.write('bottomC4, topC4=' + str(Bruker_radar_info.bottomC4) + ', ' + str(Bruker_radar_info.topC4)), f2.write(
                '#'), f2.write(Meaning_INFO.C4), f2.write('\n')
            f2.write('bottomC5, topC5=' + str(Bruker_radar_info.bottomC5) + ', ' + str(Bruker_radar_info.topC5)), f2.write(
                '#'), f2.write(Meaning_INFO.C5), f2.write('\n')
            f2.write('bottomC6, topC6=' + str(Bruker_radar_info.bottomC6) + ', ' + str(Bruker_radar_info.topC6)), f2.write(
                '#'), f2.write(Meaning_INFO.C6), f2.write('\n')

            f2.write('[DIA Windows]\n')
            f2.write('bottomW1, topW1=' + str(Bruker_radar_info.bottomW1) + ', ' + str(Bruker_radar_info.topW1)), f2.write(
                '#'), f2.write(Meaning_INFO.W1), f2.write('\n')
            f2.write('bottomW2, topW2=' + str(Bruker_radar_info.bottomW2) + ', ' + str(Bruker_radar_info.topW2)), f2.write(
                '#'), f2.write(Meaning_INFO.W2), f2.write('\n')
            f2.write('bottomW3, topW3=' + str(Bruker_radar_info.bottomW3) + ', ' + str(Bruker_radar_info.topW3)), f2.write(
                '#'), f2.write(Meaning_INFO.W3), f2.write('\n')
            f2.write('bottomW4, topW4=' + str(Bruker_radar_info.bottomW4) + ', ' + str(Bruker_radar_info.topW4)), f2.write(
                '#'), f2.write(Meaning_INFO.W4), f2.write('\n')
            f2.write('bottomW5, topW5=' + str(Bruker_radar_info.bottomW5) + ', ' + str(Bruker_radar_info.topW5)), f2.write(
                '#'), f2.write(Meaning_INFO.W5), f2.write('\n')
            f2.write('bottomW6, topW6=' + str(Bruker_radar_info.bottomW6) + ', ' + str(Bruker_radar_info.topW6)), f2.write(
                '#'), f2.write(Meaning_INFO.W6), f2.write('\n')
            f2.write('bottomW7, topW7=' + str(Bruker_radar_info.bottomW7) + ', ' + str(Bruker_radar_info.topW7)), f2.write(
                '#'), f2.write(Meaning_INFO.W7), f2.write('\n')

            f2.write('[Ion Source]\n')
            f2.write('bottomIS1, topIS1=' + str(Bruker_radar_info.bottomIS1) + ', ' + str(Bruker_radar_info.topIS1)), f2.write(
                '#'), f2.write(Meaning_INFO.IS1), f2.write('\n')
            f2.write('bottomIS2, topIS2=' + str(Bruker_radar_info.bottomIS2) + ', ' + str(Bruker_radar_info.topIS2)), f2.write(
                '#'), f2.write(Meaning_INFO.IS2), f2.write('\n')
            f2.write('bottomIS3, topIS3=' + str(Bruker_radar_info.bottomIS3) + ', ' + str(Bruker_radar_info.topIS3)), f2.write(
                '#'), f2.write(Meaning_INFO.IS3), f2.write('\n')
            f2.write('bottomIS4, topIS4=' + str(Bruker_radar_info.bottomIS4) + ', ' + str(Bruker_radar_info.topIS4)), f2.write(
                '#'), f2.write(Meaning_INFO.IS4), f2.write('\n')
            
            

            f2.write('[MS1 and MS2 Signal]\n')
            f2.write('bottomM1, topM1=' + str(Bruker_radar_info.bottomM1) + ', ' + str(Bruker_radar_info.topM1)), f2.write(
                '#'), f2.write(Meaning_INFO.M1), f2.write('\n')
            f2.write('bottomM2, topM2=' + str(Bruker_radar_info.bottomM2) + ', ' + str(Bruker_radar_info.topM2)), f2.write(
                '#'), f2.write(Meaning_INFO.M2), f2.write('\n')
            f2.write('bottomM3, topM3=' + str(Bruker_radar_info.bottomM3) + ', ' + str(Bruker_radar_info.topM3)), f2.write(
                '#'), f2.write(Meaning_INFO.M3), f2.write('\n')
            f2.write('bottomM4, topM4=' + str(Bruker_radar_info.bottomM4) + ', ' + str(Bruker_radar_info.topM4)), f2.write(
                '#'), f2.write(Meaning_INFO.M4), f2.write('\n')
            f2.write('bottomM5, topM5=' + str(Bruker_radar_info.bottomM5) + ', ' + str(Bruker_radar_info.topM5)), f2.write(
                '#'), f2.write(Meaning_INFO.M5), f2.write('\n')
            f2.write('bottomM6, topM6=' + str(Bruker_radar_info.bottomM6) + ', ' + str(Bruker_radar_info.topM6)), f2.write(
                '#'), f2.write(Meaning_INFO.M6), f2.write('\n')
            f2.write('bottomM7, topM7=' + str(Bruker_radar_info.bottomM7) + ', ' + str(Bruker_radar_info.topM7)), f2.write(
                '#'), f2.write(Meaning_INFO.M7), f2.write('\n')
            f2.write('bottomM8, topM8=' + str(Bruker_radar_info.bottomM8) + ', ' + str(Bruker_radar_info.topM8)), f2.write(
                '#'), f2.write(Meaning_INFO.M8), f2.write('\n')
            f2.write('bottomM9, topM9=' + str(Bruker_radar_info.bottomM9) + ', ' + str(Bruker_radar_info.topM9)), f2.write(
                '#'), f2.write(Meaning_INFO.M9), f2.write('\n')
            f2.write('bottomM10, topM10=' + str(Bruker_radar_info.bottomM10) + ', ' + str(
                Bruker_radar_info.topM10)), f2.write('#'), f2.write(Meaning_INFO.M10), f2.write('\n')
            f2.write('bottomM11, topM11=' + str(Bruker_radar_info.bottomM11) + ', ' + str(
                Bruker_radar_info.topM11)), f2.write('#'), f2.write(Meaning_INFO.M11), f2.write('\n')
            f2.write('bottomM12, topM12=' + str(Bruker_radar_info.bottomM12) + ', ' + str(
                Bruker_radar_info.topM12)), f2.write('#'), f2.write(Meaning_INFO.M12), f2.write('\n')
            f2.write('bottomM13, topM13=' + str(Bruker_radar_info.bottomM13) + ', ' + str(
                Bruker_radar_info.topM13)), f2.write('#'), f2.write(Meaning_INFO.M13), f2.write('\n')
            f2.write('bottomM14, topM14=' + str(Bruker_radar_info.bottomM14) + ', ' + str(
                Bruker_radar_info.topM14)), f2.write('#'), f2.write(Meaning_INFO.M14), f2.write('\n')
            f2.write('bottomM15, topM15=' + str(Bruker_radar_info.bottomM15) + ', ' + str(
                Bruker_radar_info.topM15)), f2.write('#'), f2.write(Meaning_INFO.M15), f2.write('\n')
            f2.write('bottomM16, topM16=' + str(Bruker_radar_info.bottomM16) + ', ' + str(
                Bruker_radar_info.topM16)), f2.write('#'), f2.write(Meaning_INFO.M16), f2.write('\n')
            f2.write('bottomM17, topM17=' + str(Bruker_radar_info.bottomM17) + ', ' + str(
                Bruker_radar_info.topM17)), f2.write('#'), f2.write(Meaning_INFO.M17), f2.write('\n')
            f2.write('bottomM18, topM18=' + str(Bruker_radar_info.bottomM18) + ', ' + str(
                Bruker_radar_info.topM18)), f2.write('#'), f2.write(Meaning_INFO.M18), f2.write('\n')
            f2.write('bottomM19, topM19=' + str(Bruker_radar_info.bottomM19) + ', ' + str(
                Bruker_radar_info.topM19)), f2.write('#'), f2.write(Meaning_INFO.M19), f2.write('\n')
            f2.write('bottomM20, topM20=' + str(Bruker_radar_info.bottomM20) + ', ' + str(
                Bruker_radar_info.topM20)), f2.write('#'), f2.write(Meaning_INFO.M20), f2.write('\n')

            f2.write('[Identification Result]\n')
            f2.write('bottomID1, topID1=' + str(Bruker_radar_info.bottomID1) + ', ' + str(
                Bruker_radar_info.topID1)), f2.write('#'), f2.write(Meaning_INFO.ID1), f2.write('\n')
            f2.write('bottomID2, topID2=' + str(Bruker_radar_info.bottomID2) + ', ' + str(
                Bruker_radar_info.topID2)), f2.write('#'), f2.write(Meaning_INFO.ID2), f2.write('\n')
            f2.write('bottomID3, topID3=' + str(Bruker_radar_info.bottomID3) + ', ' + str(
                Bruker_radar_info.topID3)), f2.write('#'), f2.write(Meaning_INFO.ID3), f2.write('\n')
            f2.write('bottomID4, topID4=' + str(Bruker_radar_info.bottomID4) + ', ' + str(
                Bruker_radar_info.topID4)), f2.write('#'), f2.write(Meaning_INFO.ID4), f2.write('\n')
            f2.write('bottomID5, topID5=' + str(Bruker_radar_info.bottomID5) + ', ' + str(
                Bruker_radar_info.topID5)), f2.write('#'), f2.write(Meaning_INFO.ID5), f2.write('\n')
            f2.write('bottomID6, topID6=' + str(Bruker_radar_info.bottomID6) + ', ' + str(
                Bruker_radar_info.topID6)), f2.write('#'), f2.write(Meaning_INFO.ID6), f2.write('\n')
            f2.write('bottomID7, topID7=' + str(Bruker_radar_info.bottomID7) + ', ' + str(
                Bruker_radar_info.topID7)), f2.write('#'), f2.write(Meaning_INFO.ID7), f2.write('\n')

        with open("ini/SCIEXScore.ini", 'w') as f3:
            f3.write('[Sample Preparation]\n')
            f3.write('bottomS1, topS1=' + str(SCIEX_radar_info.bottomS1) + ', ' + str(SCIEX_radar_info.topS1)), f3.write(
                '#'), f3.write(Meaning_INFO.S1), f3.write('\n')
            f3.write('bottomS2, topS2=' + str(SCIEX_radar_info.bottomS2) + ', ' + str(SCIEX_radar_info.topS2)), f3.write(
                '#'), f3.write(Meaning_INFO.S2), f3.write('\n')
            f3.write('bottomS3, topS3=' + str(SCIEX_radar_info.bottomS3) + ', ' + str(SCIEX_radar_info.topS3)), f3.write(
                '#'), f3.write(Meaning_INFO.S3), f3.write('\n')

            f3.write('[Chromatography]\n')
            f3.write('bottomC1, topC1=' + str(SCIEX_radar_info.bottomC1) + ', ' + str(SCIEX_radar_info.topC1)), f3.write(
                '#'), f3.write(Meaning_INFO.C1), f3.write('\n')
            f3.write('bottomC2, topC2=' + str(SCIEX_radar_info.bottomC2) + ', ' + str(SCIEX_radar_info.topC2)), f3.write(
                '#'), f3.write(Meaning_INFO.C2), f3.write('\n')
            f3.write('bottomC3, topC3=' + str(SCIEX_radar_info.bottomC3) + ', ' + str(SCIEX_radar_info.topC3)), f3.write(
                '#'), f3.write(Meaning_INFO.C3), f3.write('\n')
            f3.write('bottomC4, topC4=' + str(SCIEX_radar_info.bottomC4) + ', ' + str(SCIEX_radar_info.topC4)), f3.write(
                '#'), f3.write(Meaning_INFO.C4), f3.write('\n')
            f3.write('bottomC5, topC5=' + str(SCIEX_radar_info.bottomC5) + ', ' + str(SCIEX_radar_info.topC5)), f3.write(
                '#'), f3.write(Meaning_INFO.C5), f3.write('\n')
            f3.write('bottomC6, topC6=' + str(SCIEX_radar_info.bottomC6) + ', ' + str(SCIEX_radar_info.topC6)), f3.write(
                '#'), f3.write(Meaning_INFO.C6), f3.write('\n')

            f3.write('[DIA Windows]\n')
            f3.write('bottomW1, topW1=' + str(SCIEX_radar_info.bottomW1) + ', ' + str(SCIEX_radar_info.topW1)), f3.write(
                '#'), f3.write(Meaning_INFO.W1), f3.write('\n')
            f3.write('bottomW2, topW2=' + str(SCIEX_radar_info.bottomW2) + ', ' + str(SCIEX_radar_info.topW2)), f3.write(
                '#'), f3.write(Meaning_INFO.W2), f3.write('\n')
            f3.write('bottomW3, topW3=' + str(SCIEX_radar_info.bottomW3) + ', ' + str(SCIEX_radar_info.topW3)), f3.write(
                '#'), f3.write(Meaning_INFO.W3), f3.write('\n')
            f3.write('bottomW4, topW4=' + str(SCIEX_radar_info.bottomW4) + ', ' + str(SCIEX_radar_info.topW4)), f3.write(
                '#'), f3.write(Meaning_INFO.W4), f3.write('\n')
            f3.write('bottomW5, topW5=' + str(SCIEX_radar_info.bottomW5) + ', ' + str(SCIEX_radar_info.topW5)), f3.write(
                '#'), f3.write(Meaning_INFO.W5), f3.write('\n')
            f3.write('bottomW6, topW6=' + str(SCIEX_radar_info.bottomW6) + ', ' + str(SCIEX_radar_info.topW6)), f3.write(
                '#'), f3.write(Meaning_INFO.W6), f3.write('\n')
            f3.write('bottomW7, topW7=' + str(SCIEX_radar_info.bottomW7) + ', ' + str(SCIEX_radar_info.topW7)), f3.write(
                '#'), f3.write(Meaning_INFO.W7), f3.write('\n')

            f3.write('[Ion Source]\n')
            f3.write('bottomIS1, topIS1=' + str(SCIEX_radar_info.bottomIS1) + ', ' + str(SCIEX_radar_info.topIS1)), f3.write(
                '#'), f3.write(Meaning_INFO.IS1), f3.write('\n')
            f3.write('bottomIS2, topIS2=' + str(SCIEX_radar_info.bottomIS2) + ', ' + str(SCIEX_radar_info.topIS2)), f3.write(
                '#'), f3.write(Meaning_INFO.IS2), f3.write('\n')
            f3.write('bottomIS3, topIS3=' + str(SCIEX_radar_info.bottomIS3) + ', ' + str(SCIEX_radar_info.topIS3)), f3.write(
                '#'), f3.write(Meaning_INFO.IS3), f3.write('\n')
            f3.write('bottomIS4, topIS4=' + str(SCIEX_radar_info.bottomIS4) + ', ' + str(SCIEX_radar_info.topIS4)), f3.write(
                '#'), f3.write(Meaning_INFO.IS4), f3.write('\n')
            
            

            f3.write('[MS1 and MS2 Signal]\n')
            f3.write('bottomM1, topM1=' + str(SCIEX_radar_info.bottomM1) + ', ' + str(SCIEX_radar_info.topM1)), f3.write(
                '#'), f3.write(Meaning_INFO.M1), f3.write('\n')
            f3.write('bottomM2, topM2=' + str(SCIEX_radar_info.bottomM2) + ', ' + str(SCIEX_radar_info.topM2)), f3.write(
                '#'), f3.write(Meaning_INFO.M2), f3.write('\n')
            f3.write('bottomM3, topM3=' + str(SCIEX_radar_info.bottomM3) + ', ' + str(SCIEX_radar_info.topM3)), f3.write(
                '#'), f3.write(Meaning_INFO.M3), f3.write('\n')
            f3.write('bottomM4, topM4=' + str(SCIEX_radar_info.bottomM4) + ', ' + str(SCIEX_radar_info.topM4)), f3.write(
                '#'), f3.write(Meaning_INFO.M4), f3.write('\n')
            f3.write('bottomM5, topM5=' + str(SCIEX_radar_info.bottomM5) + ', ' + str(SCIEX_radar_info.topM5)), f3.write(
                '#'), f3.write(Meaning_INFO.M5), f3.write('\n')
            f3.write('bottomM6, topM6=' + str(SCIEX_radar_info.bottomM6) + ', ' + str(SCIEX_radar_info.topM6)), f3.write(
                '#'), f3.write(Meaning_INFO.M6), f3.write('\n')
            f3.write('bottomM7, topM7=' + str(SCIEX_radar_info.bottomM7) + ', ' + str(SCIEX_radar_info.topM7)), f3.write(
                '#'), f3.write(Meaning_INFO.M7), f3.write('\n')
            f3.write('bottomM8, topM8=' + str(SCIEX_radar_info.bottomM8) + ', ' + str(SCIEX_radar_info.topM8)), f3.write(
                '#'), f3.write(Meaning_INFO.M8), f3.write('\n')
            f3.write('bottomM9, topM9=' + str(SCIEX_radar_info.bottomM9) + ', ' + str(SCIEX_radar_info.topM9)), f3.write(
                '#'), f3.write(Meaning_INFO.M9), f3.write('\n')
            f3.write('bottomM10, topM10=' + str(SCIEX_radar_info.bottomM10) + ', ' + str(
                SCIEX_radar_info.topM10)), f3.write('#'), f3.write(Meaning_INFO.M10), f3.write('\n')
            f3.write('bottomM11, topM11=' + str(SCIEX_radar_info.bottomM11) + ', ' + str(
                SCIEX_radar_info.topM11)), f3.write('#'), f3.write(Meaning_INFO.M11), f3.write('\n')
            f3.write('bottomM12, topM12=' + str(SCIEX_radar_info.bottomM12) + ', ' + str(
                SCIEX_radar_info.topM12)), f3.write('#'), f3.write(Meaning_INFO.M12), f3.write('\n')
            f3.write('bottomM13, topM13=' + str(SCIEX_radar_info.bottomM13) + ', ' + str(
                SCIEX_radar_info.topM13)), f3.write('#'), f3.write(Meaning_INFO.M13), f3.write('\n')
            f3.write('bottomM14, topM14=' + str(SCIEX_radar_info.bottomM14) + ', ' + str(
                SCIEX_radar_info.topM14)), f3.write('#'), f3.write(Meaning_INFO.M14), f3.write('\n')
            f3.write('bottomM15, topM15=' + str(SCIEX_radar_info.bottomM15) + ', ' + str(
                SCIEX_radar_info.topM15)), f3.write('#'), f3.write(Meaning_INFO.M15), f3.write('\n')
            f3.write('bottomM16, topM16=' + str(SCIEX_radar_info.bottomM16) + ', ' + str(
                SCIEX_radar_info.topM16)), f3.write('#'), f3.write(Meaning_INFO.M16), f3.write('\n')
            f3.write('bottomM17, topM17=' + str(SCIEX_radar_info.bottomM17) + ', ' + str(
                SCIEX_radar_info.topM17)), f3.write('#'), f3.write(Meaning_INFO.M17), f3.write('\n')
            f3.write('bottomM18, topM18=' + str(SCIEX_radar_info.bottomM18) + ', ' + str(
                SCIEX_radar_info.topM18)), f3.write('#'), f3.write(Meaning_INFO.M18), f3.write('\n')
            f3.write('bottomM19, topM19=' + str(SCIEX_radar_info.bottomM19) + ', ' + str(
                SCIEX_radar_info.topM19)), f3.write('#'), f3.write(Meaning_INFO.M19), f3.write('\n')
            f3.write('bottomM20, topM20=' + str(SCIEX_radar_info.bottomM20) + ', ' + str(
                SCIEX_radar_info.topM20)), f3.write('#'), f3.write(Meaning_INFO.M20), f3.write('\n')

            f3.write('[Identification Result]\n')
            f3.write('bottomID1, topID1=' + str(SCIEX_radar_info.bottomID1) + ', ' + str(
                SCIEX_radar_info.topID1)), f3.write('#'), f3.write(Meaning_INFO.ID1), f3.write('\n')
            f3.write('bottomID2, topID2=' + str(SCIEX_radar_info.bottomID2) + ', ' + str(
                SCIEX_radar_info.topID2)), f3.write('#'), f3.write(Meaning_INFO.ID2), f3.write('\n')
            f3.write('bottomID3, topID3=' + str(SCIEX_radar_info.bottomID3) + ', ' + str(
                SCIEX_radar_info.topID3)), f3.write('#'), f3.write(Meaning_INFO.ID3), f3.write('\n')
            f3.write('bottomID4, topID4=' + str(SCIEX_radar_info.bottomID4) + ', ' + str(
                SCIEX_radar_info.topID4)), f3.write('#'), f3.write(Meaning_INFO.ID4), f3.write('\n')
            f3.write('bottomID5, topID5=' + str(SCIEX_radar_info.bottomID5) + ', ' + str(
                SCIEX_radar_info.topID5)), f3.write('#'), f3.write(Meaning_INFO.ID5), f3.write('\n')
            f3.write('bottomID6, topID6=' + str(SCIEX_radar_info.bottomID6) + ', ' + str(
                SCIEX_radar_info.topID6)), f3.write('#'), f3.write(Meaning_INFO.ID6), f3.write('\n')
            f3.write('bottomID7, topID7=' + str(SCIEX_radar_info.bottomID7) + ', ' + str(
                SCIEX_radar_info.topID7)), f3.write('#'), f3.write(Meaning_INFO.ID7), f3.write('\n')

    def file2config(self, path, config):

        with open(path, 'r') as f:

            for line in f.readlines():
                if line.startswith("#") or line.startswith("["):
                    continue

                p_EqualSign = line.find('=')

                if -1 == p_EqualSign:
                    pass
                else:
                    subLine = line.split(';')[0]  
                    self.__soldierParseLine(line, config)

        with open("ini/ThermoScore.ini", 'r') as f1:

            for line in f1.readlines():

                p_EqualSign = line.find('=')

                if -1 == p_EqualSign:
                    pass
                else:
                    self.__soldierThermoRadarInfo(line, config)

        with open("ini/BrukerScore.ini", 'r') as f2:

            for line in f2.readlines():

                p_EqualSign = line.find('=')

                if -1 == p_EqualSign:
                    pass
                else:
                    self.__soldierBrukerRadarInfo(line, config)

        with open("ini/SCIEXScore.ini", 'r') as f2:

            for line in f2.readlines():

                p_EqualSign = line.find('=')

                if -1 == p_EqualSign:
                    pass
                else:
                    self.__soldierSCIEXRadarInfo(line, config)

    def __soldierParseLine(self, line, cfg):

        if line.startswith("#"):
            pass
        else:

            str_name = toolGetWord(line, 0, '=')
            var_str_47 = toolGetWord(line, 1, '=').replace("\n", "")

            if "TYPE_DATA" == str_name:
                cfg.A1_TYPE_DATA = int(var_str_47)
            elif "PATH_RAW" == str_name:
                cfg.A0_PATH_RAW = var_str_47
                

            elif "PATH_RESULT" == str_name:
                cfg.B2_PATH_IDENTIFICATION_RESULT = var_str_47
            elif "TYPE_RESULT" == str_name:
                cfg.B3_TYPE_IDENTIFICATION_RESULT = int(var_str_47)
            elif "THRESHOLD_FDR" == str_name:
                cfg.B4_THRESHOLD_FDR = float(var_str_47)

            elif "THRESHOLD_PEAK_WIDTH_TAILING" == str_name:
                cfg.C5_THRESHOLD_PEAK_WIDTH_TAILING = int(var_str_47)

            elif "THRESHOLD_INVALID_ACQUIRING_SCAN" == str_name:
                cfg.C6_THRESHOLD_INVALID_ACQUIRING_SCAN = int(var_str_47)

            elif "FLAG_ANALYZE_FEATURE" == str_name:
                cfg.E3_FLAG_ANALYZE_FEATURE = int(var_str_47)

            elif "PATH_EXPORT" == str_name:      
                cfg.E1_PATH_EXPORT = var_str_47
                raw_file = cfg.A0_PATH_RAW.split('\\')[-1]
                raw_name = raw_file.split('.')[0]
                cfg.E1_PATH_EXPORT = cfg.E1_PATH_EXPORT + 'MSCohort_' + raw_name + '\\'
                if os.access(cfg.E1_PATH_EXPORT, os.F_OK):
                    pass
                else:
                    os.makedirs(cfg.E1_PATH_EXPORT)

            else:

                info = str_name + " in the config file is all right?"
                logGetWarning(info)

    def __soldierThermoRadarInfo(self, line, cfg):

        if line.startswith("["):
            pass
        else:
            content = toolGetWord(line, 0, '#')
            str_name = toolGetWord(content, 0, '=')
            var_str_47 = toolGetWord(content, 1, '=').replace("\n", "")
            var_str_47 = var_str_47.replace(" ", "")

            if "bottomS1, topS1" == str_name:

                Thermo_radar_info.bottomS1 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topS1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomS2, topS2" == str_name:

                Thermo_radar_info.bottomS2 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topS2 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomS3, topS3" == str_name:

                Thermo_radar_info.bottomS3 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topS3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC1, topC1" == str_name:

                Thermo_radar_info.bottomC1 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topC1 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomC2, topC2" == str_name:

                Thermo_radar_info.bottomC2 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topC2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC3, topC3" == str_name:

                Thermo_radar_info.bottomC3 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topC3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC4, topC4" == str_name:

                Thermo_radar_info.bottomC4 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topC4 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC5, topC5" == str_name:

                Thermo_radar_info.bottomC5 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topC5 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomC6, topC6" == str_name:

                Thermo_radar_info.bottomC6 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topC6 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW1, topW1" == str_name:

                Thermo_radar_info.bottomW1 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topW1 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomW2, topW2" == str_name:

                Thermo_radar_info.bottomW2 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topW2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW3, topW3" == str_name:

                Thermo_radar_info.bottomW3 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topW3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW4, topW4" == str_name:

                Thermo_radar_info.bottomW4 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topW4 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW5, topW5" == str_name:

                Thermo_radar_info.bottomW5 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topW5 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW6, topW6" == str_name:

                Thermo_radar_info.bottomW6 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topW6 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomW7, topW7" == str_name:

                Thermo_radar_info.bottomW7 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topW7 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS1, topIS1" == str_name:

                Thermo_radar_info.bottomIS1 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topIS1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS2, topIS2" == str_name:

                Thermo_radar_info.bottomIS2 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topIS2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS3, topIS3" == str_name:

                Thermo_radar_info.bottomIS3 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topIS3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS4, topIS4" == str_name:

                Thermo_radar_info.bottomIS4 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topIS4 = float(toolGetWord(var_str_47, 1, ','))

            
            
            
            

            elif "bottomM1, topM1" == str_name:

                Thermo_radar_info.bottomM1 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM2, topM2" == str_name:

                Thermo_radar_info.bottomM2 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM3, topM3" == str_name:

                Thermo_radar_info.bottomM3 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM4, topM4" == str_name:

                Thermo_radar_info.bottomM4 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM4 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM5, topM5" == str_name:

                Thermo_radar_info.bottomM5 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM5 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM6, topM6" == str_name:

                Thermo_radar_info.bottomM6 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM6 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM7, topM7" == str_name:

                Thermo_radar_info.bottomM7 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM7 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM8, topM8" == str_name:

                Thermo_radar_info.bottomM8 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM8 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM9, topM9" == str_name:

                Thermo_radar_info.bottomM9 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM9 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM10, topM10" == str_name:

                Thermo_radar_info.bottomM10 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM10 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM11, topM11" == str_name:

                Thermo_radar_info.bottomM11 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM11 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM12, topM12" == str_name:

                Thermo_radar_info.bottomM12 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM12 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM13, topM13" == str_name:

                Thermo_radar_info.bottomM13 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM13 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM14, topM14" == str_name:

                Thermo_radar_info.bottomM14 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM14 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM15, topM15" == str_name:

                Thermo_radar_info.bottomM15 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM15 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM16, topM16" == str_name:

                Thermo_radar_info.bottomM16 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM16 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM17, topM17" == str_name:

                Thermo_radar_info.bottomM17 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM17 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM18, topM18" == str_name:

                Thermo_radar_info.bottomM18 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM18 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM19, topM19" == str_name:

                Thermo_radar_info.bottomM19 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM19 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM20, topM20" == str_name:

                Thermo_radar_info.bottomM20 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topM20 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomID1, topID1" == str_name:

                Thermo_radar_info.bottomID1 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topID1 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID2, topID2" == str_name:

                Thermo_radar_info.bottomID2 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topID2 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID3, topID3" == str_name:

                Thermo_radar_info.bottomID3 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topID3 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID4, topID4" == str_name:

                Thermo_radar_info.bottomID4 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topID4 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID5, topID5" == str_name:

                Thermo_radar_info.bottomID5 = int(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topID5 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID6, topID6" == str_name:

                Thermo_radar_info.bottomID6 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topID6 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomID7, topID7" == str_name:

                Thermo_radar_info.bottomID7 = float(toolGetWord(var_str_47, 0, ','))
                Thermo_radar_info.topID7 = float(toolGetWord(var_str_47, 1, ','))

            else:

                info = str_name + " in the ini file is all right?"
                logGetWarning(info)


    def __soldierBrukerRadarInfo(self, line, cfg):

        if line.startswith("["):
            pass
        else:
            content = toolGetWord(line, 0, '#')
            str_name = toolGetWord(content, 0, '=')
            var_str_47 = toolGetWord(content, 1, '=').replace("\n", "")
            var_str_47 = var_str_47.replace(" ", "")

            if "bottomS1, topS1" == str_name:

                Bruker_radar_info.bottomS1 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topS1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomS2, topS2" == str_name:

                Bruker_radar_info.bottomS2 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topS2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomS3, topS3" == str_name:

                Bruker_radar_info.bottomS3 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topS3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC1, topC1" == str_name:

                Bruker_radar_info.bottomC1 = int(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topC1 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomC2, topC2" == str_name:

                Bruker_radar_info.bottomC2 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topC2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC3, topC3" == str_name:

                Bruker_radar_info.bottomC3 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topC3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC4, topC4" == str_name:

                Bruker_radar_info.bottomC4 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topC4 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC5, topC5" == str_name:

                Bruker_radar_info.bottomC5 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topC5 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC6, topC6" == str_name:

                Bruker_radar_info.bottomC6 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topC6 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW1, topW1" == str_name:

                Bruker_radar_info.bottomW1 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topW1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW2, topW2" == str_name:

                Bruker_radar_info.bottomW2 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topW2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW3, topW3" == str_name:

                Bruker_radar_info.bottomW3 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topW3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW4, topW4" == str_name:

                Bruker_radar_info.bottomW4 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topW4 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW5, topW5" == str_name:

                Bruker_radar_info.bottomW5 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topW5 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW6, topW6" == str_name:

                Bruker_radar_info.bottomW6 = int(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topW6 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomW7, topW7" == str_name:

                Bruker_radar_info.bottomW7 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topW7 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS1, topIS1" == str_name:

                Bruker_radar_info.bottomIS1 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topIS1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS2, topIS2" == str_name:

                Bruker_radar_info.bottomIS2 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topIS2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS3, topIS3" == str_name:

                Bruker_radar_info.bottomIS3 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topIS3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS4, topIS4" == str_name:

                Bruker_radar_info.bottomIS4 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topIS4 = float(toolGetWord(var_str_47, 1, ','))

            
            
            
            

            elif "bottomM1, topM1" == str_name:

                Bruker_radar_info.bottomM1 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM2, topM2" == str_name:

                Bruker_radar_info.bottomM2 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM3, topM3" == str_name:

                Bruker_radar_info.bottomM3 = int(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM3 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomM4, topM4" == str_name:

                Bruker_radar_info.bottomM4 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM4 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM5, topM5" == str_name:

                Bruker_radar_info.bottomM5 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM5 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM6, topM6" == str_name:

                Bruker_radar_info.bottomM6 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM6 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM7, topM7" == str_name:

                Bruker_radar_info.bottomM7 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM7 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM8, topM8" == str_name:

                Bruker_radar_info.bottomM8 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM8 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM9, topM9" == str_name:

                Bruker_radar_info.bottomM9 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM9 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM10, topM10" == str_name:

                Bruker_radar_info.bottomM10 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM10 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM11, topM11" == str_name:

                Bruker_radar_info.bottomM11 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM11 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM12, topM12" == str_name:

                Bruker_radar_info.bottomM12 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM12 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM13, topM13" == str_name:

                Bruker_radar_info.bottomM13 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM13 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM14, topM14" == str_name:

                Bruker_radar_info.bottomM14 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM14 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM15, topM15" == str_name:

                Bruker_radar_info.bottomM15 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM15 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM16, topM16" == str_name:

                Bruker_radar_info.bottomM16 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM16 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM17, topM17" == str_name:

                Bruker_radar_info.bottomM17 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM17 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM18, topM18" == str_name:

                Bruker_radar_info.bottomM18 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM18 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM19, topM19" == str_name:

                Bruker_radar_info.bottomM19 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM19 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM20, topM20" == str_name:

                Bruker_radar_info.bottomM20 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topM20 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomID1, topID1" == str_name:

                Bruker_radar_info.bottomID1 = int(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topID1 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID2, topID2" == str_name:

                Bruker_radar_info.bottomID2 = int(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topID2 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID3, topID3" == str_name:

                Bruker_radar_info.bottomID3 = int(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topID3 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID4, topID4" == str_name:

                Bruker_radar_info.bottomID4 = int(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topID4 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID5, topID5" == str_name:

                Bruker_radar_info.bottomID5 = int(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topID5 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID6, topID6" == str_name:

                Bruker_radar_info.bottomID6 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topID6 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomID7, topID7" == str_name:

                Bruker_radar_info.bottomID7 = float(toolGetWord(var_str_47, 0, ','))
                Bruker_radar_info.topID7 = float(toolGetWord(var_str_47, 1, ','))

            else:

                info = str_name + " in the ini file is all right?"
                logGetWarning(info)


    def __soldierSCIEXRadarInfo(self, line, cfg):

        if line.startswith("["):
            pass
        else:
            content = toolGetWord(line, 0, '#')
            str_name = toolGetWord(content, 0, '=')
            var_str_47 = toolGetWord(content, 1, '=').replace("\n", "")
            var_str_47 = var_str_47.replace(" ", "")

            if "bottomS1, topS1" == str_name:

                SCIEX_radar_info.bottomS1 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topS1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomS2, topS2" == str_name:

                SCIEX_radar_info.bottomS2 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topS2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomS3, topS3" == str_name:

                SCIEX_radar_info.bottomS3 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topS3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC1, topC1" == str_name:

                SCIEX_radar_info.bottomC1 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topC1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC2, topC2" == str_name:

                SCIEX_radar_info.bottomC2 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topC2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC3, topC3" == str_name:

                SCIEX_radar_info.bottomC3 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topC3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC4, topC4" == str_name:

                SCIEX_radar_info.bottomC4 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topC4 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC5, topC5" == str_name:

                SCIEX_radar_info.bottomC5 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topC5 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomC6, topC6" == str_name:

                SCIEX_radar_info.bottomC6 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topC6 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW1, topW1" == str_name:

                SCIEX_radar_info.bottomW1 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topW1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW2, topW2" == str_name:

                SCIEX_radar_info.bottomW2 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topW2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW3, topW3" == str_name:

                SCIEX_radar_info.bottomW3 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topW3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW4, topW4" == str_name:

                SCIEX_radar_info.bottomW4 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topW4 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW5, topW5" == str_name:

                SCIEX_radar_info.bottomW5 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topW5 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomW6, topW6" == str_name:

                SCIEX_radar_info.bottomW6 = int(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topW6 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomW7, topW7" == str_name:

                SCIEX_radar_info.bottomW7 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topW7 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS1, topIS1" == str_name:

                SCIEX_radar_info.bottomIS1 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topIS1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS2, topIS2" == str_name:

                SCIEX_radar_info.bottomIS2 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topIS2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS3, topIS3" == str_name:

                SCIEX_radar_info.bottomIS3 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topIS3 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomIS4, topIS4" == str_name:

                SCIEX_radar_info.bottomIS4 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topIS4 = float(toolGetWord(var_str_47, 1, ','))

            
            
            
            

            elif "bottomM1, topM1" == str_name:

                SCIEX_radar_info.bottomM1 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM1 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM2, topM2" == str_name:

                SCIEX_radar_info.bottomM2 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM2 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM3, topM3" == str_name:

                SCIEX_radar_info.bottomM3 = int(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM3 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomM4, topM4" == str_name:

                SCIEX_radar_info.bottomM4 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM4 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM5, topM5" == str_name:

                SCIEX_radar_info.bottomM5 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM5 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM6, topM6" == str_name:

                SCIEX_radar_info.bottomM6 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM6 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM7, topM7" == str_name:

                SCIEX_radar_info.bottomM7 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM7 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM8, topM8" == str_name:

                SCIEX_radar_info.bottomM8 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM8 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM9, topM9" == str_name:

                SCIEX_radar_info.bottomM9 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM9 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM10, topM10" == str_name:

                SCIEX_radar_info.bottomM10 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM10 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM11, topM11" == str_name:

                SCIEX_radar_info.bottomM11 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM11 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM12, topM12" == str_name:

                SCIEX_radar_info.bottomM12 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM12 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM13, topM13" == str_name:

                SCIEX_radar_info.bottomM13 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM13 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM14, topM14" == str_name:

                SCIEX_radar_info.bottomM14 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM14 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM15, topM15" == str_name:

                SCIEX_radar_info.bottomM15 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM15 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM16, topM16" == str_name:

                SCIEX_radar_info.bottomM16 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM16 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM17, topM17" == str_name:

                SCIEX_radar_info.bottomM17 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM17 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM18, topM18" == str_name:

                SCIEX_radar_info.bottomM18 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM18 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM19, topM19" == str_name:

                SCIEX_radar_info.bottomM19 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM19 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomM20, topM20" == str_name:

                SCIEX_radar_info.bottomM20 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topM20 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomID1, topID1" == str_name:

                SCIEX_radar_info.bottomID1 = int(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topID1 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID2, topID2" == str_name:

                SCIEX_radar_info.bottomID2 = int(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topID2 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID3, topID3" == str_name:

                SCIEX_radar_info.bottomID3 = int(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topID3 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID4, topID4" == str_name:

                SCIEX_radar_info.bottomID4 = int(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topID4 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID5, topID5" == str_name:

                SCIEX_radar_info.bottomID5 = int(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topID5 = int(toolGetWord(var_str_47, 1, ','))

            elif "bottomID6, topID6" == str_name:

                SCIEX_radar_info.bottomID6 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topID6 = float(toolGetWord(var_str_47, 1, ','))

            elif "bottomID7, topID7" == str_name:

                SCIEX_radar_info.bottomID7 = float(toolGetWord(var_str_47, 0, ','))
                SCIEX_radar_info.topID7 = float(toolGetWord(var_str_47, 1, ','))

            else:

                info = str_name + " in the ini file is all right?"
                logGetWarning(info)


class CFunctionRaw2M_13:

    def __init__(self, inputDP):

        self.dp = inputDP

    def var_sol_44(self, number, length):

        var_str_29 = str(number).split('.')[1]
        if len(var_str_29) == length + 1 and var_str_29[length] == '5':

            return '{:.{:d}f}'.format(number + 0.1 ** (length + 1), length)

        else:
            return '{:.{:d}f}'.format(number, length)

    def __captainWriteMS1ForScanNum(self, file, scanNum: int, rawFile: RawFileReader, ZfillNum: int):

        Zfill_scanNum = str(scanNum).zfill(ZfillNum)
        list_moz, list_int = rawFile.GetCentroidMassListFromScanNum(scanNum)
        retTime = rawFile.RTInSecondsFromScanNum(scanNum)
        dict_TrailerExtra = rawFile.GetTrailerExtraForScanNum(scanNum)
        injectionTime = dict_TrailerExtra['Ion Injection Time (ms):']
        instrumentType = rawFile.GetScanEventStringForScanNum(scanNum)
        var_lis_41 = rawFile.GetCentroidMassListFromScanNumForStr(scanNum)

        var_inf_40 = '\n'.join([
            '\t'.join(['S', Zfill_scanNum, Zfill_scanNum]),
            '\t'.join(['I', 'NumberOfPeaks', str(len(list_moz))]),
            '\t'.join(['I', 'RetTime', self.var_sol_44(retTime, 6)]),
            '\t'.join(['I', 'IonInjectionTime', injectionTime]),
            '\t'.join(['I', 'InstrumentType', instrumentType])
        ]) + '\n'

        var_inf_37 = '\n'.join([self.var_sol_44(var_lis_41[0][i], 5) + ' ' +
                                  self.var_sol_44(var_lis_41[1][i], 1) for i in range(len(var_lis_41[0]))]) + '\n'

        file.write(var_inf_40 + var_inf_37)

    def __captainWriteMS2ForScanNum(self, file, scanNum: int, rawFile: RawFileReader, ZfillNum: int, ms1Scan: int):

        Zfill_scanNum = str(scanNum).zfill(ZfillNum)
        list_moz, list_int = rawFile.GetCentroidMassListFromScanNum(scanNum)
        retTime = rawFile.RTInSecondsFromScanNum(scanNum)
        dict_TrailerExtra = rawFile.GetTrailerExtraForScanNum(scanNum)
        injectionTime = dict_TrailerExtra['Ion Injection Time (ms):']
        activationType = rawFile.GetActivationTypeForScanNum(scanNum)
        instrumentType = rawFile.GetScanEventStringForScanNum(scanNum)
        activationCenter = float(instrumentType[instrumentType.index('ms2') + 3: instrumentType.index('@')])
        isolationwidth = rawFile.GetIsolationWidthForScanNum(scanNum)

        charge = int(dict_TrailerExtra['Charge State:'])
        Mono_moz = float(dict_TrailerExtra['Monoisotopic M/Z:'])
        
        if Mono_moz < 1:
            Mono_moz = ''
            precursor_MH = ''
        else:
            precursor_MH = Mono_moz * charge - (charge - 1) * 1.00727645224
            precursor_MH = self.var_sol_44(precursor_MH, 7)
        var_lis_41 = rawFile.GetCentroidMassListFromScanNumForStr(scanNum)

        var_inf_40 = '\n'.join([
            '\t'.join(['S', Zfill_scanNum, Zfill_scanNum, str(Mono_moz)]),
            '\t'.join(['I', 'NumberOfPeaks', str(len(list_moz))]),
            '\t'.join(['I', 'RetTime', self.var_sol_44(retTime, 6)]),
            '\t'.join(['I', 'IonInjectionTime', injectionTime]),
            '\t'.join(['I', 'ActivationType', activationType]),
            '\t'.join(['I', 'InstrumentType', instrumentType]),
            '\t'.join(['I', 'PrecursorScan', str(ms1Scan)]),
            '\t'.join(['I', 'ActivationCenter', self.var_sol_44(activationCenter, 2)]),
            '\t'.join(['I', 'IsolationWidth', str(isolationwidth)]),
            '\t'.join(['I', 'MonoiosotopicMz', str(Mono_moz)]),
            '\t'.join(['Z', str(charge), precursor_MH])
        ]) + '\n'

        var_inf_37 = '\n'.join([self.var_sol_44(var_lis_41[0][i], 5) + ' ' +
                                  self.var_sol_44(var_lis_41[1][i], 1) for i in range(len(var_lis_41[0]))]) + '\n'

        file.write(var_inf_40 + var_inf_37)

    def __captainCalDate(self, data_C_Format):

        
        
        
        
        data_C_Format = data_C_Format - 25569  
        data_C_Format_second = data_C_Format * 24 * 3600  
        date = gmtime(data_C_Format_second)
        date = strftime("%Y-%m-%d %X", date)
        return date

    def Raw2MS(self, pathRaw):

        nameRaw = path.basename(pathRaw).split('.')[0]
        pathOut = path.dirname(pathRaw)

        pathMS1 = path.join(pathOut, nameRaw + IO_NAME_FILE_EXPORT[0])

        pathMS2 = path.join(pathOut, nameRaw + IO_NAME_FILE_EXPORT[1])

        rawFile = RawFileReader(pathRaw)
        FirstSpectrumNo = rawFile.FirstSpectrumNumber  
        LastSpectrumNo = rawFile.LastSpectrumNumber  
        Zfill_Num = 6 if LastSpectrumNo < 1e6 else len(str(LastSpectrumNo))

        
        ListScanNum = list(range(FirstSpectrumNo, LastSpectrumNo + 1))
        ListOrderForSpectrum = [rawFile.GetMSOrderForScanNum(i) for i in ListScanNum]

        
        f_ms1 = open(pathMS1, 'w')
        f_ms2 = open(pathMS2, 'w')
        date_C_Format = rawFile.GetCreationDate()
        date_out = self.__captainCalDate(date_C_Format)

        f_ms1.write('H' + '\t' + 'CreationDate' + '\t' + date_out + '\n')
        f_ms1.write('H' + '\t' + 'Extractor' + '\t' + 'MSExport' + '\n')
        f_ms1.write('H' + '\t' + 'Comments' + '\t' + rawFile.GetComment1() + '\n')
        f_ms2.write('H' + '\t' + 'CreationDate' + '\t' + date_out + '\n')
        f_ms2.write('H' + '\t' + 'Extractor' + '\t' + 'MSExport' + '\n')
        f_ms2.write('H' + '\t' + 'Comments' + '\t' + rawFile.GetComment1() + '\n')
        
        var_tmp_50 = FirstSpectrumNo
        countScan = 0
        countAll = LastSpectrumNo - FirstSpectrumNo + 1
        count_MS1 = 0
        count_MS2 = 0

        for scan, order in zip(ListScanNum, ListOrderForSpectrum):

            if order == 1:  

                var_tmp_50 = scan
                self.__captainWriteMS1ForScanNum(f_ms1, scan, rawFile, Zfill_Num)
                count_MS1 += 1

            elif order == 2:  

                self.__captainWriteMS2ForScanNum(f_ms2, scan, rawFile, Zfill_Num, var_tmp_50)
                count_MS2 += 1

            else:  

                pass
            countScan = countScan + 1
            if countScan % 1000 == 1:
                logToUser('%.3f%%' % (countScan / countAll * 100))

            if countScan == countAll:
                logToUser('%.1f%%' % (countScan / countAll * 100))

        
        f_ms1.close()
        f_ms2.close()

        return count_MS1, count_MS2


class CFunctionParse_4:

    def __init__(self, inputDP):
        self.dp = inputDP

    def ms1TOpkl(self, pathMS1):

        
        path_pkl = pathMS1 + ".pkl"
        if os.access(path_pkl, os.F_OK):
            pass
        else:

            
            dataMS1 = self.dp.myMS1
            op_INIT_CFILE_MS1(dataMS1)

            
            with open(pathMS1, 'r') as f:

                i_MS1 = -1

                for line in f.readlines():

                    len_line = len(line)
                    if len_line > 1:

                        if line.startswith("S	"):
                            i_MS1 = i_MS1 + 1
                            tmpScan = int(toolGetWord(line, 1, '	'))
                            dataMS1.INDEX_SCAN.append(tmpScan)

                            dataMS1.MATRIX_PEAK_MOZ[tmpScan] = []  
                            dataMS1.MATRIX_PEAK_INT[tmpScan] = []
                            dataMS1.MATRIX_PEAK_MARK[tmpScan] = []

                            if i_MS1 % 3000 == 1:
                                print(INFO_TO_USER_MSFunction[1] + str(i_MS1))

                        elif line.startswith("H	"):
                            pass
                        elif line.startswith("I	"):
                            if line.startswith("I	IonInjectionTime"):
                                t = toolGetWord(line, 2, '	')
                                dataMS1.LIST_ION_INJECTION_TIME[tmpScan] = float(t)
                            elif line.startswith("I	RetTime	"):
                                t = toolGetWord(line, 2, '	')
                                dataMS1.LIST_RET_TIME[tmpScan] = float(t)
                                dataMS1.INDEX_RT.append(float(t))
                        else:
                            if '\t' in line:
                                dataMS1.MATRIX_PEAK_MOZ[tmpScan].append(float(line.split('\t')[0]))
                                dataMS1.MATRIX_PEAK_INT[tmpScan].append(float(line.split('\t')[1]))
                                dataMS1.MATRIX_PEAK_MARK[tmpScan].append(float(-1.0))
                            else:
                                dataMS1.MATRIX_PEAK_MOZ[tmpScan].append(float(toolGetWord(line, 0, ' ')))
                                dataMS1.MATRIX_PEAK_INT[tmpScan].append(float(toolGetWord(line, 1, ' ')))
                                dataMS1.MATRIX_PEAK_MARK[tmpScan].append(float(-1.0))

            
            fid_pkl = open(path_pkl, 'wb')
            pickle.dump(dataMS1, fid_pkl)
            fid_pkl.close()


class CFuntionParseMS2:

    def __init__(self, inputDP):
        self.dp = inputDP

    def ms2TOpkl(self, pathMS2):

        
        path_pkl = pathMS2 + ".pkl"
        if os.access(path_pkl, os.F_OK):
            pass
        else:

            
            dataMS2 = self.dp.myMS2
            op_INIT_CFILE_MS2(dataMS2)

            
            with open(pathMS2, 'r', encoding='utf8') as f:

                i_MS2 = -1

                for line in f.readlines():

                    len_line = len(line)
                    if len_line > 1:

                        if line.startswith("S	"):
                            i_MS2 = i_MS2 + 1
                            tmpScan = int(toolGetWord(line, 1, '	'))
                            dataMS2.INDEX_SCAN.append(tmpScan)

                            if i_MS2 % 3000 == 1:
                                print(INFO_TO_USER_MSFunction[2] + str(i_MS2))

                            dataMS2.MATRIX_PEAK_MOZ[tmpScan] = []  
                            dataMS2.MATRIX_PEAK_INT[tmpScan] = []

                        elif line.startswith("H	"):
                            pass
                        elif line.startswith("I	"):
                            if line.startswith("I	IonInjectionTime"):
                                t = toolGetWord(line, 2, '	')
                                dataMS2.LIST_ION_INJECTION_TIME[tmpScan] = float(t)
                            elif line.startswith("I	RetTime	") or line.startswith("I	RTime	"):
                                t = toolGetWord(line, 2, '	')
                                dataMS2.LIST_RET_TIME[tmpScan] = float(t)
                                dataMS2.INDEX_RT.append(float(t))
                            elif line.startswith("I	ActivationCenter"):
                                t = toolGetWord(line, 2, '	')
                                dataMS2.LIST_ACTIVATION_CENTER[tmpScan] = float(t)
                                dataMS2.INDEX_ACTIVATION_CENTER.append(float(t))
                            elif line.startswith("I IsolationWidth"):
                                t = toolGetWord(line, 2, '	')
                                dataMS2.LIST_ISOLATION_WIDTH[tmpScan] = float(t)
                                dataMS2.INDEX_ISOLATION_WIDTH.append(float(t))
                            elif line.startswith("I	Window"):
                                t = toolGetWord(line, 2, '	')
                                if "-" in t:
                                    dataMS2.LIST_ISOLATION_WIDTH[tmpScan] = float(t.split('-')[1])-float(t.split('-')[0])
                                    dataMS2.INDEX_ISOLATION_WIDTH.append(float(t.split('-')[1])-float(t.split('-')[0]))
                            elif line.startswith("I	NumberOfPeaks"):
                                t = toolGetWord(line, 2, '	')
                                dataMS2.TIMS_NUMBER_PEAKS[tmpScan] = float(t)
                                dataMS2.INDEX_TIMS_NUMBER_PEAKS.append(float(t))
                            elif line.startswith("I	TotalIntensity"):
                                t = toolGetWord(line, 2, '	')
                                dataMS2.TIMS_TOTAL_INTENSITY[tmpScan] = float(t)
                                dataMS2.INDEX_TIMS_TOTAL_INTENSITY.append(float(t))
                            elif line.startswith("I InstrumentType"):
                                if "cv=" in line:
                                    t = toolGetWord(line, 2, '	')
                                    cv = t.split(' ')[4]
                                    dataMS2.INDEX_CV.append(str(cv))
                            elif line.startswith("I	FrameNo"):
                                pass
                        elif line.startswith("Z	"):
                            pass
                        elif line.startswith("I IonMobility"):
                            pass
                        else:
                            dataMS2.MATRIX_PEAK_MOZ[tmpScan].append(float(toolGetWord(line, 0, ' ')))
                            dataMS2.MATRIX_PEAK_INT[tmpScan].append(float(toolGetWord(line, 1, ' ')))
                            dataMS2.MATRIX_PEAK_MARK[tmpScan].append(float(-1.0))

            
            fid_pkl = open(path_pkl, 'wb')
            pickle.dump(dataMS2, fid_pkl)
            fid_pkl.close()


class CFunctionParse_9:

    def __init__(self, inputDP):

        self.dp = inputDP

    def read(self, pathID):

        global position_PrecWindowNumber, var_pos_19
        with open(pathID, 'rb') as f:
            lines = f.read().decode('utf-8').split('\r\n')

        var_tab_26 = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_49 = var_tab_26.index('R.FileName')
        var_pos_58 = var_tab_26.index('R.Run Date')   
        var_pos_18 = var_tab_26.index('R.Gradient Length [min]')  
        
        
        
        
        
        position_PGQuant = var_tab_26.index('PG.Quantity')   
        
        
        
        position_PepQuant = var_tab_26.index('PEP.Quantity')
        
        
        
        position_SignaltoNoise = var_tab_26.index('EG.SignalToNoise')  
        var_pos_51 = var_tab_26.index('EG.TotalQuantity (Settings)')   

        

        # var_pos_19 = var_tab_26.index('PG.Organisms')
        var_pos_27 = var_tab_26.index('PG.ProteinGroups')
        var_pos_12 = var_tab_26.index('PG.Qvalue')
        var_pos_14 = var_tab_26.index('EG.Qvalue')
        var_pos_28 = var_tab_26.index('PEP.StrippedSequence')
        var_pos_17 = var_tab_26.index('EG.ModifiedPeptide')
        var_pos_22 = var_tab_26.index('EG.PrecursorId')  
        position_precursorRTStart = var_tab_26.index('EG.StartRT')
        position_precursorRTEnd = var_tab_26.index('EG.EndRT')
        position_precursorRT = var_tab_26.index('EG.ApexRT')
        position_FWHM = var_tab_26.index('EG.FWHM')
        position_PeakWidth = var_tab_26.index('EG.PeakWidth')
        var_pos_35 = var_tab_26.index('FG.Charge') 
        position_precursorMOZ = var_tab_26.index('FG.PrecMz')  
        position_MS1_MassAccuray = var_tab_26.index('FG.RawMassAccuracy (PPM)')
        position_MS2_MassAccuray = var_tab_26.index('F.RawMassAccuracy (PPM)')
        position_PrecWindow = var_tab_26.index('FG.PrecWindow')
        position_PrecWindowNumber = var_tab_26.index('FG.PrecWindowNumber')
        position_MissedCleavage = var_tab_26.index('PEP.NrOfMissedCleavages')
        position_MS2_datapoint = var_tab_26.index('EG.DatapointsPerPeak')  
        position_MS1_datapoint = var_tab_26.index('EG.DatapointsPerPeak (MS1)')
        # var_pos_59 = var_tab_26.index('FG.FragmentCount')
        var_pos_45 = var_tab_26.index('EG.IsDecoy')
        last_ID = '  '

        for line in lines:

            var_lin_24 = line.split('\t')
            RAW_PATH = str(self.dp.myCFG.A0_PATH_RAW.split('\\')[-1])
            RAW_NAME = str(RAW_PATH.split('.')[0])
            var_tmp_7 = var_lin_24[var_pos_49]
            var_tmp_13 = var_lin_24[var_pos_45]

            if var_tmp_7 == RAW_NAME and (var_tmp_13 == 'FALSE' or var_tmp_13 == 'False'):
                # FragmentCount = int(var_lin_24[var_pos_59])
                var_tmp_48 = var_lin_24[var_pos_22]
                var_tmp_8 = var_lin_24[var_pos_27]
                # if 'PG.Organisms'in var_tab_26:
                #     var_tmp_31 = var_lin_24[var_pos_19]

                tmp_ID = var_tmp_7 + '_' + var_tmp_8 + '_' + var_tmp_48

                var_tmp_3 = float(var_lin_24[var_pos_12])
                var_tmp_25 = var_lin_24[var_pos_28]
                var_tmp_56 = self.__soliderParseMod(var_lin_24[var_pos_17])
                var_tmp_9 = int(var_lin_24[var_pos_35])
                tmp_precursorRTStart = float(var_lin_24[position_precursorRTStart])
                tmp_precursorRTEnd = float(var_lin_24[position_precursorRTEnd])
                tmp_precursorRT = float(var_lin_24[position_precursorRT])
                tmp_FWHM = float(var_lin_24[position_FWHM])
                tmp_PeakWidth = float(var_lin_24[position_PeakWidth])
                tmp_MS1_MassAccuray = float(var_lin_24[position_MS1_MassAccuray])
                tmp_MS2_MassAccuray = float(var_lin_24[position_MS2_MassAccuray])
                tmp_PrecWindow = var_lin_24[position_PrecWindow]
                var_tmp_32 = int(var_lin_24[position_MissedCleavage])
                tmp_MS2_datapoint = float(var_lin_24[position_MS2_datapoint])
                tmp_MS1_datapoint = float(var_lin_24[position_MS1_datapoint])
                tmp_PreWindowNumber = int(float(var_lin_24[position_PrecWindowNumber]))

                var_tmp_53 = float(var_lin_24[var_pos_14])
                tmp_precursorMOZ = float(var_lin_24[position_precursorMOZ])
                tmp_PGQuant = float(var_lin_24[position_PGQuant])
                
                tmp_PepQuant = float(var_lin_24[position_PepQuant])
                var_tmp_38 = float(var_lin_24[var_pos_51])
                tmp_SignaltoNoise = float(var_lin_24[position_SignaltoNoise])

                
                if last_ID != tmp_ID:  
                    last_ID = tmp_ID

                    self.dp.myID.PSM31_Precursor.append(var_tmp_48)
                    self.dp.myID.PSM12_SCORE2.append(var_tmp_53)
                    self.dp.myID.PSM15_PRE_MOZ.append(tmp_precursorMOZ)
                    self.dp.myID.PSM5_MOD.append(var_tmp_56)
                    self.dp.myID.PSM9_CHARGE.append(var_tmp_9)
                    
                    self.dp.myID.PSM3_RT.append(tmp_precursorRT)
                    self.dp.myID.PSM22_RT_START.append(tmp_precursorRTStart)
                    self.dp.myID.PSM23_RT_END.append(tmp_precursorRTEnd)
                    self.dp.myID.PSM28_FWHM.append(tmp_FWHM)
                    self.dp.myID.PSM29_PeakWidth.append(tmp_PeakWidth)
                    self.dp.myID.PSM32_DataPoint_MS1.append(tmp_MS1_datapoint)
                    self.dp.myID.PSM24_DataPoint.append(tmp_MS2_datapoint)
                    self.dp.myID.PSM25_PrecWindow.append(tmp_PrecWindow)
                    self.dp.myID.PSM25_PrecWindowNumber.append(tmp_PreWindowNumber)
                    self.dp.myID.PSM26_MS1_MassAccuracy.append(tmp_MS1_MassAccuray)
                    self.dp.myID.PSM27_MS2_MassAccuracy.append(tmp_MS2_MassAccuray)
                    self.dp.myID.PSM18_PRE_INTENSITY.append(var_tmp_38)
                    self.dp.myID.PSM17_PRE_SignalToNoise.append(tmp_SignaltoNoise)
                    self.dp.myID.PSM30_MissedCleavage_PRE.append(var_tmp_32)

                    self.dp.myID.N_PSM = self.dp.myID.N_PSM + 1

                    if var_tmp_25 not in self.dp.myID.PSM4_SEQ:
                        self.dp.myID.PSM4_SEQ.append(var_tmp_25)
                        self.dp.myID.PSM14_PEP_INTENSITY.append(tmp_PepQuant)
                        self.dp.myID.PSM30_MissedCleavage.append(var_tmp_32)

                    if var_tmp_8 not in self.dp.myID.PSM20_PRO:
                        self.dp.myID.PSM20_PRO.append(var_tmp_8)
                        self.dp.myID.PSM11_SCORE1.append(var_tmp_3)
                        self.dp.myID.PSM13_PRO_INTENSITY.append(tmp_PGQuant)
                        

                    if var_tmp_7 not in self.dp.myID.PSM1_RAW_NAME:
                        self.dp.myID.PSM1_RAW_NAME.append(var_tmp_7)
                        self.dp.myID.R1_RUN_DATA.append(var_lin_24[var_pos_58])
                        self.dp.myID.R2_GRADIENT.append(float(var_lin_24[var_pos_18]))
                        
                        
                        
                        
                        

                    
                    if 'CON' not in var_tmp_8 and 'REV' not in var_tmp_8:
                        if ';' in var_tmp_8:
                            var_tmp_8 = var_tmp_8.split(';')
                            for i_pro in var_tmp_8:
                                self.dp.myID.PSM20_PROTEIN.append(i_pro)
                        else:
                            self.dp.myID.PSM20_PROTEIN.append(var_tmp_8)
        self.dp.myID.PSM20_PROTEIN = set(self.dp.myID.PSM20_PROTEIN)

        
        
        
        
        

    def __soliderParseMod(self, inputMod):

        str_mod = ''
        flag_mod = 0

        for i in inputMod:
            if i == '[':
                flag_mod = 1
            elif i == ']':
                flag_mod = 0
                str_mod += ';'
            elif flag_mod == 1:
                str_mod += i

        return str_mod


class CFunctionParse_2:
    def __init__(self, inputDP):

        self.dp = inputDP

    def read(self, pathID):

        with open(pathID, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        var_tab_26 = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        if 'Run' in var_tab_26:
            var_pos_49 = var_tab_26.index('Run')
            var_fla_10 = 0
        else:  
            var_pos_49 = var_tab_26.index('File.Name')
            var_fla_10 = 1
        var_pos_22 = var_tab_26.index('Precursor.Id')
        var_pos_17 = var_tab_26.index('Modified.Sequence')
        var_pos_28 = var_tab_26.index('Stripped.Sequence')
        var_pos_35 = var_tab_26.index('Precursor.Charge')
        var_pos_57 = var_tab_26.index('Q.Value')
        var_pos_20 = var_tab_26.index('Precursor.Normalised')

        position_precursorRT = var_tab_26.index('RT')
        position_precursorRTStart = var_tab_26.index('RT.Start')
        position_precursorRTEnd = var_tab_26.index('RT.Stop')

        var_pos_27 = var_tab_26.index('Protein.Group')
        
        var_pos_12 = var_tab_26.index('Lib.PG.Q.Value')  
        var_pos_55 = var_tab_26.index('PG.Quantity')
        position_MS2Scan = var_tab_26.index('MS2.Scan')

        last_ID = '  '

        for line in lines:

            var_lin_24 = line.split('\t')
            RAW_PATH = str(self.dp.myCFG.A0_PATH_RAW.split('\\')[-1])
            RAW_NAME = str(RAW_PATH.split('.')[0])
            var_tmp_7 = var_lin_24[var_pos_49]
            if var_fla_10 == 1:
                var_tmp_7 = var_tmp_7.split('\\')[-1].split('.')[0]

            if var_tmp_7 == RAW_NAME:
                var_tmp_48 = var_lin_24[var_pos_22]
                var_tmp_8 = var_lin_24[var_pos_27]

                tmp_ID = var_tmp_7 + '_' + var_tmp_8 + '_' + var_tmp_48

                var_tmp_3 = float(var_lin_24[var_pos_12])
                var_tmp_33 = float(var_lin_24[var_pos_57])
                var_tmp_1 = float(var_lin_24[var_pos_55])

                var_tmp_25 = var_lin_24[var_pos_28]

                var_tmp_56 = self.__soliderParseMod(var_lin_24[var_pos_17])
                var_tmp_9 = int(var_lin_24[var_pos_35])
                tmp_precursorRT = float(var_lin_24[position_precursorRT])
                tmp_precursorRTStart = float(var_lin_24[position_precursorRTStart])
                tmp_precursorRTEnd = float(var_lin_24[position_precursorRTEnd])
                var_tmp_54 = float(var_lin_24[var_pos_20])
                tmp_MS2Scan = int(var_lin_24[position_MS2Scan])


                if last_ID != tmp_ID:  

                    last_ID = tmp_ID

                    self.dp.myID.PSM20_PRO.append(var_tmp_8)
                    self.dp.myID.PSM31_Precursor.append(var_tmp_48)
                    self.dp.myID.PSM4_SEQ.append(var_tmp_25)

                    self.dp.myID.PSM1_RAW_NAME.append(var_tmp_7)
                    self.dp.myID.PSM3_RT.append(tmp_precursorRT)

                    self.dp.myID.PSM5_MOD.append(var_tmp_56)
                    self.dp.myID.PSM9_CHARGE.append(var_tmp_9)
                    self.dp.myID.PSM11_SCORE1.append(var_tmp_3)
                    self.dp.myID.PSM22_RT_START.append(tmp_precursorRTStart)
                    self.dp.myID.PSM23_RT_END.append(tmp_precursorRTEnd)
                    self.dp.myID.PSM2_SCAN_ID.append(tmp_MS2Scan)
                    self.dp.myID.PSM12_SCORE2.append(var_tmp_33)

                    
                    
                    
                    
                    
                    
                    
                    
                    
                    self.dp.myID.N_PSM = self.dp.myID.N_PSM + 1

                    
                    if 'CON' not in var_tmp_8 and 'REV' not in var_tmp_8:
                        if ';' in var_tmp_8:
                            var_tmp_8 = var_tmp_8.split(';')
                            for i_pro in var_tmp_8:
                                self.dp.myID.PSM20_PROTEIN.append(i_pro)
                        else:
                            self.dp.myID.PSM20_PROTEIN.append(var_tmp_8)


    def __soliderParseMod(self, inputMod):

        str_mod = ''
        flag_mod = 0

        for i in inputMod:
            if i == '(':
                flag_mod = 1
            elif i == ')':
                flag_mod = 0
                str_mod += ';'
            elif flag_mod == 1:
                str_mod += i

        return str_mod


class CFunctionAnaly_12:

    def __init__(self, inputDP, inputDataMS1, inputDataMS2):

        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

        
        

    def __soldierWriteMS1(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[0]

        with open(path, 'w') as f:
            f.write('\t'.join(["Scan_No", "Scan_Time", "Ion_Injection_Time", "Retention_Time"]) + '\n')
            n_scan = len(self.dataMS1.INDEX_SCAN)

            for i in range(n_scan):
                tmpScan = self.dataMS1.INDEX_SCAN[i]
                self.dp.myMS1.INDEX_ION_INJECTION_TIME.append(self.dataMS1.LIST_ION_INJECTION_TIME[tmpScan])

                f.write(str(tmpScan))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dp.myMS1.INDEX_SCAN_TIME_MS1[i] * 1000))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dataMS1.LIST_ION_INJECTION_TIME[tmpScan]))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dataMS1.LIST_RET_TIME[tmpScan]))
                f.write('\n')

    def __soldierWriteMS2(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[1]

        with open(path, 'w') as f:
            f.write('\t'.join(["Scan_No", "INDEX_SCAN_TIME_MS2", "Ion_Injection_Time", "Retention_Time"]) + '\n')
            n_scan = len(self.dataMS2.INDEX_SCAN)

            for i in range(n_scan):

                tmpScan = self.dataMS2.INDEX_SCAN[i]
                self.dp.myMS2.INDEX_ION_INJECTION_TIME.append(self.dataMS2.LIST_ION_INJECTION_TIME[tmpScan])

                f.write(str(tmpScan))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dp.myMS2.INDEX_SCAN_TIME_MS2[i] * 1000))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dataMS2.LIST_ION_INJECTION_TIME[tmpScan]))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dataMS2.LIST_RET_TIME[tmpScan]))
                f.write('\n')

    def __soldierWriteMS1TOF(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[0]

        with open(path, 'w') as f:
            f.write('\t'.join(["Scan_No", "Scan_Time", "Retention_Time"]) + '\n')
            n_scan = len(self.dataMS1.INDEX_SCAN)

            for i in range(n_scan):
                tmpScan = self.dataMS1.INDEX_SCAN[i]
                self.dp.myMS1.INDEX_ION_INJECTION_TIME.append(self.dataMS1.LIST_ION_INJECTION_TIME[tmpScan])

                f.write(str(tmpScan))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dp.myMS1.INDEX_SCAN_TIME_MS1[i] * 1000))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dataMS1.LIST_RET_TIME[tmpScan]))
                f.write('\n')

    def __soldierWriteMS2TOF(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[1]

        with open(path, 'w') as f:
            f.write('\t'.join(["Scan_No", "INDEX_SCAN_TIME_MS2", "Retention_Time"]) + '\n')
            n_scan = len(self.dataMS2.INDEX_SCAN)

            for i in range(n_scan):

                tmpScan = self.dataMS2.INDEX_SCAN[i]

                f.write(str(tmpScan))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dp.myMS2.INDEX_SCAN_TIME_MS2[i] * 1000))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dataMS2.LIST_RET_TIME[tmpScan]))
                f.write('\n')

    def analyze(self):

        var_lis_36 = toolCopyList(self.dataMS1.INDEX_SCAN)
        var_lis_36.extend(self.dataMS2.INDEX_SCAN)

        var_lis_6 = toolCopyList(self.dataMS1.INDEX_RT)
        var_lis_6.extend(self.dataMS2.INDEX_RT)

        var_lis_4 = [1] * len(self.dataMS1.INDEX_SCAN)
        var_lis_4.extend([2] * len(self.dataMS2.INDEX_SCAN))

        m1 = np.array([var_lis_36, var_lis_6, var_lis_4])
        m2 = m1.T[np.lexsort(m1[::-1, :])].T  

        var_lis_36 = m2[0].tolist()
        var_lis_6 = m2[1].tolist()
        var_lis_4 = m2[2].tolist()

        for i_all in range(len(var_lis_36) - 1):  

            if 1 == var_lis_4[i_all]:

                self.dp.myMS1.INDEX_SCAN_TIME_MS1.append(var_lis_6[i_all + 1] - var_lis_6[i_all])

            elif 2 == var_lis_4[i_all]:

                self.dp.myMS2.INDEX_SCAN_TIME_MS2.append(var_lis_6[i_all + 1] - var_lis_6[i_all])

        if 1 == var_lis_4[-1]:

            self.dp.myMS1.INDEX_SCAN_TIME_MS1.append(0)

        elif 2 == var_lis_4[-1]:

            self.dp.myMS2.INDEX_SCAN_TIME_MS2.append(0)

        
        if '.raw' in self.dp.myCFG.A0_PATH_RAW[-5:]:
            self.__soldierWriteMS1()
            self.__soldierWriteMS2()
        else:
            self.__soldierWriteMS1TOF()
            self.__soldierWriteMS2TOF()

        


class CFunctionAnaly_3:

    def __init__(self, inputDP):
        self.dp = inputDP

    def analyze(self):
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[4]
        if self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_IDENTIFICATION_RESULT['Spectronaut']:
            with open(path, 'w') as f:
                f.write('\t'.join(["PrecursorID", "RT", "Precursor_Qvalue", "MS1_MassAccuracy", "MS2_MassAccuracy"]) + '\n')
                for i in range(self.dp.myID.N_PSM):
                    f.write(str(self.dp.myID.PSM31_Precursor[i]))
                    f.write('\t')
                    f.write('{0:.5f}'.format(self.dp.myID.PSM3_RT[i]))
                    f.write('\t')
                    f.write('{0:e}'.format(self.dp.myID.PSM12_SCORE2[i]))
                    f.write('\t')
                    f.write('{0:.5f}'.format(self.dp.myID.PSM26_MS1_MassAccuracy[i]))
                    f.write('\t')
                    f.write('{0:.5f}'.format(self.dp.myID.PSM27_MS2_MassAccuracy[i]))
                    f.write('\n')


class CFunctionAnaly_11:

    def __init__(self, inputDP, inputDataMS2):
        self.dp = inputDP
        self.dataMS2 = inputDataMS2

        self.SET_ID_NUM = {}

    def __soldierWriteInfo(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[3]

        with open(path, 'w') as f:
            f.write('\t'.join(["Sequence", "Redundant_Scans", "Retention_Time"]) + '\n')
            for key in self.SET_ID_NUM:
                f.write(key)
                f.write('\t')
                f.write(str(len(self.SET_ID_NUM[key])))
                f.write('\t')
                f.write(str(self.dataMS2.LIST_RET_TIME[toolGetMinValueFromList(self.SET_ID_NUM[key])]))
                f.write('\n')

    def analyze(self):

        for i in range(self.dp.myID.N_PSM):

            tmpKey = self.dp.myID.PSM4_SEQ[i] + "/" + self.dp.myID.PSM5_MOD[i] + "/" + str(self.dp.myID.PSM9_CHARGE[i])

            if tmpKey in self.SET_ID_NUM:

                self.SET_ID_NUM[tmpKey].append(self.dp.myID.PSM2_SCAN_ID[i])

            else:

                self.SET_ID_NUM[tmpKey] = [self.dp.myID.PSM2_SCAN_ID[i]]

        self.__soldierWriteInfo()


class CFunctionAnaly_1:

    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def __soldierWriteMS1(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[6]

        with open(path, 'w') as f:

            f.write('\t'.join(["Scan_No", "Retention_Time", "Peaks", "Intensities"]) + '\n')
            n_MS1 = len(self.dp.myMS1.N_PEAKS_MS1)

            for i in range(n_MS1):

                tmpScan = self.dataMS1.INDEX_SCAN[i]

                f.write(str(tmpScan))
                f.write('\t')
                f.write('{0:.2f}'.format(self.dataMS1.LIST_RET_TIME[tmpScan]))
                f.write('\t')
                f.write(str(self.dp.myMS1.N_PEAKS_MS1[i]))
                f.write('\t')
                f.write('{0:.1f}'.format(self.dp.myMS1.INTENSITY_PEAKS_MS1[i]))
                f.write('\n')

    def __soldierWriteMS2(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[7]

        with open(path, 'w') as f:

            f.write('\t'.join(["Scan_No", "Retention_Time", "Peaks", "Intensities"]) + '\n')
            n_MS2 = len(self.dp.myMS2.N_PEAKS_MS2)

            for i in range(n_MS2):

                tmpScan = self.dataMS2.INDEX_SCAN[i]

                f.write(str(tmpScan))
                f.write('\t')
                f.write('{0:.2f}'.format(self.dataMS2.LIST_RET_TIME[tmpScan]))
                f.write('\t')
                f.write(str(self.dp.myMS2.N_PEAKS_MS2[i]))
                f.write('\t')
                f.write('{0:.1f}'.format(self.dp.myMS2.INTENSITY_PEAKS_MS2[i]))
                f.write('\n')

    def analyze(self):

        n_MS1 = len(self.dataMS1.INDEX_SCAN)
        n_MS2 = len(self.dataMS2.INDEX_SCAN)

        self.dp.myMS1.N_PEAKS_MS1 = [0] * n_MS1
        self.dp.myMS1.INTENSITY_PEAKS_MS1 = [0] * n_MS1

        for i in range(n_MS1):
            tmpScan = self.dataMS1.INDEX_SCAN[i]
            self.dp.myMS1.N_PEAKS_MS1[i] = len(self.dataMS1.MATRIX_PEAK_INT[tmpScan])
            self.dp.myMS1.INTENSITY_PEAKS_MS1[i] = sum(self.dataMS1.MATRIX_PEAK_INT[tmpScan])

        self.dp.myMS2.N_PEAKS_MS2 = [0] * n_MS2
        self.dp.myMS2.INTENSITY_PEAKS_MS2 = [0] * n_MS2

        if self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['timsTOF']:
            self.dp.myMS2.N_PEAKS_MS2 = self.dataMS2.INDEX_TIMS_NUMBER_PEAKS
            self.dp.myMS2.INTENSITY_PEAKS_MS2 = self.dataMS2.INDEX_TIMS_TOTAL_INTENSITY

        else:
            for i in range(n_MS2):
                tmpScan = self.dataMS2.INDEX_SCAN[i]
                self.dp.myMS2.N_PEAKS_MS2[i] = len(self.dataMS2.MATRIX_PEAK_INT[tmpScan])
                self.dp.myMS2.INTENSITY_PEAKS_MS2[i] = sum(self.dataMS2.MATRIX_PEAK_INT[tmpScan])

        self.__soldierWriteMS1()
        self.__soldierWriteMS2()


class CFunctionAnaly_6:

    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

        self.INDEX_CYCLES_N_MS2 = []
        self.INDEX_CYCLES_TIME = []

    def __soldierWriteCycle(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[2]

        with open(path, 'w') as f:
            f.write('\t'.join(["Rentention_Time", "MS1_Cycle_Time", "MS2_Number"]) + '\n')
            n_cycle = len(self.dp.myCYCLE.LIST_CYCLES_TIME)

            for i in range(n_cycle):
                f.write('{0:.4f}'.format(self.dataMS1.INDEX_RT[i]))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dp.myCYCLE.LIST_CYCLES_TIME[i]))
                f.write('\t')
                f.write(str(self.dp.myCYCLE.LIST_CYCLES_N_MS2[i]))
                f.write('\n')

    def __soldierWriteCycle2(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[10]

        with open(path, 'w') as f:
            f.write('\t'.join(["Rentention_Time", "MS2_Cycle_Time", "MS2_Number"]) + '\n')
            MS2_windows = self.dp.myCYCLE.LIST_CYCLES_MS2_WINDOWS
            n_MS2cycle = len(self.dataMS2.INDEX_RT) // MS2_windows

            for i in range(0,n_MS2cycle):
                f.write('{0:.4f}'.format(self.dataMS2.INDEX_RT[i*MS2_windows]))
                f.write('\t')
                f.write('{0:.4f}'.format(self.dp.myCYCLE.LIST_CYCLES_TIME_MS2[i]))
                f.write('\t')
                f.write(str(MS2_windows))
                f.write('\n')

    def analyze(self):

        n_cycle = len(self.dataMS1.INDEX_SCAN) - 1  

        
        self.dp.myCYCLE.LIST_CYCLES_N_MS2 = [0] * n_cycle

        for i in range(n_cycle - 1):
            self.dp.myCYCLE.LIST_CYCLES_N_MS2[i] = self.dataMS1.INDEX_SCAN[i + 1] - self.dataMS1.INDEX_SCAN[i] - 1

        
        self.dp.myCYCLE.LIST_CYCLES_TIME = [0] * n_cycle

        for i in range(0, n_cycle):
            self.dp.myCYCLE.LIST_CYCLES_TIME[i] = self.dataMS1.INDEX_RT[i + 1] - self.dataMS1.INDEX_RT[i]

        
        self.__soldierWriteCycle()

        if self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['Thermo-Orbitrap']:
            
            if len(self.dataMS2.INDEX_CV) > 1:
                CV_INDEX_ACTIVATION_CENTER = []
                for i in range(len(self.dataMS2.INDEX_ACTIVATION_CENTER)):
                    var_cvc_11 = str(self.dataMS2.INDEX_CV[i]) + '_' + str(self.dataMS2.INDEX_ACTIVATION_CENTER[i])
                    CV_INDEX_ACTIVATION_CENTER.append(var_cvc_11)

                self.dp.myMS2.INDEX_ACTIVATION_CENTER = CV_INDEX_ACTIVATION_CENTER
                n_MS2 = set(CV_INDEX_ACTIVATION_CENTER)
                self.dp.myCYCLE.LIST_CYCLES_MS2_WINDOWS = len(n_MS2)
                n_MS2cycle = len(self.dataMS2.INDEX_RT) // len(n_MS2)
                self.dp.myCYCLE.LIST_CYCLES_TIME_MS2 = [0] * n_MS2cycle

            else:
                n_MS2 = set(self.dataMS2.INDEX_ACTIVATION_CENTER)
                self.dp.myMS2.INDEX_ACTIVATION_CENTER = self.dataMS2.INDEX_ACTIVATION_CENTER
                self.dp.myCYCLE.LIST_CYCLES_MS2_WINDOWS = len(n_MS2)
                n_MS2cycle = len(self.dataMS2.INDEX_RT)//len(n_MS2)
                self.dp.myCYCLE.LIST_CYCLES_TIME_MS2 = [0] * n_MS2cycle

            for i in range(0,n_MS2cycle-1):
                self.dp.myCYCLE.LIST_CYCLES_TIME_MS2[i] = self.dataMS2.INDEX_RT[(i+1)*len(n_MS2)]-self.dataMS2.INDEX_RT[(i)*len(n_MS2)]

            
            self.__soldierWriteCycle2()

        else:
            n_MS2 = set(self.dataMS2.INDEX_ACTIVATION_CENTER)
            self.dp.myMS2.INDEX_ACTIVATION_CENTER = self.dataMS2.INDEX_ACTIVATION_CENTER
            self.dp.myCYCLE.LIST_CYCLES_MS2_WINDOWS = len(n_MS2)
            self.dp.myCYCLE.LIST_CYCLES_TIME_MS2 = self.dp.myCYCLE.LIST_CYCLES_TIME


class CFunctionAnaly_7:

    def __init__(self, inputDP):
        self.dp = inputDP

    def analyze(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[5]
        with open(path, 'w') as f:
            f.write('\t'.join(
                ["PrecursorID", "RT_START", "RT_END", "Peak_Width", "FWHM", "DataPoint_MS2", "DataPoint_MS1"]) + '\n')
            n_psm = self.dp.myID.N_PSM

            for i_psm in range(n_psm):
                f.write(str(self.dp.myID.PSM31_Precursor[i_psm]))
                f.write('\t')
                f.write('{0:.2f}'.format(self.dp.myID.PSM22_RT_START[i_psm]))
                f.write('\t')
                f.write('{0:.2f}'.format(self.dp.myID.PSM23_RT_END[i_psm]))
                f.write('\t')
                f.write('{0:.3f}'.format(self.dp.myID.PSM29_PeakWidth[i_psm]))
                f.write('\t')
                f.write('{0:.3f}'.format(self.dp.myID.PSM28_FWHM[i_psm]))
                f.write('\t')
                f.write('{0:.2f}'.format(self.dp.myID.PSM24_DataPoint[i_psm]))
                f.write('\t')
                f.write('{0:.2f}'.format(self.dp.myID.PSM32_DataPoint_MS1[i_psm]))
                f.write('\n')

        path2 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[3]
        with open(path2, 'w') as f2:
            f2.write('\t'.join(
                ["PrecursorID", "RT", "Precursor_Mz", "EG_TargetQuantity", "EG_SignalToNoise", "PrecWindow", "PrecWindowNumber","NrOfMissedCleavages"]) + '\n')
            n_psm = self.dp.myID.N_PSM

            for i_psm in range(n_psm):
                f2.write(str(self.dp.myID.PSM31_Precursor[i_psm]))
                f2.write('\t')
                f2.write('{0:.2f}'.format(self.dp.myID.PSM3_RT[i_psm]))
                f2.write('\t')
                f2.write('{0:.2f}'.format(self.dp.myID.PSM15_PRE_MOZ[i_psm]))
                f2.write('\t')
                f2.write('{0:.2f}'.format(self.dp.myID.PSM18_PRE_INTENSITY[i_psm]))
                f2.write('\t')
                f2.write('{0:.2f}'.format(self.dp.myID.PSM17_PRE_SignalToNoise[i_psm]))
                f2.write('\t')
                f2.write(str(self.dp.myID.PSM25_PrecWindow[i_psm]))
                f2.write('\t')
                f2.write(str(self.dp.myID.PSM25_PrecWindowNumber[i_psm]+1))
                f2.write('\t')
                f2.write(str(self.dp.myID.PSM30_MissedCleavage_PRE[i_psm]))
                f2.write('\n')


class CFunctionAnaly_5:

    def __init__(self, inputDP, inputDataMS1):

        self.dp = inputDP
        self.dataMS1 = inputDataMS1

        self.PROFILE_L_MOZ = []
        self.PROFILE_L_INT = []

        self.RT_START = []
        self.RT_END = []

    def __soldierWriteChromatography(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[5]
        if self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_IDENTIFICATION_RESULT['pFind']:
            with open(path, 'w') as f:
                f.write('\t'.join(["Scan_No", "Final_Score", "Retention_Time", "Retention_Length", "Starting_FWHM", "FWHM"]) + '\n')
                n_psm = self.dp.myID.N_PSM

                for i_psm in range(n_psm):

                    f.write(str(self.dp.myID.PSM2_SCAN_ID[i_psm]))
                    f.write('\t')
                    f.write('{0:e}'.format(self.dp.myID.PSM10_SCORE0[i_psm]))
                    f.write('\t')

                    var_tmp_15 = self.RT_END[i_psm] - self.RT_START[i_psm]

                    f.write('{0:.2f}'.format(self.RT_START[i_psm] / 60))
                    f.write('\t')
                    f.write('{0:.2f}'.format(var_tmp_15 / 60))
                    f.write('\t')

                    
                    

                    tmp_delta_rt_FWHM = self.RT_END_FWHM[i_psm] - self.RT_START_FWHM[i_psm]

                    f.write('{0:.2f}'.format(self.RT_START_FWHM[i_psm] / 60))
                    f.write('\t')
                    f.write('{0:.2f}'.format(tmp_delta_rt_FWHM / 60))

                    f.write('\n')
        elif self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_IDENTIFICATION_RESULT['Spectronaut']:
            with open(path, 'w') as f:
                f.write('\t'.join(
                    ["PrecursorID", "RT_START", "RT_END", "Peak_Width", "FWHM", "DataPoint"]) + '\n')
                n_psm = self.dp.myID.N_PSM

                for i_psm in range(n_psm):
                    f.write(str(self.dp.myID.PSM31_Precursor[i_psm]))
                    f.write('\t')
                    f.write('{0:e}'.format(self.dp.myID.PSM22_RT_START[i_psm]))
                    f.write('\t')
                    f.write('{0:.2f}'.format(self.dp.myID.PSM23_RT_END[i_psm]))
                    f.write('\t')
                    f.write('{0:.2f}'.format(self.dp.myID.PSM29_PeakWidth[i_psm]))
                    f.write('\t')
                    f.write('{0:.2f}'.format(self.dp.myID.PSM28_FWHM[i_psm]))
                    f.write('\t')
                    f.write('{0:.2f}'.format(self.dp.myID.PSM24_DataPoint[i_psm]))
                    f.write('\n')


    def analyze1(self):

        pass


    def analyze(self):

        
        nPSM = self.dp.myID.N_PSM

        self.PROFILE_L_MOZ = [[]*1] * nPSM
        self.PROFILE_L_INT = [[]*1] * nPSM

        self.RT_START = [0]*nPSM
        self.RT_END = [0]*nPSM

        self.RT_START_FWHM = [0]*nPSM
        self.RT_END_FWHM = [0] * nPSM

        
        for i_PSM in range(nPSM):

            if i_PSM % 3000 == 1:   
                print(INFO_TO_USER_MSFunction[0] + str(i_PSM) + '/' + str(nPSM))

            
            msmsMass = self.dp.myID.PSM8_MH_CLC[i_PSM]
            msmsCharge = self.dp.myID.PSM9_CHARGE[i_PSM]
            msmsMZ = toolMass2MZ(msmsMass, msmsCharge)
            msmsScan = self.dp.myID.PSM2_SCAN_ID[i_PSM]

            
            iMid = toolFindNeighborFromSortedList1(self.dataMS1.INDEX_SCAN, msmsScan)
            scanMid = self.dataMS1.INDEX_SCAN[iMid]
            rtMid = self.dataMS1.INDEX_RT[iMid]

            
            iLeft = iMid
            borderRTLeft = max(0, rtMid - self.dp.myCFG.C1_WINDOW_HALF_RT * 60)  
            while iLeft > 0:  

                if self.dataMS1.INDEX_RT[iLeft] < borderRTLeft:
                    break
                else:
                    iLeft = iLeft - 1

            iRight = iMid
            borderRTRight = min(rtMid + self.dp.myCFG.C1_WINDOW_HALF_RT * 60, self.dataMS1.INDEX_RT[-1])  
            while iRight < len(self.dataMS1.INDEX_SCAN) - 1:  

                if self.dataMS1.INDEX_RT[iRight] > borderRTRight:
                    break
                else:
                    iRight = iRight + 1

            
            nScan = iRight - iLeft + 1

            self.PROFILE_L_MOZ[i_PSM] = [0.0] * nScan
            self.PROFILE_L_INT[i_PSM] = [0.0] * nScan

            
            for iScan in range(iLeft, iRight + 1):  

                tmpScan = self.dataMS1.INDEX_SCAN[iScan]

                listPeakMOZ = self.dataMS1.MATRIX_PEAK_MOZ[tmpScan]
                listPeakINT = self.dataMS1.MATRIX_PEAK_INT[tmpScan]

                i_peak = toolFindNeighborFromSortedList1(listPeakMOZ, msmsMZ)

                disMZ = abs(listPeakMOZ[i_peak] - msmsMZ) / msmsMZ * 1e6

                if disMZ < self.dp.myCFG.C2_PPM_HALF_WIN_ACCURACY_PEAK:
                    self.PROFILE_L_MOZ[i_PSM][iScan - iLeft] = listPeakMOZ[i_peak]
                    self.PROFILE_L_INT[i_PSM][iScan - iLeft] = listPeakINT[i_peak]

            
            startAndEnd = opGetStartAndEnd(self.PROFILE_L_INT[i_PSM], iMid-iLeft,
                                           self.dp.myCFG.C3_CUTOFF_INTENSITY_IN_CMTG, self.dp.myCFG.C4_NUMBER_HOLE_IN_CMTG)

            
            startAndEnd_FWHM = opGetStartAndEnd_FWHM(self.PROFILE_L_INT[i_PSM], startAndEnd[0], startAndEnd[1])


            self.RT_START[i_PSM] = self.dataMS1.INDEX_RT[iLeft+startAndEnd[0]]
            self.RT_END[i_PSM] = self.dataMS1.INDEX_RT[iLeft+startAndEnd[1]]

            self.RT_START_FWHM[i_PSM] = self.dataMS1.INDEX_RT[iLeft+startAndEnd_FWHM[0]]
            self.RT_END_FWHM[i_PSM] = self.dataMS1.INDEX_RT[iLeft+startAndEnd_FWHM[1]]

        
        self.__soldierWriteChromatography()


class CFunctionScan2_8:

    def __init__(self, inputDP, inputDataMS1, inputDataMS2):

        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def work(self):

        SCAN_PER_PEPTIDE = [[] * 1] * (self.dataMS2.INDEX_SCAN[-1] + 1)
        PEPTIDE_PER_SCAN = {}

        for scan in self.dataMS2.INDEX_SCAN:
            SCAN_PER_PEPTIDE[scan] = []
        for peptide in self.dp.myID.PSM31_Precursor:
            if peptide not in PEPTIDE_PER_SCAN.keys():
                PEPTIDE_PER_SCAN[peptide] = []

        for i in range(len(self.dp.myID.PSM22_RT_START)):
            RT_START = self.dp.myID.PSM22_RT_START[i] * 60
            RT_END = self.dp.myID.PSM23_RT_END[i] * 60
            SEQ_MOD_CHARGE = self.dp.myID.PSM31_Precursor[i]
            Window_Left = float((self.dp.myID.PSM25_PrecWindow[i]).split(' ')[0][1:])
            Window_Right = float((self.dp.myID.PSM25_PrecWindow[i]).split(' ')[2][:-1])

            for j in range(len(self.dataMS2.INDEX_SCAN)):
                SCAN = self.dataMS2.INDEX_SCAN[j]
                RT = self.dataMS2.INDEX_RT[j]
                if RT_START <= RT <= RT_END:
                    if Window_Left < self.dataMS2.LIST_ACTIVATION_CENTER[SCAN] < Window_Right:
                        SCAN_PER_PEPTIDE[SCAN].append(SEQ_MOD_CHARGE)
                        PEPTIDE_PER_SCAN[SEQ_MOD_CHARGE].append(SCAN)
                elif RT > RT_END:
                    break
        path1 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[9]
        with open(path1, 'w') as f1:
            f1.write('\t'.join(["Scan_No", "Index_RT", "peptides"]) + '\n')
            m=0
            for msmsScan in self.dataMS2.INDEX_SCAN:
                f1.write(str(msmsScan))
                f1.write('\t')
                f1.write('{0:.2f}'.format(self.dataMS2.INDEX_RT[m]))
                f1.write('\t')
                m=m+1
                f1.write(str(len(SCAN_PER_PEPTIDE[msmsScan])))
                self.dp.myID.SCAN_TO_PEPTIDE.append(int(len(SCAN_PER_PEPTIDE[msmsScan])))
                if len(SCAN_PER_PEPTIDE[msmsScan]) != 0:
                    self.dp.myID.ID2_SCAN_ID.append(msmsScan)
                    for peptide in SCAN_PER_PEPTIDE[msmsScan]:
                        f1.write('\t')
                        f1.write(str(peptide))
                f1.write('\n')

        path2 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[8]
        with open(path2, 'w') as f2:
            f2.write('\t'.join(["peptides", "Scan_Number"]) + '\n')

            for SEQ_MOD_CHARGE in PEPTIDE_PER_SCAN.keys():

                f2.write(str(SEQ_MOD_CHARGE))
                f2.write('\t')

                f2.write(str(len(PEPTIDE_PER_SCAN[SEQ_MOD_CHARGE])))
                self.dp.myID.SCAN_REDUNDANCE.append(int(len(PEPTIDE_PER_SCAN[SEQ_MOD_CHARGE])))

                if len(PEPTIDE_PER_SCAN[SEQ_MOD_CHARGE]) != 0:
                    for msmsScan in PEPTIDE_PER_SCAN[SEQ_MOD_CHARGE]:
                        f2.write('\t')
                        f2.write(str(msmsScan))
                f2.write('\n')


class CFunctionAnaly_10:

    def __init__(self, inputDP, inputDataMS1, inputDataMS2):

        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def soldierOutputFeature(self,inputDataFeature, var_fea_46):

        path1 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[11]

        
        array_INDEX_RT_S = np.array(inputDataFeature.INDEX_RT_S)
        array_INDEX_RT_E = np.array(inputDataFeature.INDEX_RT_E)
        array_LIST_MOZ_MONO = np.array(inputDataFeature.LIST_MOZ_MONO)[: len(inputDataFeature.INDEX_RT_S)]

        MATRIX_FEATURE_SCAN = {}
        MATRIX_MS2_SCAN = {}
        FeatureSCAN = []
        
        
        
        
        identified = []
        SCAN = []
        dic_PSM_SCAN = self.dp.myID.ID2_SCAN_ID
        

        for tmpSCAN in self.dataMS2.INDEX_SCAN:

            ACTIVATION_CENTER = self.dataMS2.LIST_ACTIVATION_CENTER[tmpSCAN]
            RT = self.dataMS2.LIST_RET_TIME[tmpSCAN]
            HALF_ISOLATION_WINDOW = 0.5*self.dataMS2.LIST_ISOLATION_WIDTH[tmpSCAN]

            MATRIX_FEATURE_SCAN[tmpSCAN] = []
            
            

            
            var_ind_21 = np.where(np.abs(array_LIST_MOZ_MONO - ACTIVATION_CENTER) < HALF_ISOLATION_WINDOW)[0]   
            index_rt = np.where((array_INDEX_RT_S[var_ind_21] < RT) * (array_INDEX_RT_E[var_ind_21] > RT))[0]
            var_lis_34 = [var_ind_21[i] for i in index_rt]  

            for featureSCAN in var_lis_34:

                if featureSCAN not in MATRIX_MS2_SCAN.keys():
                    MATRIX_MS2_SCAN[featureSCAN] = []

                MATRIX_FEATURE_SCAN[tmpSCAN].append(featureSCAN)
                MATRIX_MS2_SCAN[featureSCAN].append(tmpSCAN)
                FeatureSCAN.append(featureSCAN)

                if tmpSCAN in dic_PSM_SCAN:

                    
                    
                    
                    
                    
                    SCAN.append(tmpSCAN)
                    identified.append(featureSCAN)

        del self.dataMS2


        
        inputDataFeature.INDEX_CHARGE = [str(i) for i in inputDataFeature.INDEX_CHARGE]
        inputDataFeature.INDEX_INTENSITY_ALL = ['{0:.2f}'.format(i) for i in inputDataFeature.INDEX_INTENSITY_ALL[:len(inputDataFeature.INDEX_SCAN_S)]]
        inputDataFeature.LIST_MOZ_MONO = ['{0:.5f}'.format(i) for i in inputDataFeature.LIST_MOZ_MONO[:len(inputDataFeature.INDEX_SCAN_S)]]
        inputDataFeature.INDEX_SCAN_S = [str(i) for i in inputDataFeature.INDEX_SCAN_S]
        inputDataFeature.INDEX_SCAN_E = [str(i) for i in inputDataFeature.INDEX_SCAN_E]
        inputDataFeature.INDEX_RT_S = ['{0:.2f}'.format(i) for i in inputDataFeature.INDEX_RT_S]
        inputDataFeature.INDEX_RT_E = ['{0:.2f}'.format(i) for i in inputDataFeature.INDEX_RT_E]
        identified = {i: '' for i in identified}  
        FeatureSCAN = {i: '' for i in FeatureSCAN}  

        with open(path1, 'a') as f:

            var_str_39 = []
            for i in range(len(inputDataFeature.INDEX_RT_S)):

                var_str_16 = '\t'.join([str(var_fea_46 + i+1),
                                          inputDataFeature.INDEX_CHARGE[i],
                                          inputDataFeature.INDEX_INTENSITY_ALL[i],
                                          inputDataFeature.LIST_MOZ_MONO[i],
                                          inputDataFeature.INDEX_SCAN_S[i],
                                          inputDataFeature.INDEX_SCAN_E[i],
                                          inputDataFeature.INDEX_RT_S[i],
                                          inputDataFeature.INDEX_RT_E[i]]) + '\t'

                if i in identified:
                    var_str_16 += 'identified'
                    
                elif i in FeatureSCAN:
                    var_str_16 += str('acquired')
                    
                else:
                    var_str_16 += str('unknown')

                
                
                
                
                
                inputDataFeature.STATE_OF_FEATURE.append(var_str_16)
                var_str_39.append(var_str_16)
            f.write('\t'.join(['Feature_ID','Charge','Intensities','Mz','Scan_Start','Scan_End','RT_Start','RT_End','Type'])+ '\n')
            f.write('\n'.join(var_str_39))

    def soldierDecide1(self, result1, i_MS1, i_Peak, gap, var_sca_30, var_pea_2):
        
        THRESHOLD_NUMBER_ISOTOPIC_PEAK = 3
        MAXIMUM_NUMBER_ISOTOPIC_PEAK = 5
        PPM_FOR_CALIBRATION = 5
        PPM_HALF_WIN_ACCURACY_PEAK = 20

        l = 1 + THRESHOLD_NUMBER_ISOTOPIC_PEAK + 1
        tmpscan = self.dataMS1.INDEX_SCAN[i_MS1]
        var_icu_23 = i_Peak

        var_sca_30.append(tmpscan)
        var_pea_2.append(var_icu_23)
        for i in range(l):
            result1.append(0.0)
        result1[0] = -1.0
        result1[l-1] = self.dataMS1.MATRIX_PEAK_INT[tmpscan][var_icu_23]
        result1[1] = self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][var_icu_23]

        count = 1

        

        for i in range(THRESHOLD_NUMBER_ISOTOPIC_PEAK - 1):

            MZ_t_tmp = float(self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][var_icu_23] + gap)
            MZ_t = float(MZ_t_tmp + MZ_t_tmp/1000000 * PPM_FOR_CALIBRATION)
            win = float(MZ_t / 1000000 * PPM_HALF_WIN_ACCURACY_PEAK)
            i_AddFromCurrent = False

            for peak in range(var_icu_23 + 1,len(self.dataMS1.MATRIX_PEAK_MOZ[tmpscan])):

                if self.dataMS1.MATRIX_PEAK_MARK[tmpscan][peak] == -1.0:

                    value = self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][peak] - MZ_t
                    if abs(value) <= win:
                        var_icu_23 = peak
                        i_AddFromCurrent = True
                        break
                    elif value > win:
                        break
                    else:
                        pass
                else:
                    continue

            if not i_AddFromCurrent:
                break
            else:
                result1[l-1] = result1[l-1] + self.dataMS1.MATRIX_PEAK_INT[tmpscan][var_icu_23]
                result1[2+i] = self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][var_icu_23]
                var_sca_30.append(tmpscan)
                var_pea_2.append(var_icu_23)
                count = count + 1

        if count < THRESHOLD_NUMBER_ISOTOPIC_PEAK:
            pass
        else:
            result1[0] = 1.0
            for i in range(MAXIMUM_NUMBER_ISOTOPIC_PEAK - THRESHOLD_NUMBER_ISOTOPIC_PEAK):

                if var_icu_23 == len(self.dataMS1.MATRIX_PEAK_MOZ[tmpscan])-1:
                    break
                else:
                    MZ_t_tmp = float(self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][var_icu_23] + gap)
                    MZ_t = float(MZ_t_tmp + MZ_t_tmp / 1000000 * PPM_FOR_CALIBRATION)
                    win = float(MZ_t / 1000000 * PPM_HALF_WIN_ACCURACY_PEAK)
                    i_AddFromCurrent = False

                    for peak in range(var_icu_23 + 1, len(self.dataMS1.MATRIX_PEAK_MOZ[tmpscan])):

                        if self.dataMS1.MATRIX_PEAK_MARK[tmpscan][peak] == -1.0:

                            value = self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][peak] - MZ_t
                            if abs(value) <= win:
                                var_icu_23 = peak
                                i_AddFromCurrent = True
                                break
                            elif value > win:
                                break
                            else:
                                pass
                        else:
                            continue

                    if not i_AddFromCurrent:
                        break
                    else:
                        var_sca_30.append(tmpscan)
                        var_pea_2.append(var_icu_23)
                        result1[l - 1] = result1[l - 1] + self.dataMS1.MATRIX_PEAK_INT[tmpscan][var_icu_23]

        return result1

    def soldierDecide2(self, MS_next, result1, result2, gap, var_sca_30, var_pea_2):

        MAXIMUM_NUMBER_ISOTOPIC_PEAK = 5
        THRESHOLD_NUMBER_ISOTOPIC_PEAK = 3
        PPM_FOR_CALIBRATION = 5
        PPM_HALF_WIN_ACCURACY_PEAK = 20

        tmpscan = self.dataMS1.INDEX_SCAN[MS_next]
        for i in range(2):
            result2.append(0.0)
        result2[0] = -1.0
        count = 0
        var_icu_23 = -1

        for i in range(len(result1)-2):
            tmpMZ = result1[i+1]
            
            win = float(tmpMZ / 1000000 * PPM_HALF_WIN_ACCURACY_PEAK)
            i_AddFromCurrent = False

            for peak in range(var_icu_23 + 1, len(self.dataMS1.MATRIX_PEAK_MOZ[tmpscan])):

                if self.dataMS1.MATRIX_PEAK_MARK[tmpscan][peak] == -1.0:
                    peak_MZ = self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][peak]
                    var_dif_52 = peak_MZ - result1[i + 1]
                    if abs(var_dif_52) <= win:
                        var_icu_23 = peak
                        i_AddFromCurrent = True
                        break
                    elif var_dif_52 > win:
                        break
                    else:
                        pass
                else:
                    continue

            if not i_AddFromCurrent:
                break
            else:
                var_sca_30.append(tmpscan)
                var_pea_2.append(var_icu_23)
                result2[1] = result2[1] + self.dataMS1.MATRIX_PEAK_INT[tmpscan][var_icu_23]
                count = count + 1

        if count == len(result1)-2:

            result2[0] = 1.0
            for i in range(MAXIMUM_NUMBER_ISOTOPIC_PEAK - THRESHOLD_NUMBER_ISOTOPIC_PEAK):
                if var_icu_23 == len(self.dataMS1.INDEX_SCAN) -1:
                    break
                else:
                    tmpMZ = self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][var_icu_23] + gap
                    MZ_t = float(tmpMZ + tmpMZ / 1000000 * PPM_FOR_CALIBRATION)
                    win = float(MZ_t / 1000000 * PPM_HALF_WIN_ACCURACY_PEAK)
                    i_AddFromCurrent = False

                    for peak in range(var_icu_23 + 1, len(self.dataMS1.MATRIX_PEAK_MOZ[tmpscan])):

                        if self.dataMS1.MATRIX_PEAK_MARK[tmpscan][peak] == -1.0:
                            var_dif_52 = self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][peak] - MZ_t
                            if abs(var_dif_52) <= win:
                                var_icu_23 = peak
                                i_AddFromCurrent = True
                                break
                            elif var_dif_52 > win:
                                break
                            else:
                                pass
                        else:
                            continue

                    if not i_AddFromCurrent:
                        break
                    else:
                        var_sca_30.append(tmpscan)
                        var_pea_2.append(var_icu_23)
                        result2[1] = result2[1] + self.dataMS1.MATRIX_PEAK_INT[tmpscan][var_icu_23]
        return result2

    def analyze(self):

        
        MASS_AVERAGE = 1.003
        THRESHOLD_NUMBER_ISOTOPIC_PROFILE = 2
        THRESHOLD_NUMBER_ISOTOPIC_PEAK = 3

        var_fea_46 = 0
        dataFeature = self.dp.myFeature
        op_INIT_CFILE_FEATURE(dataFeature)
        n_MS1 = len(self.dataMS1.INDEX_SCAN)
        n_charge = 6
        var_ife_5 = 1

        for i_charge in range(1,n_charge, 1):

            gap = float(MASS_AVERAGE/i_charge)

            for i_MS1 in range(n_MS1 - THRESHOLD_NUMBER_ISOTOPIC_PROFILE + 1):
            
                
                    

                tmpscan = self.dataMS1.INDEX_SCAN[i_MS1]
                n_Peak = len(self.dataMS1.MATRIX_PEAK_MOZ[tmpscan])

                for i_Peak in range(n_Peak - THRESHOLD_NUMBER_ISOTOPIC_PEAK + 1):

                    mz = self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][i_Peak]

                    if self.dataMS1.MATRIX_PEAK_MARK[tmpscan][i_Peak] > -1.0:    
                        continue
                    else:
                        result1 = []
                        var_sca_30 = []
                        var_pea_2 = []

                        self.soldierDecide1(result1, i_MS1, i_Peak, gap, var_sca_30, var_pea_2)  
                        if result1[0] > 0:
                            var_int_42 = result1[-1]
                            count_MS = 1

                            for i in range(THRESHOLD_NUMBER_ISOTOPIC_PROFILE - 1):
                                
                                MS_next = i_MS1 + i + 1
                                result2 = []

                                self.soldierDecide2(MS_next, result1, result2, gap, var_sca_30, var_pea_2)   
                                if result2[0] > 0:
                                    count_MS = count_MS + 1
                                    var_int_42 = var_int_42 + result2[1]
                                else:
                                    break

                            if count_MS == THRESHOLD_NUMBER_ISOTOPIC_PROFILE:
                                index = i_MS1 + THRESHOLD_NUMBER_ISOTOPIC_PROFILE
                                if index > len(self.dataMS1.INDEX_SCAN) - 2:
                                    pass
                                else:
                                    for ms1 in range(index, n_MS1):
                                        result2 = []

                                        self.soldierDecide2(ms1, result1, result2, gap, var_sca_30, var_pea_2)

                                        if result2[0] > 0:
                                            count_MS = count_MS + 1
                                            var_int_42 = var_int_42 + result2[1]
                                        else:
                                            break

                                for i in range(len(var_sca_30)):
                                    scan = var_sca_30[i]
                                    peak = var_pea_2[i]
                                    self.dataMS1.MATRIX_PEAK_MARK[scan][peak] = var_ife_5      
                                dataFeature.INDEX_SCAN_S.append(tmpscan)
                                dataFeature.INDEX_SCAN_E.append(self.dataMS1.INDEX_SCAN[i_MS1 + count_MS - 1])
                                dataFeature.INDEX_RT_S.append(self.dataMS1.INDEX_RT[i_MS1])
                                if i_MS1 + count_MS - 1 < len(self.dataMS1.INDEX_RT) - 1:
                                    dataFeature.INDEX_RT_E.append(self.dataMS1.INDEX_RT[i_MS1 + count_MS])
                                else:
                                    dataFeature.INDEX_RT_E.append(self.dataMS1.INDEX_RT[-1])
                                dataFeature.INDEX_CHARGE.append(i_charge)
                                dataFeature.INDEX_INTENSITY_ALL.append(var_int_42)
                                dataFeature.LIST_MOZ_MONO[var_ife_5 - 1] = self.dataMS1.MATRIX_PEAK_MOZ[tmpscan][i_Peak]

                                var_ife_5 = var_ife_5 + 1
        del self.dataMS1

        self.soldierOutputFeature(dataFeature, var_fea_46)

        return len(dataFeature.INDEX_SCAN_S)












