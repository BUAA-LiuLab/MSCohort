
import sys
from MSStaff import MSStaff

staff = MSStaff(sys.argv)
staff.start()


