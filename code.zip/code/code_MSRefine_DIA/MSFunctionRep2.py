

import numpy as np
import math
from math import pi
from MSSystem import IO_FILENAME_PIC_EXPORT
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec

from collections import Counter
from MSSystem import EXPIRATION_TIME, CFG_TYPE_DATA
from matplotlib.pyplot import MultipleLocator
import os


class CFunctionPlotS_11:
    def __init__(self, inputDP):
        self.dp = inputDP

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[18]
        print("Generating image " + str(var_sav_95) + ".png ......")
        self.init_fig()
        self.draw_MissCleavage(self.fig, self.gs)
        self.draw_PeptideLength(self.fig, self.gs)

        plt.savefig(var_sav_95 + '.png', format='png')
        
        plt.close()

    def init_fig(self):
        
        fig = plt.figure()
        fig.set_size_inches(20, 5, forward=True)
        self.gs = GridSpec(6, 20)  
        self.fig = fig

    def draw_MissCleavage(self,fig, gs):
        zero = 0
        one = 0
        two = 0
        for num in self.dp.myID.PSM30_MissedCleavage:
            if num == 0:
                zero = zero + 1
            if num == 1:
                one = one + 1
            if num == 2 or num > 2:
                two = two + 1

        dimensions = [zero, one, two]
        var_tic_168 = ['0', '1', '2']
        ratio_0 = str('{:.2%}'.format(zero/len(self.dp.myID.PSM30_MissedCleavage)))
        ratio_1 = str('{:.2%}'.format(one/len(self.dp.myID.PSM30_MissedCleavage)))
        ratio_2 = str('{:.2%}'.format(two/len(self.dp.myID.PSM30_MissedCleavage)))
        ratio = [ratio_0,ratio_1,ratio_2]

        plt.rcParams.update({'font.size': 15})
        ax = fig.add_subplot(gs[0:4, 0:8])
        
        ax.bar(x=range(len(dimensions)), height=dimensions, tick_label=var_tic_168, width=0.4)
        ax.set_xlabel("Missed Cleavage Site", fontsize=15, fontname="arial", fontweight='bold')
        ax.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        
        
        
        
        
        for index, i in enumerate(ratio):
            ax.text(index, dimensions[index]+10, s=str(i), ha="center")

    def draw_PeptideLength(self,fig, gs):
        ax3 = fig.add_subplot(gs[0:4, 12:20])
        var_pep_109 = []
        for i in self.dp.myID.PSM4_SEQ:
            length = len(i)
            var_pep_109.append(length)
        var_max_50 = int(max(var_pep_109)) if max(var_pep_109) < 25 else 25
        ax3.hist(var_pep_109, edgecolor='k', color="steelblue",
                 bins=range(0, var_max_50, 1))  
        ax3.set_xlim(0, var_max_50)
        ax3.set_xticks(np.arange(0, var_max_50, 1))
        ax3.set_xlabel("Peptide Length", fontsize=15, fontname="arial", fontweight='bold')
        ax3.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        var_dat_163 = np.median(var_pep_109)
        
        
        
        
        
        
        
        
        ax3.spines['top'].set_visible(False)
        ax3.spines['right'].set_visible(False)


class CFunctionPlotC_5:
    def __init__(self, inputDP):
        self.dp = inputDP

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[0]
        print("Generating image " + str(var_sav_95) + ".png ......")
        self.init_fig()
        self.var_dra_23(self.fig, self.gs, self.dp.myID.PSM29_PeakWidth)
        self.draw_RT_Peakwidth(self.fig, self.gs, self.dp.myID.PSM3_RT, self.dp.myID.PSM29_PeakWidth,self.dp.myID.R2_GRADIENT)

        plt.savefig(var_sav_95 + '.png', format='png')
        
        plt.close()

    def init_fig(self):
        
        fig = plt.figure()
        fig.set_size_inches(20, 5, forward=True)
        self.gs = GridSpec(6, 20)  
        self.fig = fig

    def var_dra_23(self, fig, gs, peakwidth):
        
        ax1 = fig.add_subplot(gs[0:6, 0:8])
        duration = [round(x, 2) for x in peakwidth]
        ax1.hist(duration, edgecolor='k', color="steelblue", bins=np.arange(0, max(duration) + 1, 0.1))
        var_max_124 = max(duration) if max(duration)<3.0 else 3.0
        ax1.set_xlim(0, var_max_124)
        var_xlo_24 = MultipleLocator(0.2)
        ax1.xaxis.set_major_locator(var_xlo_24)
        
        ax1.set_xlabel("Full Width (min.)", fontsize=15, fontname="arial", fontweight='bold')
        ax1.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        plt.title("Histogram of Full Width of Chromatography", fontsize=15, fontname="arial", fontweight='bold')
        var_chr_157 = np.median(duration)
        plt.axvline(var_chr_157, 0, 1, color="r", linestyle="dashed")  
        ymaxlim = ax1.get_ylim()  
        ax1.text(var_chr_157 + 0.5, 0.85 * ymaxlim[1], ha="left", fontsize=12,
                 s="Median of full width \n= " + str(var_chr_157))  

        
        notail = 0
        for i in self.dp.myID.PSM29_PeakWidth:
            if i <= 1:
                notail += 1
        var_tai_141 = round((notail / len(self.dp.myID.PSM29_PeakWidth)) * 100,
                           2)  

        
        plt.axvline(1, 0, 0.4, color="r", linestyle="dashed")  
        ax1.annotate("", xytext=(1, 0.3 * ymaxlim[1]), xy=(1.5, 0.3 * ymaxlim[1]),  
                     arrowprops=dict(arrowstyle="->, head_length = 1.5, head_width = .5", facecolor="red"))
        ax1.text(1.4, 0.35 * ymaxlim[1], ha="center", fontsize=12,
                 s="Proportion of peptides\nwith full width > 1 min. = " +
                   str(round(100 - var_tai_141, 2)) + "%")

        
        ax1.spines['top'].set_visible(False)
        ax1.spines['right'].set_visible(False)

    def draw_RT_Peakwidth(self,fig, gs,RT,Peakwidth,Gradient):
        ax2 = fig.add_subplot(gs[0:6, 12:20])
        peakwidth = [round(x, 2) for x in Peakwidth]
        timesum = Gradient[0]
        if len(peakwidth) > 100000:
            step = int(len(RT)/5)
        elif len(peakwidth) > 50000:
            step = int(len(RT) / 3)
        else:
            step = 1

        ax2.scatter(RT[::step], peakwidth[::step], s=2)
        
        ax2.set_xlim(0, timesum + 3)
        ax2.set_xticks(np.arange(0, timesum + 3, int(0.1 * round(timesum))))
        ax2.set_xticklabels(np.arange(0, timesum + 3, int(0.1 * round(timesum))), fontsize=13,
                               fontname="Times New Roman")
        ax2.set_xlabel("Retention Time (min.)", fontsize=15, fontname="Times New Roman", fontweight='bold')

        
        ax2.set_ylim(0, 1.1)
        var_maj_169 = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        
        ax2.set_yticks(var_maj_169)
        ax2.set_yticklabels(var_maj_169, fontsize=13, fontname="Times New Roman")
        
        ax2.set_ylabel("Peakwidth(min)", fontsize=15, fontname="Times New Roman", fontweight='bold')

        
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)


class CFunctionPlotF_17:
    def __init__(self, inputDP):
        self.dp = inputDP

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[14]
        print("Generating image " + str(var_sav_95) + ".png ......")
        self.init_fig()
        self.var_dra_115(self.fig, self.gs, self.dp.myID.PSM28_FWHM)
        self.draw_FWHM_RT(self.fig, self.gs, self.dp.myID.PSM28_FWHM,self.dp.myID.PSM3_RT, self.dp.myID.R2_GRADIENT)

        plt.savefig(var_sav_95 + '.png', format='png')
        plt.close()

    def init_fig(self):
        
        fig = plt.figure()
        fig.set_size_inches(20, 5, forward=True)
        self.gs = GridSpec(6, 20)  
        self.fig = fig

    def var_dra_115(self, fig, gs, halfpeakwidth):
        
        ax = fig.add_subplot(gs[0:6, 0:8])
        halfduration = [round(x, 2) for x in halfpeakwidth]
        ax.hist(halfduration, edgecolor='k', color="steelblue", bins=np.arange(0, max(halfduration) + 1, 0.1))
        
        max_FWHM = max(halfduration) if max(halfduration)<3.0 else 3.0
        ax.set_xlim(0, max_FWHM)  
        var_xlo_24 = MultipleLocator(0.2)
        ax.xaxis.set_major_locator(var_xlo_24)
        
        ax.set_xlabel("FWHM (min.)", fontsize=15, fontname="arial", fontweight='bold')  
        ax.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)  
        plt.title("Histogram of Full Width at Half Maximum (FWHM) of Chromatography",
                  fontsize=15, fontname="arial", fontweight='bold')
        var_chr_157 = np.median(halfduration)
        plt.axvline(var_chr_157, 0, 1, color="r", linestyle="dashed")
        ymaxlim = ax.get_ylim()  
        ax.text(var_chr_157 + 0.5, 0.85 * ymaxlim[1], ha="left", fontsize=12,
                 s="Median of FWHM \n= " + str(var_chr_157))

        
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    def draw_FWHM_RT(self, fig, gs, halfpeakwidth,RT,Gradient):
        ax2 = fig.add_subplot(gs[0:6, 12:20])
        FWHM = [round(x, 2) for x in halfpeakwidth]
        timesum = Gradient[0]
        if len(FWHM) > 100000:
            step = int(len(RT) / 5)
        elif len(FWHM) > 50000:
            step = int(len(RT) / 3)
        else:
            step = 1

        ax2.scatter(RT[::step], FWHM[::step], s=2)
        
        ax2.set_xlim(0, timesum + 3)
        ax2.set_xticks(np.arange(0, timesum + 3, int(0.1 * round(timesum))))
        ax2.set_xticklabels(np.arange(0, timesum + 3, int(0.1 * round(timesum))), fontsize=13,
                            fontname="Times New Roman")
        ax2.set_xlabel("Retention Time (min.)", fontsize=15, fontname="Times New Roman", fontweight='bold')

        
        ax2.set_ylim(0, 1.1)
        var_maj_169 = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]
        
        ax2.set_yticks(var_maj_169)
        ax2.set_yticklabels(var_maj_169, fontsize=13, fontname="Times New Roman")
        
        ax2.set_ylabel("FWHM(min)", fontsize=15, fontname="Times New Roman", fontweight='bold')

        
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)


class CFunctionPlotS_8:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[1]
        print("Generating image " + str(var_sav_95) + ".png  ......")
        self.init_fig()
        self.var_dra_40(self.fig, self.gs, self.dp.myMS1.INDEX_SCAN_TIME_MS1, self.dp.myMS2.INDEX_SCAN_TIME_MS2)
        self.var_dra_99(self.fig, self.gs, self.dataMS1.INDEX_SCAN, self.dataMS2.INDEX_SCAN)
        plt.savefig(var_sav_95 + '.png', format='png')
        plt.savefig(var_sav_95 + '.svg', format='svg')
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(20, 6, forward=True)
        self.gs = GridSpec(6, 22)

    def var_dra_40(self, fig, gs, var_mss_126, var_mss_127):
        
        ax1 = fig.add_subplot(gs[0:6, 0:8])

        timesum1 = np.sum(var_mss_126)
        timesum2 = np.sum(var_mss_127)
        timeratio = [timesum1, timesum2]
        timelabels = ["Acquired Time (Sec.) MS1 scans", "Acquired Time (Sec.) MS2 scans"]

        def var_abs_53(val):
            a = np.round(val / 100. * (timesum1 + timesum2), 1)
            return a

        
        ax1.pie(timeratio, labels=None, autopct=var_abs_53,
                textprops={'fontsize': 15, 'color': 'white'})  
        
        ax1.legend(timelabels, loc="lower center", fontsize=15)

    def var_dra_99(self, fig, gs, ms1_scan, ms2_scan):
        
        ax2 = fig.add_subplot(gs[0:6, 14:22])

        xaxis = ["MS1", "MS2"]
        scan_no = [len(ms1_scan), len(ms2_scan)]
        
        ax2.bar(x=[2, 4], height=scan_no, width=0.8)

        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)
        ax2.spines['left'].set_visible(False)

        ax2.text(2, len(ms1_scan) + 2500, s=len(ms1_scan), ha='center', fontsize=15)
        ax2.text(4, len(ms2_scan) + 2500, s=len(ms2_scan), ha='center', fontsize=15)

        ax2.set_xlim(xmin=1, xmax=5)
        ax2.set_ylim(ymax=(len(ms2_scan) // 10000 + 1) * 10000)
        ax2.grid(axis="y", linestyle='-.')

        ax2.set_xticks([2, 4])
        
        ax2.set_xticklabels(xaxis, fontsize=15, fontname="arial")
        
        ax2.set_ylabel("Acquired Scans", fontsize=18, fontname="arial", fontweight='bold')


class CFunctionPlotM_20:
    def __init__(self, inputDP, inputDataMS1):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[2]
        print("Generating image " + str(var_sav_95) + ".png  ......")
        self.init_fig()
        self.draw_ms1(self.fig, self.gs, self.dataMS1.INDEX_RT, self.dp.myMS1.N_PEAKS_MS1,
                      self.dp.myMS1.INTENSITY_PEAKS_MS1)
        plt.savefig(var_sav_95 + '.png', format='png')
        plt.savefig(var_sav_95 + '.svg', format='svg')
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(20, 6, forward=True)
        self.gs = GridSpec(4, 24)

    
    def draw_ms1(self, fig, gs, ms1_RT, var_msp_7, var_msi_135):
        ax1 = fig.add_subplot(gs[1:4, 0:8])
        
        var_axm_65 = fig.add_subplot(gs[0, 0:8])
        var_axm_158 = fig.add_subplot(gs[1:4, 8:10])
        ms1_RT = [x / 60 for x in ms1_RT]
        ax1.scatter(ms1_RT, var_msp_7, s=3)

        ylimmax = round(1.1 * max(var_msp_7), -2)
        var_maj_87 = np.arange(0, ylimmax, 0.1 * ylimmax, dtype=int)
        var_min_47 = np.arange(0, ylimmax, 0.1 * ylimmax)
        if int(ms1_RT[-1]) > 10:
            x_ticks1 = np.arange(0, int(ms1_RT[-1] + 2), int(0.1 * ms1_RT[-1]))
        else:
            x_ticks1 = np.arange(0, int(ms1_RT[-1] + 2), 1)
        
        var_axm_65.hist(ms1_RT, rwidth=1, alpha=0.8, edgecolor='k', bins=x_ticks1)  
        var_axm_158.hist(var_msp_7, orientation="horizontal", rwidth=1, alpha=0.8, edgecolor='k', bins=var_maj_87)

        
        
        ax1.set_xlim(0, ms1_RT[-1] + 1)
        ax1.set_xticks(x_ticks1)  
        if int(ms1_RT[-1]) > 10:
            ax1.set_xticklabels(np.arange(0, int(ms1_RT[-1] + 2), int(0.1 * ms1_RT[-1])), fontsize=13)
        else:
            ax1.set_xticklabels(np.arange(0, int(ms1_RT[-1] + 2), 1), fontsize=13)
        ax1.set_xlabel("Retention Time (min.)", fontsize=15, fontname="arial", fontweight='bold')
        
        ax1.set_ylim(0, ylimmax)
        ax1.set_yticks(var_maj_87)
        ax1.set_yticks(var_min_47, minor=True)
        ax1.set_yticklabels(var_maj_87, fontsize=13)
        ax1.set_ylabel("# Peaks", fontsize=15, fontname="arial", fontweight='bold')
        
        ax1.grid(which='both')
        ax1.grid(which='minor', alpha=0.2)
        ax1.grid(which='major', alpha=0.5)
        
        ax1.spines['top'].set_visible(False)
        ax1.spines['right'].set_visible(False)

        
        y1 = var_axm_65.get_yticks()
        x1 = var_axm_158.get_xticks()
        var_axm_65.set_xlim(0, ms1_RT[-1] + 1)
        var_axm_65.set_xticks(x_ticks1)
        var_axm_65.set_yticks(np.arange(0, max(y1 + 20), max(y1) / 2))
        var_axm_158.set_ylim(0, ylimmax)
        var_axm_158.set_xticks(np.arange(0, max(x1 + 20), max(x1) / 2))
        var_axm_158.set_yticks(var_maj_87)
        
        plt.setp(var_axm_65.get_xticklabels(), visible=False)  
        plt.setp(var_axm_158.get_yticklabels(), visible=False)
        var_axm_65.tick_params(labelsize=13)
        var_axm_158.tick_params(labelsize=13, labelrotation=315)
        
        var_axm_158.spines['top'].set_visible(False)
        var_axm_158.spines['right'].set_visible(False)
        var_axm_65.spines['top'].set_visible(False)
        var_axm_65.spines['right'].set_visible(False)

        
        ax2 = fig.add_subplot(gs[1:4, 14:22])
        var_msi_135 = np.log10(var_msi_135)
        ax2.scatter(ms1_RT, var_msi_135, s=3)

        ylimmax2 = 1.1 * max(var_msi_135)
        var_maj_59 = np.arange(0, ylimmax2, 1, dtype=int)
        if int(ms1_RT[-1]) > 10:
            x_ticks1 = np.arange(0, int(ms1_RT[-1] + 2), int(0.1 * ms1_RT[-1]))
        else:
            x_ticks1 = np.arange(0, int(ms1_RT[-1] + 2), 1)

        
        
        ax2.set_xlim(0, ms1_RT[-1] + 1)
        ax2.set_xticks(x_ticks1)  
        ax2.set_xticklabels(x_ticks1, fontsize=13)
        ax2.set_xlabel("Retention Time (min.)", fontsize=15, fontname="arial", fontweight='bold')
        
        ax2.set_ylim(0, ylimmax2)
        ax2.set_yticks(var_maj_59)
        ax2.set_yticklabels(var_maj_59, fontsize=13)
        ax2.set_ylabel("$log_{10}$ Sum of peak intensities \n in one MS1 scan",
                       fontsize=15, fontname="arial", fontweight='bold')
        
        
        
        
        

        
        ax2.grid(which='both')
        ax2.grid(which='minor', alpha=0.2)
        ax2.grid(which='major', alpha=0.5)
        
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)

        
        var_axm_19 = fig.add_subplot(gs[0, 14:22])
        var_axm_46 = fig.add_subplot(gs[1:4, 22:24])
        var_axm_19.hist(ms1_RT, rwidth=1, alpha=0.8, edgecolor='k', bins=x_ticks1)  
        var_axm_46.hist(var_msi_135, orientation="horizontal",
                        rwidth=1, alpha=0.8, edgecolor='k', bins=var_maj_59)

        
        y1 = var_axm_19.get_yticks()
        x1 = var_axm_46.get_xticks()
        var_axm_19.set_xlim(0, ms1_RT[-1] + 1)
        var_axm_19.set_xticks(x_ticks1)
        var_axm_19.set_yticks(np.arange(0, max(y1 + 20), max(y1) / 2))

        var_axm_46.set_ylim(0, 1.15 * max(var_msi_135))
        var_axm_46.set_xticks(np.arange(0, max(x1 + 20), max(x1) / 2))
        var_axm_46.set_yticks(var_maj_59)
        ax = plt.gca()  
        ax.yaxis.get_major_formatter().set_powerlimits((0, 0))  
        ax.yaxis.offsetText.set_visible(False)  

        var_axm_19.tick_params(labelsize=13)  
        var_axm_46.tick_params(labelsize=13, labelrotation=340)
        plt.setp(var_axm_19.get_xticklabels(), visible=False)  
        plt.setp(var_axm_46.get_yticklabels(), visible=False)
        var_axm_46.spines['top'].set_visible(False)
        var_axm_46.spines['right'].set_visible(False)
        var_axm_19.spines['top'].set_visible(False)
        var_axm_19.spines['right'].set_visible(False)


class CFunctionPlotM_2:
    def __init__(self, inputDP, inputDataMS2):
        self.dp = inputDP
        self.dataMS2 = inputDataMS2

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[3]
        print("Generating image " + str(var_sav_95) + ".png ......")
        self.init_fig()
        self.draw_ms2(self.fig, self.gs, self.dataMS2.INDEX_RT, self.dp.myMS2.N_PEAKS_MS2,
                      self.dp.myMS2.INTENSITY_PEAKS_MS2)
        plt.savefig(var_sav_95 + '.png', format='png')
        plt.savefig(var_sav_95 + '.svg', format='svg')
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(20, 6, forward=True)
        self.gs = GridSpec(4, 24)

    
    def draw_ms2(self, fig, gs, ms2_RT, var_msp_150, var_msi_88):
        ax1 = fig.add_subplot(gs[1:4, 0:8])
        
        var_axm_65 = fig.add_subplot(gs[0, 0:8])
        var_axm_158 = fig.add_subplot(gs[1:4, 8:10])
        ms2_RT = [x / 60 for x in ms2_RT]
        ax1.scatter(ms2_RT, var_msp_150, s=3)

        ylimmax = round(1.1 * max(var_msp_150), -2)
        var_maj_87 = np.arange(0, ylimmax, 0.1 * ylimmax, dtype=int)
        var_min_47 = np.arange(0, ylimmax, 0.1 * ylimmax)
        if int(ms2_RT[-1]) > 10:
            x_ticks1 = np.arange(0, int(ms2_RT[-1]) + 2, int(0.1 * ms2_RT[-1]))
        elif int(ms2_RT[-1]) <= 10:
            x_ticks1 = np.arange(0, int(ms2_RT[-1]) + 2, 1)
        
        var_axm_65.hist(ms2_RT, rwidth=1, alpha=0.8, edgecolor='k', bins=x_ticks1)  
        var_axm_158.hist(var_msp_150, orientation="horizontal", rwidth=1, alpha=0.8, edgecolor='k', bins=var_maj_87)

        
        
        ax1.set_xlim(0, ms2_RT[-1] + 1)
        ax1.set_xticks(x_ticks1)  
        if int(ms2_RT[-1]) > 10:
            ax1.set_xticklabels(np.arange(0, int(ms2_RT[-1]) + 2, int(0.1 * ms2_RT[-1])), fontsize=13)
        else:
            ax1.set_xticklabels(np.arange(0, int(ms2_RT[-1]) + 2, 1), fontsize=13)
        ax1.set_xlabel("Retention Time (min.)", fontsize=15, fontname="arial", fontweight='bold')
        
        ax1.set_ylim(0, ylimmax)
        ax1.set_yticks(var_maj_87)
        ax1.set_yticks(var_min_47, minor=True)
        ax1.set_yticklabels(var_maj_87, fontsize=13)
        ax1.set_ylabel("# Peaks", fontsize=15, fontname="arial", fontweight='bold')
        
        ax1.grid(which='both')
        ax1.grid(which='minor', alpha=0.2)
        ax1.grid(which='major', alpha=0.5)
        
        ax1.spines['top'].set_visible(False)
        ax1.spines['right'].set_visible(False)

        
        y1 = var_axm_65.get_yticks()
        x1 = var_axm_158.get_xticks()
        var_axm_65.set_xlim(0, ms2_RT[-1] + 1)
        var_axm_65.set_xticks(x_ticks1)
        var_axm_65.set_yticks(np.arange(0, max(y1 + 20), max(y1) / 2))
        var_axm_158.set_ylim(0, ylimmax)
        var_axm_158.set_xticks(np.arange(0, max(x1 + 20), max(x1) / 2))
        var_axm_158.set_yticks(var_maj_87)
        
        plt.setp(var_axm_65.get_xticklabels(), visible=False)  
        plt.setp(var_axm_158.get_yticklabels(), visible=False)
        var_axm_65.tick_params(labelsize=13)
        var_axm_158.tick_params(labelsize=13, labelrotation=315)
        
        var_axm_158.spines['top'].set_visible(False)
        var_axm_158.spines['right'].set_visible(False)
        var_axm_65.spines['top'].set_visible(False)
        var_axm_65.spines['right'].set_visible(False)

        
        ax2 = fig.add_subplot(gs[1:4, 14:22])
        var_msi_88 = np.log10(var_msi_88)
        ax2.scatter(ms2_RT, var_msi_88, s=3)

        ylimmax2 = 1.1 * max(var_msi_88)
        var_maj_59 = np.arange(0, ylimmax2, 1, dtype=int)
        if int(ms2_RT[-1]) > 10:
            x_ticks1 = np.arange(0, int(ms2_RT[-1]) + 2, int(0.1 * ms2_RT[-1]))
        else:
            x_ticks1 = np.arange(0, int(ms2_RT[-1]) + 2, 1)

        
        
        ax2.set_xlim(0, ms2_RT[-1] + 1)
        ax2.set_xticks(x_ticks1)  
        ax2.set_xticklabels(x_ticks1, fontsize=13)
        ax2.set_xlabel("Retention Time (min.)", fontsize=15, fontname="arial", fontweight='bold')
        
        ax2.set_ylim(0, ylimmax2)
        ax2.set_yticks(var_maj_59)
        ax2.set_yticklabels(var_maj_59, fontsize=13)
        ax2.set_ylabel("$log_{10}$ Sum of peak intensities \n in one MS2 scan",
                       fontsize=15, fontname="arial", fontweight='bold')
        
        
        
        
        

        
        ax2.grid(which='both')
        ax2.grid(which='minor', alpha=0.2)
        ax2.grid(which='major', alpha=0.5)
        
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)

        
        var_axm_19 = fig.add_subplot(gs[0, 14:22])
        var_axm_46 = fig.add_subplot(gs[1:4, 22:24])
        var_axm_19.hist(ms2_RT, rwidth=1, alpha=0.8, edgecolor='k', bins=x_ticks1)  
        var_axm_46.hist(var_msi_88, orientation="horizontal",
                        rwidth=1, alpha=0.8, edgecolor='k', bins=var_maj_59)

        
        y1 = var_axm_19.get_yticks()
        x1 = var_axm_46.get_xticks()
        var_axm_19.set_xlim(0, ms2_RT[-1] + 1)
        var_axm_19.set_xticks(x_ticks1)
        var_axm_19.set_yticks(np.arange(0, max(y1 + 20), max(y1) / 2))

        var_axm_46.set_ylim(0, 1.15 * max(var_msi_88))
        var_axm_46.set_xticks(np.arange(0, max(x1 + 20), max(x1) / 2))
        var_axm_46.set_yticks(var_maj_59)
        ax = plt.gca()  
        ax.yaxis.get_major_formatter().set_powerlimits((0, 0))  
        ax.yaxis.offsetText.set_visible(False)  

        var_axm_19.tick_params(labelsize=13)  
        var_axm_46.tick_params(labelsize=13, labelrotation=340)
        plt.setp(var_axm_19.get_xticklabels(), visible=False)  
        plt.setp(var_axm_46.get_yticklabels(), visible=False)
        var_axm_46.spines['top'].set_visible(False)
        var_axm_46.spines['right'].set_visible(False)
        var_axm_19.spines['top'].set_visible(False)
        var_axm_19.spines['right'].set_visible(False)


class CFunctionPlotI_18:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[4]
        print("Generating image " + str(var_sav_95) + ".png ......")
        self.init_fig()
        self.var_dra_125(self.fig, self.gs, self.dp.myMS1.INDEX_ION_INJECTION_TIME)
        self.var_dra_166(self.fig, self.gs, self.dp.myMS2.INDEX_ION_INJECTION_TIME)
        plt.savefig(var_sav_95 + '.png', format='png')
        
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(20, 6, forward=True)
        self.gs = GridSpec(4, 20)

    def var_dra_125(self, fig, gs, var_msi_73):
        
        ax3 = fig.add_subplot(gs[0:4, 0:8])
        ax3.hist(var_msi_73, edgecolor='k', color="steelblue", bins=range(0, 60, 2))
        ax3.set_xlim(0, 61)
        ax3.set_xticks(np.arange(0, 61, 10))
        ax3.set_xlabel("MS1 Ion Injection Time (ms.)", fontsize=15, fontname="arial", fontweight='bold')
        ax3.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        
        ax3.spines['top'].set_visible(False)
        ax3.spines['right'].set_visible(False)

    def var_dra_166(self, fig, gs, var_msi_133):
        
        ax4 = fig.add_subplot(gs[0:4, 12:20])
        ax4.hist(var_msi_133, edgecolor='k', color="steelblue", bins=range(0, 60, 2))
        ax4.set_xlim(0, 61)
        ax4.set_xticks(np.arange(0, 61, 10))
        ax4.set_xlabel("MS2 Ion Injection Time (ms.)", fontsize=15, fontname="arial", fontweight='bold')
        ax4.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        ax4.spines['top'].set_visible(False)
        ax4.spines['right'].set_visible(False)


class CFunctionPlotM_19:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[5]
        print("Generating image " + str(var_sav_95) + ".png ......")
        self.init_fig()
        var_axm_159, var_axm_111, ax_joint = self.var_dra_177(self.fig, self.gs, self.dp.myCYCLE.LIST_CYCLES_TIME,
                                                            self.dp.myCYCLE.LIST_CYCLES_N_MS2)
        self.set_ax(var_axm_159, var_axm_111, ax_joint, self.dp.myCYCLE.LIST_CYCLES_TIME, self.dp.myCYCLE.LIST_CYCLES_N_MS2)
        self.draw_acc(self.fig, self.gs, self.dp.myMS1.INDEX_SCAN_TIME_MS1, self.dp.myMS2.INDEX_SCAN_TIME_MS2,
                      self.dataMS1.INDEX_RT, self.dp.myCYCLE.LIST_CYCLES_N_MS2)
        plt.savefig(var_sav_95 + '.png', format='png')
        
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(20, 6, forward=True)
        self.gs = GridSpec(4, 24)

    def var_dra_177(self, fig, gs, var_msd_61, ms3_pic):
        
        ax_joint = fig.add_subplot(gs[1:4, 0:8])  
        var_axm_159 = fig.add_subplot(gs[0, 0:8])  
        var_axm_111 = fig.add_subplot(gs[1:4, 8:10])

        ax_joint.scatter(var_msd_61, ms3_pic, s=10)
        x_ticks1 = np.arange(0, max(max(var_msd_61) + 0.5, 3.6), 0.25)
        y_ticks = np.arange(0, max(max(ms3_pic) + 3, 51), 5)
        var_axm_159.hist(var_msd_61, rwidth=1, alpha=0.8, edgecolor='k', bins=x_ticks1)  
        var_axm_111.hist(ms3_pic, orientation="horizontal", rwidth=1, alpha=0.8, edgecolor='k', bins=y_ticks)

        return var_axm_159, var_axm_111, ax_joint

    def set_ax(self, var_axm_159, var_axm_111, ax_joint, var_msd_61, ms3_pic):
        
        x_ticks = np.arange(0, max(max(var_msd_61) + 0.5, 3.6), 0.5)
        y_ticks = np.arange(0, max(max(ms3_pic) + 3, 51), 5)
        ax_joint.set_xticks(x_ticks)
        ax_joint.set_yticks(y_ticks)
        ax_joint.grid(which='major', alpha=0.5)

        
        y1 = var_axm_159.get_yticks()
        x1 = var_axm_111.get_xticks()
        var_axm_159.set_xticks(x_ticks)
        var_axm_159.set_yticks(np.arange(0, max(y1 + 20), max(y1) / 2))
        var_axm_111.set_xticks(np.arange(0, max(x1 + 20), max(x1) / 2))
        var_axm_111.set_yticks(y_ticks)

        
        plt.setp(var_axm_159.get_xticklabels(), visible=False)  
        plt.setp(var_axm_111.get_yticklabels(), visible=False)

        
        ax_joint.tick_params("x", labelsize=13, labelrotation=315)
        ax_joint.tick_params("y", labelsize=13)
        var_axm_159.tick_params(labelsize=13)
        var_axm_111.tick_params(labelsize=13, labelrotation=315)

        ax_joint.set_xlabel("Time of One Cycle (Sec.)", fontname="arial", fontsize=15, fontweight='bold')
        ax_joint.set_ylabel("MS2 Scans in One Cycle", fontname="arial", fontsize=15, fontweight='bold')

        var_axm_111.spines['top'].set_visible(False)
        var_axm_111.spines['right'].set_visible(False)
        var_axm_159.spines['top'].set_visible(False)
        var_axm_159.spines['right'].set_visible(False)

    def draw_acc(self, fig, gs, var_mss_126, var_mss_127, ms2_RT, N_MS2):
        
        ax_acc2 = fig.add_subplot(gs[0:4, 14:24])
        ms2_RT = [x / 60 for x in ms2_RT]
        ms3_RT = ms2_RT[0:-1]
        ax_acc2.scatter(ms3_RT, N_MS2, s=3)  

        
        timesum1 = np.sum(var_mss_126)
        timesum2 = np.sum(var_mss_127)
        timesum = int((timesum2 + timesum1) / 60)

        ax_acc2.set_xlim(0, timesum + 3)
        if timesum > 10:
            ax_acc2.set_xticks(np.arange(0, timesum + 3, int(0.1 * round(timesum))))  
            ax_acc2.set_xticklabels(np.arange(0, timesum + 3, int(0.1 * round(timesum))), fontsize=13)
        else:
            ax_acc2.set_xticks(np.arange(0, timesum + 6, 1))  
            ax_acc2.set_xticklabels(np.arange(0, timesum + 6, 1), fontsize=13)
        ax_acc2.set_xlabel("Retention Time (min.)", fontsize=15, fontname="arial", fontweight='bold')

        
        ax_acc2.set_ylim(0, max(N_MS2) + 2)
        var_maj_59 = np.arange(0, max(N_MS2) + 2, 10, dtype=int)
        var_min_70 = np.arange(0, max(N_MS2) + 2, 2)
        ax_acc2.set_yticks(var_maj_59)
        ax_acc2.set_yticks(var_min_70, minor=True)
        ax_acc2.set_yticklabels(var_maj_59, fontsize=13)
        ax_acc2.set_ylabel("Acquired MS2 Scans in One Cycle", fontsize=15, fontname="arial", fontweight='bold')

        
        ax_acc2.grid(which='both')
        ax_acc2.grid(which='minor', alpha=0.2)
        ax_acc2.grid(which='major', alpha=0.5)

        
        ax_acc2.spines['top'].set_visible(False)
        ax_acc2.spines['right'].set_visible(False)


class CFunctionPlotD_4:
    def __init__(self, inputDP,inputDataMS1,inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[6]
        print("Generating image " + str(var_sav_95) + ".png ......")
        self.init_fig()
        self.var_dra_68(self.fig, self.gs, self.dp.myID.PSM32_DataPoint_MS1)
        self.var_dra_174(self.fig, self.gs, self.dp.myID.PSM24_DataPoint)
        plt.savefig(var_sav_95 + '.png', format='png')
        plt.savefig(var_sav_95 + '.svg', format='svg')
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(20, 6, forward=True)
        self.gs = GridSpec(4, 20)

    def var_dra_68(self, fig, gs, var_msd_116):
        
        ax3 = fig.add_subplot(gs[0:4, 0:8])
        var_max_175 = int(max(var_msd_116)) if max(var_msd_116) < 50 else 50
        ax3.hist(var_msd_116, edgecolor='k', color="steelblue", bins=range(0, var_max_175, 1))
        ax3.set_xlim(0, var_max_175 + 2)
        ax3.set_xticks(np.arange(0, var_max_175, 4))
        ax3.set_xlabel("MS1 data point per peak(DPPP)", fontsize=15, fontname="arial", fontweight='bold')
        ax3.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        var_dat_163 = np.median(var_msd_116)
        plt.axvline(var_dat_163 + 0.5, 0, 1, color="r", linestyle="dashed")  
        ymaxlim = ax3.get_ylim()  
        ax3.text(var_dat_163 + 0.5, 0.85 * ymaxlim[1], ha="left", fontsize=12,
                 s="Median of MS1 DPPP \n= " + str(var_dat_163))  
        plt.tick_params(labelsize=13)
        
        ax3.spines['top'].set_visible(False)
        ax3.spines['right'].set_visible(False)

    def var_dra_174(self, fig, gs, var_msd_132):
        
        ax4 = fig.add_subplot(gs[0:4, 12:20])
        var_max_173 = int(max(var_msd_132)) if max(var_msd_132) < 50 else 50
        ax4.hist(var_msd_132, edgecolor='k', color="steelblue", bins=range(0, var_max_173, 1))
        ax4.set_xlim(0, var_max_173 + 2)
        ax4.set_xticks(np.arange(0, var_max_173, 2))
        ax4.set_xlabel("MS2 data point per peak", fontsize=15, fontname="arial", fontweight='bold')
        ax4.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        var_dat_163 = np.median(var_msd_132)
        plt.axvline(var_dat_163 + 0.5, 0, 1, color="r", linestyle="dashed")  
        ymaxlim = ax4.get_ylim()  
        ax4.text(var_dat_163 + 0.5, 0.85 * ymaxlim[1], ha="left", fontsize=12,
                 s="Median of MS2 DPPP \n= " + str(var_dat_163))  
        plt.tick_params(labelsize=13)
        ax4.spines['top'].set_visible(False)
        ax4.spines['right'].set_visible(False)


class CFunctionPlotP_12:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[7]
        print("Generating image " + str(var_sav_95) + ".png ......")
        self.init_fig()
        self.var_dra_31(self.fig, self.gs, self.dp.myID.SCAN_REDUNDANCE)
        
        self.var_dra_176(self.fig, self.gs, self.dp.myID.SCAN_TO_PEPTIDE)
        plt.savefig(var_sav_95 + '.png', format='png')
        plt.savefig(var_sav_95 + '.svg', format='svg')
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(20, 6, forward=True)
        self.gs = GridSpec(4, 20)

    def var_dra_31(self, fig, gs, var_pep_134):
        ax3 = fig.add_subplot(gs[0:4, 0:8])
        max_scan = int(max(var_pep_134)) if max(var_pep_134)<25 else 25
        ax3.hist(var_pep_134, edgecolor='k', color="steelblue", bins=range(0, max_scan, 1))  
        ax3.set_xlim(0, max_scan)
        ax3.set_xticks(np.arange(0, max_scan, 1))
        ax3.set_xlabel("precursor identified repeatedly in scans", fontsize=15, fontname="arial", fontweight='bold')
        ax3.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        var_dat_28 = np.mean(var_pep_134)
        plt.axvline(var_dat_28, 0, 1, color="r", linestyle="dashed")  
        ymaxlim = ax3.get_ylim()  
        ax3.text(var_dat_28, 0.85 * ymaxlim[1], ha="left", fontsize=12,
                 s="Mean of redundant scan number \n= " + str(round(var_dat_28,2)))  
        plt.tick_params(labelsize=13)
        plt.title("Histogram of redundant scan number",
                  fontsize=15, fontname="arial", fontweight='bold')
        
        ax3.spines['top'].set_visible(False)
        ax3.spines['right'].set_visible(False)

    def var_dra_48(self, fig, gs, var_one_102):
        ax4 = fig.add_subplot(gs[0:4, 12:20])
        var_max_129 = int(max(var_one_102))
        ax4.hist(var_one_102, edgecolor='k', color="steelblue", bins=range(0, var_max_129, 1))
        ax4.set_xlim(0, var_max_129 + 2)
        ax4.set_xticks(np.arange(0, var_max_129, 2))
        ax4.set_xlabel("Identified precursors number in one scan", fontsize=15, fontname="arial", fontweight='bold')
        ax4.set_ylabel("Frequency", fontsize=15, fontname="arial", fontweight='bold')
        var_dat_28 = np.mean(var_one_102)
        plt.axvline(var_dat_28, 0, 1, color="r", linestyle="dashed")  
        ymaxlim = ax4.get_ylim()  
        ax4.text(var_dat_28, 0.85 * ymaxlim[1], ha="left", fontsize=12,
                 s="Median of Spectral complexity \n= " + str(round(var_dat_28,2)))  
        plt.tick_params(labelsize=13)
        ax4.spines['top'].set_visible(False)
        ax4.spines['right'].set_visible(False)

    def var_dra_176(self, fig, gs, var_one_102):
        ax4 = fig.add_subplot(gs[0:4, 12:20])
        var_max_129 = 10
        ax4.hist(var_one_102, edgecolor='k', color="steelblue",
                 weights=[1. / len(var_one_102)] * len(var_one_102),  
                 bins=np.arange(0, var_max_129, 1))  

        
        ax4.set_xlim(0, var_max_129+1)  
        
        ax4.set_xticks(np.arange(0, var_max_129+1, 1))  
        ax4.set_xlabel("Identified precursors number in one scan", fontsize=15, fontname="arial", fontweight='bold')
        ax4.set_ylim(0, 1)
        ax4.set_yticks(np.arange(0, 1.1, 0.1))
        ax4.set_ylabel("Proportion", fontsize=15, fontname="arial", fontweight='bold')
        var_dat_28 = np.mean(var_one_102)
        plt.axvline(var_dat_28, 0, 1, color="r", linestyle="dashed")  
        ymaxlim = ax4.get_ylim()  
        ax4.text(var_dat_28, 0.85 * ymaxlim[1], ha="left", fontsize=12,
                 s="Mean of Spectral complexity \n= " + str(round(var_dat_28,2)))  
        plt.tick_params(labelsize=13)
        plt.title("Histogram of Spectral Complexity", fontsize=15,
                  fontname="arial", fontweight='bold')
        ax4.spines['top'].set_visible(False)
        ax4.spines['right'].set_visible(False)


class CFunctionPlotM_16:
    def __init__(self, inputDP):
        self.dp = inputDP
        
        

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[8]
        print("Generating image " + str(var_sav_95) + ".png......")
        self.init_fig()
        self.var_dra_110(self.fig, self.gs, self.dp.myID.PSM26_MS1_MassAccuracy)
        self.draw_devID(self.fig, self.gs, self.dp.myID.PSM3_RT, self.dp.myID.PSM26_MS1_MassAccuracy)
        self.var_dra_8(self.fig, self.gs, self.dp.myID.PSM3_RT, self.dp.myID.PSM12_SCORE2,
                           self.dp.myID.PSM26_MS1_MassAccuracy)
        plt.savefig(var_sav_95 + '.png', format='png')
        plt.savefig(var_sav_95 + '.svg', format='svg')
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(22, 5)
        self.gs = GridSpec(4, 32)

    def var_dra_110(self, fig, gs, absdev1):
        
        ax3 = fig.add_subplot(gs[0:4, 0:8])
        absdev = np.array(absdev1)[~np.isnan(absdev1)]  
        ax3.hist(absdev, edgecolor='k', color="steelblue", bins=np.arange(min(absdev), max(absdev), 0.25),
                 weights=[1. / len(absdev)] * len(absdev))  
        var_mea_43 = round(np.mean(absdev), 3)  
        var_std_138 = round(np.std(absdev, ddof=1),3)  
        
        
        plt.axvline(var_mea_43, 0, 1, color="r", linestyle="dashed")
        ymaxlim = ax3.get_ylim()  
        ax3.text(var_mea_43 + 1, 0.75 * ymaxlim[1], ha="left", fontsize=12,
                 s="Mean MS1 MassAccuracy \n= " + str(var_mea_43) + "±" + str(var_std_138), )
        
        ax3.set_xlabel("MS1 MassAccuracy (ppm)", fontsize=15, fontname="arial", fontweight='bold')
        ax3.set_ylabel("Proportion", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        plt.title("MS1 MassAccuracy",
                  fontsize=15, fontname="arial", fontweight='bold')

        ax3.spines['top'].set_visible(False)
        ax3.spines['right'].set_visible(False)

    def draw_devID(self, fig, gs, RT, absdev1):
        
        ax4 = fig.add_subplot(gs[0:4, 24:32])
        absdev = np.nan_to_num(absdev1)  
        ax4.scatter(RT, absdev, color="steelblue", s=[10] * len(RT))  
        
        ax4fitcoef = np.polyfit(RT, absdev, 1)  
        ax4fit = np.poly1d(ax4fitcoef)
        ax4.plot(RT, ax4fit(RT), c='r', label="Fitting trend")
        
        plt.axhline(0, 0, 1, color="r", linestyle="dashed", label="Standard")
        
        ax4.set_xlabel("Scan ID", fontsize=15, fontname="arial", fontweight='bold')
        ax4.set_ylabel("#MS1 MassAccuracy (ppm)", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        plt.legend(loc='upper left')
        plt.title("Relationship between MS1 Mass Accuracy and RT",
                  fontsize=15, fontname="arial", fontweight='bold')

        ax4.spines['top'].set_visible(False)
        ax4.spines['right'].set_visible(False)

    def var_dra_8(self, fig, gs, RT, devgrade1, absdev1):
        
        ax5 = fig.add_subplot(gs[0:4, 12:20])
        absdev = np.nan_to_num(absdev1)
        devgrade2 = [1e-10 if i == 0. else i for i in devgrade1]
        devgrade = [-math.log10(x) for x in devgrade2]
        ax5.scatter(absdev, devgrade, color="steelblue", s=[10] * len(RT))
        
        
        
        
        
        plt.axvline(0, 0, 1, color="r", linestyle="dashed", label="Standard")
        
        ax5.set_ylabel("$-log_{10}$Score", fontsize=15, fontname="arial", fontweight='bold')
        ax5.set_xlabel("#MS1 MassAccuracy (ppm)", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        plt.legend(loc='upper right')
        plt.title("Relationship between MS1 MassAccuracy and Score",
                  fontsize=15, fontname="arial", fontweight='bold')

        ax5.spines['top'].set_visible(False)
        ax5.spines['right'].set_visible(False)


class CFunctionPlotM_9:
    def __init__(self, inputDP):
        self.dp = inputDP
        
        

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[9]
        print("Generating image " + str(var_sav_95) + ".png......")
        self.init_fig()
        self.var_dra_110(self.fig, self.gs, self.dp.myID.PSM27_MS2_MassAccuracy)
        self.draw_devID(self.fig, self.gs, self.dp.myID.PSM3_RT, self.dp.myID.PSM27_MS2_MassAccuracy)
        self.var_dra_8(self.fig, self.gs, self.dp.myID.PSM3_RT, self.dp.myID.PSM12_SCORE2,
                           self.dp.myID.PSM27_MS2_MassAccuracy)
        plt.savefig(var_sav_95 + '.png', format='png')
        
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(22, 5)
        self.gs = GridSpec(4, 32)

    def var_dra_110(self, fig, gs, absdev1):
        
        ax3 = fig.add_subplot(gs[0:4, 0:8])
        absdev = np.nan_to_num(absdev1)
        ax3.hist(absdev, edgecolor='k', color="steelblue", bins=np.arange(min(absdev), max(absdev), 0.25),
                 weights=[1. / len(absdev)] * len(absdev))  
        var_mea_43 = round(np.mean(absdev), 3)  
        var_std_138 = round(np.std(absdev, ddof=1),3)  
        
        
        plt.axvline(var_mea_43, 0, 1, color="r", linestyle="dashed")
        ymaxlim = ax3.get_ylim()  
        ax3.text(var_mea_43 + 1, 0.75 * ymaxlim[1], ha="left", fontsize=12,
                 s="Mean MS2 MassAccuracy \n= " + str(var_mea_43) + "±" + str(var_std_138), )
        
        ax3.set_xlabel("MS2 MassAccuracy (ppm)", fontsize=15, fontname="arial", fontweight='bold')
        ax3.set_ylabel("Proportion", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        plt.title("MS2 MassAccuracy",
                  fontsize=15, fontname="arial", fontweight='bold')

        ax3.spines['top'].set_visible(False)
        ax3.spines['right'].set_visible(False)

    def draw_devID(self, fig, gs, RT, absdev1):
        
        ax4 = fig.add_subplot(gs[0:4, 24:32])
        absdev = np.nan_to_num(absdev1)
        ax4.scatter(RT, absdev, color="steelblue", s=[1] * len(RT))
        
        ax4fitcoef = np.polyfit(RT, absdev, 1)  
        ax4fit = np.poly1d(ax4fitcoef)
        ax4.plot(RT, ax4fit(RT), c='r', label="Fitting trend")
        
        plt.axhline(0, 0, 1, color="r", linestyle="dashed", label="Standard")
        
        ax4.set_xlabel("RT(min.)", fontsize=15, fontname="arial", fontweight='bold')
        ax4.set_ylabel("#MS2 MassAccuracy (ppm)", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        plt.legend(loc='upper left')
        plt.title("Relationship between MS2 Mass Accuracy and RT",
                  fontsize=15, fontname="arial", fontweight='bold')

        ax4.spines['top'].set_visible(False)
        ax4.spines['right'].set_visible(False)

    def var_dra_8(self, fig, gs, RT, devgrade1, absdev1):
        
        ax5 = fig.add_subplot(gs[0:4, 12:20])
        absdev = np.nan_to_num(absdev1)
        devgrade2 = [1e-10 if i == 0.0 else i for i in devgrade1]
        devgrade = [-math.log10(x) for x in devgrade2]
        ax5.scatter(absdev, devgrade, color="steelblue", s=[10] * len(RT))
        
        
        
        
        
        plt.axvline(0, 0, 1, color="r", linestyle="dashed", label="Standard")
        
        ax5.set_ylabel("$-log_{10}$Score", fontsize=15, fontname="arial", fontweight='bold')
        ax5.set_xlabel("#MS2 MassAccuracy (ppm)", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        plt.legend(loc='upper right')
        plt.title("Relationship between MS2 MassAccuracy and Score",
                  fontsize=15, fontname="arial", fontweight='bold')

        ax5.spines['top'].set_visible(False)
        ax5.spines['right'].set_visible(False)


class CFunctionPlotT_13:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[10]
        print("Generating image " + str(var_sav_95) + ".png......")
        self.init_fig()
        self.draw_acc(self.fig, self.gs, self.dp.myMS1.INDEX_SCAN_TIME_MS1, self.dp.myMS2.INDEX_SCAN_TIME_MS2,
                      self.dataMS2.INDEX_SCAN, self.dataMS2.INDEX_RT, self.dp.myID.PSM3_RT,
                      self.dp.myID.PSM31_Precursor, self.dp.myID.SCAN_TO_PEPTIDE)
        plt.savefig(var_sav_95 + '.png', format='png')
        
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(10, 6, forward=True)
        self.gs = GridSpec(6, 10)

    def draw_acc(self, fig, gs, var_mss_126, var_mss_127, ms2_scan, ms2_rt, pep_rt3, pep_ac, scan_num):

        
        timesum1 = np.sum(var_mss_126)
        timesum2 = np.sum(var_mss_127)
        timesum = int((timesum2 + timesum1) / 60)

        
        ax_acc = fig.add_subplot(gs[0:6, 0:10])

        
        Ac_scan = []
        for i in range(1, len(ms2_scan) + 1, 1):
            Ac_scan.append(i / 10000)
        Ac_RT = [i / 60 for i in ms2_rt]

        
        a = np.array(list(zip(ms2_scan, scan_num, ms2_rt)))
        var_Idm_13 = a[np.all(a != 0, axis=1)]  
        Id_ms2_RT = var_Idm_13[:, 2]
        var_Idm_38 = var_Idm_13[:, 0]
        Id_scan = []
        for i in range(1, len(var_Idm_38) + 1, 1):
            Id_scan.append(i / 10000)
        Id_ms2_RT = [i / 60 for i in Id_ms2_RT]

        
        Id_pep = []
        for i in range(1, len(pep_ac) + 1, 1):
            Id_pep.append(i / 10000)
        pep_rt = sorted(pep_rt3)

        ax_acc.plot(Ac_RT, Ac_scan, c="black", label="Acquired MS2 Scans")
        ax_acc.plot(Id_ms2_RT, Id_scan, c="red", label="Identified MS2 Scans")
        ax_acc.plot(pep_rt, Id_pep, c="blue", label="Identified Precursors")
        plt.legend()

        
        
        

        
        ax_acc.set_xlim(0, timesum + 2)
        if timesum > 10:
            ax_acc.set_xticks(np.arange(0, timesum + 2, int(0.1 * round(timesum))))
            ax_acc.set_xticklabels(np.arange(0, timesum + 2, int(0.1 * round(timesum))), fontsize=13)
        else:
            ax_acc.set_xticks(np.arange(0, timesum + 2, 1))
            ax_acc.set_xticklabels(np.arange(0, timesum + 2, 1), fontsize=13)
        ax_acc.set_xlabel("Retention Time (min.)", fontsize=15, fontname="arial", fontweight='bold')

        
        
        
        
        
        
        

        
        ax_acc.set_ylim(0, Ac_scan[-1] + 1)
        max_y = max(Ac_scan[-1], Id_scan[-1], Id_pep[-1])
        var_maj_169 = np.arange(0, max_y + 1, 0.5)
        var_min_105 = np.arange(0, max_y + 1, 0.1)
        ax_acc.set_yticks(var_maj_169)
        ax_acc.set_yticklabels(var_maj_169, fontsize=13)
        ax_acc.set_yticks(var_min_105, minor=True)
        ax_acc.set_ylabel("Accumulated Number of MS2 Scans / Peptides", fontsize=15, fontname="arial",
                          fontweight='bold')

        
        ax_acc.grid(which='both')
        ax_acc.grid(which='minor', alpha=0.2)
        ax_acc.grid(which='major', alpha=0.5)

        
        ax_acc.text(1, Ac_scan[-1] + 1.2, "×$\mathregular{10^4}$", fontsize=12)  
        ax_acc.text(timesum + 2, Ac_scan[-1], s=int(Ac_scan[-1] * 10000), fontsize=12)
        ax_acc.text(timesum + 2, Id_scan[-1], s=int(Id_scan[-1] * 10000), fontsize=12)
        ax_acc.text(timesum + 2, Id_pep[-1], s=int(Id_pep[-1] * 10000), fontsize=12)

        
        ax_acc.spines['top'].set_visible(False)
        ax_acc.spines['right'].set_visible(False)


class CFunctionPlotP_1:
    def __init__(self, inputDP):
        self.dp = inputDP
        
        

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[11]
        print("Generating image " + str(var_sav_95) + ".png......")
        self.init_fig()
        self.var_dra_44(self.fig, self.gs, self.dp.myID.PSM25_PrecWindow, self.dp.myID.PSM25_PrecWindowNumber)
        plt.savefig(var_sav_95 + '.png', format='png')
        plt.savefig(var_sav_95 + '.svg', format='svg')
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(20, 6, forward=True)
        self.gs = GridSpec(4, 20)

    def var_dra_44(self, fig, gs, prewindow, prewindownumber):
        Window_Left = []
        Window_Right = []
        var_Win_56 = []
        var_new_145 = []
        var_new_29 = []

        for i in range(len(prewindow)):
            i_window = prewindow[i]
            if i_window not in var_new_145:
                var_new_145.append(i_window)
                left = float(i_window.split(' ')[0][1:])
                right = float(i_window.split(' ')[2][:-1])
                Window_Left.append(left)
                Window_Right.append(right)
                var_Win_56.append(right - left)
                var_new_29.append(prewindownumber[i] + 1)
            else:
                pass

        var_bar_67 = [i / max(var_Win_56) for i in var_Win_56]
        array = np.array(list(zip(var_bar_67, var_new_29,var_Win_56, Window_Left)))
        a_sort = array[np.lexsort(array.T)]  
        var_Bar_71 = a_sort[:, 0]
        var_new_29 = a_sort[:, 1]
        var_win_80 = a_sort[:, 2]
        var_win_121 = a_sort[:, 3]

        if np.array(var_new_29).any() == 0:
            var_new_29 = np.arange(1, len(var_win_80)+1)

        
        ax1 = fig.add_subplot(gs[0:4, 0:8])
        ax1.bar(var_new_29, var_win_80, color="steelblue")
        if len(var_new_29) < 100:
            ax1.set_xticks(np.arange(0, len(var_new_29), 5))
        elif len(var_new_29)> 200:
            ax1.set_xticks(np.arange(0, len(var_new_29), 20))
        else:
            ax1.set_xticks(np.arange(0, len(var_new_29), 10))
        ax1.spines['top'].set_visible(False)
        ax1.spines['right'].set_visible(False)

        ax1.set_xlim(xmin=0, xmax=max(var_new_29)+0.5)
        ax1.set_ylim(ymax=int(max(var_Win_56) + 1))
        
        ax1.set_xlabel("MS2 Window Number", fontsize=15, fontname="arial", fontweight='bold')
        ax1.set_ylabel("Window Size(Da)", fontsize=15, fontname="arial", fontweight='bold')
        ax1.axhline(y=np.median(var_Win_56), color="r", linestyle="dashed")  
        ax1.text(np.median(var_new_29), y=np.median(var_Win_56) + 0.5, ha="center", fontsize=12,
                 s="Median of window size \n= " + str(round(np.median(var_Win_56), 1)))

        
        ax2 = fig.add_subplot(gs[0:4, 12:20])

        ax2.plot(var_win_121, var_win_80, color="steelblue", marker='o')
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)

        ax2.set_xlim(xmin=min(var_win_121), xmax=max(Window_Right)+1)
        ax2.set_ylim(ymin=0, ymax=int(max(var_win_80))+1)
        
        ax2.set_xlabel("m/z Window", fontsize=15, fontname="arial", fontweight='bold')
        ax2.set_ylabel("Window Size(Da)", fontsize=15, fontname="arial", fontweight='bold')
        ax2.axhline(y=np.median(var_win_80), color="r", linestyle="dashed")  
        ax2.text(np.median(Window_Right), y=np.median(var_win_80) + 0.5, ha="center", fontsize=12,
                 s="Median of window size \n= " + str(round(np.median(var_Win_56), 1)))


class CFunctionPlotI_6:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[15]
        print("Generating image " + str(var_sav_95) + ".png......")
        self.init_fig()
        
        self.draw_IDRate_RT(self.fig, self.gs)
        
        self.draw_IDRate_Precursor(self.fig, self.gs)
        
        self.draw_IDRate_MZ(self.fig, self.gs)
        plt.savefig(var_sav_95 + '.png', format='png',var_bbo_172="tight")
        
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(30, 6, forward=True)
        self.gs = GridSpec(6, 28)

    def draw_IDRate_RT(self,fig,gs):
        ID_MIN = [i * 100 for i in self.dp.myPicture.IDrate_min]

        var_mss_126 = self.dataMS1.INDEX_SCAN_TIME_MS1
        var_mss_127 = self.dataMS2.INDEX_SCAN_TIME_MS2
        timesum1 = np.sum(var_mss_126)
        timesum2 = np.sum(var_mss_127)
        timesum = int((timesum2 + timesum1) / 60)

        ax1 = fig.add_subplot(gs[0:6, 0:8])
        ax1.bar(x=range(len(ID_MIN)), height=ID_MIN)
        ax1.set_xlim(0, timesum + 1)
        if timesum>10:
            ax1.set_xticks(np.arange(0, timesum + 1, int(0.1 * round(timesum))))
        else:
            ax1.set_xticks(np.arange(0, timesum + 1, 1))
        ax1.set_xlabel("Retention time(min.)", fontsize=15, fontname="arial", fontweight='bold')
        ax1.set_ylabel("Identification Rate(%)", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        
        
        

        
        ax1.spines['top'].set_visible(False)
        ax1.spines['right'].set_visible(False)

    def draw_IDRate_Precursor(self, fig, gs):
        ID_precursor = self.dp.myPicture.IDRate_precursor
        var_mss_126 = self.dp.myMS1.INDEX_SCAN_TIME_MS1
        var_mss_127 = self.dp.myMS2.INDEX_SCAN_TIME_MS2
        timesum1 = np.sum(var_mss_126)
        timesum2 = np.sum(var_mss_127)
        timesum = int((timesum2 + timesum1) / 60)

        ax2 = fig.add_subplot(gs[0:6, 10:18])
        ax2.bar(x=range(len(ID_precursor)), height=ID_precursor)
        ax2.set_xlim(0, timesum + 1)
        if timesum > 10:
            ax2.set_xticks(np.arange(0, timesum + 1, int(0.1 * round(timesum))))
        else:
            ax2.set_xticks(np.arange(0, timesum + 1, 1))
        ax2.set_xlabel("Retention time(min.)", fontsize=15, fontname="arial", fontweight='bold')
        ax2.set_ylabel("Identified Precursors per Minute", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        
        
        

        
        ax2.spines['top'].set_visible(False)
        ax2.spines['right'].set_visible(False)

    def draw_IDRate_MZ(self, fig, gs):
        ID_window = list(self.dp.myPicture.IDRate_mz.keys())
        ID_rate_mz = list(self.dp.myPicture.IDRate_mz.values())
        ID_rate_mz = [i * 100 for i in ID_rate_mz]
        ax3 = fig.add_subplot(gs[0:6, 20:28])
        ax3.bar(x=range(len(ID_rate_mz)), height=ID_rate_mz,tick_label=ID_window)
        ax3.set_xlim(0, len(ID_rate_mz))
        ax3.set_xticklabels(ID_window, rotation=90)
        ax3.set_xlabel("DIA window", fontsize=15, fontname="arial", fontweight='bold')
        ax3.set_ylabel("Identified Precursors Rate(%)", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        if len(ID_rate_mz)>40:
            ax3.set_xticks(range(len(ID_rate_mz))[::3])
            var_xti_92 = [i for i in ID_window[::3]]
            ax3.set_xticklabels(var_xti_92)
            
        
        
        

        
        ax3.spines['top'].set_visible(False)
        ax3.spines['right'].set_visible(False)


class CFunctionPlotT_3:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2


    def draw(self,figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[13]
        print("Generating image " + str(var_sav_95) + ".png......")
        self.init_fig()
        self.var_dra_96(self.fig, self.gs)
        plt.savefig(var_sav_95 + '.png', format='png')
        plt.savefig(var_sav_95 + '.svg', format='svg')
        plt.close()


    def init_fig(self):
    
        self.fig = plt.figure()
        self.fig.set_size_inches(10, 7, forward=True)
        self.gs = GridSpec(7, 10)

    def var_dra_96(self, fig, gs):
        score = []
        for i in self.dp.scores:
            if i == '-':
                score.append(2.5)
            else:
                score.append(i)

        
        IdResult = round(np.mean(score[40:]), 1)
        
        NumberScans = round((score[2] + sum(score[4:6]) + sum(score[9:11]) + sum(score[16:19]) + sum(score[20:27]) + sum(score[36:38])) / 17, 1)
        
        ScansQuality = round((sum(score[0:2]) + sum(score[3:6]) + sum(score[7:9])+ sum(score[16:20]) + score[22]+ sum(score[27:36]) + sum(score[38:40])) / 23, 1)
        
        ScansUtility = round((sum(score[0:2]) + sum(score[3:6]) + score[7] + sum(score[9:12])+ score[13]+ score[22]+ sum(score[27:29]) + score[30]+ score[33]) / 15, 1)
        
        ScansRedundancy = round((sum(score[0:2])+ sum(score[4:7])+ sum(score[9:11])+sum(score[12:16]))/ 11, 1)

        TotalScore = round((IdResult + NumberScans + ScansUtility + ScansQuality+ScansRedundancy) / 5, 1)
        dimensions = [TotalScore, IdResult, NumberScans, ScansQuality, ScansUtility,ScansRedundancy]
        var_tic_168 = ['TotalScore', '${N_{identification\_results}}$', '${N_{acquired\_MS2}}$', '$Q_{MS2}$', '$P_{Precursor\_per\_MS2}$', '$R_{precursor}$']

        plt.rcParams.update({'font.size': 12})
        ax = fig.add_subplot(gs[0:7, 0:10])
        
        ax.bar(x=range(len(dimensions)),
               height=dimensions,
               tick_label=var_tic_168, width=0.4)
        
        ax.set_ylim(ymax=5)
        
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        plt.title("Total Score and First-level Scores", fontsize=20,
                  fontname = "arial", fontweight='bold', y=1.1)
        
        for index, i in enumerate(dimensions):
            ax.text(index, i+0.1, s=str(i), ha="center")
        plt.tight_layout()


class CFunctionPlotM_14:
    def __init__(self, inputDP):

        self.dp = inputDP

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(16, 10, forward=True)
        self.gs = GridSpec(16, 10)

    def var_dra_83(self, fig, gs):

        from matplotlib.colors import LinearSegmentedColormap, BoundaryNorm, Normalize
        from matplotlib.cm import ScalarMappable

        data = [

            [self.dp.myScore.score_TIC, self.dp.myScore.score_ms1_time, self.dp.myScore.score_ms1_injection_time, '*',
             self.dp.myScore.score_fwhm_median, self.dp.myScore.score_chrom_median, '*', '*', self.dp.myScore.score_TIC,
             self.dp.myScore.score_Acq_MS2_Scans, self.dp.myScore.score_windows_size,
             self.dp.myScore.score_charge_oneTotwo],
            ['*', '*', '*', '*', '*', '*', '*', '*', self.dp.myScore.score_charge_threeTotwo,
             self.dp.myScore.score_charge_fourTotwo, self.dp.myScore.score_ms1_time,
             self.dp.myScore.score_ms1_injection_time],
            ['*', '*', '*', '*', '*', '*', '*', '*', self.dp.myScore.score_ms2_injection_time,
             self.dp.myScore.score_ms1_cycle_time, self.dp.myScore.score_ms2_cycle_time,
             self.dp.myScore.score_ms1_peak_intensity],
            ['*', '*', '*', '*', '*', '*', '*', '*', self.dp.myScore.score_ms1_peak_number,
             self.dp.myScore.score_acq_MS1_scan, self.dp.myScore.score_acq_MS2_scan, '*'],

            [self.dp.myScore.score_miss_cleavage, self.dp.myScore.score_peptide_length,
             self.dp.myScore.score_charge_oneTotwo, self.dp.myScore.score_charge_threeTotwo,
             self.dp.myScore.score_deadtime, self.dp.myScore.score_fwhm_median, self.dp.myScore.score_chrom_median,
             self.dp.myScore.score_precursor_per_min, self.dp.myScore.score_ms2_injection_time,
             self.dp.myScore.score_ms2_peak_number, self.dp.myScore.score_ms2_peak_intensity,
             self.dp.myScore.score_ID_feature],
            [self.dp.myScore.score_charge_fourTotwo, self.dp.myScore.score_precursor_mz, '*', '*',
             self.dp.myScore.score_IDrate_RT, self.dp.myScore.score_ID_feature, '*', '*',
             self.dp.myScore.score_SN_precursor, self.dp.myScore.score_ms1_ppm, self.dp.myScore.score_ms2_ppm,
             self.dp.myScore.score_precursor_intensity],
            ['*', '*', '*', '*', '*', '*', '*', '*', self.dp.myScore.score_peptide_intensity,
             self.dp.myScore.score_protein_intesnity, self.dp.myScore.score_ms2_ID_Rate,
             self.dp.myScore.score_IDrate_MZ],
            ['*', '*', '*', '*', '*', '*', '*', '*', self.dp.myScore.score_charge_oneTotwo,
             self.dp.myScore.score_charge_threeTotwo, self.dp.myScore.score_charge_fourTotwo,
             self.dp.myScore.score_precursor_mz],

            [self.dp.myScore.score_miss_cleavage, self.dp.myScore.score_peptide_length,
             self.dp.myScore.score_precursors_per_scan, '*', self.dp.myScore.score_deadtime,
             self.dp.myScore.score_fwhm_median, self.dp.myScore.score_chrom_median,
             self.dp.myScore.score_precursor_per_min, self.dp.myScore.score_Acq_MS2_Scans,
             self.dp.myScore.score_windows_size, self.dp.myScore.score_precursors_per_scan,
             self.dp.myScore.score_precusor_scan_rate],
            ['*', '*', '*', '*', self.dp.myScore.score_precursors_per_scan, '*', '*', '*',
             self.dp.myScore.score_ms2_injection_time, self.dp.myScore.score_ms2_peak_number,
             self.dp.myScore.score_ms2_peak_intensity, self.dp.myScore.score_SN_precursor],
            ['*', '*', '*', '*', '*', '*', '*', '*', self.dp.myScore.score_precursor_intensity, '*', '*', '*'],
            ['*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*'],

            [self.dp.myScore.score_miss_cleavage, self.dp.myScore.score_peptide_length, '*', '*',
             self.dp.myScore.score_fwhm_median, self.dp.myScore.score_chrom_median, self.dp.myScore.score_tail_ratio,
             self.dp.myScore.score_precursor_redundancy, self.dp.myScore.score_Acq_MS2_Scans,
             self.dp.myScore.score_windows_size, self.dp.myScore.score_precursor_redundancy,
             self.dp.myScore.score_precusor_scan_rate],
            ['*', '*', '*', '*', self.dp.myScore.score_precusor_scan_rate, self.dp.myScore.score_ms1_DPPP,
             self.dp.myScore.score_ms2_DPPP, '*', self.dp.myScore.score_ms1_DPPP, self.dp.myScore.score_ms2_DPPP, '*',
             '*'],
            ['*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*'],
            ['*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*', '*'],
        ]


        for i in range(16):
            for j in range(12):
                if type(data[i][j]) == str:
                    if data[i][j] == '-':
                        data[i][j] = 8
                    elif data[i][j] == '*':
                        data[i][j] = -1
                else:
                    if data[i][j] < 1:
                        data[i][j] = 1
                    elif data[i][j] > 5 or data[i][j] == 5:
                        data[i][j] = 4.999

        labels = [

            ['S3', 'M1', 'M2', 'NA', 'C2', 'C3', 'NA', 'NA', 'S3', 'W1', 'W2', 'IS1'],
            ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'IS2','IS3', 'M1', 'M2'],
            ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'M3', 'M4', 'M5', 'M6'],
            ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'M7', 'M17', 'M18', 'NA'],

            ['S1', 'S2', 'IS1', 'IS2', 'C1', 'C2', 'C3', 'C5', 'M3','M8', 'M9', 'M10'],
            ['IS3', 'IS4', 'NA', 'NA', 'C6', 'M10', 'NA','NA', 'M11', 'M12', 'M13', 'M14'],
            ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'M15', 'M16', 'M19', 'M20'],
            ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'IS1','IS2','IS3','IS4'],

            ['S1', 'S2', 'W3', 'NA', 'C1', 'C2', 'C3', 'C5', 'W1', 'W2', 'W3', 'W5'],
            ['NA', 'NA', 'NA', 'NA', 'W3', 'NA', 'NA', 'NA', 'M3', 'M8', 'M9', 'M11'],
            ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'M14', 'NA', 'NA', 'NA'],
            ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA'],

            ['S1', 'S2', 'NA', 'NA', 'C2', 'C3', 'C4', 'W4', 'W1', 'W2', 'W4', 'W5'],
            ['NA', 'NA', 'NA', 'NA', 'W5', 'W6', 'W7', 'NA', 'W6', 'W7', 'NA', 'NA'],
            ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA'],
            ['NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA', 'NA'],

        ]

        mat_data = np.array(data)
        var_mat_131 = np.array(labels)

        
        var_cma_97 = [(0.87, 0.12, 0.04),  
                     (0.99, 0.89, 0.57),  
                     (0.45, 0.82, 0.64),
                    ]  
        cmap = LinearSegmentedColormap.from_list('my_cmap', var_cma_97, N=3)
        
        bounds = [1, 2, 4, 5]
        colors = [var_cma_97[0], var_cma_97[1], var_cma_97[2]]
        
        norm = BoundaryNorm(bounds, len(colors))

        
        
        

        
        

        
        
        plt.imshow(mat_data, extent=[0, 12, 0, 16], cmap=cmap, norm=norm,interpolation='nearest')
        plt.colorbar()
        cmap.set_over((0.93, 0.93, 0.93))
        cmap.set_under('white')
        

        plt.axvline(x=4, color='black',linestyle='--', linewidth=1)
        plt.axvline(x=8, color='black', linestyle='--', linewidth=1)
        
        plt.axhline(y=4, color='black', linestyle='--', linewidth=1)
        plt.axhline(y=8, color='black', linestyle='--', linewidth=1)
        plt.axhline(y=12, color='black', linestyle='--', linewidth=1)

        plt.xticks([2, 6, 10], ['Sample Preparation', 'Liquid Chromatography', 'Mass Spectrometry'], fontname = "arial", fontsize=15)
        plt.yticks([2, 6, 10, 14], ['$R_{precursor}$','$P_{precursor\_pep\_MS2}$', '$Q_{MS2}$','${N_{acquired\_MS2}}$'], fontname = "arial", fontsize=15)

        
        for i in range(len(var_mat_131)):
            for j in range(len(var_mat_131[i])):
                plt.text(j+0.5, 16-i-0.5, var_mat_131[i][j], ha='center', va='center', color='white', fontsize=12, fontname = "arial", fontweight='bold')

        plt.tight_layout()


    
    def save_fig(self, var_sav_95):

        plt.savefig(var_sav_95, var_bbo_172="tight")
        plt.clf()
        plt.close()

    def draw(self,figfolder):

        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[12]
        print("Generating image " + str(var_sav_95) + ".png......")
        self.init_fig()
        self.var_dra_83(self.fig, self.gs)
        self.save_fig(var_sav_95)


class CFunctionPlotC_7:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[16]
        print("Generating image " + str(var_sav_95) + ".png......")
        self.init_fig()
        
        
        
        self.draw_Charge_Precursor(self.fig, self.gs)
        plt.savefig(var_sav_95 + '.png', format='png',var_bbo_172="tight")
        
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(15, 6, forward=True)
        self.gs = GridSpec(6, 15)

    def var_dra_90(self, fig, gs):

        var_Cha_136 = 0
        var_Cha_160 = 0
        var_Cha_171 = 0
        var_Cha_155 = 0
        for charge in self.dp.myFeature.INDEX_CHARGE:
            if charge == '1':
                var_Cha_136 = var_Cha_136 + 1
            if charge == '2':
                var_Cha_160 = var_Cha_160 + 1
            if charge == '3':
                var_Cha_171 = var_Cha_171 + 1
            if charge == '4' or charge == '5':
                var_Cha_155 = var_Cha_155 + 1
        ChargeSum = var_Cha_136 + var_Cha_160 + var_Cha_171 + var_Cha_155

        dimensions = [var_Cha_136, var_Cha_160, var_Cha_171, var_Cha_155]
        var_tic_168 = ['Charge 1', 'Charge 2', 'Charge 3', 'Charge >3']

        plt.rcParams.update({'font.size': 15})
        ax = fig.add_subplot(gs[0:4, 0:10])
        
        ax.bar(x=range(len(dimensions)),height=dimensions,tick_label=var_tic_168, width=0.4)
        
        
        
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        plt.title("Features Charge Distribution", fontsize=15,
                  fontname="arial", fontweight='bold', y=1.1)
        
        for index, i in enumerate(dimensions):
            ax.text(index, i + 10, s=str(i), ha="center")

    def draw_Charge_Precursor(self, fig, gs):
        var_Cha_136 = 0
        var_Cha_160 = 0
        var_Cha_171 = 0
        var_Cha_155 = 0
        for charge in self.dp.myID.PSM9_CHARGE:
            if charge == 1:
                var_Cha_136 = var_Cha_136 + 1
            if charge == 2:
                var_Cha_160 = var_Cha_160 + 1
            if charge == 3:
                var_Cha_171 = var_Cha_171 + 1
            if charge == 4 or charge >= 5:
                var_Cha_155 = var_Cha_155 + 1
        ChargeSum = var_Cha_136 + var_Cha_160 + var_Cha_171 + var_Cha_155

        dimensions = [var_Cha_136, var_Cha_160, var_Cha_171, var_Cha_155]
        var_tic_168 = ['Charge 1', 'Charge 2', 'Charge 3', 'Charge >3']

        plt.rcParams.update({'font.size': 15})
        ax1 = fig.add_subplot(gs[0:4, 0:10])
        
        ax1.bar(x=range(len(dimensions)), height=dimensions, tick_label=var_tic_168, width=0.4)
        
        
        
        ax1.spines['top'].set_visible(False)
        ax1.spines['right'].set_visible(False)
        
        plt.title("Precursors Charge Distribution", fontsize=15,
                  fontname="arial", fontweight='bold', y=1.1)
        
        for index, i in enumerate(dimensions):
            ax1.text(index, i + 10, s=str(i), ha="center")


class CFunctionPlotF_15:
    def __init__(self, inputDP):
        self.dp = inputDP

    def draw(self, figfolder):
        var_sav_95 = figfolder + IO_FILENAME_PIC_EXPORT[17]
        print("Generating image " + str(var_sav_95) + ".png......")
        self.init_fig()
        
        self.var_dra_60(self.fig, self.gs)
        if self.dp.myCFG.E3_FLAG_ANALYZE_FEATURE != 0:
            self.var_dra_41(self.fig, self.gs)
        

        plt.savefig(var_sav_95 + '.png', format='png',var_bbo_172="tight")
        
        plt.close()

    def init_fig(self):
        
        self.fig = plt.figure()
        self.fig.set_size_inches(24, 6, forward=True)
        self.gs = GridSpec(6, 24)

    def var_dra_60(self, fig, gs):
        rt = self.dp.myID.PSM3_RT
        mz = self.dp.myID.PSM15_PRE_MOZ

        ax4 = fig.add_subplot(gs[0:4, 0:10])
        ax4.scatter(rt, mz, color="steelblue", s=1)

        
        ax4.set_xlabel("Retention Time", fontsize=15, fontname="arial", fontweight='bold')
        ax4.set_ylabel("Precursor M/Z", fontsize=15, fontname="arial", fontweight='bold')
        plt.tick_params(labelsize=13)
        plt.title("Precursor M/Z Distribution", fontsize=15, fontname="arial", fontweight='bold')

        ax4.spines['top'].set_visible(False)
        ax4.spines['right'].set_visible(False)

    def var_dra_41(self, fig, gs):

        plt.rcParams.update({'font.size': 15})
        ax = fig.add_subplot(gs[0:4, 12:22])

        INT1 = self.dp.myFeature.INDEX_INTENSITY_ALL
        INT2 = []
        INT3 = []

        FeatureScan = list(self.dp.myFeature.LIST_MOZ_MONO)
        for i in range(len(self.dp.myFeature.LIST_MOZ_MONO)):
            tmpScan = FeatureScan[i]
            tmpState = self.dp.myFeature.STATE_OF_FEATURE[i].split('\t')[-1]
            if tmpState == 'acquired':
                INT2.append(self.dp.myFeature.INDEX_INTENSITY_ALL[i])
            elif tmpState == 'identified':
                INT2.append(self.dp.myFeature.INDEX_INTENSITY_ALL[i])
                INT3.append(self.dp.myFeature.INDEX_INTENSITY_ALL[i])

        x_ticks = np.arange(4,10,0.1)
        x_ticks1 = np.arange(4,10,1)
        y_ticks = np.arange(0, 10000, 1000)


        
        
        

        INT1 = [round(math.log(float(i),10), 2) for i in INT1]
        INT2 = [round(math.log(float(i),10), 2) for i in INT2]
        INT3 = [round(math.log(float(i),10), 2) for i in INT3]

        ax.hist(INT1, rwidth=1, alpha=0.5, facecolor =(0.7,0.7,0.7),edgecolor=(0.5,0.5,0.5), bins=x_ticks)  
        ax.hist(INT2, rwidth=1, alpha=1, facecolor = (0.7,0,0),edgecolor=(0.5,0,0), bins=x_ticks)  
        ax.hist(INT3, rwidth=1, alpha=1, facecolor = (0,0.7,0),edgecolor=(0,0.5,0), bins=x_ticks)

        ax.text(9,9000,'Detected:'+ str(len(INT1)), fontname="Times New Roman", fontsize=13, fontweight='bold')
        ax.text(9, 8000, 'Targeted:'+ str(len(INT2)), fontname="Times New Roman", fontsize=13, fontweight='bold')
        ax.text(9, 7000, 'Identified:'+ str(len(INT3)), fontname="Times New Roman", fontsize=13, fontweight='bold')

        ax.set_xticks(x_ticks1)
        ax.set_yticks(y_ticks)
        ax.set_xticklabels(x_ticks1, fontsize=13, fontname="Times New Roman")
        ax.set_yticklabels(y_ticks, fontsize=13, fontname="Times New Roman")

        plt.xlabel('Intensity(log10)',fontsize=15, fontname="Times New Roman", fontweight='bold')
        plt.ylabel('Frequency',fontsize=15, fontname="Times New Roman", fontweight='bold')
        




class CFunctionDraw__21:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):
        self.head_str = "<html>\n" \
                        "<head>\n" \
                        '<meta http-equiv="Content-Type" content="text/html">\n' \
                        '<meta name=Generator content="MSRefine">\n' \
                        '<title>MSRefine Report</title>\n' \
                        '<style>\n' \
                        'body {font-family: Times New Roman, serif, Garamond; font-size: 28.0pt;}\n' \
                        '.title1 {text-align:center;font-size:32.0pt;font-weight:bold}\n' \
                        '.version1 {text-align:center;font-size:24.0pt;font-style:italic;}\n' \
                        '.section1 {text-align:left;font-size:28.0pt;font-weight:bold;}\n' \
                        '.figure_legend1 {text-align:center;font-size:16.0pt;}\n' \
                        '.table_legend1 {text-align:center;font-size:16.0pt;}\n' \
                        '.table1 {border-collapse:collapse;border:none;font-size:16.0pt;}\n' \
                        '.table_head1 {border:solid black 1.0pt;background:#8DB3E2;padding:3pt 10pt 3pt 10pt;text-align:center;color:white;font-weight:bold;}\n' \
                        '.table_data1 {border:solid black 1.0pt; padding:3pt 10pt 3pt 10pt;text-align:center;}\n' \
                        '.Reference1 {font-style:italic;}\n' \
                        '</style>\n' \
                        '</head>\n' \
                        '<body>\n'

        self.tail_str = "</body>\n" \
                        "</html>"

        self.var_tab_117 = "<p class=section1>"

        self.var_pic_85 = "<p>&nbsp;</p>\n" \
                            "<div align=center>\n" \
                            "<p class=section1>"

        self.pic_sp = "<div align=center>\n" \
                      "<p class=section1>"

        self.var_pic_21 = "<div align=center>\n"

        self.var_pic_76 = "</p>\n" \
                             "<p class='table_legend1'>"

        self.var_pic_20 = "</div>\n"

        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def var_wri_91(self, var_cla_81):

        var_tit_64 = "</br>\n"+ self.var_pic_85 + var_cla_81 + "</p>\n"
        return var_tit_64

    def var_wri_130(self):
        print("Generating Webpage ......")
        var_sav_95 = self.dp.myCFG.E1_PATH_EXPORT + "Analysis_Report.html"
        f = open(var_sav_95, 'w')

        f.write(self.head_str)
        f.write(self.var_pic_21)
        
        f.write("<p class = 'title1'><b>" + str(self.dp.myHtml.html_title) + "</b></p>")
        

        
        title1 = self.var_wri_91("1 Overview of Dataset")
        f.write(title1)
        var_pic_162 = self.var_dra_114("1.1 Accumulated Number of MS2 Scans or Peptides vs Retention time",
                                       "",
                                       "./picture/Fig11_TrilinearChart.png",
                                       "Trilinear Chart")  
        f.write(var_pic_162)

        
        var_pic_35 = self.var_dra_114("1.2 First-level Scores of Dataset",
                             "",
                             "./picture/Fig14_TotalScoreBar.png", "bar figure")  
        f.write(var_pic_35)

        
        var_pic_154 = self.draw_pic("1.3 Metric-Score Analysis",
                             "\n",
                             "./picture/Fig13_MetricsScore.png", "Metrics-Score figure")  
        f.write(var_pic_154)

        
        var_tab_15 = self.var_dra_51("1.4 Second-level Scores of Dataset",
                                            self.dp.myHtml.lineSCORE_T, self.dp.myHtml.lineSCORE_I, 3, 6, 7, 4, 20, 7)
        f.write(var_tab_15)

        table1 = self.var_dra_11("1.5 Acquired Scans and Identification Results", " ", self.dp.myHtml.lineSUM_T, self.dp.myHtml.lineSUM_I)
        f.write(table1)

        f.write(self.var_pic_20)
        title2 = self.var_wri_91("2 Sample Preparation")
        f.write(title2)
        
        pic_SP = self.draw_pic("2.1 Sample Preparation Analysis",
                                  "\n",
                                  "./picture/Fig19_sample preparation.png", "Sample Preparation figure")  
        f.write(pic_SP)
        
        f.write(self.var_pic_20)
        
        title3 = self.var_wri_91("3 liquid Chromatography")
        f.write(title3)
        
        var_pic_144 = self.draw_pic("3.1 Peak Width Analysis",
                                  "\n",
                                  "./picture/Fig1_Chemo_Peakwidth.png", "Chromtography figure")  
        f.write(var_pic_144)

        var_pic_69 = self.draw_pic("3.2 FWHM Analysis",
                                  "\n",
                                  "./picture/Fig15_FWHM.png", "FWHM figure")  
        f.write(var_pic_69)

        f.write(self.var_pic_20)

        title4 = self.var_wri_91("4 MS Data Acquisition")
        f.write(title4)

        var_pic_104 = self.draw_pic("4.1 Acquired Time and Scan Numbers of MS1 and MS2","","./picture/Fig2_MS1_MS2_Scantime.png", "MS1_MS2_Scantime figure")  
        f.write(var_pic_104)

        if self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['Thermo-Orbitrap'] or self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['Thermo-FAIMS']:
            
            var_pic_12 = self.draw_pic("4.2 The Distribution of Ion Injection Time of MS1/MS2","","./picture/Fig5_IonInjectiontime.png","Ion Injection Time figure")  
            f.write(var_pic_12)

        
        var_pic_75 = self.draw_pic("4.3 Acquiring Speed Analysis","","./picture/Fig6_Cycletime.png", "MS1 Cycletime figure")  
        f.write(var_pic_75)

        
        var_pic_26 = self.draw_pic("4.4 Acquiring Data Point Per Peak","","./picture/Fig7_Datapoint.png", "Datapoint figure")  
        f.write(var_pic_26)

        
        var_pic_2 = self.draw_pic("4.5 Acquiring Precursor Window Analysis","","./picture/Fig12_PrecursorWindow.png", "PrecursorWindow figure")  
        f.write(var_pic_2)

        
        var_pic_72 = self.draw_pic("4.6 Identified Scan and Precursor Redundancy","","./picture/Fig8_PeptideScanRatio.png", "PeptideScanRatio figure")  
        f.write(var_pic_72)

        var_pic_16 = self.draw_pic("4.7 MS1 Mass Accuracy Analysis","","./picture/Fig9_MS1_MassAccuracy.png", "MS1_MassAccuracy figure")  
        f.write(var_pic_16)

        var_pic_62 = self.draw_pic("4.8 MS2 Mass Accuracy Analysis","","./picture/Fig10_MS2_MassAccuracy.png", "MS2_MassAccuracy figure")  
        f.write(var_pic_62)

        
        var_pic_148 = self.draw_pic("4.9 ID rate Analysis", "", "./picture/Fig16_IDRate.png",
                                   "ID rate figure")  
        f.write(var_pic_148)

        
        var_pic_161 = self.draw_pic("4.10 Number of Peaks and Intensities of MS1 Scans","","./picture/Fig3_MS1_Peaks_Intensity.png", "MS1 peaks and intensity figure")  
        f.write(var_pic_161)

        
        var_pic_86 = self.draw_pic("4.11 Number of Peaks and Intensities of MS2 Scans","","./picture/Fig4_MS2_Peaks_Intensity.png", "MS2 peaks and intensity figure")  
        f.write(var_pic_86)

        
        var_pic_37 = self.draw_pic("4.12 Charge Distribution", "","./picture/Fig17_Charge.png","Charge Distribution figure")  
        f.write(var_pic_37)

        
        var_pic_84 = self.draw_pic("4.13 Feature Distribution", "", "./picture/Fig18_feature.png",
                                   "Feature Distribution figure")  
        f.write(var_pic_84)

        f.write(self.tail_str)
        f.close()
        print("Analysis Successfully Finished.")

    def var_dra_11(self, var_cla_81, var_pic_118, headers, values):
        var_tab_18 = self.var_tab_117 + var_cla_81 + "</p>\n"
        var_tab_18 += "<p class='table_legend1'>" + var_pic_118 + "</p>\n"
        var_tab_18 += "<div align=center>\n<table class='table1'>"
        var_tab_18 += "\n<tr>"
        for head in headers:
            var_tab_18 += "\n<td class='table_head1'>" + head + "</td>"
        var_tab_18 += "\n</tr>"

        for v_list in values:
            
            var_tab_18 += "\n<td class='table_data1'>" + str(v_list) + "</td>"
            
        var_tab_18 += "\n</table>\n</div>"
        return var_tab_18

    def var_dra_3(self, headers, values):
        var_tab_18 = self.var_tab_117 + "</p >\n"
        var_tab_18 += "<p class='table_legend1'>" + "</p >\n"
        var_tab_18 += "<div align=center>\n<table class='table1'>"
        var_tab_18 += "\n<tr>"
        for head in headers:
            var_tab_18 += "\n<td class='table_head1'>" + head + "</td>"
        var_tab_18 += "\n</tr>"

        for v_list in values:
            var_tab_18 += "\n<tr>"
            for v in v_list:
                var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            var_tab_18 += "\n</tr>"
        var_tab_18 += "\n</table>\n"
        return var_tab_18

    def var_dra_51(self, var_cla_81, headers, values, rowspan1, rowspan2, rowspan3, rowspan4, rowspan5,rowspan6):
        var_tab_18 = self.var_tab_117 + var_cla_81 + "</p >\n"
        var_tab_18 += "<p class='table_legend1'>" + "</p >\n"
        var_tab_18 += "<div align=center>\n<table class='table1'>"
        var_tab_18 += "\n<tr>"
        for head in headers:
            var_tab_18 += "\n<td class='table_head1'>" + head + "</td>"
        var_tab_18 += "\n</tr>"

        for index, v_list in enumerate(values):
            var_tab_18 += "\n<tr>"
            if index == 0:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan1) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan2) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1 + rowspan2:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan3) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1 + rowspan2 + rowspan3:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan4) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1 + rowspan2 + rowspan3 + rowspan4:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan5) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1 + rowspan2 + rowspan3 + rowspan4 + rowspan5:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan6) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            else:
                for v in v_list:
                    var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            var_tab_18 += "\n</tr>"
        var_tab_18 += "\n</table>\n"
        return var_tab_18

    def draw_pic(self, var_cla_81, var_pic_118, pic_path, var_pic_22):
        pic_res = self.var_pic_85 + var_cla_81 + "</p>\n" + "</br>\n</br>\n"
        pic_res += '<img src="' + pic_path + '" alt="Could not Find ' + var_pic_22 + '"></img>\n'
        pic_res += self.var_pic_20
        return pic_res

    def var_dra_114(self, var_cla_81, var_pic_118, pic_path, var_pic_22):
        pic_res = self.pic_sp + var_cla_81 + "</p>\n"  
        pic_res += '<img src="' + pic_path + '" alt="Could not Find ' + var_pic_22 + '"></img>\n'
        pic_res += self.var_pic_20
        return pic_res

    def var_dra_33(self, var_cla_81, var_pic_118, pic_path, var_pic_22):
        pic_res = self.var_pic_21 + "\n" + "</br>\n</br>\n"
        pic_res += '<img src="' + pic_path + '" alt="Could not Find ' + var_pic_22 + '"></img>\n'
        pic_res += self.var_pic_20
        return pic_res


class CFunctionDraw__10:
    def __init__(self, inputDP):
        self.head_str = "<html>\n" \
                        "<head>\n" \
                        '<meta http-equiv="Content-Type" content="text/html">\n' \
                        '<meta name=Generator content="MSRefine">\n' \
                        '<title>MSRefine Report</title>\n' \
                        '<style>\n' \
                        'body {font-family: Times New Roman, serif, Garamond; font-size: 28.0pt;}\n' \
                        '.title1 {text-align:center;font-size:28.0pt;font-weight:bold}\n' \
                        '.version1 {text-align:center;font-size:24.0pt;font-style:italic;}\n' \
                        '.section1 {text-align:left;font-size:28.0pt;font-weight:bold;}\n' \
                        '.figure_legend1 {text-align:center;font-size:16.0pt;}\n' \
                        '.table_legend1 {text-align:center;font-size:16.0pt;}\n' \
                        '.table1 {border-collapse:collapse;border:none;font-size:16.0pt;}\n' \
                        '.table_head1 {border:solid black 1.0pt;background:#8DB3E2;padding:3pt 10pt 3pt 10pt;text-align:center;color:white;font-weight:bold;}\n' \
                        '.table_data1 {border:solid black 1.0pt; padding:3pt 10pt 3pt 10pt;text-align:center;}\n' \
                        '.Reference1 {font-style:italic;}\n' \
                        '</style>\n' \
                        '</head>\n' \
                        '<body>\n'

        self.tail_str = "</body>\n" \
                        "</html>"

        self.var_tab_117 = "<p class=section1>"

        self.var_pic_85 = "<p>&nbsp;</p>\n" \
                            "<div align=center>\n" \
                            "<p class=section1>"

        self.pic_sp = "<div align=center>\n" \
                      "<p class=section1>"

        self.var_pic_21 = "<div align=center>\n"

        self.var_pic_76 = "</p>\n" \
                             "<p class='table_legend1'>"

        self.var_pic_20 = "</div>\n"

        self.dp = inputDP

    def var_wri_130(self):
        print("Generating Webpage ......")
        var_sav_95 = self.dp.myCFG.E1_PATH_EXPORT + "Analysis_Report.html"
        f = open(var_sav_95, 'w')

        f.write(self.head_str)
        f.write(self.var_pic_21)
        f.write("<p class = 'title1'><b>" + str(self.dp.myID.PSM1_RAW_NAME[0]) + "</b></p>")
        f.write(self.var_pic_20)

        

        

        

        
        table1t = ["Identified precursors", "Identified peptides", "Identified proteins", "Identified protein groups"]
        var_Idp_27 = len(self.dp.myID.PSM31_Precursor)
        var_Idp_14 = len(self.dp.myID.PSM4_SEQ)
        var_Idp_78 = len(self.dp.myID.PSM20_PROTEIN)
        Id_PGs = len(self.dp.myID.PSM20_PRO)
        table1n = [var_Idp_27, var_Idp_14, var_Idp_78, Id_PGs]

        table1 = self.var_dra_11("1. Acquired and Identified Scans", " ", table1t, table1n)
        f.write(table1)


        f.write(self.head_str)

        

        

        

        
        var_pic_12 = self.draw_pic("2. Acquiring Data Point Per Peak",
                                  "",
                                  "./picture/Fig7_Datapoint.png", "Datapoint figure")  
        f.write(var_pic_12)

        
        var_pic_148 = self.draw_pic("3. Acquiring Precursor Window Analysis",
                                  "",
                                  "./picture/Fig12_PrecursorWindow.png", "PrecursorWindow figure")  
        f.write(var_pic_148)

        

        
        var_pic_26 = self.draw_pic("4. Chromatography Analysis",
                                  "\n",
                                  "./picture/Fig1_Chemo_Scans.png", "Chematography figure")  
        f.write(var_pic_26)

        
        var_pic_2 = self.draw_pic("5. MS1 Mass Accuracy Analysis",
                                  "",
                                  "./picture/Fig9_MS1_MassAccuracy.png", "MS1_MassAccuracy figure")  
        f.write(var_pic_2)

        
        var_pic_72 = self.draw_pic("6. MS2 Mass Accuracy Analysis",
                                  "",
                                  "./picture/Fig10_MS2_MassAccuracy.png", "MS2_MassAccuracy figure")  
        f.write(var_pic_72)

        

        
        print("Analysis Successfully Finished.")

    def var_dra_11(self, var_cla_81, var_pic_118, headers, values):
        var_tab_18 = self.var_tab_117 + var_cla_81 + "</p>\n"
        var_tab_18 += "<p class='table_legend1'>" + var_pic_118 + "</p>\n"
        var_tab_18 += "<div align=center>\n<table class='table1'>"
        var_tab_18 += "\n<tr>"
        for head in headers:
            var_tab_18 += "\n<td class='table_head1'>" + head + "</td>"
        var_tab_18 += "\n</tr>"

        for v_list in values:
            
            var_tab_18 += "\n<td class='table_data1'>" + str(v_list) + "</td>"
            
        var_tab_18 += "\n</table>\n</div>"
        return var_tab_18

    def var_dra_3(self, headers, values):
        var_tab_18 = self.var_tab_117 + "</p >\n"
        var_tab_18 += "<p class='table_legend1'>" + "</p >\n"
        var_tab_18 += "<div align=center>\n<table class='table1'>"
        var_tab_18 += "\n<tr>"
        for head in headers:
            var_tab_18 += "\n<td class='table_head1'>" + head + "</td>"
        var_tab_18 += "\n</tr>"

        for v_list in values:
            var_tab_18 += "\n<tr>"
            for v in v_list:
                var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            var_tab_18 += "\n</tr>"
        var_tab_18 += "\n</table>\n"
        return var_tab_18

    def var_dra_51(self, var_cla_81, headers, values, rowspan1, rowspan2, rowspan3, rowspan4,rowspan5):
        var_tab_18 = self.var_tab_117 + var_cla_81 + "</p >\n"
        var_tab_18 += "<p class='table_legend1'>" + "</p >\n"
        var_tab_18 += "<div align=center>\n<table class='table1'>"
        var_tab_18 += "\n<tr>"
        for head in headers:
            var_tab_18 += "\n<td class='table_head1'>" + head + "</td>"
        var_tab_18 += "\n</tr>"

        for index, v_list in enumerate(values):
            var_tab_18 += "\n<tr>"
            if index == 0:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan1) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == 2:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan2) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == 6:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan3) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == 14:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan4) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == 16:
                for index, v in enumerate(v_list):
                    if index == 0:
                        var_tab_18 += "\n<td class='table_data1' rowspan=" + str(rowspan5) + '>' + str(v) + "</td>"
                    else:
                        var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            else:
                for v in v_list:
                    var_tab_18 += "\n<td class='table_data1'>" + str(v) + "</td>"
            var_tab_18 += "\n</tr>"
        var_tab_18 += "\n</table>\n"
        return var_tab_18

    def draw_pic(self, var_cla_81, var_pic_118, pic_path, var_pic_22):
        pic_res = self.var_pic_85 + var_cla_81 + "</p>\n" + "</br>\n</br>\n"
        pic_res += '<img src="' + pic_path + '" alt="Could not Find ' + var_pic_22 + '"></img>\n'
        pic_res += self.var_pic_20
        return pic_res

    def var_dra_114(self, var_cla_81, var_pic_118, pic_path, var_pic_22):
        pic_res = self.pic_sp + var_cla_81 + "</p>\n"  
        pic_res += '<img src="' + pic_path + '" alt="Could not Find ' + var_pic_22 + '"></img>\n'
        pic_res += self.var_pic_20
        return pic_res

    def var_dra_33(self, var_cla_81, var_pic_118, pic_path, var_pic_22):
        pic_res = self.var_pic_21 + "\n" + "</br>\n</br>\n"
        pic_res += '<img src="' + pic_path + '" alt="Could not Find ' + var_pic_22 + '"></img>\n'
        pic_res += self.var_pic_20
        return pic_res