# -*- coding: utf-8 -*-
class Config:

    A0_PATH_RAW = ''
    A1_TYPE_DATA = ''   #'Thermo-Orbitrap': 0, 'timsTOF': 1, 'SCIEX': 2
    A1_PATH_MS1 = ''
    A2_PATH_MS2 = ''

    S1_PATH_XTRACT = 'xtract.exe'

    B1_TYPE_RAW = 0
    B2_PATH_IDENTIFICATION_RESULT = ''
    B3_TYPE_IDENTIFICATION_RESULT = 0
    B4_THRESHOLD_FDR = 0.01

    C1_WINDOW_HALF_RT = 5
    C2_PPM_HALF_WIN_ACCURACY_PEAK = 15
    C3_CUTOFF_INTENSITY_IN_CMTG = 0.01
    C4_NUMBER_HOLE_IN_CMTG = 1
    C5_THRESHOLD_PEAK_WIDTH_TAILING = 1
    C6_THRESHOLD_INVALID_ACQUIRING_SCAN = 100

    E1_PATH_EXPORT = '\\MSCohort\\'
    E2_FLAG_SAVE_FIGURE = 0
    E3_FLAG_ANALYZE_FEATURE = 0


class CFileMS1:

    INDEX_SCAN = []
    INDEX_RT = []

    LIST_RET_TIME = []
    LIST_ION_INJECTION_TIME = []

    MATRIX_PEAK_MOZ = []
    MATRIX_PEAK_INT = []
    MATRIX_PEAK_MARK = []


    INDEX_SCAN_TIME_MS1 = []
    INDEX_ION_INJECTION_TIME = []
    N_PEAKS_MS1 = []
    INTENSITY_PEAKS_MS1 = []


class CFileMS2:

    INDEX_SCAN = []
    INDEX_RT = []
    INDEX_CV = []

    LIST_RET_TIME = []
    LIST_ION_INJECTION_TIME = []
    LIST_ACTIVATION_CENTER = []
    LIST_PRECURSOR_SCAN = []
    LIST_ISOLATION_WIDTH = []

    MATRIX_PEAK_MOZ = []
    MATRIX_PEAK_INT = []
    MATRIX_CHARGE = []
    MATRIX_MZ = []
    MATRIX_PEAK_MARK = []


    INDEX_SCAN_TIME_MS2 = []
    INDEX_ION_INJECTION_TIME = []
    INDEX_ISOLATION_WIDTH = []
    INDEX_ACTIVATION_CENTER = []
    N_PEAKS_MS2 = []
    INTENSITY_PEAKS_MS2 = []
    INDEX_TIMS_TOTAL_INTENSITY = []
    INDEX_TIMS_NUMBER_PEAKS = []


    TIMS_TOTAL_INTENSITY = []
    TIMS_NUMBER_PEAKS = []



class CCycle:

    # calc
    LIST_CYCLES_N_MS2 = []
    LIST_CYCLES_TIME = []
    LIST_CYCLES_TIME_MS2 = []
    LIST_CYCLES_MS2_WINDOWS = 0


class CEvidence:


    MATRIX_PROFILE = []


    LIST_RET_TIME = []
    LIST_SCAN = []

    LIST_I_START = []
    LIST_I_END = []

    I_START = 0
    I_END = -1


    DIS_ISO_MOZ_EXP = []
    DIS_ISO_INT_EXP = []
    PROFILE_ALL = []


class CFileID:

    N_PSM = 0

    PSM1_RAW_NAME = []
    PSM2_SCAN_ID = []
    PSM3_RT = []

    PSM4_SEQ = []
    PSM5_MOD = []
    PSM6_GLC = []
    PSM6_GLC_T = 'GLC'
    PSM6_LIK = []

    PSM7_MH_EXP = []
    PSM8_MH_CLC = []
    PSM9_CHARGE = []

    PSM10_SCORE0 = []
    PSM11_SCORE1 = []
    PSM12_SCORE2 = []

    PSM20_PRO = []  # protein groups
    PSM20_PROTEIN = [] # proteins
    PSM21_SITE = []


    R1_RUN_DATA = []
    R2_GRADIENT = []
    R3_MS1_NUMBER = []
    R4_MS2_NUMBER = []
    R5_MS1_CYCLE = []
    R6_MS2_CYCLE = []
    R7_MS1_TIC = []

    PSM13_PRO_INTENSITY = []
    PSM14_PEP_INTENSITY = []
    PSM15_PRE_MOZ = []
    PSM16_ProteinIBAQ = []
    PSM17_PRE_SignalToNoise = []
    PSM18_PRE_INTENSITY = []

    PSM22_RT_START = []
    PSM23_RT_END = []
    PSM24_DataPoint = []
    PSM25_PrecWindow = []
    PSM25_PrecWindowNumber = []
    PSM26_MS1_MassAccuracy = []
    PSM27_MS2_MassAccuracy = []
    PSM28_FWHM = []
    PSM29_PeakWidth = []
    PSM30_MissedCleavage = []
    PSM30_MissedCleavage_PRE = []
    PSM31_Precursor = []
    PSM32_DataPoint_MS1 = []

    SCAN_REDUNDANCE = []
    SCAN_TO_PEPTIDE = []
    ID2_SCAN_ID = []

    PSM_LINE_T = []
    PSM_LINE_C = []


    MOD1_DICT_PSM = {}

    SITE1_DICT_PSM = {}

    PRO1_DICT_PSM = {}
    PRO2_DICT_SEQ = {}
    PRO3_DICT_N_SEQ = {}
    PRO4_LIST_AC = []
    PRO5_LIST_DE = []
    PRO6_LIST_ID = []
    PRO7_LIST_TYPE = []


class CFileFeature:

    INDEX_FEATURE_SCAN = []
    INDEX_CHARGE = []
    INDEX_INTENSITY_ALL = []
    INDEX_MOZ_MONO = []
    LIST_MOZ_MONO = []

    INDEX_SCAN_S = []
    INDEX_RT_S = []
    INDEX_SCAN_E = []
    INDEX_RT_E = []

    STATE_OF_FEATURE = []

class CFileHtml:



    lineSUM_T = 0
    lineSUM_I = 0

    lineSCORE_T = 0
    lineSCORE_I = 0

    html_title = 0


class CFileValue:

# S1. Missed cleavages(n=0) of peptides
    miss_cleavage = 0
# S2. Median peptide length
    peptide_length = 0
# S3. Median Total Ion Current (TIC)
    TIC = 0

# C1. Chromatographic invalid acquiring time
    deadtime = 0
# C2. Med. FWHM
    fwhm_median = 0
# C3. Med. peptide eluting width
    chrom_median = 0
# C4. Tailing ratio for IDs
    tail_ratio = 0
# C5. Median precursors identified over RT
    precursor_per_min = 0
# C6. Max. identification rate over RT
    IDrate_RT = 0

# W1. Acquired MS2 scans in one cycle
    MS2_window = 0
# W2. Median of window size (Da)
    windows_size = 0
# W3. Redundant identified precursors/ Identified Scan Rate
    precursors_per_scan = 0
# W4. Redundant identified precursors/ Identified precursors Rate
    precursor_redundancy = 0
# W5. Identified precursors/ identified scan rate
    precusor_scan_rate = 0
# W6. MS1 data point per peak
    ms1_DPPP = 0
# W7. MS2 data point per peak
    ms2_DPPP = 0


# IS1. 1+/2+ ions detected
    charge_oneTotwo = 0
# IS2. 3+/2+ ions detected
    charge_threeTotwo = 0
# IS3. 4+/2+ ions detected
    charge_fourTotwo = 0
# IS4. Med. precursor m/z
    precursor_mz = 0
# IS5. Precursors charge distribution   one/all
#     charge_oneToall = 0


# M1. Proportion of MS1 time
    ms1_time = 0
# M2. Med. MS1 ion injection time
    ms1_injection_time = 0
# M3. Median MS2 ion injection time
    ms2_injection_time = 0
# M4. MS1 cycle time
    ms1_cycle_time = 0
# M5. MS2 cycle time
    ms2_cycle_time = 0
# M6. Median peaks intensity of MS1
    ms1_peak_intensity = 0
# M7. Median peaks number of MS1
    ms1_peak_number = 0
# M8. Median peaks number of MS2
    ms2_peak_number = 0
# M9. Median peaks intensity of MS2
    ms2_peak_intensity = 0
# M10. Identified / detected features
    ID_feature = 0
# M11. Signal to noise（S/N）for precursors
    SN_precursor = 0
# M12. Median of MS1 raw mass accuracy
    ms1_ppm = 0
# M13. Median of MS2 raw mass accuracy
    ms2_ppm = 0
# M14. Median intensities for precursors
    precursor_intensity = 0
# M15. Median intensities for peptides
    peptide_intensity = 0
# M16. Median intensities for protein groups
    protein_intesnity = 0
# M17. Acquired MS1 scans
    acq_MS1_scan = 0
# M18. Acquired MS2 scans
    acq_MS2_scan = 0
# M19. MS2 identification rate
    ms2_ID_Rate = 0
# M20. Max. identification rate over M/Z range
    IDrate_MZ = 0

# ID1. Identified MS2 scans
    num_id_MS2scan = 0
# ID2: Number of precursors
    num_precursor = 0
# ID3: Number of peptides
    num_peptide = 0
# ID4: Number of protein groups
    num_pgs = 0
# ID5. Number of proteins
    num_pro = 0
# ID6. AVG peptides per protein group
    num_PEP_PRO = 0
# ID7. AVG precursors per protein group
    num_precur_PRO = 0

class CFilePicture:

    IDRate_mz = {}
    IDrate_min = []
    IDRate_precursor = []


class CFileScore:
    # S1. Missed cleavages(n=0) of peptides
    score_miss_cleavage = 0
    # S2. Median peptide length
    score_peptide_length = 0
    # S3. Median Total Ion Current (TIC)
    score_TIC = 0

    # C1. Chromatographic invalid acquiring time
    score_deadtime = 0
    # C2. Med. FWHM
    score_fwhm_median = 0
    # C3. Med. peptide eluting width
    score_chrom_median = 0
    # C4. Tailing ratio for IDs
    score_tail_ratio = 0
    # C5. Median precursors identified over RT
    score_precursor_per_min = 0
    # C6. Max. identification rate over RT
    score_IDrate_RT = 0

    # W1. Acquired MS2 scans in one cycle
    score_Acq_MS2_Scans = 0
    # W2. Median of window size (Da)
    score_windows_size = 0
    # W3. Redundant identified precursors/ Identified Scan Rate
    score_precursors_per_scan = 0
    # W4. Redundant identified precursors/ Identified precursors Rate
    score_precursor_redundancy = 0
    # W5. Identified precursors/ identified scan rate
    score_precusor_scan_rate = 0
    # W6. MS1 data point per peak
    score_ms1_DPPP = 0
    # W7. MS2 data point per peak
    score_ms2_DPPP = 0

    # IS1. 1+/2+ ions detected
    score_charge_oneTotwo = 0
    # IS2. 3+/2+ ions detected
    score_charge_threeTotwo = 0
    # IS3. 4+/2+ ions detected
    score_charge_fourTotwo = 0
    # IS4. Med. precursor m/z
    score_precursor_mz = 0
    # IS5. Precursors charge distribution
    # score_precursor_charge = 0

    # M1. Proportion of MS1 time
    score_ms1_time = 0
    # M2. Med. MS1 ion injection time
    score_ms1_injection_time = 0
    # M3. Median MS2 ion injection time
    score_ms2_injection_time = 0
    # M4. MS1 cycle time
    score_ms1_cycle_time = 0
    # M5. MS2 cycle time
    score_ms2_cycle_time = 0
    # M6. Median peaks intensity of MS1
    score_ms1_peak_intensity = 0
    # M7. Median peaks number of MS1
    score_ms1_peak_number = 0
    # M8. Median peaks number of MS2
    score_ms2_peak_number = 0
    # M9. Median peaks intensity of MS2
    score_ms2_peak_intensity = 0
    # M10. Identified / detected features
    score_ID_feature = 0
    # M11. Signal to noise（S/N）for precursors
    score_SN_precursor = 0
    # M12. Median of MS1 raw mass accuracy
    score_ms1_ppm = 0
    # M13. Median of MS2 raw mass accuracy
    score_ms2_ppm = 0
    # M14. Median intensities for precursors
    score_precursor_intensity = 0
    # M15. Median intensities for peptides
    score_peptide_intensity = 0
    # M16. Median intensities for protein groups
    score_protein_intesnity = 0
    # M17. Acquired MS1 scans
    score_acq_MS1_scan = 0
    # M18. Acquired MS2 scans
    score_acq_MS2_scan = 0
    # M19. MS2 identification rate
    score_ms2_ID_Rate = 0
    # M20. Max. identification rate over M/Z range
    score_IDrate_MZ = 0

    # ID1. Identified MS2 scans
    score_num_id_MS2scan = 0
    # ID2: Number of precursors
    score_num_precursor = 0
    # ID3: Number of peptides
    score_num_peptide = 0
    # ID4: Number of protein groups
    score_num_pgs = 0
    # ID5. Number of proteins
    score_num_pro = 0
    # ID6. AVG peptides per protein group
    score_num_PEP_PRO = 0
    # ID7. AVG precursors per protein group
    score_num_precur_PRO = 0


class CDataPack:

    myCFG = Config()


    LIST_PATH_MS1 = []
    LIST_PATH_MS2 = []

    LIST_PATH_ID = []


    myID = CFileID()
    myMS1 = CFileMS1()
    myMS2 = CFileMS2()
    myCYCLE = CCycle()
    myFeature = CFileFeature()
    myValue = CFileValue()
    myScore = CFileScore()
    myPicture = CFilePicture()
    myHtml = CFileHtml()

    scores = 0



