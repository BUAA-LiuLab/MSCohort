# -*- coding: utf-8 -*-
"""
Created on Tue Mar 12 18:52:55 2019

"""

VALUE_MAX_SCAN = 500000
VALUE_APP_SCAN = 100000
VALUE_ILLEGAL = -7.16  # 搞成整数有实际意义，不行


EXPIRATION_TIME = {'Year': 2024, 'Month': 12, 'Day': 31}

IO_NAME_FILE_EXPORT =('.ms1', '.ms2')

IO_PREFIX_EXPORT = (
    r'\txt\\',
    r'\picture\\',
    r'\tmp_file\\')

IO_FILENAME_EXPORT = (
    'INFO_MS1.txt',
    'INFO_MS2.txt',
    'INFO_Cycle_MS1.txt',
    'INFO_ID.txt',
    'INFO_Mass_Deviation.txt',
    'INFO_Chromatography.txt',
    'INFO_MS1_PEAKS.txt',
    'INFO_MS2_PEAKS.txt',
    'INFO_peptides.txt',
    'INFO_Scans.txt',
    'INFO_Cycle_MS2.txt',
    'INFO_Feature.txt',
    'IFNO_Summary.txt')

IO_FILENAME_PIC_EXPORT = (
    'Fig1_Chemo_Peakwidth',
    'Fig2_MS1_MS2_Scantime',
    'Fig3_MS1_Peaks_Intensity',
    'Fig4_MS2_Peaks_Intensity',
    'Fig5_IonInjectiontime',
    'Fig6_Cycletime',
    'Fig7_Datapoint',
    'Fig8_PeptideScanRatio',
    'Fig9_MS1_MassAccuracy',
    'Fig10_MS2_MassAccuracy',
    'Fig11_TrilinearChart',
    'Fig12_PrecursorWindow',
    'Fig13_MetricsScore',
    'Fig14_TotalScoreBar',
    'Fig15_FWHM',
    'Fig16_IDRate',
    'Fig17_Charge',
    'Fig18_feature',
    'Fig19_sample preparation')


CFG_TYPE_RAW = {'DDA': 0, 'DIA': 1}
CFG_TYPE_DATA = {'Thermo-Orbitrap': 0, 'timsTOF': 1, 'SCIEX': 2, 'Thermo-FAIMS':3}
CFG_TYPE_IDENTIFICATION_RESULT = {'Spectronaut': 0,'DIANN':1}
CFG_TYPE_MS1 = {'MS1': 1, }

