# -*- coding: utf-8 -*-


import datetime
import os
from MSLogging import logGetError, INFO_TO_USER_Staff, logToUser
from MSSystem import EXPIRATION_TIME, CFG_TYPE_DATA
from MSData import CDataPack
from MSFunction1 import FunctionConfig
from MSFlow import Flow1,Flow2,Flow3


class MSStaff:
    def __init__(self, inputArgv):

        self.dp = CDataPack()
        self.argv = inputArgv

    def start(self):

        # time
        self.__checkTime()

        # config
        n = len(self.argv)

        if n == 1:

            logToUser(INFO_TO_USER_Staff[4])
            functionConfig = FunctionConfig()
            if os.access("ini\\", os.F_OK):
                pass
            else:
                os.makedirs("ini\\")
            functionConfig.config2file('MSCohort_intra_cfg.txt', self.dp.myCFG)

        elif n == 2:

            functionConfig = FunctionConfig()
            functionConfig.file2config(self.argv[1], self.dp.myCFG)

            if self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['Thermo-Orbitrap']:
                flow1 = Flow1(self.dp)
                flow1.run()

            if self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['timsTOF']:
                flow2 = Flow2(self.dp)
                flow2.run()

            elif self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['SCIEX']:
                flow3 = Flow3(self.dp)
                flow3.run()

        else:

            info = 'Run MSCohort with this command: python MSCohort parameter file'
            logGetError(info)

        # finish
        logToUser(INFO_TO_USER_Staff[3])
        dateNow = datetime.datetime.now()
        logToUser(str(dateNow))

    @staticmethod
    def __checkTime():

        dateNow = datetime.datetime.now()
        dateDead = datetime.datetime(EXPIRATION_TIME['Year'], EXPIRATION_TIME['Month'], EXPIRATION_TIME['Day'], 23, 59)

        n_day = (dateDead - dateNow).days

        #print("MSStaff63: "+str(n_day))

        if n_day < 0:

            logGetError(INFO_TO_USER_Staff[0])

        elif n_day < 7:

            logToUser(INFO_TO_USER_Staff[1])

        else:

            logToUser(INFO_TO_USER_Staff[2])
            logToUser(str(dateNow))
