# -*- coding: utf-8 -*-
"""
Created on Tue Dec 12 19:03:21 2023

@author: liu xiang
"""

import logging
import sys

myLogPath = 'MSRefine_DIA.log'

INFO_TO_USER_FLOW1 = (

    '\n[MSRefine_DIA] <Flow1 DIA> Checking the environment...',
    '\n[MSRefine_DIA] <Flow1 DIA> Xtracting data from raw files...',
    '\n[MSRefine_DIA] <Flow1 DIA> Reading MS1 and MS2 files...',
    '\n[MSRefine_DIA] <Flow1 DIA> Analyzing scans...',
    '\n[MSRefine_DIA] <Flow1 DIA> Reading identification results...',
    '\n[MSRefine_DIA] <Flow1 DIA> Analyzing identification results.....',
    '\n[MSRefine_DIA] <Flow1 DIA> Writing report files...',
)

INFO_TO_USER_FLOW2 = (

    '\n[MSRefine_DIA] <Flow2 DIA> Checking the environment...',
    '\n[MSRefine_DIA] <Flow2 DIA> Xtracting data from raw files...',
    '\n[MSRefine_DIA] <Flow2 DIA> Reading MS1 and MS2 files...',
    '\n[MSRefine_DIA] <Flow2 DIA> Analyzing scans...',
    '\n[MSRefine_DIA] <Flow2 DIA> Reading identification results...',
    '\n[MSRefine_DIA] <Flow2 DIA> Analyzing identification results.....',
    '\n[MSRefine_DIA] <Flow2 DIA> Writing report files...',
)


INFO_TO_USER_Staff = (
    '\n[MSRefine_DIA] MSRefine_DIA is expired! Please send e-mail to liuchaobuaa@buaa.edu.cn for the new version.',
    '\n[MSRefine_DIA] Warning! The current license will expired in 7 days. Please send e-mail to liuchaobuaa@buaa.edu.cn for the new version.',
    '\n[MSRefine_DIA] Starting...',
    '\n[MSRefine_DIA] Finished!',
    '\n[MSRefine_DIA] Writing config file...',)

INFO_TO_USER_TaskReadMS = (
    '\n[MSRefine_DIA] <TaskReadMS> Reading MS1 file...',
    '\n[MSRefine_DIA] <TaskReadMS> Reading MS2 file...',)

INFO_TO_USER_TaskDraw = (
    '\n[MSRefine_DIA] Drawing figures...')

INFO_TO_USER_TaskExport = (
    '\n[MSRefine_DIA] <TaskExport> Export identified results...',
    '\n[MSRefine_DIA] <TaskExport> Export features...')

INFO_TO_USER_TaskXtract = (

    '\n[MSRefine_DIA] <TaskXtract> Extract RAW File:',
    '\n[MSRefine_DIA] <TaskXtract> MS1 and MS2 files are existed!',
    '\n[MSRefine_DIA] <TaskXtract> Extract wiff File:',
    '\n[MSRefine_DIA] <TaskXtract> Extract timsTOF.d File:',)


INFO_TO_USER_MSFunction = (

    '[MSRefine_DIA] <MSFunction> #Chromatograms: ',
    '[MSRefine_DIA] <MSFunction> #MS1: ',
    '[MSRefine_DIA] <MSFunction> #MS2: ')

def logToUser(strInfo):

    # if os.access(myLogPath, os.W_OK):  # 当文件被excel打开时，这个东东没啥用

    try:
        print(strInfo)
        f_w = open(myLogPath, 'a', encoding='utf8')
        f_w.write(strInfo + '\n')
        f_w.close()
    except IOError:
        print("MSRefine_DIA.log is opened! Please close it and run the program again!")
        sys.exit(0)



def logGetError(info):
    
    print(info)
    
    logging.basicConfig(filename='MSRefine_DIA.log',
                        filemode='a',
                        format='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'
                        )
    logging.error(info)
    sys.exit(0)
    

def logGetWarning(info):
    
    print(info)
    
    logging.basicConfig(filename = 'MSRefine_DIA.log',
                        filemode='a',
                        format = '%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'
                        )
    logging.warn(info)

