# -*- coding: utf-8 -*-


from MSTask import CTaskReadID, CTaskReadMS, CTaskReport, CTaskXtract, CTaskRaw2MS, CTaskCheck, CTaskAnalyzeMS, CTaskAnalyzeID, CTaskAnalyzeIDtims, CTaskReporttims
from MSLogging import INFO_TO_USER_FLOW1, INFO_TO_USER_FLOW2, logToUser


class Flow0:

    def run(self):
        pass


class Flow1:

    def __init__(self, inputDP):

        self.dp = inputDP

    def run(self):
        logToUser(INFO_TO_USER_FLOW1[0])
        taskCheck = CTaskCheck(self.dp)
        taskCheck.work()


        logToUser(INFO_TO_USER_FLOW1[1])
        taskRaw2MS = CTaskRaw2MS(self.dp)
        taskRaw2MS.workThermo()


        logToUser(INFO_TO_USER_FLOW1[2])
        taskRead1 = CTaskReadMS(self.dp)
        taskRead1.work()


        logToUser(INFO_TO_USER_FLOW1[3])
        taskAnalyze1 = CTaskAnalyzeMS(self.dp)
        taskAnalyze1.work()


        logToUser(INFO_TO_USER_FLOW1[4])
        taskRead2 = CTaskReadID(self.dp)
        taskRead2.work()


        logToUser(INFO_TO_USER_FLOW1[5])
        taskAnalyze2 = CTaskAnalyzeID(self.dp)
        taskAnalyze2.work()


        logToUser(INFO_TO_USER_FLOW1[6])
        taskReport = CTaskReport(self.dp)
        taskReport.workDIA()


class Flow2:

    def __init__(self, inputDP):

        self.dp = inputDP

    def run(self):


        logToUser(INFO_TO_USER_FLOW2[0])
        taskCheck = CTaskCheck(self.dp)
        taskCheck.work()


        logToUser(INFO_TO_USER_FLOW2[1])
        taskRaw2MS = CTaskRaw2MS(self.dp)
        taskRaw2MS.workTIMS()


        logToUser(INFO_TO_USER_FLOW2[2])
        taskRead1 = CTaskReadMS(self.dp)
        taskRead1.work()


        logToUser(INFO_TO_USER_FLOW2[3])
        taskAnalyze1 = CTaskAnalyzeMS(self.dp)
        taskAnalyze1.work()


        logToUser(INFO_TO_USER_FLOW2[4])
        taskRead2 = CTaskReadID(self.dp)
        taskRead2.work()


        logToUser(INFO_TO_USER_FLOW2[5])
        taskAnalyze2 = CTaskAnalyzeIDtims(self.dp)
        taskAnalyze2.work()


        logToUser(INFO_TO_USER_FLOW2[6])
        taskReport = CTaskReport(self.dp)
        taskReport.workDIA()


class Flow3:

    def __init__(self, inputDP):

        self.dp = inputDP

    def run(self):


        logToUser(INFO_TO_USER_FLOW2[0])
        taskCheck = CTaskCheck(self.dp)
        taskCheck.work()


        logToUser(INFO_TO_USER_FLOW2[1])
        taskRaw2MS = CTaskRaw2MS(self.dp)
        taskRaw2MS.workSCIEX()


        logToUser(INFO_TO_USER_FLOW2[2])
        taskRead1 = CTaskReadMS(self.dp)
        taskRead1.work()


        logToUser(INFO_TO_USER_FLOW2[3])
        taskAnalyze1 = CTaskAnalyzeMS(self.dp)
        taskAnalyze1.work()


        logToUser(INFO_TO_USER_FLOW2[4])
        taskRead2 = CTaskReadID(self.dp)
        taskRead2.work()


        logToUser(INFO_TO_USER_FLOW2[5])
        taskAnalyze2 = CTaskAnalyzeID(self.dp)
        taskAnalyze2.work()


        logToUser(INFO_TO_USER_FLOW2[6])
        taskReport = CTaskReport(self.dp)
        taskReport.workDIA()


