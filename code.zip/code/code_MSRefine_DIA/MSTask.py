
import numpy as np
import os
import pickle

from MSTool import toolGetWord,  toolMass2MZ, toolCopyList, toolCountInList
from MSSystem import IO_FILENAME_EXPORT, CFG_TYPE_IDENTIFICATION_RESULT
from MSFunction1 import CFunctionParse_9, CFunctionRaw2M_13, CFunctionParse_4, CFuntionParseMS2, CFunctionScan2_8, \
    CFunctionAnaly_12, CFunctionAnaly_6, CFunctionAnaly_3, CFunctionAnaly_7, \
    CFunctionAnaly_1 ,CFunctionParse_2 ,CFunctionAnaly_10
from MSLogging import INFO_TO_USER_TaskXtract, INFO_TO_USER_TaskReadMS, INFO_TO_USER_TaskExport, logGetError, logToUser
from MSFunctionRep2 import CFunctionPlotC_5, CFunctionPlotS_8, CFunctionPlotM_20, CFunctionPlotF_17 ,CFunctionPlotM_2, CFunctionPlotI_18, CFunctionPlotM_19, CFunctionPlotD_4 ,CFunctionPlotP_12, CFunctionPlotM_16, CFunctionPlotM_9, \
    CFunctionPlotT_13, CFunctionPlotP_1 ,CFunctionPlotT_3, CFunctionDraw__21 ,CFunctionDraw__10 ,CFunctionPlotM_14 \
    ,CFunctionPlotI_6 ,CFunctionPlotC_7 ,CFunctionPlotS_11 ,CFunctionPlotF_15
from MSFunctionTab3 import Metrics_Table


class CTaskCheck:



    def __init__(self, inputDP):

        self.dp = inputDP

    def work(self):


        for nameFile in IO_FILENAME_EXPORT:

            path = self.dp.myCFG.E1_PATH_EXPORT + nameFile

            if os.access(self.dp.myCFG.E1_PATH_EXPORT, os.F_OK):

                try:

                    fid1 = open(path, 'w', -1)
                    fid1.close()

                except IOError:

                    logGetError(path + ' is opened! Please close it and run the program again!')

            else:

                os.makedirs(self.dp.myCFG.E1_PATH_EXPORT)


class CTaskXtract:

    def __init__(self, p):

        self.dp = p

    def work(self):

        self.dp.myCFG.A1_PATH_MS1 = self.dp.myCFG.A0_PATH_RAW[0:-3] + 'ms1'
        self.dp.myCFG.A2_PATH_MS2 = self.dp.myCFG.A0_PATH_RAW[0:-3] + 'ms2'

        if os.access(self.dp.myCFG.A1_PATH_MS1, os.R_OK) and os.access(self.dp.myCFG.A2_PATH_MS2, os.R_OK):

            logToUser(INFO_TO_USER_TaskXtract[1])

        else:

            logToUser(INFO_TO_USER_TaskXtract[0])
            out_xtract = os.system(self.dp.myCFG.S1_PATH_XTRACT +" -ms -a  " +self.dp.myCFG.A0_PATH_RAW)
            logToUser(str(out_xtract))


class CTaskRaw2MS:

    def __init__(self, inputDP):

        self.dp = inputDP

    def workThermo(self):

        self.dp.myCFG.A1_PATH_MS1 = self.dp.myCFG.A0_PATH_RAW.split('.')[0] + '.ms1'
        self.dp.myCFG.A2_PATH_MS2 = self.dp.myCFG.A0_PATH_RAW.split('.')[0] + '.ms2'

        if os.access(self.dp.myCFG.A1_PATH_MS1, os.R_OK) and os.access(self.dp.myCFG.A2_PATH_MS2, os.R_OK):

            logToUser(INFO_TO_USER_TaskXtract[1])
        else:

            functionRaw2MS = CFunctionRaw2M_13(self.dp)
            count_MS1, count_MS2 = functionRaw2MS.Raw2MS(self.dp.myCFG.A0_PATH_RAW)
            print(INFO_TO_USER_TaskXtract[0] + 'MS1 number:{:d}, MS2 number:{:d}'.format(count_MS1, count_MS2))

    def workSCIEX(self):
        self.dp.myCFG.A1_PATH_MS1 = self.dp.myCFG.A0_PATH_RAW.split('.')[0] + '.ms1'
        self.dp.myCFG.A2_PATH_MS2 = self.dp.myCFG.A0_PATH_RAW.split('.')[0] + '.ms2'

        if os.access(self.dp.myCFG.A1_PATH_MS1, os.R_OK) and os.access(self.dp.myCFG.A2_PATH_MS2, os.R_OK):
            logToUser(INFO_TO_USER_TaskXtract[1])
        else:
            WIFF = self.dp.myCFG.A0_PATH_RAW
            WIFF2 = WIFF + '2'
            if os.path.exists(WIFF2):
                os.system(r".\lib\wiff2\wiffExport.exe " + " -f " + WIFF2+ " -a")
            else:
                os.system(r".\lib\wiff\xtract_wiff.exe -mgf -ms " + WIFF)
            logToUser(INFO_TO_USER_TaskXtract[2])







    def workTIMS(self):
        path_d = self.dp.myCFG.A0_PATH_RAW.split('\\')[-1]
        self.dp.myCFG.A1_PATH_MS1 = self.dp.myCFG.A0_PATH_RAW +'\\' + path_d + '.ms1'
        self.dp.myCFG.A2_PATH_MS2 = self.dp.myCFG.A0_PATH_RAW +'\\' + path_d + '.ms2'

        if os.access(self.dp.myCFG.A1_PATH_MS1, os.R_OK) and os.access(self.dp.myCFG.A2_PATH_MS2, os.R_OK):
            logToUser(INFO_TO_USER_TaskXtract[1])
        else:
            exe_MSFileReader = r'.\lib\read_timsTof_simple\read_timsTof_simple.exe'
            path = self.dp.myCFG.A0_PATH_RAW
            cmd = exe_MSFileReader + ' {:s}'.format(path)
            try:
                os.system(cmd)
            except:
                logGetError('read_timsTof.exe run wrong!')
            logToUser(INFO_TO_USER_TaskXtract[3])







class CTaskExport:

    def __init__(self, c, p):

        self.config = c
        self.packExp = p

    def work(self):

        print(INFO_TO_USER_TaskExport[0])




        self.__soldier_Export_INFO_ID()
        self.__soldier_Export_INFO_MASS_DEVIATION()
        self.__soldier_Export_INFO_CHROMATOGRAPHY()

    def __soldier_Export_INFO_CHROMATOGRAPHY(self):

        path = self.config.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[5]

        with open(path, 'w') as f:

            n_psm = len(self.packExp.LIST_ID_SCAN)

            for i_psm in range(n_psm):

                f.write(str(self.packExp.LIST_ID_SCAN[i_psm]))
                f.write('\t')
                f.write('{0:e}'.format(self.packExp.LIST_ID_SCORE[i_psm]))
                f.write('\t')

                tmp_delta_rt = self.packExp.PROFILE_L_MS1_RT[i_psm][self.packExp.PROFILE_I_END[i_psm]] - self.packExp.PROFILE_L_MS1_RT[i_psm][self.packExp.PROFILE_I_START[i_psm]]

                f.write('{0:.2f}'.format(tmp_delta_rt / 60))
                f.write('\n')

    def __soldier_Export_INFO_MASS_DEVIATION(self):

        path = self.config.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[4]

        with open(path, 'w') as f:

            n_psm = len(self.packExp.LIST_ID_SCAN)

            for i in range(n_psm):
                f.write(str(self.packExp.LIST_ID_SCAN[i]))
                f.write('\t')
                f.write('{0:e}'.format(self.packExp.LIST_ID_SCORE[i]))
                f.write('\t')

                tmp_delta_mass = self.packExp.LIST_ID_MASS_E[i] - self.packExp.LIST_ID_MASS_T[i]

                f.write('{0:.5f}'.format(tmp_delta_mass))
                f.write('\t')
                f.write('{0:.2f}'.format(tmp_delta_mass /self.packExp.LIST_ID_MASS_T[i ] *1E6))
                f.write('\n')

    def __soldier_Export_INFO_ID(self):

        path = self.config.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[3]

        with open(path, 'w') as f:

            n_uni = len(self.packExp.LIST_ID_UNI)

            for i in range(n_uni):

                f.write(self.packExp.LIST_ID_UNI[i])
                f.write('\t')
                f.write(str(self.packExp.LIST_ID_UNI_N_PSM[i]))
                f.write('\n')


class CTaskReadMS:

    def __init__(self, inputDP):

        self.dp = inputDP

    def work(self):

        logToUser(INFO_TO_USER_TaskReadMS[0])
        functionMS1 = CFunctionParse_4(self.dp)
        functionMS1.ms1TOpkl(self.dp.myCFG.A1_PATH_MS1)

        logToUser(INFO_TO_USER_TaskReadMS[1])
        functionMS2 = CFuntionParseMS2(self.dp)
        functionMS2.ms2TOpkl(self.dp.myCFG.A2_PATH_MS2)


class CTaskReadID:

    def __init__(self, inputDP):

        self.dp = inputDP

    def work(self):
        if self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_IDENTIFICATION_RESULT['Spectronaut']:

            functionRead = CFunctionParse_9(self.dp)
            functionRead.read(self.dp.myCFG.B2_PATH_IDENTIFICATION_RESULT)

        elif self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_IDENTIFICATION_RESULT['DIANN']:
            functionRead = CFunctionParse_2(self.dp)
            functionRead.read(self.dp.myCFG.B2_PATH_IDENTIFICATION_RESULT)


class CTaskAnalyzeMS:

    def __init__(self, inputDP):
        self.dp = inputDP

    def work(self):


        pathPKLMS1 = self.dp.myCFG.A1_PATH_MS1 + ".pkl"
        pklFileMS1 = open(pathPKLMS1, 'rb')
        dataMS1 = pickle.load(pklFileMS1)
        pklFileMS1.close()

        pathPKLMS2 = self.dp.myCFG.A2_PATH_MS2 + ".pkl"
        pklFileMS2 = open(pathPKLMS2, 'rb')
        dataMS2 = pickle.load(pklFileMS2)
        pklFileMS2.close()


        function1 = CFunctionAnaly_12(self.dp, dataMS1, dataMS2)
        function1.analyze()


        function2 = CFunctionAnaly_6(self.dp, dataMS1, dataMS2)
        function2.analyze()


        function3 = CFunctionAnaly_1(self.dp, dataMS1, dataMS2)
        function3.analyze()


class CTaskAnalyzeID:

    def __init__(self, inputDP):
        self.dp = inputDP

    def work(self):

        if self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_IDENTIFICATION_RESULT['Spectronaut']:

            pathPKLMS1 = self.dp.myCFG.A1_PATH_MS1 + ".pkl"
            pklFileMS1 = open(pathPKLMS1, 'rb')
            dataMS1 = pickle.load(pklFileMS1)
            pklFileMS1.close()

            pathPKLMS2 = self.dp.myCFG.A2_PATH_MS2 + ".pkl"
            pklFileMS2 = open(pathPKLMS2, 'rb')
            dataMS2 = pickle.load(pklFileMS2)
            pklFileMS2.close()


            logToUser(INFO_TO_USER_TaskExport[0])
            functionPrint = CFunctionScan2_8(self.dp, dataMS1, dataMS2)
            functionPrint.work()


            function2 = CFunctionAnaly_3(self.dp)
            function2.analyze()


            function3 = CFunctionAnaly_7(self.dp)
            function3.analyze()


            if self.dp.myCFG.E3_FLAG_ANALYZE_FEATURE != 0:
                logToUser(INFO_TO_USER_TaskExport[1])
                function4 = CFunctionAnaly_10(self.dp, dataMS1, dataMS2)
                function4.analyze()

        else:
            info = 'The type of identification result is unknown.'
            logGetError(info)


class CTaskReport:
    def __init__(self, inputDP):
        self.dp = inputDP

    def workDIA(self):

        if self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_IDENTIFICATION_RESULT['Spectronaut']:

            pathPKLMS1 = self.dp.myCFG.A1_PATH_MS1 + ".pkl"
            pklFileMS1 = open(pathPKLMS1, 'rb')
            dataMS1 = pickle.load(pklFileMS1)
            pklFileMS1.close()

            pathPKLMS2 = self.dp.myCFG.A2_PATH_MS2 + ".pkl"
            pklFileMS2 = open(pathPKLMS2, 'rb')
            dataMS2 = pickle.load(pklFileMS2)
            pklFileMS2.close()


            Summary = Metrics_Table(self.dp, dataMS1, dataMS2)
            Summary.CFunctionValue()


            figfolder = self.dp.myCFG.E1_PATH_EXPORT + "picture\\"
            if not os.path.exists(figfolder):
                os.makedirs(figfolder)


            Plot1 = CFunctionPlotT_13(self.dp, dataMS1, dataMS2)
            Plot1.draw(figfolder)


            Plot2 = CFunctionPlotT_3(self.dp, dataMS1, dataMS2)
            Plot2.draw(figfolder)


            Plot3 = CFunctionPlotM_14(self.dp)
            Plot3.draw(figfolder)


            Plot4 = CFunctionPlotF_17(self.dp)
            Plot4.draw(figfolder)


            Plot5 = CFunctionPlotC_5(self.dp)
            Plot5.draw(figfolder)


            Plot6 = CFunctionPlotS_8(self.dp, dataMS1, dataMS2)
            Plot6.draw(figfolder)


            Plot7 = CFunctionPlotM_19(self.dp, dataMS1, dataMS2)
            Plot7.draw(figfolder)


            Plot8 = CFunctionPlotI_18(self.dp, dataMS1, dataMS2)
            Plot8.draw(figfolder)


            Plot9 = CFunctionPlotP_1(self.dp)
            Plot9.draw(figfolder)


            Plot10 = CFunctionPlotD_4(self.dp, dataMS1, dataMS2)
            Plot10.draw(figfolder)


            Plot11 = CFunctionPlotP_12(self.dp, dataMS1, dataMS2)
            Plot11.draw(figfolder)


            Plot12 = CFunctionPlotM_16(self.dp)
            Plot12.draw(figfolder)


            Plot13 = CFunctionPlotM_9(self.dp)
            Plot13.draw(figfolder)


            Plot14 = CFunctionPlotM_20(self.dp, dataMS1)
            Plot14.draw(figfolder)


            Plot15 = CFunctionPlotM_2(self.dp, dataMS2)
            Plot15.draw(figfolder)


            Plot16 = CFunctionPlotI_6(self.dp ,dataMS1 ,dataMS2)
            Plot16.draw(figfolder)


            Plot17 = CFunctionPlotC_7(self.dp ,dataMS1 ,dataMS2)
            Plot17.draw(figfolder)

            Plot18 = CFunctionPlotS_11(self.dp)
            Plot18.draw(figfolder)


            Plot19 = CFunctionPlotF_15(self.dp)
            Plot19.draw(figfolder)


            Repothtml = CFunctionDraw__21(self.dp, dataMS1, dataMS2)
            Repothtml.var_wri_130()


class CTaskAnalyzeIDtims:

    def __init__(self, inputDP):
        self.dp = inputDP

    def work(self):
        if self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_IDENTIFICATION_RESULT['Spectronaut']:

            pathPKLMS1 = self.dp.myCFG.A1_PATH_MS1 + ".pkl"
            pklFileMS1 = open(pathPKLMS1, 'rb')
            dataMS1 = pickle.load(pklFileMS1)
            pklFileMS1.close()

            pathPKLMS2 = self.dp.myCFG.A2_PATH_MS2 + ".pkl"
            pklFileMS2 = open(pathPKLMS2, 'rb')
            dataMS2 = pickle.load(pklFileMS2)
            pklFileMS2.close()


            functionPrint = CFunctionScan2_8(self.dp, dataMS1, dataMS2)
            functionPrint.work()


            function2 = CFunctionAnaly_3(self.dp)
            function2.analyze()


            function3 = CFunctionAnaly_7(self.dp)
            function3.analyze()

        else:
            info = 'The type of identification result is illegal.'
            logGetError(info)


class CTaskReporttims:
    def __init__(self, inputDP):
        self.dp = inputDP

    def workDIA(self):

        if self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_IDENTIFICATION_RESULT['Spectronaut']:

            pathPKLMS1 = self.dp.myCFG.A1_PATH_MS1 + ".pkl"
            pklFileMS1 = open(pathPKLMS1, 'rb')
            dataMS1 = pickle.load(pklFileMS1)
            pklFileMS1.close()

            pathPKLMS2 = self.dp.myCFG.A2_PATH_MS2 + ".pkl"
            pklFileMS2 = open(pathPKLMS2, 'rb')
            dataMS2 = pickle.load(pklFileMS2)
            pklFileMS2.close()


            figfolder = self.dp.myCFG.E1_PATH_EXPORT + "picture\\"
            if not os.path.exists(figfolder):
                os.makedirs(figfolder)


            Plot1 = CFunctionPlotC_5(self.dp)
            Plot1.draw(figfolder)


            Plot2 = CFunctionPlotS_8(self.dp, dataMS1, dataMS2)
            Plot2.draw(figfolder)


            Plot3 = CFunctionPlotM_20(self.dp, dataMS1)
            Plot3.draw(figfolder)


            Plot4 = CFunctionPlotM_2(self.dp, dataMS2)
            Plot4.draw(figfolder)


            Plot5 = CFunctionPlotI_18(self.dp, dataMS1, dataMS2)
            Plot5.draw(figfolder)


            Plot6 = CFunctionPlotM_19(self.dp, dataMS1, dataMS2)
            Plot6.draw(figfolder)


            Plot7 = CFunctionPlotD_4(self.dp)
            Plot7.draw(figfolder)


            Plot8 = CFunctionPlotP_12(self.dp, dataMS1, dataMS2)
            Plot8.draw(figfolder)


            Plot9 = CFunctionPlotM_16(self.dp)
            Plot9.draw(figfolder)


            Plot10 = CFunctionPlotM_9(self.dp)
            Plot10.draw(figfolder)


            Plot11 = CFunctionPlotT_13(self.dp, dataMS1, dataMS2)
            Plot11.draw(figfolder)


            Plot12 = CFunctionPlotP_1(self.dp)
            Plot12.draw(figfolder)

            Repothtml = CFunctionDraw__10(self.dp)
            Repothtml.write_html()











