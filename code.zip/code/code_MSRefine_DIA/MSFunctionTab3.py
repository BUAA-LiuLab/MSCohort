
import numpy as np
import math
from MSSystem import IO_FILENAME_EXPORT, CFG_TYPE_DATA
from MSOperator import feature_INFO, Meaning_INFO, Thermo_radar_info, Bruker_radar_info, SCIEX_radar_info


class Metrics_Table:
    def __init__(self, inputDP, inputDataMS1, inputDataMS2):

        self.dp = inputDP
        self.dataMS1 = inputDataMS1
        self.dataMS2 = inputDataMS2

    def CFunctionValue(self):
        timesum1 = np.sum(self.dp.myMS1.INDEX_SCAN_TIME_MS1)
        timesum2 = np.sum(self.dp.myMS2.INDEX_SCAN_TIME_MS2)
        timesum = int((timesum2 + timesum1) / 60)

        # Sample Preparation
        # S1. Missed cleavages(n=0) of peptides
        pep_MC_ratio = round(float((self.dp.myID.PSM30_MissedCleavage.count(0)) / (len(self.dp.myID.PSM30_MissedCleavage))*100), 2)
        self.dp.myValue.miss_cleavage = pep_MC_ratio

        # S2. Median peptide length
        pep_length = []
        for i in self.dp.myID.PSM4_SEQ:
            length = len(i)
            pep_length.append(length)
        self.dp.myValue.peptide_length = np.median(pep_length)

        # S3. Median Total Ion Current (TIC)
        TIC = round(sum(self.dp.myMS1.INTENSITY_PEAKS_MS1) + sum(self.dp.myMS2.INTENSITY_PEAKS_MS2), 2)
        self.dp.myValue.TIC = TIC

        # Chromatography
        # C1. Chromatographic invalid acquiring time
        a = np.array(list(zip(self.dataMS2.INDEX_SCAN, self.dp.myID.SCAN_TO_PEPTIDE, self.dataMS2.INDEX_RT)))
        Id_ms2scan = a[np.all(a != 0, axis=1)]  # 去除含0的行
        Id_ms2_RT = Id_ms2scan[:, 2]
        Id_ms2_RT = [i / 60 for i in Id_ms2_RT]
        Id_ms2_scan = Id_ms2scan[:, 0]




        IDms2permin_index = [0]
        flag = 0
        for i in range(1, timesum):
            for index, rt in enumerate(Id_ms2_RT[flag:]):
                if rt / 1 < i:
                    continue
                if rt / 1 >= i:
                    IDms2permin_index.append(flag + index)
                    flag = flag + index
                    break
        dead_index = 0
        for i in range(1,len(IDms2permin_index)):
            num = IDms2permin_index[i] - IDms2permin_index[i-1]
            if num > self.dp.myCFG.C6_THRESHOLD_INVALID_ACQUIRING_SCAN:
                dead_index = i
                break
        self.dp.myValue.deadtime = dead_index
        del flag, index, dead_index

        # C2. Median of full width at half maximum (FWHM)
        self.dp.myValue.fwhm_median = round(float(np.median(self.dp.myID.PSM28_FWHM)),2)
        # C3. Median of peak width
        self.dp.myValue.chrom_median = round(float(np.median(self.dp.myID.PSM29_PeakWidth)), 2)
        # C4. Proportion of peptides with long eluting width
        notail = 0
        for i in self.dp.myID.PSM29_PeakWidth:
            if i <= self.dp.myCFG.C5_THRESHOLD_PEAK_WIDTH_TAILING:
                notail += 1
        self.dp.myValue.tail_ratio = round(1 - (notail / len(self.dp.myID.PSM29_PeakWidth)), 4)
        # C5. Median precursors identified over RT
        precursor_permin = [0]
        percursor_permin_index = [0]
        PSM_RT = [i for i in self.dp.myID.PSM3_RT]
        PSM_RT.sort()
        flag = 0
        for i in range(1, timesum):
            for index, item in enumerate(PSM_RT[flag:]):
                tempRt = item
                if tempRt < i:
                    continue
                if tempRt >= i:
                    percursor_permin_index.append(flag + index)
                    flag = flag + index
                    break

        for i in range(1, len(percursor_permin_index)):
            if i == 0:
                precursor_permin.append(percursor_permin_index[i])
            else:
                num = percursor_permin_index[i] - percursor_permin_index[i-1]
                precursor_permin.append(num)
        self.dp.myValue.precursor_per_min = np.median(precursor_permin)
        self.dp.myPicture.IDRate_precursor = precursor_permin
        del flag,index,PSM_RT,num
        # C6. Max. identification rate over RT
        IDratepermin = []
        Acquiredms2permin_index = [0]
        flag = 0
        for i in range(1, timesum):
            for index, item in enumerate(self.dataMS2.INDEX_RT[flag:]):
                tempRt = item / 60
                if tempRt < i:
                    continue
                if tempRt >= i:
                    Acquiredms2permin_index.append(flag + index)
                    flag = flag + index
                    break
        len_min = min(len(IDms2permin_index), len(Acquiredms2permin_index))
        if Acquiredms2permin_index[0] != 0:
            IDratepermin.append(round(IDms2permin_index[0] / Acquiredms2permin_index[0], 4))
        else:
            IDratepermin.append(0)
        for i in range(1, len_min):
            if (Acquiredms2permin_index[i] - Acquiredms2permin_index[i-1])!= 0:
                IDratepermin.append(round((IDms2permin_index[i] - IDms2permin_index[i-1])/(Acquiredms2permin_index[i] - Acquiredms2permin_index[i-1]),4))
            else:
                IDratepermin.append(0)
        self.dp.myValue.IDrate_RT = max(IDratepermin)
        self.dp.myPicture.IDrate_min = IDratepermin
        del IDratepermin, Acquiredms2permin_index,IDms2permin_index

        # DIA window
        # W1. Acquired MS2 scans in one cycle
        self.dp.myValue.MS2_window = len(set(self.dp.myMS2.INDEX_ACTIVATION_CENTER))

        # W2. Median of window size (Da)
        # if self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['SCIEX']:
        # 用prewindow范围计算window size
        Window_Left = []
        Window_Right = []
        Window_size = []
        new_window = []

        for i in range(len(self.dp.myID.PSM25_PrecWindow)):
            i_window = self.dp.myID.PSM25_PrecWindow[i]
            if i_window not in new_window:
                new_window.append(i_window)
                left = float(i_window.split(' ')[0][1:])
                right = float(i_window.split(' ')[2][:-1])
                Window_Left.append(left)
                Window_Right.append(right)
                Window_size.append(right - left)
            else:
                pass
        self.dp.myValue.windows_size = round(float(np.median(Window_size)), 2)

        # else:
        #     window_size = list(set(self.dataMS2.INDEX_ISOLATION_WIDTH))
        #     self.dp.myValue.windows_size = round(float(np.median(window_size)),1)

        # W3. Redundant identified precursors/ Identified Scan Rate
        Id_MS2scan = len(self.dp.myID.SCAN_TO_PEPTIDE) - self.dp.myID.SCAN_TO_PEPTIDE.count(0)
        self.dp.myValue.precursors_per_scan = round(np.sum(self.dp.myID.SCAN_TO_PEPTIDE)/Id_MS2scan,2)

        # W4. Redundant identified precursors/ Identified precursors Rate
        self.dp.myValue.precursor_redundancy = round(float(np.mean(self.dp.myID.SCAN_REDUNDANCE)),2)

        # W5. Identified precursors/ identified scan rate
        self.dp.myValue.precusor_scan_rate = round(len(self.dp.myID.PSM31_Precursor)/len(Id_ms2_scan),2)

        # W6. MS1 data point per peak
        self.dp.myValue.ms1_DPPP = int(np.median(self.dp.myID.PSM32_DataPoint_MS1))

        # W7. MS2 data point per peak
        self.dp.myValue.ms2_DPPP = int(np.median(self.dp.myID.PSM24_DataPoint))

        # Ion source
        # IS1. 1+/2+ ions detected
        # IS2. 3+/2+ ions detected
        # IS3. 4+/2+ ions detected
        if self.dp.myCFG.E3_FLAG_ANALYZE_FEATURE == 0:
            self.dp.myValue.charge_oneTotwo = '-'
            self.dp.myValue.charge_threeTotwo = '-'
            self.dp.myValue.charge_fourTotwo = '-'
        else:
            ID_Feature_Mz, ID_Feature_Int = [], []
            targeted = 0
            identified = 0
            FeatureScan = list(self.dp.myFeature.LIST_MOZ_MONO)
            detected = len(FeatureScan)
            for i in range(len(self.dp.myFeature.LIST_MOZ_MONO)):
                tmpScan = FeatureScan[i]
                tmpState = self.dp.myFeature.STATE_OF_FEATURE[i].split('\t')[-1]
                if tmpState == 'acquired':
                    targeted = targeted + 1
                elif tmpState == 'identified':
                    ID_Feature_Mz.append(self.dp.myFeature.LIST_MOZ_MONO[i])
                    ID_Feature_Int.append(self.dp.myFeature.INDEX_INTENSITY_ALL[i])
                    targeted = targeted + 1
                    identified = identified + 1
            #targeted_detected = round(targeted / detected, 2)
            #identified_targeted = round(identified / targeted, 2)

            one = 0
            two = 0
            three = 0
            four = 0
            for charge in self.dp.myFeature.INDEX_CHARGE:
                if charge == '1':
                    one = one + 1
                elif charge == '2':
                    two = two + 1
                elif charge == '3':
                    three = three + 1
                elif charge == '4' or charge == '5':
                    four = four + 1
            self.dp.myValue.charge_oneTotwo = round(one / two, 2)
            self.dp.myValue.charge_threeTotwo = round(three / two, 2)
            self.dp.myValue.charge_fourTotwo = round(four / two, 2)



        # IS4. Median precursor m/z
        self.dp.myValue.precursor_mz = round(float(np.median(self.dp.myID.PSM15_PRE_MOZ)), 3)
        # IS5. Precursors charge distribution
        pre_one = 0
        for charge_i in self.dp.myID.PSM9_CHARGE:
            if charge_i == 1:
                pre_one = pre_one + 1
        self.dp.myValue.charge_oneToall = round(pre_one / len(self.dp.myID.PSM9_CHARGE), 2)

        # MS1 and MS2 Signal
        # M1. Proportion of MS1 time
        self.dp.myValue.ms1_time = round((timesum1/60) / timesum, 2)

        if self.dp.myCFG.A1_TYPE_DATA == 1 or self.dp.myCFG.A1_TYPE_DATA == 2:
            self.dp.myValue.ms1_injection_time = '-'
            self.dp.myValue.ms2_injection_time = '-'
        else:
            # M2. Median MS1 ion injection time
            self.dp.myValue.ms1_injection_time = round(float(np.median(self.dataMS1.INDEX_ION_INJECTION_TIME)), 2)
            # M3. Median MS2 ion injection time
            self.dp.myValue.ms2_injection_time = round(float(np.median(self.dataMS2.INDEX_ION_INJECTION_TIME)), 2)
        # M4. MS1 cycle time
        self.dp.myValue.ms1_cycle_time = round(float(np.median(self.dp.myCYCLE.LIST_CYCLES_TIME)), 2)
        # M5. MS2 cycle time
        self.dp.myValue.ms2_cycle_time = round(float(np.median(self.dp.myCYCLE.LIST_CYCLES_TIME_MS2)), 2)
        # M6. Median peaks intensity of MS1
        self.dp.myValue.ms1_peak_intensity = round(float(np.median(self.dp.myMS1.INTENSITY_PEAKS_MS1)), 2)
        # M7. Median peaks number of MS1
        self.dp.myValue.ms1_peak_number = round(float(np.median(self.dp.myMS1.N_PEAKS_MS1)), 2)
        # M8. Median peaks number of MS2
        self.dp.myValue.ms2_peak_number = round(float(np.median(self.dp.myMS2.N_PEAKS_MS2)), 2)
        # M9. Median peaks intensity of MS2
        self.dp.myValue.ms2_peak_intensity = round(float(np.median(self.dp.myMS2.INTENSITY_PEAKS_MS2)), 2)
        # M10. Identified / detected features
        if self.dp.myCFG.E3_FLAG_ANALYZE_FEATURE == 0 or self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['SCIEX']:
            self.dp.myValue.ID_feature = '-'
        else:
            self.dp.myValue.ID_feature = round(float(identified / detected), 2)
        # M11. Signal to noise（S/N）for precursors
        SN_pre = np.array(self.dp.myID.PSM17_PRE_SignalToNoise)[~np.isnan(self.dp.myID.PSM17_PRE_SignalToNoise)]
        self.dp.myValue.SN_precursor = round(float(np.median(SN_pre)),2)
        # M12. Median of MS1 raw mass accuracy
        MS1_absdev = np.array(self.dp.myID.PSM26_MS1_MassAccuracy)[~np.isnan(self.dp.myID.PSM26_MS1_MassAccuracy)]
        self.dp.myValue.ms1_ppm = round(abs(np.median(MS1_absdev)), 2)
        # M13. Median of MS2 raw mass accuracy
        MS2_absdev = np.array(self.dp.myID.PSM27_MS2_MassAccuracy)[~np.isnan(self.dp.myID.PSM27_MS2_MassAccuracy)]
        self.dp.myValue.ms2_ppm = round(abs(np.median(MS2_absdev)), 2)
        # M14. Median intensities for precursors
        pre_intensity = np.array(self.dp.myID.PSM18_PRE_INTENSITY)[~np.isnan(self.dp.myID.PSM18_PRE_INTENSITY)]
        self.dp.myValue.precursor_intensity = round(float(np.median(pre_intensity)),2)
        # M15. Median intensities for peptides
        pep_intensity = np.array(self.dp.myID.PSM14_PEP_INTENSITY)[~np.isnan(self.dp.myID.PSM14_PEP_INTENSITY)]
        self.dp.myValue.peptide_intensity = round(float(np.median(pep_intensity)),2)
        # M16. Median intensities for protein groups
        pro_intensity = np.array(self.dp.myID.PSM13_PRO_INTENSITY)[~np.isnan(self.dp.myID.PSM13_PRO_INTENSITY)]
        self.dp.myValue.protein_intesnity = round(float(np.median(pro_intensity)),2)
        # M17. Acquired MS1 scans
        self.dp.myValue.acq_MS1_scan = round(len(self.dataMS1.INDEX_SCAN)/timesum,2)
        # M18. Acquired MS2 scans
        self.dp.myValue.acq_MS2_scan = round(len(self.dataMS2.INDEX_SCAN)/timesum,2)
        # M19. MS2 identification rate
        Id_ms2_scan = Id_ms2_scan.tolist()
        self.dp.myValue.ms2_ID_Rate = round(len(Id_ms2_scan) / len(self.dataMS2.INDEX_SCAN), 2)
        # M20. Max. identification rate over M/Z range
        Acquired_MS2Window = {}
        Identified_MS2Window = {}
        ID_mz_rate = {}
        for i in self.dataMS2.INDEX_ACTIVATION_CENTER:
            if i not in Acquired_MS2Window.keys():
                Acquired_MS2Window[i] = self.dataMS2.INDEX_ACTIVATION_CENTER.count(i)
            else:
                pass

        for j in self.dp.myID.PSM25_PrecWindow:
            if j not in Identified_MS2Window.keys():
                Identified_MS2Window[j] = self.dp.myID.PSM25_PrecWindow.count(j)
            else:
                pass

        for key,value in Acquired_MS2Window.items():
            for key1,value1 in Identified_MS2Window.items():
                left = float(key1.split(' ')[0][1:])
                right = float(key1.split(' ')[2][:-1])
                if key>=left and key<= right:
                    ID_mz_rate[key1] = value1/value
                    break
                else:
                    pass

        self.dp.myPicture.IDRate_mz = ID_mz_rate
        self.dp.myValue.IDrate_MZ = round(max(ID_mz_rate.values()), 2)

        # ID1. Identified MS2 scans
        self.dp.myValue.num_id_MS2scan = int(len(Id_ms2_scan))
        # ID2: Number of precursors
        self.dp.myValue.num_precursor = int(len(self.dp.myID.PSM31_Precursor))
        # ID3: Number of peptides
        self.dp.myValue.num_peptide = int(len(self.dp.myID.PSM4_SEQ))
        # ID4. Number of protein groups
        self.dp.myValue.num_pgs = int(len(self.dp.myID.PSM20_PRO))
        # ID5. Number of proteins
        self.dp.myValue.num_pro = int(len(self.dp.myID.PSM20_PROTEIN))
        # ID6. AVG peptides per protein group
        self.dp.myValue.num_PEP_PRO = round(float(len(self.dp.myID.PSM4_SEQ)/len(self.dp.myID.PSM20_PRO)),2)
        # ID7. AVG precursors per protein group
        self.dp.myValue.num_precur_PRO = round(float(len(self.dp.myID.PSM31_Precursor) / len(self.dp.myID.PSM20_PRO)),2)

        self.CFunctionScoring()

    def CFunctionScoring(self):

        if self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['Thermo-Orbitrap']:
            radar_info = Thermo_radar_info
        elif self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['timsTOF']:
            radar_info = Bruker_radar_info
        elif self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['SCIEX']:
            radar_info = SCIEX_radar_info

        fracS1 = 4 / (radar_info.topS1 - radar_info.bottomS1)
        fracS2 = 4 / (radar_info.topS2 - radar_info.bottomS2)
        fracS3 = 4 / (radar_info.topS3 - radar_info.bottomS3)

        fracC1 = 4 / (radar_info.topC1 - radar_info.bottomC1)
        fracC2 = 4 / (radar_info.topC2 - radar_info.bottomC2)
        fracC3 = 4 / (radar_info.topC3 - radar_info.bottomC3)
        fracC4 = 4 / (radar_info.topC4 - radar_info.bottomC4)
        fracC5 = 4 / (radar_info.topC5 - radar_info.bottomC5)
        fracC6 = 4 / (radar_info.topC6 - radar_info.bottomC6)

        fracW1 = 4 / (radar_info.topW1 - radar_info.bottomW1)
        fracW2 = 4 / (radar_info.topW2 - radar_info.bottomW2)
        fracW3 = 4 / (radar_info.topW3 - radar_info.bottomW3)
        fracW4 = 4 / (radar_info.topW4 - radar_info.bottomW4)
        fracW5 = 4 / (radar_info.topW5 - radar_info.bottomW5)
        fracW6 = 4 / (radar_info.topW6 - radar_info.bottomW6)
        fracW7 = 4 / (radar_info.topW7 - radar_info.bottomW7)

        fracIS1 = 4 / (radar_info.topIS1 - radar_info.bottomIS1)
        fracIS2 = 4 / (radar_info.topIS2 - radar_info.bottomIS2)
        fracIS3 = 4 / (radar_info.topIS3 - radar_info.bottomIS3)
        fracIS4 = 4 / (radar_info.topIS4 - radar_info.bottomIS4)

        fracM1 = 4 / (radar_info.topM1 - radar_info.bottomM1)
        fracM2 = 4 / (radar_info.topM2 - radar_info.bottomM2)
        fracM3 = 4 / (radar_info.topM3 - radar_info.bottomM3)
        fracM4 = 4 / (radar_info.topM4 - radar_info.bottomM4)
        fracM5 = 4 / (radar_info.topM5 - radar_info.bottomM5)
        fracM6 = 4 / (radar_info.topM6 - radar_info.bottomM6)
        fracM7 = 4 / (radar_info.topM7 - radar_info.bottomM7)
        fracM8 = 4 / (radar_info.topM8 - radar_info.bottomM8)
        fracM9 = 4 / (radar_info.topM9 - radar_info.bottomM9)
        fracM10 = 4 / (radar_info.topM10 - radar_info.bottomM10)
        fracM11 = 4 / (radar_info.topM11 - radar_info.bottomM11)
        fracM12 = 4 / (radar_info.topM12 - radar_info.bottomM12)
        fracM13 = 4 / (radar_info.topM13 - radar_info.bottomM13)
        fracM14 = 4 / (radar_info.topM14 - radar_info.bottomM14)
        fracM15 = 4 / (radar_info.topM15 - radar_info.bottomM15)
        fracM16 = 4 / (radar_info.topM16 - radar_info.bottomM16)
        fracM17 = 4 / (radar_info.topM17 - radar_info.bottomM17)
        fracM18 = 4 / (radar_info.topM18 - radar_info.bottomM18)
        fracM19 = 4 / (radar_info.topM19 - radar_info.bottomM19)
        fracM20 = 4 / (radar_info.topM20 - radar_info.bottomM20)

        fracID1 = 4 / (radar_info.topID1 - radar_info.bottomID1)
        fracID2 = 4 / (radar_info.topID2 - radar_info.bottomID2)
        fracID3 = 4 / (radar_info.topID3 - radar_info.bottomID3)
        fracID4 = 4 / (radar_info.topID4 - radar_info.bottomID4)
        fracID5 = 4 / (radar_info.topID5 - radar_info.bottomID5)
        fracID6 = 4 / (radar_info.topID6 - radar_info.bottomID6)
        fracID7 = 4 / (radar_info.topID7 - radar_info.bottomID7)

        # S1. Missed cleavages(n=0) of peptides
        self.dp.myScore.score_miss_cleavage = round(1+ (self.dp.myValue.miss_cleavage - radar_info.bottomS1) * fracS1, 1)
        # S2. Median peptide length
        self.dp.myScore.score_peptide_length = round(1+ (self.dp.myValue.peptide_length - radar_info.bottomS2) * fracS2, 1)
        # S3. Median Total Ion Current (TIC)
        self.dp.myScore.score_TIC =  round(1+ (float(math.log10(self.dp.myValue.TIC)) - radar_info.bottomS3) * fracS3, 1)

        # C1. Chromatographic invalid acquiring time
        self.dp.myScore.score_deadtime =  round(1+ (self.dp.myValue.deadtime - radar_info.bottomC1) * fracC1, 1)
        # C2. Med. FWHM
        self.dp.myScore.score_fwhm_median =  round(1+ (self.dp.myValue.fwhm_median - radar_info.bottomC2) * fracC2, 1)
        # C3. Median of peak width(min.)
        self.dp.myScore.score_chrom_median =  round(1+ (self.dp.myValue.chrom_median - radar_info.bottomC3) * fracC3, 1)
        # C4. Proportion of peptides with long eluting width
        self.dp.myScore.score_tail_ratio =  round(1+ (self.dp.myValue.tail_ratio - radar_info.bottomC4) * fracC4, 1)
        # C5. Median precursors identified over RT
        self.dp.myScore.score_precursor_per_min = round(1 + (self.dp.myValue.precursor_per_min - radar_info.bottomC5) * fracC5, 1)
        # C6. Max. identification rate over RT
        self.dp.myScore.score_IDrate_RT = round(1 + (self.dp.myValue.IDrate_RT - radar_info.bottomC6) * fracC6, 1)

        # W1. Acquired MS2 scans in one cycle
        self.dp.myScore.score_Acq_MS2_Scans =  round(1+ (self.dp.myValue.MS2_window - radar_info.bottomW1) * fracW1, 1)
        # W2. Median of window size (Da)
        self.dp.myScore.score_windows_size =  round(1+ (self.dp.myValue.windows_size - radar_info.bottomW2) * fracW2, 1)
        # W3. Redundant identified precursors/ Identified Scan Rate
        self.dp.myScore.score_precursors_per_scan =  round(1+ (self.dp.myValue.precursors_per_scan - radar_info.bottomW3) * fracW3, 1)
        # W4. Redundant identified precursors/ Identified precursors Rate
        self.dp.myScore.score_precursor_redundancy =  round(1+ (self.dp.myValue.precursor_redundancy - radar_info.bottomW4) * fracW4, 1)
        # W5. Identified precursors/ identified scan rate
        self.dp.myScore.score_precusor_scan_rate =  round(1+ (self.dp.myValue.precusor_scan_rate - radar_info.bottomW5) * fracW5, 1)
        # W6. MS1 data point per peak
        self.dp.myScore.score_ms1_DPPP = round(1 + (self.dp.myValue.ms1_DPPP - radar_info.bottomW6) * fracW6, 1)
        # W7. MS2 data point per peak
        self.dp.myScore.score_ms2_DPPP = round(1 + (self.dp.myValue.ms2_DPPP - radar_info.bottomW7) * fracW7, 1)

        if self.dp.myCFG.E3_FLAG_ANALYZE_FEATURE == 0:
            self.dp.myScore.score_charge_oneTotwo = '-'
            self.dp.myScore.score_charge_threeTotwo = '-'
            self.dp.myScore.score_charge_fourTotwo = '-'
        else:
            # IS1. 1+/2+ ions detected
            self.dp.myScore.score_charge_oneTotwo = round(1+ (self.dp.myValue.charge_oneTotwo - radar_info.bottomIS1) * fracIS1, 1)
            # IS2. 3+/2+ ions detected
            self.dp.myScore.score_charge_threeTotwo = round(1+ (self.dp.myValue.charge_threeTotwo - radar_info.bottomIS2) * fracIS2, 1)
            # IS3. 4+/2+ ions detected
            self.dp.myScore.score_charge_fourTotwo = round(1+ (self.dp.myValue.charge_fourTotwo - radar_info.bottomIS3) * fracIS3, 1)
        # IS4. Med. precursor m/z
        self.dp.myScore.score_precursor_mz = round(1+ (self.dp.myValue.precursor_mz - radar_info.bottomIS4) * fracIS4, 1)

        # M1. Proportion of MS1 time
        self.dp.myScore.score_ms1_time = round(1+ (self.dp.myValue.ms1_time - radar_info.bottomM1) * fracM1, 1)

        if self.dp.myCFG.A1_TYPE_DATA == 1 or self.dp.myCFG.A1_TYPE_DATA == 2:
            self.dp.myScore.score_ms1_injection_time = '-'
            self.dp.myScore.score_ms2_injection_time = '-'
        else:
            # M2. Med. MS1 ion injection time
            self.dp.myScore.score_ms1_injection_time = round(1+ (self.dp.myValue.ms1_injection_time - radar_info.bottomM2) * fracM2, 1)
            # M3. Med. MS2 ion injection time
            self.dp.myScore.score_ms2_injection_time = round(1+ (self.dp.myValue.ms2_injection_time - radar_info.bottomM3) * fracM3, 1)

        # M4. MS1 cycle time(s)
        self.dp.myScore.score_ms1_cycle_time = round(1+ (self.dp.myValue.ms1_cycle_time - radar_info.bottomM4) * fracM4, 1)
        # M5. MS2 cycle time(s)
        self.dp.myScore.score_ms2_cycle_time = round(1+ (self.dp.myValue.ms2_cycle_time - radar_info.bottomM5) * fracM5, 1)

        # M6. Median peaks intensity of MS1
        self.dp.myScore.score_ms1_peak_intensity = round(1+ (math.log10(self.dp.myValue.ms1_peak_intensity) - radar_info.bottomM6) * fracM6, 1)
        # M7. Median peaks number of MS1
        self.dp.myScore.score_ms1_peak_number = round(1+ (self.dp.myValue.ms1_peak_number - radar_info.bottomM7) * fracM7, 1)

        # M8. Median peaks number of MS2
        self.dp.myScore.score_ms2_peak_number = round(1+ (self.dp.myValue.ms2_peak_number - radar_info.bottomM8) * fracM8, 1)
        # M9. Median peaks intensity of MS2
        self.dp.myScore.score_ms2_peak_intensity = round(1 + (math.log10(self.dp.myValue.ms2_peak_intensity) - radar_info.bottomM9) * fracM9, 1)

        # M10. Identified / detected features
        if self.dp.myCFG.E3_FLAG_ANALYZE_FEATURE == 0 or self.dp.myCFG.A1_TYPE_DATA == CFG_TYPE_DATA['SCIEX']:
            self.dp.myScore.score_ID_feature = '-'
        else:
            self.dp.myScore.score_ID_feature = round(1+ (self.dp.myValue.ID_feature - radar_info.bottomM10) * fracM10, 1)
        # M11. Signal to noise（S/N）for precursors
        self.dp.myScore.score_SN_precursor = round(1+ (self.dp.myValue.SN_precursor - radar_info.bottomM11) * fracM11, 1)
        # M12. Median of MS1 raw mass accuracy(ppm)
        self.dp.myScore.score_ms1_ppm = round(1+ (self.dp.myValue.ms1_ppm - radar_info.bottomM12) * fracM12, 1)
        # M13. Median of MS2 raw mass accuracy(ppm)
        self.dp.myScore.score_ms2_ppm = round(1 + (self.dp.myValue.ms2_ppm - radar_info.bottomM13) * fracM13, 1)
        # M14. Median intensities for precursors
        self.dp.myScore.score_precursor_intensity = round(1+ (math.log10(self.dp.myValue.precursor_intensity) - radar_info.bottomM14) * fracM14, 1)
        # M15. Median intensities for peptides
        self.dp.myScore.score_peptide_intensity = round(1+ (math.log10(self.dp.myValue.peptide_intensity) - radar_info.bottomM15) * fracM15, 1)
        # M16. Median intensities for protein groups
        self.dp.myScore.score_protein_intesnity = round(1+ (math.log10(self.dp.myValue.protein_intesnity) - radar_info.bottomM16) * fracM16, 1)
        # M17. Acquired MS1 scans
        self.dp.myScore.score_acq_MS1_scan = round(1+ (self.dp.myValue.acq_MS1_scan - radar_info.bottomM17) * fracM17, 1)
        # M18. Acquired MS2 scans
        self.dp.myScore.score_acq_MS2_scan = round(1+ (self.dp.myValue.acq_MS2_scan - radar_info.bottomM18) * fracM18, 1)
        # M19. MS2 identification rate
        self.dp.myScore.score_ms2_ID_Rate = round(1+ (self.dp.myValue.ms2_ID_Rate - radar_info.bottomM19) * fracM19, 1)
        # M20. Max. identification rate over M/Z range
        self.dp.myScore.score_IDrate_MZ = round(1+ (self.dp.myValue.IDrate_MZ - radar_info.bottomM20) * fracM20, 1)

        # ID1. Identified MS2 scans
        self.dp.myScore.score_num_id_MS2scan = round(1+ (self.dp.myValue.num_id_MS2scan - radar_info.bottomID1) * fracID1, 2)
        # ID2: Number of precursors
        self.dp.myScore.score_num_precursor = round(1+ (self.dp.myValue.num_precursor - radar_info.bottomID2) * fracID2, 2)
        # ID3: Number of peptides
        self.dp.myScore.score_num_peptide = round(1+ (self.dp.myValue.num_peptide - radar_info.bottomID3) * fracID3, 2)
        # ID4. Number of protein groups
        self.dp.myScore.score_num_pgs = round(1+ (self.dp.myValue.num_pgs - radar_info.bottomID4) * fracID4, 2)
        # ID5. Number of proteins
        self.dp.myScore.score_num_pro = round(1+ (self.dp.myValue.num_pro - radar_info.bottomID5) * fracID5, 2)
        # ID6. AVG peptides per protein group
        self.dp.myScore.score_num_PEP_PRO = round(1 + (self.dp.myValue.num_PEP_PRO - radar_info.bottomID6) * fracID6, 2)
        # ID7. AVG precursors per protein group
        self.dp.myScore.score_num_precur_PRO = round(1 + (self.dp.myValue.num_precur_PRO - radar_info.bottomID7) * fracID7, 2)

        totalscore = [
        self.dp.myScore.score_miss_cleavage, self.dp.myScore.score_peptide_length, self.dp.myScore.score_TIC, self.dp.myScore.score_deadtime, self.dp.myScore.score_fwhm_median,
        self.dp.myScore.score_chrom_median, self.dp.myScore.score_tail_ratio, self.dp.myScore.score_precursor_per_min, self.dp.myScore.score_IDrate_RT,self.dp.myScore.score_Acq_MS2_Scans,
        self.dp.myScore.score_windows_size, self.dp.myScore.score_precursors_per_scan, self.dp.myScore.score_precursor_redundancy, self.dp.myScore.score_precusor_scan_rate,self.dp.myScore.score_ms1_DPPP,
        self.dp.myScore.score_ms2_DPPP,self.dp.myScore.score_charge_oneTotwo, self.dp.myScore.score_charge_threeTotwo, self.dp.myScore.score_charge_fourTotwo, self.dp.myScore.score_precursor_mz,
        self.dp.myScore.score_ms1_time, self.dp.myScore.score_ms1_injection_time, self.dp.myScore.score_ms2_injection_time, self.dp.myScore.score_ms1_cycle_time,self.dp.myScore.score_ms2_cycle_time,
        self.dp.myScore.score_ms1_peak_intensity, self.dp.myScore.score_ms1_peak_number, self.dp.myScore.score_ms2_peak_number, self.dp.myScore.score_ms2_peak_intensity,self.dp.myScore.score_ID_feature,
        self.dp.myScore.score_SN_precursor, self.dp.myScore.score_ms1_ppm, self.dp.myScore.score_ms2_ppm, self.dp.myScore.score_precursor_intensity,self.dp.myScore.score_peptide_intensity,
        self.dp.myScore.score_protein_intesnity, self.dp.myScore.score_acq_MS1_scan, self.dp.myScore.score_acq_MS2_scan, self.dp.myScore.score_ms2_ID_Rate,self.dp.myScore.score_IDrate_MZ,
        self.dp.myScore.score_num_id_MS2scan, self.dp.myScore.score_num_precursor, self.dp.myScore.score_num_peptide, self.dp.myScore.score_num_pgs,self.dp.myScore.score_num_pro,
        self.dp.myScore.score_num_PEP_PRO, self.dp.myScore.score_num_precur_PRO]

        totalvalues = [
            self.dp.myValue.miss_cleavage, self.dp.myValue.peptide_length, self.dp.myValue.TIC, self.dp.myValue.deadtime, self.dp.myValue.fwhm_median,
            self.dp.myValue.chrom_median, self.dp.myValue.tail_ratio, self.dp.myValue.precursor_per_min,self.dp.myValue.IDrate_RT,
            self.dp.myValue.MS2_window, self.dp.myValue.windows_size, self.dp.myValue.precursors_per_scan,self.dp.myValue.precursor_redundancy, self.dp.myValue.precusor_scan_rate,
            self.dp.myValue.ms1_DPPP,self.dp.myValue.ms2_DPPP,self.dp.myValue.charge_oneTotwo, self.dp.myValue.charge_threeTotwo,self.dp.myValue.charge_fourTotwo, self.dp.myValue.precursor_mz,
            self.dp.myValue.ms1_time, self.dp.myValue.ms1_injection_time, self.dp.myValue.ms2_injection_time, self.dp.myValue.ms1_cycle_time,
            self.dp.myValue.ms2_cycle_time, self.dp.myValue.ms1_peak_intensity, self.dp.myValue.ms1_peak_number, self.dp.myValue.ms2_peak_number,self.dp.myValue.ms2_peak_intensity,
            self.dp.myValue.ID_feature, self.dp.myValue.SN_precursor, self.dp.myValue.ms1_ppm, self.dp.myValue.ms2_ppm, self.dp.myValue.precursor_intensity,
            self.dp.myValue.peptide_intensity, self.dp.myValue.protein_intesnity, self.dp.myValue.acq_MS1_scan, self.dp.myValue.acq_MS2_scan,self.dp.myValue.ms2_ID_Rate,
            self.dp.myValue.IDrate_MZ, self.dp.myValue.num_id_MS2scan,self.dp.myValue.num_precursor, self.dp.myValue.num_peptide, self.dp.myValue.num_pgs,
            self.dp.myValue.num_pro, self.dp.myValue.num_PEP_PRO, self.dp.myValue.num_precur_PRO]


        for index, i in enumerate(totalscore):
            if i == '-':
                pass
            elif i < 1:
                totalscore[index] = 1
            elif i > 5:
                totalscore[index] = 5
            else:
                pass


        self.dp.scores = totalscore

        linert = ["Category", "Level II Scoring Item", "Description", "Actual Value", "Score"]

        linerS1 = ["1. Sample Preparation", feature_INFO.S1, Meaning_INFO.S1 + "<b>Score 1</b>: <=" + str(radar_info.bottomS1) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topS1), str(totalvalues[0])+"%", str(totalscore[0]), ]
        linerS2 = [feature_INFO.S2, Meaning_INFO.S2 + "<b>Score 1</b>: >=" + str(radar_info.bottomS2) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topS2), str(totalvalues[1]), str(totalscore[1]), ]
        linerS3 = [feature_INFO.S3, Meaning_INFO.S3 + "<b>Score 1</b>: <=" + str(radar_info.bottomS3) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topS3), str('%.3e' %totalvalues[2]), str(totalscore[2]), ]

        linerC1 = ["2. Chromatography", feature_INFO.C1,Meaning_INFO.C1 + "<b>Score 1</b>: >=" + str(radar_info.bottomC1) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topC1), str(totalvalues[3])+'min', str(totalscore[3]), ]
        linerC2 = [feature_INFO.C2, Meaning_INFO.C2 + "<b>Score 1</b>: >=" + str(radar_info.bottomC2) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topC2), str(totalvalues[4])+"min", str(totalscore[4]), ]
        linerC3 = [feature_INFO.C3, Meaning_INFO.C3 + "<b>Score 1</b>: >=" + str(radar_info.bottomC3) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topC3), str(totalvalues[5])+"min", str(totalscore[5]), ]
        linerC4 = [feature_INFO.C4, Meaning_INFO.C4 + "<b>Score 1</b>: >=" + str(radar_info.bottomC4) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topC4), str(round(totalvalues[6]*100,2))+"%", str(totalscore[6]), ]
        linerC5 = [feature_INFO.C5, Meaning_INFO.C5 + "<b>Score 1</b>: <=" + str(radar_info.bottomC5) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topC5), str(totalvalues[7]), str(totalscore[7]), ]
        linerC6 = [feature_INFO.C6, Meaning_INFO.C6 + "<b>Score 1</b>: <=" + str(radar_info.bottomC6) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topC6), str(round(totalvalues[8] * 100, 2)) + "%",
                   str(totalscore[8]), ]

        linerW1 = ["3. DIA Windows", feature_INFO.W1,Meaning_INFO.W1 + "<b>Score 1</b>: <=" + str(radar_info.bottomW1) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topW1), str(totalvalues[9]), str(totalscore[9]), ]
        linerW2 = [feature_INFO.W2, Meaning_INFO.W2 + "<b>Score 1</b>: >=" + str(radar_info.bottomW2) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topW2), str(totalvalues[10]), str(totalscore[10]), ]
        linerW3 = [feature_INFO.W3, Meaning_INFO.W3 + "<b>Score 1</b>: <=" + str(radar_info.bottomW3) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topW3), str(totalvalues[11]), str(totalscore[11]), ]
        linerW4 = [feature_INFO.W4, Meaning_INFO.W4 + "<b>Score 1</b>: >=" + str(radar_info.bottomW4) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topW4), str(totalvalues[12]), str(totalscore[12]), ]
        linerW5 = [feature_INFO.W5, Meaning_INFO.W5 + "<b>Score 1</b>: <=" + str(radar_info.bottomW5) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topW5), str(totalvalues[13]), str(totalscore[13]), ]
        linerW6 = [feature_INFO.W6, Meaning_INFO.W6 + "<b>Score 1</b>: <=" + str(radar_info.bottomW6) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topW6), str(totalvalues[14]), str(totalscore[14]), ]
        linerW7 = [feature_INFO.W7, Meaning_INFO.W7 + "<b>Score 1</b>: >=" + str(radar_info.bottomW7) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topW7), str(totalvalues[15]), str(totalscore[15]), ]

        linerIS1 = ["4. Ion Source", feature_INFO.IS1,Meaning_INFO.IS1 + "<b>Score 1</b>: >=" + str(radar_info.bottomIS1) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topIS1), str(totalvalues[16]), str(totalscore[16]), ]
        linerIS2 = [feature_INFO.IS2, Meaning_INFO.IS2 + "<b>Score 1</b>: <=" + str(radar_info.bottomIS2) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topIS2), str(totalvalues[17]), str(totalscore[17]), ]
        linerIS3 = [feature_INFO.IS3, Meaning_INFO.IS3 + "<b>Score 1</b>: <=" + str(radar_info.bottomIS3) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topIS3), str(totalvalues[18]), str(totalscore[18]), ]
        linerIS4 = [feature_INFO.IS4, Meaning_INFO.IS4 + "<b>Score 1</b>: >=" + str(radar_info.bottomIS4) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topIS4), str(totalvalues[19]), str(totalscore[19]), ]

        linerM1 = ["5. MS1 and MS2 Signal", feature_INFO.M1,Meaning_INFO.M1 + "<b>Score 1</b>: >=" + str(radar_info.bottomM1) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topM1), str(totalvalues[20]), str(totalscore[20]), ]
        linerM2 = [feature_INFO.M2, Meaning_INFO.M2 + "<b>Score 1</b>: >=" + str(radar_info.bottomM2) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topM2), str(totalvalues[21]), str(totalscore[21]), ]
        linerM3 = [feature_INFO.M3, Meaning_INFO.M3 + "<b>Score 1</b>: <=" + str(radar_info.bottomM3) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM3), str(totalvalues[22]), str(totalscore[22]), ]
        linerM4 = [feature_INFO.M4, Meaning_INFO.M4 + "<b>Score 1</b>: >=" + str(radar_info.bottomM4) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topM4), str(totalvalues[23]), str(totalscore[23]), ]
        linerM5 = [feature_INFO.M5, Meaning_INFO.M5 + "<b>Score 1</b>: <=" + str(radar_info.bottomM5) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM5), str(totalvalues[24]), str(totalscore[24]), ]

        linerM6 = [feature_INFO.M6, Meaning_INFO.M6 + "<b>Score 1</b>: <=" + str(radar_info.bottomM6) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM6), str('%.3e'%totalvalues[25]), str(totalscore[25]), ]
        linerM7 = [feature_INFO.M7, Meaning_INFO.M7 + "<b>Score 1</b>: <=" + str(radar_info.bottomM7) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM7), totalvalues[26], str(totalscore[26]), ]
        linerM8 = [feature_INFO.M8, Meaning_INFO.M8 + "<b>Score 1</b>: <=" + str(radar_info.bottomM8) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM8), totalvalues[27], str(totalscore[27]), ]
        linerM9 = [feature_INFO.M9, Meaning_INFO.M9 + "<b>Score 1</b>: <=" + str(radar_info.bottomM9) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM9), str('%.3e'%totalvalues[28]), str(totalscore[28]), ]
        linerM10 = [feature_INFO.M10, Meaning_INFO.M10 + "<b>Score 1</b>: <=" + str(radar_info.bottomM10) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM10), str(totalvalues[29]), str(totalscore[29]), ]

        linerM11 = [feature_INFO.M11, Meaning_INFO.M11 + "<b>Score 1</b>: <=" + str(radar_info.bottomM11) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM11), str(totalvalues[30]), str(totalscore[30]), ]
        linerM12 = [feature_INFO.M12, Meaning_INFO.M12 + "<b>Score 1</b>: >=" + str(radar_info.bottomM12) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topM12), str(totalvalues[31])+"ppm", str(totalscore[31]), ]
        linerM13 = [feature_INFO.M13, Meaning_INFO.M13 + "<b>Score 1</b>: >=" + str(radar_info.bottomM13) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topM13), str(totalvalues[32])+"ppm", str(totalscore[32]), ]
        linerM14 = [feature_INFO.M14, Meaning_INFO.M14 + "<b>Score 1</b>: <=" + str(radar_info.bottomM14) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM14), str('%.3e'%totalvalues[33]), str(totalscore[33]), ]
        linerM15 = [feature_INFO.M15, Meaning_INFO.M15 + "<b>Score 1</b>: <=" + str(radar_info.bottomM15) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM15), str('%.3e'%totalvalues[34]), str(totalscore[34]), ]

        linerM16 = [feature_INFO.M16, Meaning_INFO.M16 + "<b>Score 1</b>: <=" + str(radar_info.bottomM16) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM16), str('%.3e'%totalvalues[35]), str(totalscore[35]), ]
        linerM17 = [feature_INFO.M17, Meaning_INFO.M17 + "<b>Score 1</b>: <=" + str(radar_info.bottomM17) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM17), str(totalvalues[36]), str(totalscore[36]), ]
        linerM18 = [feature_INFO.M18, Meaning_INFO.M18 + "<b>Score 1</b>: <=" + str(radar_info.bottomM18) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topM18), str(totalvalues[37]), str(totalscore[37]), ]
        linerM19 = [feature_INFO.M19, Meaning_INFO.M19 + "<b>Score 1</b>: >=" + str(radar_info.bottomM19) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topM19), str(round(totalvalues[38]*100,2))+'%', str(totalscore[38]), ]
        linerM20 = [feature_INFO.M20, Meaning_INFO.M20 + "<b>Score 1</b>: >=" + str(radar_info.bottomM20) +
                   "; <b>Score 5</b>: <=" + str(radar_info.topM20), totalvalues[39], str(totalscore[39]), ]


        linerID1 = ["6. Identification Result",feature_INFO.ID1, Meaning_INFO.ID1 + "<b>Score 1</b>: <=" + str(radar_info.bottomID1) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topID1), totalvalues[40], str(totalscore[40]), ]
        linerID2 = [feature_INFO.ID2, Meaning_INFO.ID2 + "<b>Score 1</b>: <=" + str(radar_info.bottomID2) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topID2), totalvalues[41], str(totalscore[41]), ]
        linerID3 = [feature_INFO.ID3, Meaning_INFO.ID3 + "<b>Score 1</b>: <=" + str(radar_info.bottomID3) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topID3), totalvalues[42], str(totalscore[42]), ]
        linerID4 = [feature_INFO.ID4, Meaning_INFO.ID4 + "<b>Score 1</b>: <=" + str(radar_info.bottomID4) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topID4), totalvalues[43], str(totalscore[43]), ]
        linerID5 = [feature_INFO.ID5, Meaning_INFO.ID5 + "<b>Score 1</b>: <=" + str(radar_info.bottomID5) +
                   "; <b>Score 5</b>: >=" + str(radar_info.topID5), str(totalvalues[44]), str(totalscore[44]), ]
        linerID6 = [feature_INFO.ID6, Meaning_INFO.ID6 + "<b>Score 1</b>: <=" + str(radar_info.bottomID6) +
                    "; <b>Score 5</b>: >=" + str(radar_info.topID6), totalvalues[45], str(totalscore[45]), ]
        linerID7 = [feature_INFO.ID7, Meaning_INFO.ID7 + "<b>Score 1</b>: <=" + str(radar_info.bottomID7) +
                    "; <b>Score 5</b>: >=" + str(radar_info.topID7), str(totalvalues[46]),
                    str(totalscore[46]), ]

        self.dp.myHtml.lineSCORE_T = linert
        self.dp.myHtml.lineSCORE_I = [linerS1, linerS2, linerS3,
                                                  linerC1, linerC2, linerC3, linerC4,linerC5,linerC6,
                                                  linerW1, linerW2, linerW3, linerW4, linerW5,linerW6, linerW7,
                                                  linerIS1, linerIS2, linerIS3, linerIS4,
                                                  linerM1, linerM2, linerM3, linerM4, linerM5, linerM6, linerM7, linerM8, linerM9, linerM10, linerM11, linerM12,
                                                  linerM13, linerM14, linerM15, linerM16, linerM17, linerM18, linerM19, linerM20,
                                                  linerID1, linerID2, linerID3, linerID4, linerID5,linerID6, linerID7]

        table1t = ["Acquired MS1 Scans", "Acquired MS2 Scans", "Identified MS2 Scans", "Identified precursors",
                   "Identified peptides", "Identified proteins", "Identified protein groups"]
        MS1scan = len(self.dataMS1.INDEX_SCAN)
        Ac_MS2scan = len(self.dataMS2.INDEX_SCAN)
        Id_MS2scan = len(self.dp.myID.SCAN_TO_PEPTIDE) - self.dp.myID.SCAN_TO_PEPTIDE.count(0)
        Id_precursors = len(self.dp.myID.PSM31_Precursor)
        Id_peptides = len(self.dp.myID.PSM4_SEQ)
        Id_protein = len(self.dp.myID.PSM20_PROTEIN)
        Id_PGs = len(self.dp.myID.PSM20_PRO)
        table1n = [MS1scan, Ac_MS2scan, Id_MS2scan, Id_precursors, Id_peptides, Id_protein, Id_PGs]
        self.dp.myHtml.lineSUM_T = table1t
        self.dp.myHtml.lineSUM_I = table1n
        self.dp.myHtml.html_title = str(self.dp.myCFG.A0_PATH_RAW.split('\\')[-1])

        self.summaryReport()

    def summaryReport(self):
        path_summary = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[12]
        score_list = [2.5 if item == "-" else item for item in self.dp.scores]
        with open(path_summary, 'w') as f:

            f.write('File name\t' + str(self.dp.myHtml.html_title)+'\t' + str(self.dp.myHtml.html_title)+ '\n')
            f.write('Metrics\t'+ 'Values\t'+'Scores\t'+ '\n')
            f.write('Total score\t' + '\t'+str(np.sum(score_list)/47)+ '\n')

            f.write('S1. Missed cleavages(n=0) of peptides\t' + str(self.dp.myValue.miss_cleavage) + '%'+'\t'+str(self.dp.scores[0])+ '\n')
            f.write('S2. Median peptide length\t' + str(self.dp.myValue.peptide_length) + '\t'+str(self.dp.scores[1])+'\n')
            f.write('S3. Median Total Ion Current (TIC)\t' + str('%.3e' %self.dp.myValue.TIC) + '\t'+str(self.dp.scores[2])+'\n')

            f.write('C1. Chromatographic invalid acquiring time(min.)\t' + str(self.dp.myValue.deadtime) + '\t'+str(self.dp.scores[3])+'\n')
            f.write('C2. Median of full width at half maximum (FWHM)(min.)\t' + str(self.dp.myValue.fwhm_median) + '\t'+str(self.dp.scores[4])+'\n')
            f.write('C3. Median of peak width(min.)\t' + str(self.dp.myValue.chrom_median) + '\t'+str(self.dp.scores[5])+'\n')
            f.write('C4. Proportion of peptides with long eluting width \t' + str(self.dp.myValue.tail_ratio * 100) + '%'+'\t'+str(self.dp.scores[6])+'\n')
            f.write('C5. Median precursors identified over RT\t' + str(self.dp.myValue.precursor_per_min) + '\t'+str(self.dp.scores[7])+'\n')
            f.write('C6. Max. identification rate over RT\t' + str(self.dp.myValue.IDrate_RT) + '\t'+str(self.dp.scores[8])+'\n')

            f.write('W1. Acquired MS2 scans in one cycle\t' + str(self.dp.myValue.MS2_window) + '\t'+str(self.dp.scores[9])+'\n')
            f.write('W2. Median of window size (Da)\t' + str(self.dp.myValue.windows_size) + '\t'+str(self.dp.scores[10])+'\n')
            f.write('W3. Redundant identified precursors/ Identified Scan Rate\t' + str(
                self.dp.myValue.precursors_per_scan) + '\t'+str(self.dp.scores[11])+'\n')
            f.write('W4. Redundant identified precursors/ Identified precursors Rate\t' + str(
                self.dp.myValue.precursor_redundancy) + '\t'+str(self.dp.scores[12])+'\n')
            f.write('W5. Identified precursors/ identified scan rate\t' + str(self.dp.myValue.precusor_scan_rate) + '\t'+str(self.dp.scores[13])+'\n')
            f.write('W6. MS1 data point per peak\t' + str(self.dp.myValue.ms1_DPPP) + '\t'+str(self.dp.scores[14])+'\n')
            f.write('W7. MS2 data point per peak\t' + str(self.dp.myValue.ms2_DPPP) + '\t'+str(self.dp.scores[15])+'\n')

            f.write('IS1. 1+/2+ ions detected\t' + str(self.dp.myValue.charge_oneTotwo) + '\t'+str(self.dp.scores[16])+'\n')
            f.write('IS2. 3+/2+ ions detected\t' + str(self.dp.myValue.charge_threeTotwo) + '\t'+str(self.dp.scores[17])+'\n')
            f.write('IS3. 4+/2+ ions detected \t' + str(self.dp.myValue.charge_fourTotwo) + '\t'+str(self.dp.scores[18])+'\n')
            f.write('IS4. Median precursor m/z\t' + str(self.dp.myValue.precursor_mz) + '\t'+str(self.dp.scores[19])+'\n')

            f.write('M1. Proportion of MS1 time\t' + str(self.dp.myValue.ms1_time) + '\t'+str(self.dp.scores[20])+'\n')
            f.write('M2. Median MS1 ion injection time(ms)\t' + str(self.dp.myValue.ms1_injection_time) + '\t'+str(self.dp.scores[21])+'\n')
            f.write('M3. Median MS2 ion injection time(ms)\t' + str(self.dp.myValue.ms2_injection_time) + '\t'+str(self.dp.scores[22])+'\n')
            f.write('M4. MS1 cycle time(s)\t' + str(self.dp.myValue.ms1_cycle_time) + '\t'+str(self.dp.scores[23])+'\n')
            f.write('M5. MS2 cycle time(s)\t' + str(self.dp.myValue.ms2_cycle_time) + '\t'+str(self.dp.scores[24])+'\n')
            f.write('M6. Median peaks intensity of MS1\t' + str('%.3e' % self.dp.myValue.ms1_peak_intensity) + '\t'+str(self.dp.scores[25])+'\n')
            f.write('M7. Median peaks number of MS1\t' + str(self.dp.myValue.ms1_peak_number) + '\t'+str(self.dp.scores[26])+'\n')
            f.write('M8. Median peaks number of MS2\t' + str(self.dp.myValue.ms2_peak_number) + '\t'+str(self.dp.scores[27])+'\n')
            f.write('M9. Median peaks intensity of MS2\t' + str('%.3e' % self.dp.myValue.ms2_peak_intensity) + '\t'+str(self.dp.scores[28])+'\n')
            f.write('M10. Identified / detected features\t' + str(self.dp.myValue.ID_feature) + '\t'+str(self.dp.scores[29])+'\n')
            f.write('M11. Signal to noise（S/N）for precursors\t' + str(self.dp.myValue.SN_precursor) + '\t'+str(self.dp.scores[30])+'\n')
            f.write('M12. Median of MS1 raw mass accuracy(ppm)\t' + str(self.dp.myValue.ms1_ppm) + '\t'+str(self.dp.scores[31])+'\n')
            f.write('M13. Median of MS2 raw mass accuracy(ppm)\t' + str(self.dp.myValue.ms2_ppm) + '\t'+str(self.dp.scores[32])+'\n')
            f.write('M14. Median intensities for precursors\t' + str('%.3e' % self.dp.myValue.precursor_intensity) + '\t'+str(self.dp.scores[33])+'\n')
            f.write('M15. Median intensities for peptides\t' + str('%.3e' % self.dp.myValue.peptide_intensity) + '\t'+str(self.dp.scores[34])+'\n')
            f.write('M16. Median intensities for protein groups\t' + str('%.3e' % self.dp.myValue.protein_intesnity) + '\t'+str(self.dp.scores[35])+'\n')
            f.write('M17. Acquired MS1 scans per minute\t' + str(self.dp.myValue.acq_MS1_scan) + '\t'+str(self.dp.scores[36])+'\n')
            f.write('M18. Acquired MS2 scans per minute\t' + str(self.dp.myValue.acq_MS2_scan) + '\t'+str(self.dp.scores[37])+'\n')
            f.write('M19. MS2 identification rate\t' + str(self.dp.myValue.ms2_ID_Rate) + '\t'+str(self.dp.scores[38])+'\n')
            f.write('M20. Max. identificatied precursors rate over M/Z range\t' + str(self.dp.myValue.IDrate_MZ) + '\t'+str(self.dp.scores[39])+'\n')

            f.write('ID1. Identified MS2 scans\t' + str(self.dp.myValue.num_id_MS2scan) + '\t'+str(self.dp.scores[40])+'\n')
            f.write('ID2: Number of precursors\t' + str(self.dp.myValue.num_precursor) + '\t'+str(self.dp.scores[41])+'\n')
            f.write('ID3: Number of peptides\t' + str(self.dp.myValue.num_peptide) + '\t'+str(self.dp.scores[42])+'\n')
            f.write('ID4. Number of protein groups\t' + str(self.dp.myValue.num_pgs) + '\t'+str(self.dp.scores[43])+'\n')
            f.write('ID5. Number of proteins\t' + str(self.dp.myValue.num_pro) + '\t'+str(self.dp.scores[44])+'\n')
            f.write('ID6. AVG peptides per protein group\t' + str(self.dp.myValue.num_PEP_PRO) + '\t'+str(self.dp.scores[45])+'\n')
            f.write('ID7. AVG precursors per protein group\t' + str(self.dp.myValue.num_precur_PRO) +'\t'+ str(self.dp.scores[46])+'\n')

