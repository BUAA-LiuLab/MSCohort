from MSSystem import VALUE_MAX_SCAN, VALUE_ILLEGAL
from MSTool import toolGetMaxIndexFromList
from MSData import Config


def op_INIT_CFILE_MS2(inputMS2):

	inputMS2.INDEX_SCAN = []
	inputMS2.INDEX_RT = []
	inputMS2.INDEX_ISOLATION_WIDTH = []
	inputMS2.INDEX_ACTIVATION_CENTER = []
	inputMS2.INDEX_CV = []
	inputMS2.INDEX_TIMS_NUMBER_PEAKS = []
	inputMS2.INDEX_TIMS_TOTAL_INTENSITY = []

	inputMS2.LIST_RET_TIME = [VALUE_ILLEGAL] * VALUE_MAX_SCAN
	inputMS2.LIST_ION_INJECTION_TIME = [VALUE_ILLEGAL] * VALUE_MAX_SCAN
	inputMS2.LIST_ACTIVATION_CENTER = [VALUE_ILLEGAL] * VALUE_MAX_SCAN
	inputMS2.LIST_ISOLATION_WIDTH = [VALUE_ILLEGAL] * VALUE_MAX_SCAN
	inputMS2.LIST_PRECURSOR_SCAN = [VALUE_ILLEGAL] * VALUE_MAX_SCAN
	inputMS2.TIMS_NUMBER_PEAKS= [VALUE_ILLEGAL] * VALUE_MAX_SCAN
	inputMS2.TIMS_TOTAL_INTENSITY = [VALUE_ILLEGAL] * VALUE_MAX_SCAN

	inputMS2.MATRIX_PEAK_MOZ = [[]*1] * VALUE_MAX_SCAN # 每一行是个list
	inputMS2.MATRIX_PEAK_INT = [[]*1] * VALUE_MAX_SCAN
	inputMS2.MATRIX_CHARGE = [[]*1] * VALUE_MAX_SCAN  # 相同的scan，可能有多个母离子状态（质量+电荷）
	inputMS2.MATRIX_MZ = [[]*1] * VALUE_MAX_SCAN  # 相同的scan，可能有多个母离子状态（质量+电荷）
	inputMS2.MATRIX_PEAK_MARK = [[]*1] * VALUE_MAX_SCAN

def op_INIT_CFILE_FEATURE(inputFeature):
	inputFeature.INDEX_FEATURE_SCAN = []
	inputFeature.INDEX_CHARGE = []
	inputFeature.INDEX_INTENSITY_ALL = []
	inputFeature.LIST_MOZ_MONO = [0] * VALUE_MAX_SCAN

	inputFeature.INDEX_SCAN_S = []
	inputFeature.INDEX_RT_S = []
	inputFeature.INDEX_SCAN_E = []
	inputFeature.INDEX_RT_E = []

	inputFeature.DICT_STATE_OF_FEATURE = {}


def op_INIT_CFILE_MS1(inputMS1):

	inputMS1.INDEX_SCAN = []
	inputMS1.INDEX_RT = []

	inputMS1.LIST_RET_TIME = [VALUE_ILLEGAL] * VALUE_MAX_SCAN
	inputMS1.LIST_ION_INJECTION_TIME = [VALUE_ILLEGAL] * VALUE_MAX_SCAN

	inputMS1.MATRIX_PEAK_MOZ = [[] * 1] * VALUE_MAX_SCAN  # 每一行是个list
	inputMS1.MATRIX_PEAK_INT = [[] * 1] * VALUE_MAX_SCAN
	inputMS1.MATRIX_PEAK_MARK = [[] * 1] * VALUE_MAX_SCAN


def opGetStartAndEnd_FWHM(input_profile, input_start, input_end):

	subProfile = input_profile[input_start:input_end+1]

	iMax = toolGetMaxIndexFromList(subProfile)  # 这是子曲线的中央
	vMax = subProfile[iMax]

	int_thr = vMax * 0.5
	input_n_hole = 1  # 这里必须是1个，不然就出去了
	nHoleLeft = 0
	nHoleRight = 0

	if iMax > 0:
		i_left = iMax - 1
	else:
		i_left = iMax

	i_right = iMax

	walkLeft = True
	walkRight = True

	while True:

		if walkLeft or walkRight:
			pass
		else:
			break

		if i_left > 0:

			if walkLeft:
				i_left = i_left - 1

		else:

			walkLeft = False

		if i_right < len(subProfile) - 1:

			if walkRight:
				i_right = i_right + 1

		else:

			walkRight = False

		int_left = subProfile[i_left]
		int_right = subProfile[i_right]

		# hole
		if int_left < int_thr and walkLeft:
			nHoleLeft = nHoleLeft + 1

		if int_right < int_thr and walkRight:
			nHoleRight = nHoleRight + 1

		if nHoleLeft == input_n_hole:
			walkLeft = False

		if nHoleRight == input_n_hole:
			walkRight = False

	result = [input_start+i_left, input_start+i_right]

	return result


def opGetStartAndEnd(input_profile, input_seed, input_cutoff, input_n_hole):

	nHoleLeft = 0
	nHoleRight = 0

	i_middle = input_seed

	if i_middle > 0:
		i_left = i_middle - 1
	else:
		i_left = i_middle

	i_right = i_middle

	result = [i_left, i_right]  # start and end

	int_left = input_profile[i_left]
	int_right = input_profile[i_right]

	int_max = int_left
	int_thr = int_max * input_cutoff  # 设置强度阈值，计算起点终点

	walkLeft = True
	walkRight = True

	while True:

		if walkLeft or walkRight:
			pass
		else:
			break

		if i_left > 0:

			if walkLeft:
				i_left = i_left - 1

		else:

			walkLeft = False

		if i_right < len(input_profile) - 1:

			if walkRight:
				i_right = i_right + 1

		else:

			walkRight = False

		int_left = input_profile[i_left]
		int_right = input_profile[i_right]

		# max
		if int_max < int_left:
			int_max = int_left

		if int_max < int_right:
			int_max = int_right

		int_thr = int_max * input_cutoff

		# hole
		if int_left < int_thr and walkLeft:
			nHoleLeft = nHoleLeft + 1


		if int_right < int_thr and walkRight:
			nHoleRight = nHoleRight + 1


		if nHoleLeft == input_n_hole:

			walkLeft = False

		if nHoleRight == input_n_hole:

			walkRight = False

	result[0] = i_left
	result[1] = i_right

	return result

class Thermo_radar_info:

# S1. Missed cleavages(n=0) of peptides
# S2. Median peptide length
# S3. Median Total Ion Current (TIC)(log10)
	bottomS1, topS1 = 0.8, 0.9
	bottomS2, topS2 = 20, 10
	bottomS3, topS3 = 11.8, 12.2

# C1. Chromatographic invalid acquiring time
# C2. Median of FWHM
# C3. Median of peak width
# C4. Proportion of peptides with long eluting width
# C5. Median precursors identified over RT
# C6. Max. identification rate over RT
	bottomC1, topC1 = 10, 1
	bottomC2, topC2 = 0.2, 0.12
	bottomC3, topC3 = 0.4, 0.2
	bottomC4, topC4 = 0.005, 0.001
	bottomC5, topC5 = 600, 800
	bottomC6, topC6 = 0.75, 0.9

# W1. Acquired MS2 scans in one cycle
# W2. Median of window size (Da)
# W3. Redundant identified precursors/ Identified Scan Rate
# W4. Redundant identified precursors/ Identified precursors Rate
# W5. Identified precursors/ identified scan rate
# W6. MS1 data point per peak
# W7. MS2 data point per peak
	bottomW1, topW1 = 10, 40
	bottomW2, topW2 = 40, 10
	bottomW3, topW3 = 1, 2
	bottomW4, topW4 = 6, 2
	bottomW5, topW5 = 1, 1.5
	bottomW6, topW6 = 1, 4
	bottomW7, topW7 = 6, 3

# IS1. 1+/2+ ions detected
# IS2. 3+/2+ ions detected
# IS3. 4+/2+ ions detected
# IS4. Med. precursor m/z
# IS5. Precursors charge distribution
	bottomIS1, topIS1 = 3, 1.3
	bottomIS2, topIS2 = 0.1, 0.4
	bottomIS3, topIS3 = 0.01, 0.05
	bottomIS4, topIS4 = 1000, 580
	# bottomIS5, topIS5 = 1, 0.4

# M1. Proportion of MS1 time
# M2. Med. MS1 ion injection time
# M3. Med. MS2 ion injection time
# M4. MS1 cycle time
# M5. MS2 cycle time
	bottomM1, topM1 = 0.25, 0.13
	bottomM2, topM2 = 10, 4
	bottomM3, topM3 = 5, 50
	bottomM4, topM4 = 5, 2.5
	bottomM5, topM5 = 1, 4
# M6. Median peaks intensity of MS1
# M7. Median peaks number of MS1
# M8. Median peaks number of MS2
# M9. Median peaks intensity of MS2
# M10. Identified / detected features
	bottomM6, topM6 = 8, 9
	bottomM7, topM7 = 800, 1500
	bottomM8, topM8 = 150, 320
	bottomM9, topM9 = 5.8, 6.8
	bottomM10, topM10 = 0.3, 0.7
# M11. Signal to noise（S/N）for precursors
# M12. Median of MS1 raw mass accuracy
# M13. Median of MS2 raw mass accuracy
# M14. Median intensities for precursors
# M15. Median intensities for peptides
	bottomM11, topM11 = 6.5, 10
	bottomM12, topM12 = 5, 1
	bottomM13, topM13 = 5, 1
	bottomM14, topM14 = 2.8, 3.8
	bottomM15, topM15 = 2.8, 3.8
# M16. Median intensities for protein groups
# M17. Acquired MS1 scans
# M18. Acquired MS2 scans
# M19. MS2 identification rate
# M20. Max. identification rate over M/Z range
	bottomM16, topM16 = 2.8, 3.8
	bottomM17, topM17 = 16, 25
	bottomM18, topM18 = 500, 700
	bottomM19, topM19 = 0.5, 0.7
	bottomM20, topM20 = 0.9, 1.5

# ID1. Identified MS2 scans
# ID2: Precursors
# ID3: Peptides
# ID4. Protein groups
# ID5. Proteins
# ID6. AVG peptides per protein group
# ID7. AVG precursors per protein group
	bottomID1, topID1 = 10000, 20000
	bottomID2, topID2 = 10000, 20000
	bottomID3, topID3 = 10000, 20000
	bottomID4, topID4 = 2000, 3000
	bottomID5, topID5 = 2000, 3000
	bottomID6, topID6 = 4, 6
	bottomID7, topID7 = 4, 8


class Bruker_radar_info:
# S1. Missed cleavages(n=0) of peptides
# S2. Med. Total Ion Current (TIC) (log10)
# S3. Med. peaks intensity of MS1
	bottomS1, topS1 = 0.8, 0.9
	bottomS2, topS2 = 20, 10
	bottomS3, topS3 = 9.8, 10.5

# C1. Chromatographic invalid acquiring time
# C2. Median of FWHM
# C3. Median of peak width
# C4. Proportion of peptides with long eluting width
# C5. Median precursors identified over RT
# C6. Max. identification rate over RT
	bottomC1, topC1 = 10, 1
	bottomC2, topC2 = 0.2, 0.12
	bottomC3, topC3 = 0.4, 0.2
	bottomC4, topC4 = 0.005, 0.001
	bottomC5, topC5 = 400, 800
	bottomC6, topC6 = 0.6, 0.8

# W1. Acquired MS2 scans in one cycle
# W2. Median of window size (Da)
# W3. Redundant identified precursors/ Identified Scan Rate
# W4. Redundant identified precursors/ Identified precursors Rate
# W5. Identified precursors/ identified scan rate
# W6. MS1 data point per peak
# W7. MS2 data point per peak
	bottomW1, topW1 = 20, 60
	bottomW2, topW2 = 30, 12.5
	bottomW3, topW3 = 1, 4
	bottomW4, topW4 = 10, 4
	bottomW5, topW5 = 0.3, 0.7
	bottomW6, topW6 = 1, 6
	bottomW7, topW7 = 10, 5

# IS1. 1+/2+ ions detected
# IS2. 3+/2+ ions detected
# IS3. 4+/2+ ions detected
# IS4. Med. precursor m/z
# IS5. Precursors charge distribution
	bottomIS1, topIS1 = 2.5, 1.3
	bottomIS2, topIS2 = 0.1, 0.4
	bottomIS3, topIS3 = 0.01, 0.05
	bottomIS4, topIS4 = 1000, 580
	# bottomIS5, topIS5 = 100, 300

# M1. Proportion of MS1 time
# M2. Med. MS1 ion injection time
# M3. Med. MS2 ion injection time
# M4. MS1 cycle time
# M5. MS2 cycle time
	bottomM1, topM1 = 0.3, 0.1
	bottomM2, topM2 = 10, 4
	bottomM3, topM3 = 10, 50
	bottomM4, topM4 = 5, 2.5
	bottomM5, topM5 = 5, 2.5
# M6. Median peaks intensity of MS1
# M7. Median peaks number of MS1
# M8. Median peaks number of MS2
# M9. Median peaks intensity of MS2
# M10. Identified / detected features
	bottomM6, topM6 = 5, 6
	bottomM7, topM7 = 1500, 2000
	bottomM8, topM8 = 150, 320
	bottomM9, topM9 = 4, 4.8
	bottomM10, topM10 = 0.3, 0.7
# M11. Signal to noise（S/N）for precursors
# M12. Median of MS1 raw mass accuracy
# M13. Median of MS2 raw mass accuracy
# M14. Median intensities for precursors
# M15. Median intensities for peptides
	bottomM11, topM11 = 6.5, 10
	bottomM12, topM12 = 5, 1
	bottomM13, topM13 = 5, 1
	bottomM14, topM14 = 1, 2.5
	bottomM15, topM15 = 1, 2.5
# M16. Median intensities for protein groups
# M17. Acquired MS1 scans
# M18. Acquired MS2 scans
# M19. MS2 identification rate
# M20. Max. identification rate over M/Z range
	bottomM16, topM16 = 1, 2.5
	bottomM17, topM17 = 19, 26
	bottomM18, topM18 = 1000, 1500
	bottomM19, topM19 = 0.3, 0.7
	bottomM20, topM20 = 0.4, 1

# ID1. Identified MS2 scans
# ID2: Precursors
# ID3: Peptides
# ID4. Protein groups
# ID5. Proteins
# ID6. AVG peptides per protein group
# ID7. AVG precursors per protein group
	bottomID1, topID1 = 10000, 20000
	bottomID2, topID2 = 10000, 20000
	bottomID3, topID3 = 10000, 20000
	bottomID4, topID4 = 2000, 3000
	bottomID5, topID5 = 2000, 3000
	bottomID6, topID6 = 4, 6
	bottomID7, topID7 = 4, 8


class SCIEX_radar_info:
# S1. Missed cleavages(n=0) of peptides
# S2. Med. Total Ion Current (TIC) (log10)
# S3. Med. peaks intensity of MS1
	bottomS1, topS1 = 0.8, 0.9
	bottomS2, topS2 = 20, 10
	bottomS3, topS3 = 9.8, 10.2

# C1. Chromatographic invalid acquiring time
# C2. Median of FWHM
# C3. Median of peak width
# C4. Proportion of peptides with long eluting width
# C5. Median precursors identified over RT
# C6. Max. identification rate over RT
	bottomC1, topC1 = 10, 1
	bottomC2, topC2 = 0.2, 0.12
	bottomC3, topC3 = 0.4, 0.2
	bottomC4, topC4 = 0.005, 0.001
	bottomC5, topC5 = 600, 800
	bottomC6, topC6 = 0.6, 0.8

# W1. Acquired MS2 scans in one cycle
# W2. Median of window size (Da)
# W3. Redundant identified precursors/ Identified Scan Rate
# W4. Redundant identified precursors/ Identified precursors Rate
# W5. Identified precursors/ identified scan rate
# W6. MS1 data point per peak
# W7. MS2 data point per peak
	bottomW1, topW1 = 20, 80
	bottomW2, topW2 = 30, 12.5
	bottomW3, topW3 = 1, 4
	bottomW4, topW4 = 6, 2
	bottomW5, topW5 = 0.3, 0.7
	bottomW6, topW6 = 1, 6
	bottomW7, topW7 = 10, 5

# IS1. 1+/2+ ions detected
# IS2. 3+/2+ ions detected
# IS3. 4+/2+ ions detected
# IS4. Med. precursor m/z
# IS5. Precursors charge distribution
	bottomIS1, topIS1 = 2.5, 1.3
	bottomIS2, topIS2 = 0.1, 0.4
	bottomIS3, topIS3 = 0.01, 0.05
	bottomIS4, topIS4 = 1000, 580
	# bottomIS5, topIS5 = 100, 300

# M1. Proportion of MS1 time
# M2. Med. MS1 ion injection time
# M3. Med. MS2 ion injection time
# M4. MS1 cycle time
# M5. MS2 cycle time
	bottomM1, topM1 = 0.3, 0.1
	bottomM2, topM2 = 10, 4
	bottomM3, topM3 = 10, 50
	bottomM4, topM4 = 5, 2.5
	bottomM5, topM5 = 5, 2.5
# M6. Median peaks intensity of MS1
# M7. Median peaks number of MS1
# M8. Median peaks number of MS2
# M9. Median peaks intensity of MS2
# M10. Identified / detected features
	bottomM6, topM6 = 5, 6.5
	bottomM7, topM7 = 2000, 9000
	bottomM8, topM8 = 300, 600
	bottomM9, topM9 = 4, 5
	bottomM10, topM10 = 0.3, 0.7
# M11. Signal to noise（S/N）for precursors
# M12. Median of MS1 raw mass accuracy
# M13. Median of MS2 raw mass accuracy
# M14. Median intensities for precursors
# M15. Median intensities for peptides
	bottomM11, topM11 = 6.5, 10
	bottomM12, topM12 = 10, 2
	bottomM13, topM13 = 10, 2
	bottomM14, topM14 = 1, 2.5
	bottomM15, topM15 = 1, 2.5
# M16. Median intensities for protein groups
# M17. Acquired MS1 scans
# M18. Acquired MS2 scans
# M19. MS2 identification rate
# M20. Max. identification rate over M/Z range
	bottomM16, topM16 = 1, 2.5
	bottomM17, topM17 = 20, 40
	bottomM18, topM18 = 1500, 3000
	bottomM19, topM19 = 0.3, 0.7
	bottomM20, topM20 = 0.3, 0.7

# ID1. Identified MS2 scans
# ID2: Precursors
# ID3: Peptides
# ID4. Protein groups
# ID5. Proteins
# ID6. AVG peptides per protein group
# ID7. AVG precursors per protein group
	bottomID1, topID1 = 10000, 20000
	bottomID2, topID2 = 10000, 20000
	bottomID3, topID3 = 10000, 20000
	bottomID4, topID4 = 2000, 3000
	bottomID5, topID5 = 2000, 3000
	bottomID6, topID6 = 4, 6
	bottomID7, topID7 = 4, 8


class feature_INFO:

	S1 = 'S1. Missed cleavages(n=0) of peptides '
	S2 = 'S2. Median peptide length'
	S3 = 'S3. Median Total Ion Current (TIC)'

	C1 = 'C1. Chromatographic invalid acquiring time'
	C2 = 'C2. Median of full width at half maximum (FWHM)'
	C3 = 'C3. Median of peak width'
	C4 = 'C4. Proportion of peptides with long eluting width'
	C5 = 'C5. Median precursors identified over RT'
	C6 = 'C6. Maximum identification rate over RT'

	W1 = 'W1. Acquired MS2 scans in one cycle'
	W2 = 'W2. Median of window size (Da)'
	W3 = 'W3. Redundant identified precursors/ Identified Scan Rate'
	W4 = 'W4. Redundant identified precursors/ Identified precursors Rate'
	W5 = 'W5. Identified precursors/ identified scan rate'
	W6 = 'W6. MS1 data point per peak'
	W7 = 'W7. MS2 data point per peak'

	IS1 = 'IS1. 1+/2+ ions detected'
	IS2 = 'IS2. 3+/2+ ions detected'
	IS3 = 'IS3. 4+/2+ ions detected '
	IS4 = 'IS4. Median precursor m/z'
	# IS5 = 'IS6. Precursors charge distribution'

	M1 = 'M1. Proportion of MS1 time'
	M2 = 'M2. Median MS1 ion injection time'
	M3 = 'M3. Median MS2 ion injection time'
	M4 = 'M4. MS1 cycle time'
	M5 = 'M5. MS2 cycle time'
	M6 = 'M6. Median peaks intensity of MS1'
	M7 = 'M7. Median peaks number of MS1 '
	M8 = 'M8. Median peaks number of MS2'
	M9 = 'M9. Median peaks intensity of MS2'
	M10 = 'M10. Identified / detected features'
	M11 = 'M11. Signal to noise（S/N）for precursors'
	M12 = 'M12. Median of MS1 raw mass accuracy'
	M13 = 'M13. Median of MS2 raw mass accuracy'
	M14 = 'M14. Median intensities for precursors'
	M15 = 'M15. Median intensities for peptides '
	M16 = 'M16. Median intensities for protein groups '
	M17 = 'M17. Acquired MS1 scans'
	M18 = 'M18. Acquired MS2 scans'
	M19 = 'M19. MS2 identification rate'
	M20 = 'M20. Maximum identified precursors rate over M/Z range'

	ID1 = 'ID1. Number of Identified MS2 scans'
	ID2 = 'ID2. Number of Precursors'
	ID3 = 'ID3. Number of Peptides'
	ID4 = 'ID4. Number of protein groups'
	ID5 = 'ID5. Number of proteins'
	ID6 = 'ID6. AVG peptides per protein group'
	ID7 = 'ID7. AVG precursors per protein group'


class Meaning_INFO:

	S1 = 'The percentage of all identifed precursors without missed cleavage site;'
	S2 = 'The median of all identified peptide sequence length;'
	S3 = 'The median of total ion chromatography (TIC);'
	# S4 = 'The median of peaks number in one MS1 scan;'

	C1 = 'The retention time length from the start to the number of identified MS2 scans per minute more than'+ str(Config.C6_THRESHOLD_INVALID_ACQUIRING_SCAN)+ ";"
	C2 = 'The median full width at half maximum(FWHM) in retention time (RT) dimension for all peptide precursors;'
	C3 = 'The median peak width in RT dimension for all peptide precursors;'
	C4 = 'The percentage of peptide precursors with eluting width more than 1 minutes;'
	C5 = 'The median number of precursors identified per minute;'
	C6 = 'The maximum identification rate per minute;'

	W1 = 'The MS2 DIA windows number in one cycle;'
	W2 = 'The median number of  isolation width of MS2 DIA windows;'
	W3 = 'The mean identified precursors number per MS2 scan;'
	W4 = 'The mean redundant identification number per precursor;'
	W5 = 'The mean unique identified precursors number per MS2 scan;'
	W6 = 'The median MS1 data points per peak in RT dimension for all peptide precursors;'
	W7 = 'The median MS2 data points per peak in RT dimension for all peptide precursors;'

	IS1 = 'The number of 1+ peptide features over 2+ peptide features;'
	IS2 = 'The number of 3+ peptide features over 2+ peptide features;'
	IS3 = 'The number of 4+ peptide features over 2+ peptide features;'
	IS4 = 'The median m/z value for all identified precursors;'

	M1 = 'The proportion of time taken to acquire MS1 scan;'
	M2 = 'The median ion injection time of MS1 scan;'
	M3 = 'The median ion injection time of MS2 scan;'
	M4 = 'The median MS1 cycle time;'
	M5 = 'The median MS2 cycle time;'
	M6 = 'The median of sum peak intensities (log10) per MS1 scan;'
	M7 = 'The median of the peaks number per MS1 scan;'
	M8 = 'The median of sum peak intensities (log10) per MS2 scan;'
	M9 = 'The median of the peaks number per MS2 scan;'
	M10 = 'The percentage of identified features divided by detected features;'
	M11 = 'The signal to noise ratio of the LC-MS peak for a given peptide precursor;'
	M12 = 'The median of delta mass between the monoisotopic theoretical and the measured m/z of precursors;'
	M13 = 'The median of delta mass between the monoisotopic theoretical and the measured m/z of fragments;'
	M14 = 'The median of precursors quantity;'
	M15 = 'The median of peptide group quantity;'
	M16 = 'The median of protein group quantity;'
	M17 = 'The mean acquired MS1 scans per minute;'
	M18 = 'The mean acquired MS2 scans per minute;'
	M19 = 'The proportion of identified MS2 scans divided by acquired MS2 scans;'
	M20 = 'The identification rate over each MS2 DIA window;'

	ID1 = 'The number of identified MS2 scans;'
	ID2 = 'The number of identified precursors;'
	ID3 = 'The number of identified peptides;'
	ID4 = 'The number of identified protein groups;'
	ID5 = 'The number of identified proteins;'
	ID6 = 'The average peptides per protein group;'
	ID7 = 'The average precursors per protein group;'

