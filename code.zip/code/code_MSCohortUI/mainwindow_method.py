import os
import sys
import subprocess
import shutil
from PyQt5 import QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QColor
import ms_tool as plugins
from mainwindow import Ui_MainWindow
from config import CConfigOne
from config_file import *
from config_ui import *
from if_register import Register


class MainWindow(QMainWindow, Ui_MainWindow):

    def __init__(self, parent=None):
        global import_file
        import_file = ''
        super(MainWindow, self).__init__(parent)
        self.setupUi(self)
        self.cwd = os.getcwd()
        self.color_warning = QColor(255, 0, 0)
        self.color_normal = QColor(255, 255, 255)
        self.last_local = self.cwd
        try:
            self.mac_address = plugins.get_mac_address()
        except Exception as e:
            print("Error ocurrs {}".format(e))
            QMessageBox.warning(
                self, 'Error', 'Sorry, Not Support By Current System！', QMessageBox.Yes)
            exit(-1)
        self.check_registered(self.mac_address)

        self.config_list = [
            ['config_1.txt', CConfigOne, CConfigFileOne, CConfigUiOne]]
        self.setMouseTracking(True)


        self.initUI()

    def initUI(self):


        cconfig = CConfigOne()
        cconfig_file = CConfigFileOne()
        cconfig_ui = CConfigUiOne()

        path = os.path.dirname(os.path.realpath(sys.argv[0])) + r'\ini\default.ini'
        cconfig = cconfig_file.fileconfig(path, cconfig)
        cconfig_ui.configui(self, cconfig)
        self.export_2.setText('')

    def check_registered(self, mac_address):
        result = plugins.check_register(mac_address)
        result['code']=10
        if result['code'] == 1 or result['code'] == 2:
            QMessageBox.warning(
                self, 'Warning', 'It has not been authorized, please register first！', QMessageBox.Yes)
            self.setWindowTitle('MSCohort(Unauthorized)')
            self.welcome.hide()
            self.save_btn.setEnabled(False)
            self.save_as_btn.setEnabled(False)
            self.imp_btn.setEnabled(False)
            self.sub_btn.setEnabled(False)
            self.new_btn.setEnabled(False)
        elif result['code'] == -1:
            QMessageBox.warning(
                self, 'Warning', 'No permission, please delete cfg.ini first！', QMessageBox.Yes)
            exit(1)
        else:
            QMessageBox.information(
                self, 'Welcome', 'It has been authorized, please enjoy it！', QMessageBox.Yes)
            self.setWindowTitle('MSCohort(Authorized)')
            self.reg_btn.hide()
            self.welcome.setVisible(True)
            self.save_btn.setEnabled(True)
            self.save_as_btn.setEnabled(True)
            self.imp_btn.setEnabled(True)
            self.sub_btn.setEnabled(True)
            self.new_btn.setEnabled(True)

    def checkPathExist(self, table, row, value):
        table.setItem(row, 1, QTableWidgetItem(value))
        flag = os.path.exists(value)
        table.item(row, 1).setBackground(self.color_normal if flag else self.color_warning)
        return 0 if flag else 1

    def checkSBox(self, table, row, value):
        table.setItem(row, 1, QTableWidgetItem(value))
        table.item(row, 1).setBackground(self.color_normal if Decimal(value) > 0 else self.color_warning)
        return 0 if Decimal(value) > 0 else 1

    @pyqtSlot()
    def on_reg_btn_clicked(self):


        register = Register(self)
        register.ledt_number.setText(self.mac_address)
        code = register.exec_()

        if register.result['code'] == 0:
            self.setWindowTitle('MSRefine(Authorized)')
            self.reg_btn.hide()
            self.welcome.setVisible(True)
            self.new_btn.setEnabled(True)
            self.save_btn.setEnabled(True)
            self.save_as_btn.setEnabled(True)
            self.imp_btn.setEnabled(True)
            self.sub_btn.setEnabled(True)

    @pyqtSlot()
    def on_imp_btn_clicked(self):
        global import_file
        file_name, file_type = QFileDialog.getOpenFileName(self, '配置文件选择', self.cwd, 'Text Files(*.txt)')

        if file_name == '':
            return
        for config in self.config_list:
            cconfig = config[1]()
            cconfig_file = config[2]()
            cconfig_ui = config[3]()

            import_file = file_name
            if file_name:
                cconfig = cconfig_file.fileconfig(file_name, cconfig)
                cconfig_ui.configui(self, cconfig)

        if file_name:
            QMessageBox.information(self, 'Message', 'Config file has been loaded successfully!', QMessageBox.Yes)
        return

    @pyqtSlot()
    def on_save_btn_clicked(self):
        global import_file
        if import_file == '':
            QMessageBox.information(self, 'Message', 'Please click "Save as" first to generate the local config file!', QMessageBox.Yes)
            return
        else:
            for config in self.config_list:
                cconfig = config[1]()
                cconfig_file = config[2]()
                cconfig_ui = config[3]()

                cconfig = cconfig_ui.uiconfig(self, cconfig)
                cconfig_file.configfile(import_file, cconfig)

            QMessageBox.information(self, 'Message', 'Modified config file has been saved successfully!', QMessageBox.Yes)

    @pyqtSlot()
    def on_save_as_btn_clicked(self):
        global import_file
        if len(self.config_list) == 0:
            QMessageBox.warning(self, 'Message', 'No config file to save，please import first!', QMessageBox.Yes)
            return
        file_name, file_type = QFileDialog.getSaveFileName(self, '文件保存', self.last_local, 'Text Files(*.txt)')
        self.last_local = os.path.abspath(file_name)
        if file_name == '':
            return
        else:
            for config in self.config_list:
                cconfig = config[1]()
                cconfig_file = config[2]()
                cconfig_ui = config[3]()
                import_file = file_name

                cconfig = cconfig_ui.uiconfig(self, cconfig)

                cconfig_file.configfile(file_name, cconfig)

            QMessageBox.information(self, 'Message', 'Config file has been saved successfully!', QMessageBox.Yes)

    @pyqtSlot()
    def on_sub_btn_clicked(self):
        global import_file
        if import_file == '':
            
            QMessageBox.information(self, 'Message', 'Need to import or generate config file first!', QMessageBox.Yes)
            return
        else:
            QMessageBox.information(self, 'Message', 'MSRefine is running，please wait patiently！', QMessageBox.Yes)

        if type(import_file) == list:
            import_file = import_file[0]

        if self.com_type_flow.currentText() == 'Inter-Experiment':
            order = os.getcwd() + '\\bin\\MSCohort.exe ' + import_file
            subprocess.Popen(order, shell=True)
        elif self.com_type_flow.currentText() == 'Intra-Experiment':
            order = os.getcwd() + '\\bin\\MSRefine_DIA.exe ' + import_file
            subprocess.Popen(order, shell=True)



    @pyqtSlot()
    def on_new_btn_clicked(self):

        global import_file
        import_file = ''
        self.ledt_file.setText('')

        self.ledt_result.setText('')
        self.exper_result.setText('')
        self.com_type_data.setCurrentIndex(0)
        self.com_type_result.setCurrentIndex(0)

        self.FDR.setText('0.01')

        self.normalize_type.setCurrentIndex(2)

        self.outlier.setCurrentIndex(0)
        self.show_order.setCurrentIndex(0)
        self.peak_width.setText('1')
        self.invalid_scan.setText('100')
        self.feature.setCurrentIndex(0)

        self.export_2.setText('')
        return

    @pyqtSlot()
    def on_add_file_btn_clicked(self):
        if self.com_type_data.currentText() == 'Bruker_timsTOF':
            file_name = QFileDialog.getExistingDirectory(self, "Select", self.last_local)
        elif self.com_type_data.currentText() == 'SCIEX_ZenoTOF':
            file_name, file_type = QFileDialog.getOpenFileNames(self, "Select", self.last_local, 'WIFF Files(*.wiff)')
        else:
            file_name, file_type = QFileDialog.getOpenFileNames(self, "Select",  self.last_local, 'RAW Files(*.raw)')
        if len(file_name) == 0:
            return
        self.last_local = os.path.abspath(file_name[0])
        if self.com_type_data.currentText() == 'Bruker_timsTOF':
            str_file_name = file_name+'|'
        else:
            str_file_name = '|'.join(file_name) + '|'
        self.ledt_file.setText(self.ledt_file.text() + '{}'.format(str_file_name))

    @pyqtSlot()
    def on_add_file_ms1_btn_clicked(self):

        file_name, file_type = QFileDialog.getOpenFileNames(self, "Select",  self.cwd, 'MS1 Files(*.ms1)')
        if len(file_name) == 0:
            return
        self.ledt_file_ms1.setText('{}'.format(file_name))

    @pyqtSlot()
    def on_add_file_ms2_btn_clicked(self):

        file_name, file_type = QFileDialog.getOpenFileNames(self, "Select", self.cwd, 'MS2 Files(*.ms2)')
        if len(file_name) == 0:
            return
        self.ledt_file_ms2.setText('{}'.format(file_name))

    @pyqtSlot()
    def on_add_result_btn_clicked(self):
        file_name, file_type = QFileDialog.getOpenFileNames(self, "Select",  self.last_local, 'Result File(*)')
        if len(file_name) == 0:
            return
        self.last_local = os.path.abspath(file_name[0])
        str_result_name = '|'.join(file_name) + '|'
        self.ledt_result.setText(self.ledt_result.text() + '{}'.format(str_result_name))

    @pyqtSlot()
    def on_add_experiment_btn_clicked(self):

        file_name, file_type = QFileDialog.getOpenFileName(self, "Select", self.last_local, 'TSV Files(*.tsv)')
        if len(file_name) == 0:
            return
        self.last_local = os.path.abspath(file_name)
        self.exper_result.setText('{}'.format(file_name))

    @pyqtSlot()
    def on_exp_btn_clicked(self):
        path = QFileDialog.getExistingDirectory(self, 'File Select', self.last_local)
        if not os.path.exists(path):
            return
        self.last_local = os.path.abspath(path)
        self.export_2.setText('{}'.format(path))






