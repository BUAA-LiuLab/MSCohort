from Crypto.Cipher import AES
import uuid
import base64
import os
import configparser
# import requests


class AutoConfigParser(configparser.ConfigParser):
    def optionxform(self, optionstr):
        return optionstr

    def remove_note(self):
        section_list = self.sections()
        for section in section_list:
            for k, v in self.items(section):
                self.set(section, k, v)

class CConfigKeyValue():

    def __init__(self):

        self.TYPE_FLOW_LIST = {'Inter-Experiment': '0', 'Intra-Experiment': '1'}
        self.FLAG_FAIMS_LIST = {'No': 0, 'Yes': 1}
        self.TYPE_IDENTIFICATION_RESULT_LIST = {'Spectronaut': 0}
        self.TYPE_DATA_LIST = {'Thermo_Orbitrap': 0, 'Bruker_timsTOF': 1, 'SCIEX_ZenoTOF': 2, 'Thermo_Orbitrap(FAIMS)': 3}
        self.TYPE_NORMALIZATION = {'DirectLFQ': 0,'MaxLFQ': 1, 'Quantile': 2}
        self.FLAG_OUTLIERS = {'2-SD': 0, 'customized threshold': 1}
        self.FLAG_SHOW_ORDER = {'group series': 0, 'time series': 1}
        self.FLAG_ANALYZE_FEATURE = {'No': 0, 'Yes': 1}
        self.FLAG_IRT_PEPTIDE = {'No': 0, 'Yes': 1}
        self.FLAG_CONTAMINATE = {'No': 0, 'Yes': 1}
        self.FLAG_PDF_EXPORT = {'No': 0, 'Yes': 1}
        self.FLAG_EXTRACT_MS_LIST = {'No': 0, 'Yes': 1}
        self.FLAG_MERGE_MS2_LIST = {'No': 0, 'Yes': 1}
        self.FLAG_ANALYZE_FEATURE_LIST = {'No': 0, 'Yes': 1}
        self.FLAG_ANALYZE_PIF_LIST = {'No': 0, 'Yes': 1}
        self.FLAG_ANALYZE_TAG_LIST = {'No': 0, 'Yes': 1}

# 本机机器码
def get_mac_address():
    return uuid.uuid1().hex[-12:].upper()

class License(object):
    def __init__(self, key='1415599040@qq.com'):
        if len(key) > 32:
            key = key[:32]
        self.key = self.to_16(key)

    def to_16(self, key):
        key = bytes(key, encoding="utf8")
        while len(key) % 16 != 0:
            key += b'\0'
        return key  # 返回bytes

    def aes(self):
        return AES.new(self.key, AES.MODE_ECB)  # 初始化加密器
    # 加密生成序列号
    def make_license(self, text):
        aes = self.aes()
        return str(base64.b64encode(aes.encrypt(self.to_16(text))),
                   encoding='utf8')  # 加密

    def valid_license(self, text):
        aes = self.aes()
        return str(aes.decrypt(base64.b64decode(bytes(
            text, encoding='utf-8'))).rstrip(b'\0').decode("utf-8"))  # 解密


def check_register(mac_address):
    result = {'code': 0, 'message': 'Already Registered!'}
    conf = configparser.ConfigParser()
    if os.path.exists('./ini/emergency.ini'):
        return result
    if os.path.exists('./ini/cfg.ini'):
        conf.read('./ini/cfg.ini', encoding='utf-8')
        if 'license' in conf.sections():
            properties = [item[0] for item in conf.items('license')]
            if 'key' in properties and 'host' in properties:
                # if conf.get('license', 'host') == '60F2620F453E' and conf.get('license', 'key') == 'B9wC4Kq+ZK9lHnI2qSP/cQ==':
                #     result['code'] = 0
                #     return result
                if mac_address == conf.get('license', 'host'):
                    license = License()
                    key_real = license.make_license(mac_address)
                    if not key_real == conf.get('license', 'key'):
                        result['code'] = 1
                        result['message'] = 'Not Registered Yet!'
                else:
                    result['code'] = -1
                    result['message'] = 'Error, File cfg.ini has been modified!'
            else:
                result['code'] = -1
                result['message'] = 'Error, File cfg.ini has been modified!'
        else:
            result['code'] = -1
            result['message'] = 'Error, File cfg.ini has been modified!'
    else:
        conf.add_section('license')
        conf.set('license', 'host', mac_address)
        conf.set('license', 'key', '')
        conf.write(open('./ini/cfg.ini', 'w'))
        result['code'] = 2
        result['message'] = 'No cfg.ini File, Create it!'
    return result


def update_license(license_number):
    result = {'code': 0, 'message': 'Regist and Update License Success!'}
    conf = configparser.ConfigParser()
    try:
        conf.read('./ini/cfg.ini', encoding='utf-8')
        conf.set('license', 'key', license_number)
        conf.write(open('./ini/cfg.ini', 'w'))
    except Exception as e:
        result['code'] = -1
        result['message'] = 'Update License Error: {}'.format(e)
    return result


def register(pay_load):
    result = {'code': 0, 'message': 'Regist Success!'}
    try:
        response = requests.get('http://101.200.172.189:77/monitor_regist', params=pay_load, timeout=2)
        # response = requests.get('192.168.1.108:77/monitor_regist', params=pay_load, timeout=2)
        result['message'] = response.json()
    except Exception as e:
        result = {'code': -1, 'message': '{}'.format(e)}
    return result


if __name__ == '__main__':
    license = License()
    print(get_mac_address())
    print(license.make_license(get_mac_address()))
