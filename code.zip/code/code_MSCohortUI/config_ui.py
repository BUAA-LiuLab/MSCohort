from decimal import Decimal
from ms_tool import *
from mainwindow import Ui_MainWindow
from config import CConfigOne
class CConfigUiOne:
    def configui(self, ui: Ui_MainWindow, config: CConfigOne):

        ui.com_type_flow.setCurrentIndex(config.TYPE_FLOW_LIST.index(config.TYPE_FLOW))

        ui.com_type_data.setCurrentIndex(config.TYPE_DATA_LIST.index(config.TYPE_DATA))

        ui.ledt_file.setText(config.PATH_DATA)

        ui.com_type_result.setCurrentIndex(config.TYPE_IDENTIFICATION_RESULT_LIST.index(config.TYPE_IDENTIFICATION_RESULT))
        ui.ledt_result.setText(config.PATH_IDENTIFICATION_RESULT)
        ui.FDR.setText(config.THRESHOLD_FDR)

        if config.TYPE_FLOW == '0':
            ui.exper_result.setText(config.PATH_EXPERIMENT_RESULT)
            ui.normalize_type.setCurrentIndex(config.TYPE_NORMALIZATION_LIST.index(config.TYPE_NORMALIZATION))

            ui.outlier.setCurrentIndex(config.FLAG_OUTLIERS_LIST.index(config.FLAG_OUTLIERS))
            ui.show_order.setCurrentIndex(config.FLAG_SHOW_ORDER_LIST.index(config.FLAG_SHOW_ORDER))
        ui.peak_width.setText(config.THRESHOLD_PEAK_WIDTH_TAILING)
        ui.invalid_scan.setText(config.THRESHOLD_INVALID_ACQUIRING_SCAN)
        ui.feature.setCurrentIndex(config.FLAG_ANALYZE_FEATURE_LIST.index(config.FLAG_ANALYZE_FEATURE))



        ui.export_2.setText(config.PATH_EXPORT)


        return ui

    def uiconfig(self, ui: Ui_MainWindow, config: CConfigOne):
        cv = CConfigKeyValue()
        config.TYPE_FLOW =cv.TYPE_FLOW_LIST[ui.com_type_flow.currentText()]
        config.TYPE_DATA = cv.TYPE_DATA_LIST[ui.com_type_data.currentText()]
        # config.FLAG_FAIMS = cv.FLAG_FAIMS_LIST[ui.com_faims.currentText()]
        config.PATH_DATA = ui.ledt_file.text()


        config.TYPE_IDENTIFICATION_RESULT = cv.TYPE_IDENTIFICATION_RESULT_LIST[ui.com_type_result.currentText()]
        config.PATH_IDENTIFICATION_RESULT = ui.ledt_result.text()
        config.THRESHOLD_FDR = ui.FDR.text()

        if config.TYPE_FLOW == '0':
            config.PATH_EXPERIMENT_RESULT = ui.exper_result.text()
            config.TYPE_NORMALIZATION = cv.TYPE_NORMALIZATION[ui.normalize_type.currentText()]
            config.FLAG_OUTLIERS = cv.FLAG_OUTLIERS[ui.outlier.currentText()]
            config.FLAG_SHOW_ORDER = cv.FLAG_SHOW_ORDER[ui.show_order.currentText()]
        config.THRESHOLD_PEAK_WIDTH_TAILING = ui.peak_width.text()
        config.THRESHOLD_INVALID_ACQUIRING_SCAN = ui.invalid_scan.text()
        config.FLAG_ANALYZE_FEATURE =cv.FLAG_ANALYZE_FEATURE[ui.feature.currentText()]
        config.PATH_EXPORT = ui.export_2.text()

        print(config.PATH_EXPORT)
        return config
