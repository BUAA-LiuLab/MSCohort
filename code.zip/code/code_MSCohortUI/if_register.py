# -*- coding: utf-8 -*-

"""
Module implementing Register.
"""

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import *
from reg import Ui_Register
import ms_tool as plugins


class Register(QDialog, Ui_Register):
    """
    Class documentation goes here.
    """

    def __init__(self, parent=None):
        """
        Constructor

        @param parent reference to the parent widget
        @type QWidget
        """
        super(Register, self).__init__(parent)
        self.setupUi(self)
        self.cbox_country.addItems(
            ["Afghanistan", "Aland Islands", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla",
             "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas",
             "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan",
             "Bolivia", "Bosnia and Herzegovina", "Botswana", "Bouvet Island", "Brazil", "Brunei", "Bulgaria",
             "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Cape Verde", "Central African Republic",
             "Chad", "Chile", "China", "Christmas Islands", "Cocos (keeling) Islands", "Colombia", "Comoros", "Congo",
             "Congo (Congo-Kinshasa)", "Cook Islands", "Costa Rica", "Cote D'Ivoire", "Croatia", "Cuba", "Cyprus",
             "Czech", "Denmark", "Djibouti", "Dominica", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea",
             "Eritrea", "Estonia", "Ethiopia", "Faroe Islands", "Fiji", "Finland", "France", "French Guiana",
             "French Polynesia", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Grenada",
             "Guadeloupe", "Guam", "Guatemala", "Guernsey", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras",
             "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Isle of Man", "Israel", "Italy",
             "Jamaica", "Japan", "Jersey", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Korea (North)",
             "Korea (South)", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya",
             "Liechtenstein", "Lithuania", "Luxembourg", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives",
             "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte",
             "MetropolitanFrance", "Mexico", "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Montserrat",
             "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "New Caledonia",
             "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "Norway", "Oman", "Pakistan",
             "Palau", "Palestine", "Panama", "Papua New Guinea", "Peru", "Philippines", "Pitcairn Islands", "Poland",
             "Portugal", "Puerto Rico", "Qatar", "Reunion", "Romania", "Russian Federation", "Rwanda", "Saint Helena",
             "Saint Kitts-Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "San Marino",
             "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore",
             "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "Spain", "Sri Lanka", "Sudan",
             "Suriname", "Swaziland", "Sweden", "Switzerland", "Syria", "Tajikistan", "Tanzania", "Thailand",
             "Timor-Leste", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan",
             "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "Uruguay",
             "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", "Wallis and Futuna", "Western Sahara",
             "Yemen", "Yugoslavia", "Zambia", "Zimbabwe"])
        self.cbox_country.setCurrentIndex(41)
        self.result = {'code': -1, 'message': 'Not Regist Yet'}

    @pyqtSlot()
    def on_btn_submit_clicked(self):
        sn = self.ledt_number.text()
        username = self.ledt_username.text()
        email = self.ledt_email.text()
        organization = self.ledt_organization.text()
        supervisor = self.ledt_supervisor.text()
        supermail = self.ledt_supemail.text()
        country = self.cbox_country.currentText()
        hearfrom = self.list_hearfrom.toPlainText()
        usefor = self.list_usefor.toPlainText()

        if len(username) == 0:
            QMessageBox.information(self, 'Warning', 'Username is empty, please fill it!', QMessageBox.Yes)
            return
        if len(organization) == 0:
            QMessageBox.information(self, 'Warning', 'University/Company is empty, please fill it!', QMessageBox.Yes)
            return
        if len(email) == 0:
            QMessageBox.information(self, 'Warning', 'Email address is empty, please fill it!', QMessageBox.Yes)
            return
        if not ('@' in email and '.' in email):
            QMessageBox.information(self, 'Warning', 'Wrong email format, please input right one!', QMessageBox.Yes)
            self.ledt_email.setFocus()
            return
        if len(supervisor) == 0:
            QMessageBox.information(self, 'Warning', 'Supervisor is empty, please fill it!', QMessageBox.Yes)
            return
        if len(supermail) == 0:
            QMessageBox.information(self, 'Warning', "Supervisor's email is empty, please fill it!", QMessageBox.Yes)
            return
        if not ('@' in supermail and '.' in supermail):
            QMessageBox.information(self, 'Warning',
                                    "The format of supervisor's email is wrong, please input the right one!",
                                    QMessageBox.Yes)
            self.ledt_supemail.setFocus()
            return
        if len(country) == 0:
            QMessageBox.information(self, 'Warning', 'Country/Region is empty, please fill it!', QMessageBox.Yes)
            return
        if len(hearfrom) == 0:
            QMessageBox.information(self, 'Warning', 'Please maintain the integrity of the information!',
                                    QMessageBox.Yes)
            return
        if len(usefor) == 0:
            QMessageBox.information(self, 'Warning', 'Please maintain the integrity of the information!',
                                    QMessageBox.Yes)
            return

        pay_load = {'sn': sn, 'username': username, 'email': email, 'organization': organization,
                    'supervisor': supervisor, 'supermail': supermail, 'country': country, 'hearfrom': hearfrom,
                    'usefor': usefor}

        self.result = plugins.register(pay_load)
        if self.result['code'] == 0:
            key = self.result['message']['license']
            self.result = plugins.update_license(key)
            if self.result['code'] == 0:
                QMessageBox.information(self, 'Success', 'Registered successfully, enjoy it!', QMessageBox.Yes)
                self.close()
            else:
                QMessageBox.information(self, 'Failed', 'Registered successfully, but updated license failed!',
                                        QMessageBox.Yes)
                return
        elif self.result['code'] == -1:
            QMessageBox.information(self, 'Failed', 'Registered failed, please check your network!', QMessageBox.Yes)
            return
        else:
            pass
