# -*- coding:utf-8 -*-

from flask import Flask, request, jsonify, send_from_directory, render_template
from flask_sqlalchemy import SQLAlchemy
import datetime
import os
import base64
from Crypto.Cipher import AES
import json


class License(object):
    def __init__(self, key):
        if len(key) > 32:
            key = key[:32]
        self.key = self.to_16(key)

    def to_16(self, key):
        key = bytes(key, encoding="utf8")
        while len(key) % 16 != 0:
            key += b'\0'
        return key  # 返回bytes

    def aes(self):
        return AES.new(self.key, AES.MODE_ECB)  # 初始化加密器

    def make_lincense(self, text):
        aes = self.aes()
        return str(base64.encodebytes(aes.encrypt(self.to_16(text))),
                   encoding='utf8').replace('\n', '')  # 加密

    def valid_license(self, text):
        aes = self.aes()
        return str(aes.decrypt(base64.decodebytes(bytes(
            text, encoding='utf-8'))).rstrip(b'\0').decode("utf-8"))  # 解密


app = Flask(__name__, static_url_path='')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)


class LicenseInfo(db.Model):  
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    sn = db.Column(db.String(80), unique=True, nullable=False)
    username = db.Column(db.String(100), unique=False, nullable=False)
    email = db.Column(db.String(80), unique=False, nullable=False)
    university = db.Column(db.String(200), unique=False, nullable=False)
    supervisor = db.Column(db.String(100), unique=False, nullable=False)
    supervisor_email = db.Column(db.String(80), unique=False, nullable=False)
    country = db.Column(db.String(100), unique=False, nullable=False)
    how = db.Column(db.String(1000), unique=False, nullable=False)
    what = db.Column(db.String(1000), unique=False, nullable=False)
    license = db.Column(db.String(80), unique=False, nullable=False)
    time_regist = db.Column(db.Date, nullable=False,
                            default=datetime.datetime.now)

    def __repr__(self):
        return '<SN: {}>'.format(self.sn)


license = License('1415599040@qq.com')


@app.route('/monitor_regist', methods=['POST', 'GET'])
def regist():
    if request.method == 'GET':
        sn = request.args.get('sn')
        username = request.args.get('username')
        email = request.args.get('email')
        university = request.args.get('university')
        supervisor = request.args.get('supervisor')
        supervisor_email = request.args.get('supervisor_email')
        country = request.args.get('country')
        how = request.args.get('how')
        what = request.args.get('what')

    data = {'license': license.make_lincense(sn)}
    if len(LicenseInfo.query.filter_by(sn=sn).all()) > 0:
        data['message'] = 'SN number Exist!'
        print('SN number Exist!')
    else:
        li = LicenseInfo(sn=sn, username=username,
                         email=email, university=university, supervisor=supervisor, supervisor_email=supervisor_email,
                         country=country, how=how, what=what, license=data['license'])
        db.session.add(li)
        db.session.commit()
        print('[{}] License Info Insert to DB Success'.format(sn))
    return jsonify(data)


@app.route('/download/<filename>', methods=['POST', 'GET'])
def download_data(filename):
    if request.method == 'GET':
        if os.path.isfile(os.path.join('downloads', filename)):
            print("Finde")
            return send_from_directory('downloads', filename, as_attachment=True)
        else:
            print("Not Exist")
    else:
        print("Not GET Method")



if __name__ == '__main__':
    # app.debug = True  # 设置调试模式，生产模式的时候要关掉debug
    if not os.path.exists('./monitor_database.db'):
        db.create_all()
    app.run(host='0.0.0.0', port=77, debug=False)
