from ms_tool import *
from config import CConfigOne


class CConfigFileOne():
    def configfile(self, path, config: CConfigOne):
        print('save config file')
        c = AutoConfigParser()
        # [Data file]
        c.add_section('Work Flow')
        c.set('Work Flow', 'WORK_FLOW', str(config.TYPE_FLOW))
        c.add_section('Data file')
        c.set('Data file', 'TYPE_DATA', str(config.TYPE_DATA))
        # c.set('Data file', 'FLAG_FAIMS', str(config.FLAG_FAIMS))
        c.set('Data file', 'PATH_RAW', str(config.PATH_DATA).replace("/", "\\"))


        # [Identification results]
        c.add_section('Identification result')
        c.set('Identification result', 'TYPE_ANALYSIS_RESULT', str(config.TYPE_IDENTIFICATION_RESULT))
        c.set('Identification result', 'PATH_ANALYSIS_RESULT', str(config.PATH_IDENTIFICATION_RESULT).replace("/", "\\"))
        c.set('Identification result', 'THRESHOLD_FDR', str(config.THRESHOLD_FDR))

        # [Setting]
        c.add_section('Setting')
        # print(config.TYPE_FLOW)
        if config.TYPE_FLOW == '0':
            # print('123')
            c.set('Setting', 'PATH_EXPERIMENT_SETTING', str(config.PATH_EXPERIMENT_RESULT).replace("/", "\\"))
            c.set('Setting', 'TYPE_NORMALIZATION', str(config.TYPE_NORMALIZATION))
            c.set('Setting', 'FLAG_OUTLIERS', str(config.FLAG_OUTLIERS))
            c.set('Setting', 'FLAG_SHOW_ORDER', str(config.FLAG_SHOW_ORDER))
        c.set('Setting', 'THRESHOLD_PEAK_WIDTH_TAILING', str(config.THRESHOLD_PEAK_WIDTH_TAILING))
        c.set('Setting', 'THRESHOLD_INVALID_ACQUIRING_SCAN', str(config.THRESHOLD_INVALID_ACQUIRING_SCAN))
        c.set('Setting', 'FLAG_ANALYZE_FEATURE', str(config.FLAG_ANALYZE_FEATURE))
        # c.set('Setting', 'FLAG_PDF_EXPORT', str(config.FLAG_PDF_EXPORT))

        # [Export]
        c.add_section('Export')
        c.set('Export', 'PATH_EXPORT', str(config.PATH_EXPORT).replace("/", "\\") + '\\')

        with open(path, 'w+', encoding='utf-8') as f:
            c.write(f)
        with open(path, 'r') as f:
            context = f.read()
        f1 = open(path, 'w')
        f1.write(context.replace(" = ", "="))
        f1.close()
        print('save config file finished')

    def fileconfig(self, path, config: CConfigOne):
        print('load config file')
        c = AutoConfigParser()
        c.read(path, encoding='utf-8')
        c.remove_note()
        config.TYPE_FLOW = c.get('Work Flow', 'WORK_FLOW')
        # [Data file]
        config.TYPE_DATA = c.get('Data file', 'TYPE_DATA')
        # config.FLAG_FAIMS = c.get('Data file', 'FLAG_FAIMS')
        config.PATH_DATA = c.get('Data file', 'PATH_RAW').replace("\\", "/")


        # [Identification result]
        config.TYPE_IDENTIFICATION_RESULT = c.get('Identification result', 'TYPE_ANALYSIS_RESULT')
        config.PATH_IDENTIFICATION_RESULT = c.get('Identification result', 'PATH_ANALYSIS_RESULT').replace("\\", "/")
        config.THRESHOLD_FDR = c.get('Identification result', 'THRESHOLD_FDR')

        # [Setting]
        if config.TYPE_FLOW == '0':
            config.PATH_EXPERIMENT_RESULT = c.get('Setting', 'PATH_EXPERIMENT_SETTING')
            config.TYPE_NORMALIZATION = c.get('Setting', 'TYPE_NORMALIZATION')
            config.FLAG_OUTLIERS = c.get('Setting', 'FLAG_OUTLIERS')
            config.FLAG_SHOW_ORDER = c.get('Setting', 'FLAG_SHOW_ORDER')
            # config.FLAG_IRT = c.get('Setting', 'FLAG_IRT')
            # config.FLAG_CONTAMINATE = c.get('Setting', 'FLAG_CONTAMINATE')
        config.THRESHOLD_PEAK_WIDTH_TAILING = c.get('Setting', 'THRESHOLD_PEAK_WIDTH_TAILING')
        config.THRESHOLD_INVALID_ACQUIRING_SCAN = c.get('Setting', 'THRESHOLD_INVALID_ACQUIRING_SCAN')
        config.FLAG_ANALYZE_FEATURE = c.get('Setting', 'FLAG_ANALYZE_FEATURE')


        # [Export]
        config.PATH_EXPORT = c.get('Export', 'PATH_EXPORT').replace("\\", "/")[:-1]

        print('load config file finished')
        return config
