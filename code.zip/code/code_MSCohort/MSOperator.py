import numpy as np
import os
from MSData import CSeed, CEvidence, CFeatureEntry, CFeaturePepEntry
from MSSystem import VALUE_MAX_SCAN, VALUE_ILLEGAL, CFG_TYPE_ACCURACY_HALF_WIN_PEAK
from MSLogging import logGetError


class metrics_INFO:
    Total = 'Average Overall Quality'
    SP = 'The ratio of Contaminants'  # 根据ini列表中污染list统计指标数目
    LC1 = 'LC1. DeltaRT (predicted-measured)'
    LC2 = 'LC2. RT relative deviation'
    MS1 = 'MS1. The number of identified precursors'
    MS2 = 'MS2. Median of precursor intensity'
    MS3 = 'MS3. IQR of precursor intensity'
    MS4 = 'MS4. Robust Dev of precursor intensity'
    MS5 = 'MS5. Pearson correlation of precursor intensity'
    MS6 = 'MS6. Normalization factor of precursor intensity'
    MS7 = 'MS7. The number of identified peptides'
    MS8 = 'MS8. Median of peptide intensity'
    MS9 = 'MS9. IQR of peptide intensity'
    MS10 = 'MS10. Robust Dev of peptide intensity'
    MS11 = 'MS11. Pearson correlation of peptide intensity'
    MS12 = 'MS12. Normalization factor of peptide intensity'
    MS13 = 'MS13. The number of identified proteins'
    MS14 = 'MS14. Median of protein intensity'
    MS15 = 'MS15. IQR of protein intensity'
    MS16 = 'MS16. Robust Dev of protein intensity'
    MS17 = 'MS17. Pearson correlation of protein intensity'
    MS18 = 'MS18. Normalization factor of protein intensity'

class meaning_INFO:
    Total = 'The total score is obtained by averaging the sum of scores for each metric.'
    SP = 'The summed intensity of contaminant proteins in each sample is divided by the total summed intensity for all quantified proteins, yielding the ratio of contaminant proteins. The median and standard deviation are calculated for the ratios across all samples. '  # 根据ini列表中污染list统计指标数目
    LC1 = 'The difference between the predicted retention time (RT) and the measured mean apex RT is computed for each precursor. '
    LC2 = 'The RT relative deviation between each run and the first run for each precursor. '
    MS1 = 'The number of identified precursors for each sample. '
    MS2 = 'The median intensity of quantified precursors for each sample. '
    MS3 = 'The interquartile range (IQR) of the intensity of quantified precursors for each sample. '
    MS4 = 'Robust standard deviation is computed based on log2-transformed quantitation ratios of two runs. Robust standard deviation = (the 84.13% percentiles - 15.87% percentiles) / 2. '
    MS5 = 'The median of Pearson correlation coefficients between each sample and the other samples. '
    MS6 = 'The normalization factor of precursor intensity for each sample. '
    MS7 = 'The number of identified peptides for each sample. '
    MS8 = 'The median intensity of quantified peptides for each sample.'
    MS9 = 'The interquartile range (IQR) of the intensity of quantified peptides for each sample. '
    MS10 = 'Robust standard deviation is computed based on log2-transformed quantitation ratios of two runs. Robust standard deviation = (the 84.13% percentiles - 15.87% percentiles) / 2. '
    MS11 = 'The median of Pearson correlation coefficients between each sample and the other samples. '
    MS12 = 'The normalization factor of peptide intensity for each sample. '
    MS13 = 'The number of identified protein groups for each sample. '
    MS14 = 'The median intensity of quantified protein groups for each sample. '
    MS15 = 'The interquartile range (IQR) of the intensity of quantified protein groups for each sample. '
    MS16 = 'Robust standard deviation is computed based on log2-transformed quantitation ratios of two runs. Robust standard deviation = (the 84.13% percentiles - 15.87% percentiles) / 2. '
    MS17 = 'The median of Pearson correlation coefficients between each sample and the other samples. '
    MS18 = 'The normalization factor of protein intensity for each sample. '

def op_INIT_CFEATURE_ENTRY(inputCFeatureEntry: CFeatureEntry):

    inputCFeatureEntry.N_FEATURE = 0
    inputCFeatureEntry.FEA_X1_SEQ = []
    inputCFeatureEntry.FEA_X2_MOD = []
    inputCFeatureEntry.FEA_X3_CHARGE = []
    inputCFeatureEntry.FEA_X4_LEN = []
    inputCFeatureEntry.FEA_Y_RATIO = []


def op_INIT_CFEATURE_PEP_ENTRY(inputCFeatureEntry: CFeaturePepEntry):

    inputCFeatureEntry.N_FEATURE = 0
    inputCFeatureEntry.FEA_X1_SEQ = []
    inputCFeatureEntry.FEA_X2_LEN = []
    inputCFeatureEntry.FEA_Y_RATIO = []
    inputCFeatureEntry.FEA_Y_INTENSITY = []


def op_INIT_CSEED(CSeed: CSeed):

    CSeed.MID_SCAN = 0
    CSeed.MID_RT = 0
    CSeed.MOZ_FRAGMENT = []
    CSeed.TYPE_FRAGMENT = []
    CSeed.DIS_ISO_MOZ_CLC = []
    CSeed.DIS_ISO_INT_CLC = []
    CSeed.MOZ_PRECURSOR = []
    CSeed.DICT_COMPOSITION = []
    CSeed.INDEX_MONO = 0


def op_INIT_CEVIDENCE(CEvidence: CEvidence):

    CEvidence.LIST_RET_TIME = []
    CEvidence.LIST_SCAN = []
    CEvidence.LIST_I_START = []
    CEvidence.LIST_I_END = []
    CEvidence.I_START = 0
    CEvidence.I_END = -1
    CEvidence.DIS_ISO_MOZ_EXP = []
    CEvidence.DIS_ISO_INT_EXP = []
    CEvidence.PROFILE_ALL = []
    CEvidence.MS2_PEAK_MOZ = []
    CEvidence.MS2_PEAK_INT = []


def op_FILL_LIST_PATH_ID(inputPath, inputList):

    separator = '|'

    if len(inputPath) < 1:
        logGetError("MSOperator.py, op_FILL_LIST_PATH_ID, MK_1: Path for identification results is empty!")

    if inputPath[-1] == separator:
        inputPath = inputPath[:-1]
    else:
        pass

    inputList.extend(inputPath.split(separator))


def op_FILL_LIST_PATH_MS(inputPath, inputList, inputExt):

    separator = '|'
    listStrPath = []

    if len(inputPath) < 1:
        logGetError("MSOperator.py, op_FILL_LIST_PATH_MS: Path for MS is empty!")

    if inputPath[-1] == separator:
        inputPath = inputPath[:-1]
    else:
        pass

    listStrPath = inputPath.split(separator)

    for strPath in listStrPath:

        if os.path.isdir(strPath):
            inputList.append(strPath)



        elif os.path.isfile(strPath):

            inputList.append(strPath)

        else:

            logGetError("MSOperator.py, op_FILL_LIST_PATH_MS: Path for MS is illegal!")


def op_INIT_CFILE_MS1(inputMS1):

    inputMS1.INDEX_SCAN = []
    inputMS1.INDEX_RT = []

    inputMS1.LIST_ION_INJECTION_TIME = [VALUE_ILLEGAL] * VALUE_MAX_SCAN

    inputMS1.MATRIX_PEAK_MOZ = [[] * 1] * VALUE_MAX_SCAN  # 每一行是个list
    inputMS1.MATRIX_PEAK_INT = [[] * 1] * VALUE_MAX_SCAN
    inputMS1.MATRIX_PEAK_MARK = [[] * 1] * VALUE_MAX_SCAN


def op_INIT_CFILE_MS2(inputMS2):

    inputMS2.INDEX_SCAN = []
    inputMS2.INDEX_RT = []

    inputMS2.LIST_RET_TIME = [VALUE_ILLEGAL] * VALUE_MAX_SCAN
    inputMS2.LIST_ION_INJECTION_TIME = [VALUE_ILLEGAL] * VALUE_MAX_SCAN
    inputMS2.LIST_ACTIVATION_CENTER = [VALUE_ILLEGAL] * VALUE_MAX_SCAN
    inputMS2.LIST_PRECURSOR_SCAN = [VALUE_ILLEGAL] * VALUE_MAX_SCAN

    inputMS2.MATRIX_PEAK_MOZ = [[]*1] * VALUE_MAX_SCAN # 每一行是个list
    inputMS2.MATRIX_PEAK_INT = [[]*1] * VALUE_MAX_SCAN
    inputMS2.MATRIX_CHARGE = [[]*1] * VALUE_MAX_SCAN  # 相同的scan，可能有多个母离子状态（质量+电荷）
    inputMS2.MATRIX_MZ = [[]*1] * VALUE_MAX_SCAN  # 相同的scan，可能有多个母离子状态（质量+电荷）


def op_DIVIDE_ION_TYPE(input_ion_type: str):
    # 拆分by离子类型（如：b2++)到[b/y类型，离子位点，离子电荷数]（如：[b,2,2])
    ion_by = input_ion_type[0]
    site_index = 1
    while input_ion_type[site_index] != '+':
        site_index += 1
    ion_site = int(input_ion_type[1:site_index])
    ion_charge = len(input_ion_type[site_index:])

    return ion_by, ion_site, ion_charge


def op_DIVIDE_ION_TYPE_WITHLOSS(input_ion_type: str):
    # 拆分by离子类型（如：b2++_H2O)到[b/y类型，离子位点，离子电荷数]（如：[b,2,2])
    # 先拆分离子类型和损失
    ion_type_list = input_ion_type.split('_')
    ion_type = ion_type_list[0] if len(ion_type_list) == 1 else ion_type_list[0]
    return op_DIVIDE_ION_TYPE(ion_type)


def op_FindSame(exe, data, peak, bias_type, bias):
    '''
    查找最近的质荷比
    :param exe: 理论质荷比list
    :param data: 实际质荷比list
    :param peak: 峰强list
    :param bias_type: 偏差类型，ppm或Da
    :param bias: 偏差大小，float
    :return: outputL:满足误差范围内的质荷比list, output_peak：对应强度的List, output_ppm：对应的偏差list
    '''
    # 查找接近的质荷比
    # exe理论质荷比，data实际质荷比，peak实际峰值(已换算成百分比)，bias偏差
    output = list()
    output_ppm = list()
    output_peak = list()

    for index in exe:  # 遍历理论数据
        first = 0
        last = len(data) - 1
        if (index <= data[last]) & (index >= data[first]):
            flag = 0
            while first <= last:  # 二分查找
                mid = (first + last) // 2
                if index > data[mid]:
                    first = mid + 1
                elif index < data[mid]:
                    last = mid - 1
                else:
                    first = mid
                    last = mid - 1
                    break
        else:
            flag = -2
        if flag == 0:
            #Da偏差
            if bias_type == CFG_TYPE_ACCURACY_HALF_WIN_PEAK['Da']:
                if abs(data[first] - index) < bias:
                    loc = first
                    if peak[loc] == 0:
                        output.append(0)
                        output_peak.append(0)
                        output_ppm.append(0)
                    else:
                        output.append(data[loc])
                        output_peak.append(peak[loc])
                        output_ppm.append((- index + data[loc]) / index * 1000000)

                elif abs(data[last] - index) < bias:
                    loc = last
                    if peak[loc] == 0:
                        output.append(0)
                        output_peak.append(0)
                        output_ppm.append(0)
                    else:
                        output.append(data[loc])
                        output_peak.append(peak[loc])
                        output_ppm.append((- index + data[loc]) / index * 1000000)

                else:
                    flag = -2

            elif bias_type == CFG_TYPE_ACCURACY_HALF_WIN_PEAK['PPM']:
                if (abs(data[first] - index) / index * 1000000) < bias:
                    loc = first
                    if peak[loc] == 0:
                        output.append(0)
                        output_peak.append(0)
                        output_ppm.append(0)
                    else:
                        #output.append(data[loc])
                        output.append(index)
                        output_peak.append(peak[loc])
                        output_ppm.append((- index + data[loc]) / index * 1000000)

                elif (abs(data[last] - index) / index * 1000000) < bias:
                    loc = last
                    if peak[loc] == 0:
                        output.append(0)
                        output_peak.append(0)
                        output_ppm.append(0)
                    else:
                        #output.append(data[loc])
                        output.append(index)
                        output_peak.append(peak[loc])
                        output_ppm.append((- index + data[loc]) / index * 1000000)
                else:
                    flag = -2
        if flag == -2:
            output.append(0)
            output_peak.append(0)
            output_ppm.append(0)
    return output, output_peak, output_ppm


def op_PlotMozText(clc_tag, plot_moz, moz_start):

    moz_text = '' + moz_start
    moz_underline_text = '' + moz_start
    moz_type, _, _ = op_DIVIDE_ION_TYPE_WITHLOSS(clc_tag[0])
    if moz_type == 'b':  # b离子
        for pep_index in range(len(plot_moz)):
            if plot_moz[pep_index] != 0:
                if pep_index < 9:
                    moz_text = moz_text + moz_type + "%s" % (pep_index + 1) + '  '
                else:
                    moz_text = moz_text + moz_type + '%s' % (pep_index + 1) + ' '
                moz_underline_text = moz_underline_text + '  __'
            else:
                moz_text = moz_text + '    '
                moz_underline_text = moz_underline_text + '    '
    elif moz_type == 'y':  # y离子
        moz_text = moz_text + '    '
        moz_underline_text = moz_underline_text + '    '
        for pep_index in range(len(plot_moz)):
            if plot_moz[len(plot_moz) - pep_index - 1] != 0:
                if (len(plot_moz) - pep_index - 1) < 9:
                    moz_text = moz_text + moz_type + "%s" % (len(plot_moz) - pep_index) + '  '
                else:
                    moz_text = moz_text + moz_type + '%s' % (len(plot_moz) - pep_index) + ' '
                moz_underline_text = moz_underline_text + '__  '
            else:
                moz_text = moz_text + '    '
                moz_underline_text = moz_underline_text + '    '

    return moz_text, moz_underline_text


def op_GetColor(moz_type):

    if moz_type == 'b':
        return 'blue'
    elif moz_type == 'y':
        return 'orange'
    elif moz_type == 'a':
        return 'green'
    elif moz_type == 'x':
        return 'cyan'
    elif moz_type == 'u':
        return 'red'
    elif moz_type == 'v':
        return 'brown'
    elif moz_type == 'p':
        return 'violet'
    elif moz_type == 'M':
        return 'deeppink'
    elif moz_type == 'yb':
        return 'indigo'
    elif moz_type == 'by':
        return 'purple'
    else:
        return 'yellow'


def op_GetFont(moz_type, size):

    color = op_GetColor(moz_type)
    font2 = {'family': 'SimHei',
             'color': color,
             'weight': 'normal',
             'size': size,
             }
    return font2

def op_PlotMozTopText(clc_tag, plot_moz, ax, moz_start, pep_type):

    moz_type, _, _ = op_DIVIDE_ION_TYPE_WITHLOSS(clc_tag[0])
    moz_text, moz_underline_text = op_PlotMozText(clc_tag, plot_moz, moz_start)
    if moz_type == 'b':
        if pep_type == 'alpha':
            loc1 = 0.75
            loc2 = 0.78
            ax.text(0.100, loc1, moz_text, fontdict=op_GetFont(moz_type, 15))
            ax.text(0.090, loc2, moz_underline_text, fontdict=op_GetFont(moz_type, 15))
        elif pep_type == 'beta':
            loc1 = 0.64
            loc2 = 0.67
            ax.text(0.100, loc1, moz_text, fontdict=op_GetFont(moz_type, 15))
            ax.text(0.090, loc2, moz_underline_text, fontdict=op_GetFont(moz_type, 15))
        elif pep_type == 'single':
            loc1 = 0
            loc2 = 14.5
            ax.text(100, loc1, moz_text, fontdict=op_GetFont(moz_type, 10))
            ax.text(80, loc2, moz_underline_text, fontdict=op_GetFont(moz_type, 10))
        else:
            loc1 = 0
            loc2 = 0

    elif moz_type == 'y':
        if pep_type == 'alpha':
            loc1 = 0.81
            loc2 = 0.81
            ax.text(0.130, loc1, moz_text, fontdict=op_GetFont(moz_type, 15))
            ax.text(0.120, loc2, moz_underline_text, fontdict=op_GetFont(moz_type, 15))
        elif pep_type == 'beta':
            loc1 = 0.70
            loc2 = 0.70
            ax.text(0.130, loc1, moz_text, fontdict=op_GetFont(moz_type, 15))
            ax.text(0.120, loc2, moz_underline_text, fontdict=op_GetFont(moz_type, 15))
        elif pep_type == 'single':
            loc1 = 25.5
            loc2 = 25.5
            ax.text(100, loc1, moz_text, fontdict=op_GetFont(moz_type, 10))
            ax.text(80, loc2, moz_underline_text, fontdict=op_GetFont(moz_type, 10))
        else:
            loc1 = 0
            loc2 = 0
    else:
        pass
    # elif moz_type == 'M':x


def op_Data_fill_plot(clc_moz, clc_tag, exp_moz, exp_intensity, type_bias, bias, ax1, ax2, ax3, ax4, pep_moz_start,
                      type_pep, record_used_moz):

    clc_moz_type = []
    left_loc = 0

    if len(clc_tag) > 0:
        flag1, _, flag2 = op_DIVIDE_ION_TYPE_WITHLOSS(clc_tag[0])

        for clc_tag_index in range(len(clc_tag)):

            next_flag1, _, next_flag2 = op_DIVIDE_ION_TYPE_WITHLOSS(clc_tag[clc_tag_index])
            if (next_flag1 != flag1) | (flag2 != next_flag2):
                right_loc = clc_tag_index
                clc_moz_type.append([left_loc, right_loc])
                flag1, flag2 = next_flag1, next_flag2
                left_loc = clc_tag_index
        clc_moz_type.append([left_loc, len(clc_tag)])
        moz_type_num = len(clc_moz_type)

        plot_moz_list, plot_peak_list, ppm_list, clc_tag_list = [], [], [], []
        for math_index in range(moz_type_num):
            clc_tag_one = clc_tag[clc_moz_type[math_index][0]:clc_moz_type[math_index][1]]
            clc_moz_one = clc_moz[clc_moz_type[math_index][0]:clc_moz_type[math_index][1]]
            plot_moz, plot_peak, ppm = op_FindSame(clc_moz_one, exp_moz, exp_intensity, type_bias,
                                                   bias)
            plot_moz_list.append(plot_moz)
            plot_peak_list.append(plot_peak)
            ppm_list.append(ppm)
            clc_tag_list.append(clc_tag_one)

        max_match_peak = max(np.max(plot_peak_list), 1)
        exp_intensity_match = np.array(exp_intensity) / max_match_peak * 100.
        exp_intensity_match[exp_intensity_match > 1.2 * 100] = 1.2 * 100.
        info_base_peak = '{:.3g}'.format(max_match_peak)

        ax1.text(0, 5, 'BasePeak:', color='black', fontsize=10)
        ax1.text(8, 5, info_base_peak, color='red', fontsize=10)

        ax3.bar(exp_moz, exp_intensity_match, width=2, facecolor='#000000')

        for plot_moz, plot_peak, ppm, clc_tag_one in zip(plot_moz_list, plot_peak_list, ppm_list, clc_tag_list):
            plot_peak_match = list(np.array(plot_peak) / max_match_peak * 100)
            if type_pep == 'precursor':
                pass
            else:
                op_PlotMozTopText(clc_tag_one, plot_moz, ax2, pep_moz_start, type_pep)  # 标顶部离子

            # 谱图离子标注
            i = 1
            moz_type, _, valence = op_DIVIDE_ION_TYPE_WITHLOSS(clc_tag_one[0])

            ax3.bar(plot_moz, plot_peak_match, width=2, facecolor=op_GetColor(moz_type))
            for xx, yy in zip(plot_moz, plot_peak_match):
                if plot_peak_match[i - 1] != 0:
                    if type_pep == 'alpha':
                        p_str_start = 'α '
                    elif type_pep == 'beta':
                        p_str_start = 'β '
                    elif type_pep == 'single':
                        p_str_start = ''
                    else:
                        p_str_start = ''

                    #p_str = p_str_start + op_GetMozType(clc_tag_one[0]) + str(i) + op_GetMozValenceText(valence) + loss_text
                    if '.' in clc_tag_one[i - 1]:
                        if clc_tag_one[i - 1].split('.')[0][0:2] == 'by' or clc_tag_one[i - 1].split('.')[0][2:] == '0':
                            p_str = p_str_start + 'β ' + clc_tag_one[i - 1].split('.')[1]
                        else:
                            p_str = p_str_start + clc_tag_one[i - 1].split('.')[1]
                    else:
                        p_str = p_str_start + clc_tag_one[i - 1]
                    if yy > 80:
                        if xx in record_used_moz:
                            xx1_add = 10
                            yy1_add = 20
                        else:
                            xx1_add = 0
                            yy1_add = 5
                        ax3.text(xx + 10 + xx1_add, 80 + yy1_add, p_str, color=op_GetColor(moz_type), fontsize=6, ha='center',
                                 rotation='vertical')
                    else:
                        if xx in record_used_moz:
                            xx1_add = 4
                            yy2_add = 20
                        else:
                            xx1_add = 4
                            yy2_add = 10
                        ax3.text(xx + xx1_add, yy + yy2_add, p_str, color=op_GetColor(moz_type), fontsize=6, ha='center',
                                 rotation='vertical')
                        record_used_moz.append(xx)
                i = i + 1

            # 偏差图标注
            i = 1
            for xx, yy in zip(plot_moz, ppm):
                if plot_moz[i - 1] != 0:
                    if plot_peak_match[i - 1] != 0:
                        ax4.scatter(xx, yy, marker=',', color=op_GetColor(moz_type), s=1)
                i = i + 1
        # ax3.set_ylim([0, max_match_peak * 1.2])
        # ytick_ax3 = [max_peak * (i / 5) for i in range(6)]
        # ax3.set_yticks(ytick_ax3, ['0', '20', '40', '60', '80', '100'])
    else:
        pass

def opGetStartAndEndForProfile(input_profile, input_seed, input_cutoff, input_n_hole):  # 就这个名字格式特殊

    nHoleLeft = 0
    nHoleRight = 0

    i_middle = input_seed

    if i_middle > 0:
        i_left = i_middle - 1
    else:
        i_left = i_middle

    i_right = i_middle

    result = [i_left, i_right]  # start and end

    int_left = input_profile[i_left]
    int_right = input_profile[i_right]

    int_max = int_left
    int_thr = int_max * input_cutoff

    walkLeft = True
    walkRight = True

    while True:

        if walkLeft or walkRight:
            pass
        else:
            break

        if i_left > 0:

            if walkLeft:
                i_left = i_left - 1

        else:

            walkLeft = False

        if i_right < len(input_profile) - 1:

            if walkRight:
                i_right = i_right + 1

        else:

            walkRight = False

        int_left = input_profile[i_left]
        int_right = input_profile[i_right]

        # max
        if int_max < int_left:
            int_max = int_left

        if int_max < int_right:
            int_max = int_right

        int_thr = int_max * input_cutoff

        # hole
        if int_left < int_thr and walkLeft:
            nHoleLeft = nHoleLeft + 1

        if int_right < int_thr and walkRight:
            nHoleRight = nHoleRight + 1

        if nHoleLeft == input_n_hole:

            walkLeft = False

        if nHoleRight == input_n_hole:

            walkRight = False

    result[0] = i_left
    result[1] = i_right

    return result
