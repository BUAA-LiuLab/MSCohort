
import datetime
from MSData import CDataPack
from MSFlow import CFlow0, CFlow1, CFlow2, CFlow3
from MSFunction1 import CFunctionConfi_11
from MSSystem import CFG_TYPE_COHORT, TIME_EXPIRATION
from MSLogging import logToUser, INFO_TO_USER_Staff, logGetError


class CStaff:

    def __init__(self, inputArgv):

        self.dp = CDataPack()
        self.argv = inputArgv

    def start(self):


        logToUser(INFO_TO_USER_Staff[0])
        dateNow = datetime.datetime.now()
        logToUser(str(dateNow))


        self.__captainCheckTime()

        self.__captainRunFlow()


        logToUser(INFO_TO_USER_Staff[4])
        dateNow = datetime.datetime.now()
        logToUser(str(dateNow))

    def __captainCheckTime(self):

        dateNow = datetime.datetime.now()
        dateDead = datetime.datetime(TIME_EXPIRATION['Year'], TIME_EXPIRATION['Month'], TIME_EXPIRATION['Day'], 23, 59)

        n_day = (dateDead - dateNow).days

        if n_day < 0:

            logGetError(INFO_TO_USER_Staff[1])

        elif n_day < 7:

            logToUser(INFO_TO_USER_Staff[2])

    def __captainRunFlow(self):

        n = len(self.argv)

        if n == 1:

            flow0 = CFlow0()
            flow0.run()

        elif n == 2:

            FunctionConfig = CFunctionConfi_11()
            FunctionConfig.file2config(self.argv[1], self.dp.myCFG)
            print(self.dp.myCFG.C1_TYPE_COHORT)
            if self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DDACohort']:

                flow1 = CFlow1(self.dp)
                flow1.run()

            elif self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DIACohort']:

                flow2 = CFlow2(self.dp)
                flow2.run()

            # elif self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['iRTOnlyIndicator']:
            #
            #     flow3 = CFlow3(self.dp)
            #     flow3.run()



