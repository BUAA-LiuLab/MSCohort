"""
存放全局使用的数据结构
"""


class CINI:

    MASS_ELECTRON = 0.0005485799
    MASS_PROTON_MONO = 1.00727645224  # 1.00782503214-0.0005485799
    MASS_PROTON_ARVG = 1.0025

    DICT0_ELEMENT_MASS = {}
    DICT0_ELEMENT_ABDC = {}

    DICT1_AA_COM = {}
    DICT2_MOD_COM = {}

    LIST_IRT_PEPTIDE = []  # 存放要分析的（iRT）肽段
    LIST_IRT_CHARGE = (2, )  # 存放要分析肽段的电荷


class CPlotINI:

    # RT range
    MIN_RT_DEVIATION = -2
    MAX_RT_DEVIATION = 2

    # CV range
    MIN_CV_SHOW = 0
    MAX_CV_SHOW = 1

    # Violin range
    MIN_VIOLIN_SHOW = -5
    MAX_VIOLIN_SHOW = 5

    # t-SNE perplexity value
    T_SNE_PERPLEXITY = 3.0

    # PCA interpolation threshold
    THRESHOLD_PCA_INTERPOLATION = 0.5

    # outlier filter threshold
    TYPE_FILTER_OUTLIER = 0
    THRESHOLD_OUTLIER_FILTER = -1


class CContaminant:

    DIC_CONTAM = {}
    DIC_CON_ERYTHROCYTES = {}
    DIC_CON_CELLULAR_DEBRIS = {}
    DIC_CON_SERUM_HIGH_ABUNDANCE = {}
    CON_RATIO = []


class CExpScore:

    THRESHOLD_CONTAMINANT = 2.
    THRESHOLD_DELTART = 2.
    THRESHOLD_RT_DEV = 2.

    THRESHOLD_MISSING_PRE = 2.
    THRESHOLD_MEDIAN_INT_PRE = 2.
    THRESHOLD_IQR_PRE = 2.
    THRESHOLD_DEV_INT_PRE = 2.
    THRESHOLD_PEARSON_INT_PRE = 2.
    THRESHOLD_NORM_PRE = 2.

    THRESHOLD_MISSING_PEP = 2.
    THRESHOLD_MEDIAN_INT_PEP = 2.
    THRESHOLD_IQR_PEP = 2.
    THRESHOLD_DEV_INT_PEP = 2.
    THRESHOLD_PEARSON_INT_PEP = 2.
    THRESHOLD_NORM_PEP = 2.

    THRESHOLD_MISSING_PRP = 2.
    THRESHOLD_MEDIAN_INT_PRP = 2.
    THRESHOLD_IQR_PRO = 2.
    THRESHOLD_DEV_INT_PRO = 2.
    THRESHOLD_PEARSON_INT_PRO = 2.
    THRESHOLD_NORM_PRO = 2.

    WEIGHT_CONTAMINANT = 1.
    WEIGHT_DELTART = 1.
    WEIGHT_RT_DEV = 1.

    WEIGHT_MISSING_PRE = 1.
    WEIGHT_MEDIAN_INT_PRE = 1.
    WEIGHT_IQR_PRE = 1.
    WEIGHT_DEV_INT_PRE = 1.
    WEIGHT_PEARSON_INT_PRE = 1.
    WEIGHT_NORM_PRE = 1.

    WEIGHT_MISSING_PEP = 1.
    WEIGHT_MEDIAN_INT_PEP = 1.
    WEIGHT_IQR_PEP = 1.
    WEIGHT_DEV_INT_PEP = 1.
    WEIGHT_PEARSON_INT_PEP = 1.
    WEIGHT_NORM_PEP = 1.

    WEIGHT_MISSING_PRO = 1.
    WEIGHT_MEDIAN_INT_PRO = 1.
    WEIGHT_IQR_PRO = 1.
    WEIGHT_DEV_INT_PRO = 1.
    WEIGHT_PEARSON_INT_PRO = 1.
    WEIGHT_NORM_PRO = 1.

class Config:
    A0_TYPE_FLOW = 0  # Flow0:Inter-experiment; Flow1:intra-experiment
    A1_PATH_MS1 = ''  # raw文件路径
    A2_PATH_MS2 = ''
    A3_TYPE_MS = 1  # 0代表ms2,1代表raw
    A4_TYPE_DATA = ''  # 0代表Orbitrap，1代表timsTOF，2代表zenoTOF

    B1_PATH_ANALYSIS_RESULT = ''
    B2_PATH_EXPERIMENT_SETTING_RESULT = ''
    B3_TYPE_IDENTIFICATION_RESULT = 0
    B4_THRESHOLD_FDR = 0.01
    B5_INSTRUMENT_CORRECTION_SETTING = ''

    C1_TYPE_COHORT = 1  # 0：DDA大队列数据分析， 1：DIA大队列数据分析
    C5_THRESHOLD_PEAK_WIDTH_TAILING = 1 # 拖尾时间设置
    C6_THRESHOLD_INVALID_ACQUIRING_SCAN = 100   # 平均每分钟鉴定数目大于100，开始为有效采集时间
    C7_FLAG_ANALYZE_FEATURE = 0
    C11_DDA_PRECURSOR_RT_HALF_WIN_IN_MIN = 2  # 正负两分钟 RT窗口
    C12_DDA_PRECURSOR_PPM_HALF_WIN_ACCURACY_REAK = 20  # 母离子色谱曲线匹配质量精度，默认20ppm
    C13_DDA_FRAGMENT_PPM_HALF_WIN_ACCURACY_PEAK = 20  # 碎片离子色谱曲线匹配质量精度，默认20ppm
    C14_DDA_FLAG_NORMALIZATION = 0  # 定量归一化类型，'DirectLFQ': 0,'MaxLFQ': 1, 'Quantile': 2
    C15_DDA_FRAGMENT_INT_NUM = 300
    C16_FLAG_MISSING_VALUE_THRESHOLD = 1
    C17_TYPE_MISSING_VALUE_IMPUTATION = 0
    C18_FLAG_SHOW_ORDER = 0
    C19_FLAG_OUTLIERS = 0
    # C20_TYPE_FILTER_OUTLIERS = 0  # 0:svm, 1:IsolationForest
    C2_FLAG_PDF_REPORT = 1

    I0_INI_PATH_ELEMENT = 'ini/element.ini'
    I1_INI_PATH_AA = 'ini/aa.ini'
    I2_INI_PATH_MOD = 'ini/modification_ForSpectronaut.ini'
    I3_INI_PATH_IRT = 'ini/iRT.ini'
    I4_INI_PLOT = 'ini/plot.ini'
    I5_INI_CONTAM = 'ini/contam.ini'
    I6_INI_EXP_THRESHOLD = 'ini/inter_exp_threshold.ini'
    I7_INI_EXP_WEIGHT = 'ini/inter_exp_weight.ini'
    # IO_INI_PATH_EXPERIMENT = 'experiment_setting.ini'
    DDA_CUTOFF_INTENSITY_IN_CMTG = 0.1
    DDA_NUMBER_HOLE_IN_CMTG = 2

    E1_PATH_EXPORT = 'D:\\test\\'
    E2_FLAG_CREATE_NEW_FOLDER = 1
    E3_FLAG_ANALYZE_FEATURE = 0
    E4_PATH_MSREFINE_REPORT = []


class CFileMS2:

    INDEX_SCAN = []
    INDEX_RT = []

    LIST_RET_TIME = []
    LIST_ION_INJECTION_TIME = []
    LIST_ACTIVATION_CENTER = []
    LIST_PRECURSOR_SCAN = []

    MATRIX_PEAK_MOZ = []
    MATRIX_PEAK_INT = []
    MATRIX_CHARGE = []
    MATRIX_MZ = []


class CFileMS1:

    INDEX_SCAN = []
    INDEX_RT = []


    LIST_ION_INJECTION_TIME = []

    MATRIX_PEAK_MOZ = []
    MATRIX_PEAK_INT = []
    MATRIX_PEAK_MARK = []


class CSeed:

    MID_SCAN = 0
    MID_RT = 0

    DICT_COMPOSITION = {}

    DIS_ISO_MOZ_CLC = []
    DIS_ISO_INT_CLC = []

    INDEX_MONO = 0

    MOZ_FRAGMENT = []
    TYPE_FRAGMENT = []


class CEvidence:

    MATRIX_PROFILE = []
    MATRIX_MASS_ACCURACY = []

    LIST_RET_TIME = []
    LIST_SCAN = []

    LIST_I_START = []
    LIST_I_END = []

    I_START = 0
    I_END = -1

    DIS_ISO_MOZ_EXP = []
    DIS_ISO_INT_EXP = []
    PROFILE_ALL = []

    MS2_PEAK_MOZ = []
    MS2_PEAK_INT = []


class CFileID:

    N_PSM = 0
    N_PEPTIDE = 0
    N_PROTEIN = 0
    N_PROTEINGROUP = 0

    LIST_SAMPLE_ID = []
    LIST_EXPERIMENT_ID = []

    PSM_LIST_ID = []
    PEP_LIST_ID = []
    PRO_LIST_ID = []
    PROGROUP_LIST_ID = []


class CFileIDForProtein:

    N_PROTEIN = 0

    LIST_SAMPLE_ID = []
    LIST_EXPERIMENT_ID = []
    LIST_PROTEIN_ID = []
    LIST_NORM_PARAM = []

    DICT_PROTEIN2PEPTIDE = {}

    MATRIX_INTENSITY = []
    MATRIX_INTENSITY_LOG2 = []
    MATRIX_ORIGIN_INTENSITY = []
    MATRIX_ORIGIN_INTENSITY_LOG2 = []
    MATRIX_IBAQ_LOG10 = []

    PRO1_NAME = []
    PRO2_INTENSITY = []
    PRO3_SCORE0 = []
    PRO4_iBAQ = []


class CFileIDForProteinGROUP:

    N_PROTEIN = 0

    LIST_SAMPLE_ID = []
    LIST_EXPERIMENT_ID = []
    LIST_PROTEIN_ID = []
    LIST_NORM_PARAM = []

    MATRIX_INTENSITY = []
    MATRIX_INTENSITY_LOG2 = []
    MATRIX_IBAQ_LOG10 = []

    PRO1_NAME = []
    PRO2_INTENSITY = []
    PRO3_SCORE0 = []
    PRO4_iBAQ = []


class CFileIDForPeptide:

    N_PEPTIDE = 0

    LIST_SAMPLE_ID = []
    LIST_EXPERIMENT_ID = []
    LIST_PEPTIDE_ID = []
    LIST_NORM_PARAM = []

    DICT_PEPTIDE2POSITION = {}

    MATRIX_INTENSITY = []
    MATRIX_INTENSITY_LOG2 = []
    MATRIX_ORIGIN_INTENSITY = []
    MATRIX_ORIGIN_INTENSITY_LOG2 = []

    PEP1_SEQ = []
    PEPLIST1_INTENSITY = []
    PEPLIST2_INTENSITY_FORMERGE = []


class CFeatureEntry:

    N_FEATURE = 0

    LIST_PRECURSOR_ID = []

    FEA_X1_SEQ = []
    FEA_X2_MOD = []
    FEA_X3_CHARGE = []
    FEA_X4_LEN = []

    FEA_Y_RATIO = []
    FEA_Y_INTENSITY = []


class CFeaturePepEntry:

    N_FEATURE = 0

    LIST_PEPTIDE_ID = []

    FEA_X1_SEQ = []
    FEA_X2_LEN = []

    FEA_F1_QSAR = []
    FEA_F2_DEEPLC = []
    FEA_F3_PROT = []

    FEA_Y_RATIO = []
    FEA_Y_INTENSITY = []


class CFeature:

    N_GROUP_PAIR = 0

    LIST_GROUP_PAIR_NAME = []
    LIST_GROUP_PAIR_FEATURE = []


class CFileIDForPrecursor:

    N_PRECURSOR = 0

    LIST_SAMPLE_ID = []
    LIST_EXPERIMENT_ID = []
    LIST_PRECURSOR_ID = []
    LIST_PRECURSOR_ID_MV = []
    LIST_NORM_PARAM = []

    MATRIX_RT = []
    MATRIX_INTENSITY = []
    MATRIX_INTENSITY_LOG2 = []
    MATRIX_ORIGIN_INTENSITY = []
    MATRIX_ORIGIN_INTENSITY_LOG2 = []

    PRE1_SEQ = []
    PRE2_MOD = []
    PRE3_CHARGE = []

    PRELIST1_RT = []
    PRELIST2_INTENSITY = []
    PRELIST3_RTSTART = []
    PRELIST4_RTEND = []
    PRELIST5_PEAKWIDTH = []
    PRELIST6_DELTART = []
    PRELIST7_FWHM = []
    PRELIST8_MS1_ACCURACY = []
    PRELIST9_MS2_ACCURACY = []
    PRELIST10_MS1_DPPP = []
    PRELIST11_MS2_DPPP = []

    PRELIST11_SCORE0 = []
    PRELIST12_SCORE1 = []
    PRELIST13_CALIBRATE_MS1_ACCURACY = []
    PRELIST14_CALIBRATE_MS2_ACCURACY = []


class CFileIDForIRT:

    N_PRECURSOR = 0

    LIST_SAMPLE_ID = []
    LIST_EXPERIMENT_ID = []
    LIST_PRECURSOR_ID = []

    PRE1_SEQ = []
    PRE2_MOD = []
    PRE3_CHARGE = []
    PRE4_MOZ_CLC = []
    PRE5_PROTEIN = []

    PRELIST1_SCAN_ID = []
    PRELIST2_RT = []
    PRELIST3_RT_START = []
    PRELIST4_RT_END = []
    PRELIST5_MOZ_EXP = []
    PRELIST6_SCORE0 = []
    PRELIST7_SCORE1 = []
    PRELIST8_INTENSITY = []
    PRELIST9_NORM_INTENSITY = []

    # 统计iRT质控指标要用的
    PRELIST10_MS1_INTENSITY = []
    PRELIST11_MS1_MASS_ACCURACY = []
    PRELIST_12_MS2_INTENSITY = []
    PRELIST_13_MS2_MASS_ACCURACY = []
    PRELIST_14_DATA_POINT_PRE_PEAK = []
    PRELIST15_FWHM = []

    FRAGLIST1_TYPE = []
    FRAGLIST2_NUM = []
    FRAGLIST3_CHARGE = []
    FRAGLIST4_LOSS = []
    FRAGLIST5_MOZ = []


class CDataPack:

    myCFG = Config()
    myINI = CINI()
    myPLOT = CPlotINI()
    myCONTAM = CContaminant()
    myEXPSCORE = CExpScore

    LIST_PATH_MS1 = []
    LIST_PATH_MS2 = []

    LIST_PATH_ID = []
    LIST_EXPERIMENT_GROUP = []
    LIST_EXPERIMENT_GROUP_TRAIN = []
    LIST_EXPERIMENT_GROUP_TEST = []
    LIST_EXPERIMENT = []
    LIST_EXPERIMENT_INT_THRESHOLD = []
    LIST_INSCORR_GROUP_PAIR = []

    myID = CFileID()
    myProteinGroupID = CFileIDForProteinGROUP()
    myProteinID = CFileIDForProtein()
    myPeptideID = CFileIDForPeptide()
    myPrecursorID = CFileIDForPrecursor()
    myIDForIRT = CFileIDForIRT()
    myFeature = CFeature()
