
import numpy as np
import os
from MSFunctionCor2 import *
from MSFunctionNor6 import CFunctionNormU_1, CFunctionNormU_2, CFunctionNormU_3, CFunctionProte_4
from MSFunction1 import CFunctionINI_5, CFunctionParse_6, CFunctionParse_10, CFunctionParse_10, \
    CFunctionParse_12, CFunctionParse_3, CFunctionParse_8, CFunctionParse_1, CFunctionParse_7, CFunctionID2Fe_2

from MSFunctionRep7 import *
from MSFunctionIRT5 import CFunctionExtra_1, CFunctionOutIR_3
from MSOperator import op_FILL_LIST_PATH_ID, op_FILL_LIST_PATH_MS
from MSData import CDataPack
from MSSystem import CFG_TYPE_MS, CFG_TYPE_ANALYSIS_RESULT, IO_FILENAME_EXPORT, IO_PREFIX_EXPORT, CFG_TYPE_NORMALIZATION, IO_FILENAME_TMP_EXPORT
from MSLogging import INFO_TO_USER_TaskReadMS1, INFO_TO_USER_TaskReadMS2, INFO_TO_USER_TaskReadID, \
    INFO_TO_USER_TaskStatMV, logGetError,logToUser,INFO_TO_USER_TaskParseMSRefine



class CTaskReadINI:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self):

        functionINI = CFunctionINI_5(self.dp)

        functionINI.file2ini()


class CTaskCheck:

    

    def __init__(self, inputDP):

        self.dp = inputDP

    def work(self):

        
        if not os.access(self.dp.myCFG.E1_PATH_EXPORT, os.F_OK):

            os.makedirs(self.dp.myCFG.E1_PATH_EXPORT)

        for nameFile in IO_PREFIX_EXPORT:

            path = self.dp.myCFG.E1_PATH_EXPORT + nameFile

            if os.access(path, os.F_OK):
                pass
            else:
                os.makedirs(path)

        for nameFile in IO_FILENAME_EXPORT:

            path = self.dp.myCFG.E1_PATH_EXPORT + nameFile

            if os.access(self.dp.myCFG.E1_PATH_EXPORT, os.F_OK):

                try:

                    fid1 = open(path, 'w', -1)
                    fid1.close()

                except IOError:

                    logGetError(path + ' is opened! Please close it and run the program again!')

            else:

                os.makedirs(self.dp.myCFG.E1_PATH_EXPORT)


class CTaskReadMS:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self):

        self.dp.myCFG.A1_PATH_MS1 = self.dp.myCFG.A1_PATH_MS1.strip()
        self.dp.myCFG.A2_PATH_MS2 = self.dp.myCFG.A2_PATH_MS2.strip()

        if self.dp.myCFG.A1_PATH_MS1 == '' and self.dp.myCFG.A2_PATH_MS2 == '':

            pass

        else:
            LIST_PATH_RAW = []
            op_FILL_LIST_PATH_MS(self.dp.myCFG.A1_PATH_MS1, LIST_PATH_RAW, [".raw"])
            
            functionRaw2MS = CFunctionParse_10(self.dp)
            functionRaw2MS.raw2MS(LIST_PATH_RAW)
            self.dp.LIST_PATH_MS1 = [i_raw.replace('.raw', '.ms1') for i_raw in LIST_PATH_RAW]
            self.dp.LIST_PATH_MS2 = [i_raw.replace('.raw', '.ms2') for i_raw in LIST_PATH_RAW]

    def workEstimate(self):

        self.dp.myCFG.A1_PATH_MS1 = self.dp.myCFG.A1_PATH_MS1.strip()
        self.dp.myCFG.A2_PATH_MS2 = self.dp.myCFG.A2_PATH_MS2.strip()

        if self.dp.myCFG.A1_PATH_MS1 == '' and self.dp.myCFG.A2_PATH_MS2 == '':

            pass

        elif self.dp.myCFG.A3_TYPE_MS == CFG_TYPE_MS['MS']:

            op_FILL_LIST_PATH_MS(self.dp.myCFG.A1_PATH_MS1, self.dp.LIST_PATH_MS1, [".ms1", ".MS1"])
            if self.dp.myCFG.A2_PATH_MS2 != '':
                op_FILL_LIST_PATH_MS(self.dp.myCFG.A2_PATH_MS2, self.dp.LIST_PATH_MS2, [".ms2", ".MS2"])

        elif self.dp.myCFG.A3_TYPE_MS == CFG_TYPE_MS['RAW']:
            
            LIST_PATH_RAW = []
            op_FILL_LIST_PATH_MS(self.dp.myCFG.A1_PATH_MS1, LIST_PATH_RAW, [".raw"])
            
            functionRaw2MS = CFunctionParse_10(self.dp)
            functionRaw2MS.raw2MS(LIST_PATH_RAW)
            self.dp.LIST_PATH_MS1 = [i_raw.replace('.raw', '.ms1') for i_raw in LIST_PATH_RAW]
            self.dp.LIST_PATH_MS2 = [i_raw.replace('.raw', '.ms2') for i_raw in LIST_PATH_RAW]
        
        
        # for path in self.dp.LIST_PATH_MS1:
        #
        #     print(INFO_TO_USER_TaskReadMS1[0] + path)
        #
        #     functionMS1 = CFunctionParse_2()
        #     functionMS1.ms1TOpkl(path)


class CTaskReadID:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self):

        op_FILL_LIST_PATH_ID(self.dp.myCFG.B1_PATH_ANALYSIS_RESULT, self.dp.LIST_PATH_ID)

        if self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_ANALYSIS_RESULT['pQuant']:

            for path in self.dp.LIST_PATH_ID:
                print(INFO_TO_USER_TaskReadID[0] + path)
                functionRead = CFunctionParse_3(self.dp)
                functionRead.read(path)
                print(INFO_TO_USER_TaskReadID[1] + str(self.dp.myProteinID.N_PROTEIN))
                print(INFO_TO_USER_TaskReadID[2] + str(self.dp.myPeptideID.N_PEPTIDE))

        # elif self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_ANALYSIS_RESULT['MaxQuant']:
        #
        #     for path in self.dp.LIST_PATH_ID:
        #         print(INFO_TO_USER_TaskReadID[0] + path)
        #         functionRead = CFunctionParse_12(self.dp)
        #         functionRead.read(path)
        #         print(INFO_TO_USER_TaskReadID[1] + str(self.dp.myProteinID.N_PROTEIN))
        #         print(INFO_TO_USER_TaskReadID[2] + str(self.dp.myPeptideID.N_PEPTIDE))
        #         print(INFO_TO_USER_TaskReadID[3] + str(self.dp.myPrecursorID.N_PRECURSOR))
        #
        # elif self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_ANALYSIS_RESULT['MaxQuant_with_Mod']:
        #
        #     for path in self.dp.LIST_PATH_ID:
        #         print(INFO_TO_USER_TaskReadID[0] + path)
        #         functionRead = CFunctionParse_7(self.dp)
        #         functionRead.read(path)
        #         print(INFO_TO_USER_TaskReadID[1] + str(self.dp.myProteinID.N_PROTEIN))
        #         print(INFO_TO_USER_TaskReadID[2] + str(self.dp.myPeptideID.N_PEPTIDE))
        #         print(INFO_TO_USER_TaskReadID[3] + str(self.dp.myPrecursorID.N_PRECURSOR))

        elif self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_ANALYSIS_RESULT['Spectronaut']:
            list_precursor_id = []
            for i, path in enumerate(self.dp.LIST_PATH_ID):
                print(INFO_TO_USER_TaskReadID[0] + path)
                functionRead = CFunctionParse_8(self.dp)
                functionRead.read(path, list_precursor_id)
                print(INFO_TO_USER_TaskReadID[1] + str(self.dp.myProteinID.N_PROTEIN))
                print(INFO_TO_USER_TaskReadID[2] + str(self.dp.myPeptideID.N_PEPTIDE))
                print(INFO_TO_USER_TaskReadID[3] + str(self.dp.myPrecursorID.N_PRECURSOR))
                if i == len(self.dp.LIST_PATH_ID) - 1:
                    functionRead.merge(list_precursor_id)

        elif self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_ANALYSIS_RESULT['DIA-NN']:

            for i, path in enumerate(self.dp.LIST_PATH_ID):

                print(INFO_TO_USER_TaskReadID[0] + path)

                functionRead = CFunctionParse_1(self.dp)

                functionRead.read(path)

                print(INFO_TO_USER_TaskReadID[1] + str(self.dp.myProteinID.N_PROTEIN))
                print(INFO_TO_USER_TaskReadID[2] + str(self.dp.myPeptideID.N_PEPTIDE))
                print(INFO_TO_USER_TaskReadID[3] + str(self.dp.myPrecursorID.N_PRECURSOR))

                if i == len(self.dp.LIST_PATH_ID) - 1:
                    functionRead.merge()

            pass

        # elif self.dp.myCFG.B3_TYPE_IDENTIFICATION_RESULT == CFG_TYPE_ANALYSIS_RESULT['pGlycoQuant']:
        #
        #     for path in self.dp.LIST_PATH_ID:
        #         print(INFO_TO_USER_TaskReadID[0] + path)
        #         functionRead = CFunctionParse_4(self.dp)
        #         functionRead.read(path)
        #         print(INFO_TO_USER_TaskReadID[1] + str(self.dp.myProteinID.N_PROTEIN))
        #         print(INFO_TO_USER_TaskReadID[2] + str(self.dp.myPeptideID.N_PEPTIDE))


class CTaskStatMV:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self):

        print(INFO_TO_USER_TaskStatMV[0])
        functionStatMV = CFunctionStatM_9(self.dp)
        functionStatMV.stat()
        functionStatMV.stat_share()
        print(INFO_TO_USER_TaskStatMV[1] + str(len(self.dp.myProteinID.LIST_PROTEIN_ID)))
        print(INFO_TO_USER_TaskStatMV[2] + str(len(self.dp.myPeptideID.LIST_PEPTIDE_ID)))
        if len(self.dp.myPrecursorID.LIST_PRECURSOR_ID) > 0:
            print(INFO_TO_USER_TaskStatMV[3] + str(len(self.dp.myPrecursorID.LIST_PRECURSOR_ID_MV)))


class CTaskCorrAnalysis:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self, flag_norm):

        
        if flag_norm:  
            
            filename_norm_intensity = IO_FILENAME_EXPORT[8]
            filename_norm_intensity_npy = IO_FILENAME_TMP_EXPORT[3]
            self.__captainWriteIntensity(filename_norm_intensity, filename_norm_intensity_npy, self.dp.myProteinID.MATRIX_INTENSITY)
            filename_origin_norm_intensity = IO_FILENAME_EXPORT[9]
            filename_log2_norm_intensity_npy = IO_FILENAME_TMP_EXPORT[4]
            self.__captainWriteIntensity('', filename_log2_norm_intensity_npy, self.dp.myProteinID.MATRIX_INTENSITY_LOG2)
            filename_origin_log2_norm_intensity_npy = IO_FILENAME_TMP_EXPORT[23]
            self.__captainWriteIntensity('', filename_origin_log2_norm_intensity_npy,self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2)
            self.__captainWriteIntensity(filename_origin_norm_intensity, '', self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY)
            
            filename_norm_cv_npy = IO_FILENAME_TMP_EXPORT[5]
            functionCalcv = CFunctionCalcu_2(self.dp)
            functionCalcv.calculate(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY, flag_norm, filename_norm_cv_npy)
            
            functionCalPCA = CFunctionCalcu_14(self.dp)
            functionCalPCA.calculate(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY, flag_norm=1)
            functionCalTSNE = CFunctionCalcu_5(self.dp)
            functionCalTSNE.calculate(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY, flag_norm=1)
            
            
            

        else:  
            
            file_intensity = IO_FILENAME_EXPORT[2]
            filename_intensity_npy = IO_FILENAME_TMP_EXPORT[0]
            self.__captainWriteIntensity(file_intensity, filename_intensity_npy, self.dp.myProteinID.MATRIX_INTENSITY)
            filename_origin_intensity = IO_FILENAME_EXPORT[3]
            filename_log2_intensity_npy = IO_FILENAME_TMP_EXPORT[1]
            self.__captainWriteIntensity('', filename_log2_intensity_npy, self.dp.myProteinID.MATRIX_INTENSITY_LOG2)
            filename_origin_log2_intensity_npy = IO_FILENAME_TMP_EXPORT[22]
            self.__captainWriteIntensity('', filename_origin_log2_intensity_npy,self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2)
            self.__captainWriteIntensity(filename_origin_intensity, '', self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY)
            
            filename_cv_npy = IO_FILENAME_TMP_EXPORT[2]
            functionCalcv = CFunctionCalcu_2(self.dp)
            functionCalcv.calculate(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY, flag_norm, filename_cv_npy)
            
            functionCalPCA = CFunctionCalcu_14(self.dp)
            functionCalPCA.calculate(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY, flag_norm=0)
            functionCalTSNE = CFunctionCalcu_5(self.dp)
            functionCalTSNE.calculate(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY, flag_norm=0)

        
        if flag_norm:  
            
            filename_norm_intensity = IO_FILENAME_EXPORT[26]
            filename_norm_intensity_npy = IO_FILENAME_TMP_EXPORT[13]
            self.__captainWriteIntensityForPeptide(filename_norm_intensity, filename_norm_intensity_npy, self.dp.myPeptideID.MATRIX_INTENSITY)
            filename_origin_norm_intensity = IO_FILENAME_EXPORT[27]
            filename_log2_norm_intensity_npy = IO_FILENAME_TMP_EXPORT[14]
            self.__captainWriteIntensityForPeptide('', filename_log2_norm_intensity_npy, self.dp.myPeptideID.MATRIX_INTENSITY_LOG2)
            filename_origin_log2_norm_intensity_npy = IO_FILENAME_TMP_EXPORT[25]
            self.__captainWriteIntensityForPeptide('', filename_origin_log2_norm_intensity_npy, self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2)
            self.__captainWriteIntensityForPeptide(filename_origin_norm_intensity, '', self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY)
            
            filename_norm_cv_npy = IO_FILENAME_TMP_EXPORT[15]
            functionCalcv = CFunctionCalcu_2(self.dp)
            functionCalcv.calculateForPeptide(self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY, flag_norm, filename_norm_cv_npy)

        else:  
            
            file_intensity = IO_FILENAME_EXPORT[24]
            filename_intensity_npy = IO_FILENAME_TMP_EXPORT[10]
            self.__captainWriteIntensityForPeptide(file_intensity, filename_intensity_npy, self.dp.myPeptideID.MATRIX_INTENSITY)
            filename_origin_intensity = IO_FILENAME_EXPORT[25]
            filename_log2_intensity_npy = IO_FILENAME_TMP_EXPORT[11]
            self.__captainWriteIntensityForPeptide('', filename_log2_intensity_npy, self.dp.myPeptideID.MATRIX_INTENSITY_LOG2)
            filename_origin_log2_intensity_npy = IO_FILENAME_TMP_EXPORT[24]
            self.__captainWriteIntensityForPeptide('', filename_origin_log2_intensity_npy, self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2)
            self.__captainWriteIntensityForPeptide(filename_origin_intensity, '', self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY)

            
            filename_cv_npy = IO_FILENAME_TMP_EXPORT[12]
            functionCalcv = CFunctionCalcu_2(self.dp)
            functionCalcv.calculateForPeptide(self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY, flag_norm, filename_cv_npy)

        if self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DIACohort'] or self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['InstrumentCorrelation']:
            
            if flag_norm:  
                
                filename_norm_intensity = IO_FILENAME_EXPORT[41]
                filename_norm_intensity_npy = IO_FILENAME_TMP_EXPORT[19]
                self.__captainWriteIntensityForPrecursor(filename_norm_intensity, filename_norm_intensity_npy,
                                                       self.dp.myPrecursorID.MATRIX_INTENSITY)
                filename_origin_norm_intensity = IO_FILENAME_EXPORT[42]
                filename_log2_norm_intensity_npy = IO_FILENAME_TMP_EXPORT[20]
                self.__captainWriteIntensityForPrecursor('', filename_log2_norm_intensity_npy,
                                                       self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2)
                filename_origin_log2_norm_intensity_npy = IO_FILENAME_TMP_EXPORT[27]
                self.__captainWriteIntensityForPrecursor('', filename_origin_log2_norm_intensity_npy,
                                                         self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2)
                self.__captainWriteIntensityForPrecursor(filename_origin_norm_intensity, '', self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY)
                
                filename_norm_cv_npy = IO_FILENAME_TMP_EXPORT[21]
                functionCalcv = CFunctionCalcu_2(self.dp)
                functionCalcv.calculateForPrecursor(self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY, flag_norm, filename_norm_cv_npy)

            else:  
                
                file_intensity = IO_FILENAME_EXPORT[39]
                filename_intensity_npy = IO_FILENAME_TMP_EXPORT[16]
                self.__captainWriteIntensityForPrecursor(file_intensity, filename_intensity_npy,
                                                       self.dp.myPrecursorID.MATRIX_INTENSITY)
                filename_origin_intensity = IO_FILENAME_EXPORT[40]
                filename_log2_intensity_npy = IO_FILENAME_TMP_EXPORT[17]
                self.__captainWriteIntensityForPrecursor('', filename_log2_intensity_npy,
                                                       self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2)
                filename_origin_log2_intensity_npy = IO_FILENAME_TMP_EXPORT[26]
                self.__captainWriteIntensityForPrecursor('', filename_origin_log2_intensity_npy,
                                                         self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2)
                self.__captainWriteIntensityForPrecursor(filename_origin_intensity, '', self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY)
                
                filename_cv_npy = IO_FILENAME_TMP_EXPORT[18]
                functionCalcv = CFunctionCalcu_2(self.dp)
                functionCalcv.calculateForPrecursor(self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY, flag_norm, filename_cv_npy)

    def __captainWriteIntensity(self, filename_export, filename_export_npy, matrix_intensity):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + filename_export
        path_npy = self.dp.myCFG.E1_PATH_EXPORT + '\\' + filename_export_npy

        list_name = self.dp.myProteinID.LIST_PROTEIN_ID if len(self.dp.myProteinID.LIST_PROTEIN_ID) == matrix_intensity.shape[0] else self.dp.myProteinID.PRO1_NAME

        if filename_export_npy:
            np.save(path_npy, matrix_intensity)
        if filename_export:
            with open(path, 'w') as f:

                f.write('Protein\t' + '\t'.join(
                    ['Intensity({:s})'.format(i) for i in self.dp.myProteinID.LIST_EXPERIMENT_ID]) + '\n')

                for i in range(matrix_intensity.shape[0]):
                    f.write(list_name[i] + '\t' +
                            '\t'.join([str(matrix_intensity[i, j]) for j in range(len(matrix_intensity[i]))]) + '\n')

    def __captainWriteIntensityForPeptide(self, filename_export, filename_export_npy, matrix_intensity):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + filename_export
        path_npy = self.dp.myCFG.E1_PATH_EXPORT + '\\' + filename_export_npy

        list_name = self.dp.myPeptideID.LIST_PEPTIDE_ID if len(self.dp.myPeptideID.LIST_PEPTIDE_ID) == matrix_intensity.shape[0] else self.dp.myPeptideID.PEP1_SEQ

        if filename_export_npy:
            np.save(path_npy, matrix_intensity)

        if filename_export:
            with open(path, 'w')as f:

                f.write('Peptide\t' + '\t'.join(['Intensity({:s})'.format(i) for i in self.dp.myPeptideID.LIST_EXPERIMENT_ID]) + '\n')

                for i in range(matrix_intensity.shape[0]):

                    f.write(list_name[i] + '\t' +
                            '\t'.join([str(matrix_intensity[i, j]) for j in range(len(matrix_intensity[i]))]) + '\n')

    def __captainWriteIntensityForPrecursor(self, filename_export, filename_export_npy, matrix_intensity):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + filename_export
        path_npy = self.dp.myCFG.E1_PATH_EXPORT + '\\' + filename_export_npy

        list_name = self.dp.myPrecursorID.LIST_PRECURSOR_ID if len(self.dp.myPrecursorID.LIST_PRECURSOR_ID) == matrix_intensity.shape[0] else self.dp.myPrecursorID.PRE1_SEQ

        if filename_export_npy:
            np.save(path_npy, matrix_intensity)

        if filename_export:
            with open(path, 'w')as f:

                f.write('Precursor\t' + '\t'.join(['Intensity({:s})'.format(i) for i in self.dp.myPrecursorID.LIST_EXPERIMENT_ID]) + '\n')

                for i in range(matrix_intensity.shape[0]):

                    f.write(list_name[i] + '\t' +
                            '\t'.join([str(matrix_intensity[i, j]) for j in range(len(matrix_intensity[i]))]) + '\n')


class CTaskRTDevAnalysis:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self):

        functionRTDev = CFunctionRTAna_3(self.dp)
        functionRTDev.analysis()


class CTaskVisualForIRTDDA:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self):

        functionIRTVisualXIC = CFunctionIRTVi_4(self.dp)
        functionIRTVisualXIC.analysis()
        
        functionIRTVisualLabel = CFunctionIRTVi_12(self.dp)
        functionIRTVisualLabel.analysis()
        
        functionIRT = CFunctionIRTAn_7(self.dp)
        functionIRT.analysis()
        
        functioniRTSummary = CFunctionIRTSu_11(self.dp)
        functioniRTSummary.analysis()


class CTaskVisualForIRT:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self):

        functionIRT = CFunctionIRTAn_7(self.dp)
        functionIRT.analysis()



class CTaskNormalization:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self):

        if self.dp.myCFG.C14_DDA_FLAG_NORMALIZATION == CFG_TYPE_NORMALIZATION['MaxLFQ']:

            functionNorm = CFunctionNormU_1()
            self.dp.myProteinID.MATRIX_INTENSITY, est_param = functionNorm.norm(self.dp.myProteinID.MATRIX_INTENSITY)
            est_param = [float(i) for i in est_param]
            self.dp.myProteinID.MATRIX_INTENSITY_LOG2 = np.log2(self.dp.myProteinID.MATRIX_INTENSITY_LOG2)
            self.dp.myProteinID.LIST_NORM_PARAM = [1.] + list(est_param)
            for i in range(0, self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2.shape[1]):
                flag_no_mv = self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[:,i] > 0.
                self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] = self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] * est_param[i - 1]
                self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY[flag_no_mv, i] = np.exp2(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i])

            self.dp.myPeptideID.MATRIX_INTENSITY, est_param = functionNorm.norm(self.dp.myPeptideID.MATRIX_INTENSITY)
            est_param = [float(i) for i in est_param]
            self.dp.myPeptideID.MATRIX_INTENSITY_LOG2 = np.log2(self.dp.myPeptideID.MATRIX_INTENSITY)
            self.dp.myPeptideID.LIST_NORM_PARAM = [1.] + list(est_param)
            for i in range(1, self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2.shape[1]):
                flag_no_mv = self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[:, i] > 0.
                self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] = self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] * est_param[i - 1]
                self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY[flag_no_mv, i] =np.exp2(self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i])

            if self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DIACohort']:
                self.dp.myPrecursorID.MATRIX_INTENSITY, est_param = functionNorm.norm(self.dp.myPrecursorID.MATRIX_INTENSITY)
                est_param = [float(i) for i in est_param]
                self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2 = np.log2(self.dp.myPrecursorID.MATRIX_INTENSITY)
                for i in range(1, self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2.shape[1]):
                    flag_no_mv = self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[:, i] > 0.
                    self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv,i] = self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] * est_param[i - 1]
                    self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY[flag_no_mv, i] = np.exp2(self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY[flag_no_mv, i])


            for i in range(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)):
                list_norm = []
                for j, i_intensity in enumerate(self.dp.myIDForIRT.PRELIST8_INTENSITY[i]):
                    list_norm.append(i_intensity * self.dp.myPeptideID.LIST_NORM_PARAM[j])
                self.dp.myIDForIRT.PRELIST9_NORM_INTENSITY.append(list_norm)

            
            

        elif self.dp.myCFG.C14_DDA_FLAG_NORMALIZATION == CFG_TYPE_NORMALIZATION['Quantile']:

            matrix_peptide = self.dp.myPeptideID.MATRIX_INTENSITY.copy()

            functionNorm = CFunctionNormU_2()
            self.dp.myProteinID.MATRIX_INTENSITY = functionNorm.norm(self.dp.myProteinID.MATRIX_INTENSITY)
            self.dp.myPeptideID.MATRIX_INTENSITY = functionNorm.norm(self.dp.myPeptideID.MATRIX_INTENSITY)
            self.dp.myProteinID.MATRIX_INTENSITY_LOG2 = functionNorm.norm(self.dp.myProteinID.MATRIX_INTENSITY_LOG2)
            self.dp.myPeptideID.MATRIX_INTENSITY_LOG2 = functionNorm.norm(self.dp.myPeptideID.MATRIX_INTENSITY_LOG2)

            if self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DIACohort']:
                self.dp.myPrecursorID.MATRIX_INTENSITY = functionNorm.norm(self.dp.myPrecursorID.MATRIX_INTENSITY)
                self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2 = functionNorm.norm(self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2)

            
            for i in range(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)):
                self.dp.myIDForIRT.PRELIST9_NORM_INTENSITY.append([VALUE_ILLEGAL] * self.dp.myPeptideID.MATRIX_INTENSITY.shape[1])

            list_index = []
            for i in range(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)):
                if self.dp.myIDForIRT.PRELIST8_INTENSITY[i].count(VALUE_ILLEGAL) == 0:
                    list_index.append(i)
                    matrix_peptide = np.concatenate([matrix_peptide, np.array([self.dp.myIDForIRT.PRELIST8_INTENSITY[i]])], axis=0)

            matrix_peptide = functionNorm.norm(matrix_peptide)

            for i, index in enumerate(list_index):
                self.dp.myIDForIRT.PRELIST9_NORM_INTENSITY[index] = matrix_peptide[self.dp.myPeptideID.MATRIX_INTENSITY.shape[0]+i]

        elif self.dp.myCFG.C14_DDA_FLAG_NORMALIZATION == CFG_TYPE_NORMALIZATION['DirectLFQ']:

            functionNorm = CFunctionNormU_3()
            self.dp.myProteinID.MATRIX_INTENSITY_LOG2, est_param = functionNorm.norm(self.dp.myProteinID.MATRIX_INTENSITY_LOG2)
            self.dp.myProteinID.MATRIX_INTENSITY = np.exp2(self.dp.myProteinID.MATRIX_INTENSITY_LOG2)
            est_param = [est_param[i] if i in est_param else 0. for i in range(self.dp.myProteinID.MATRIX_INTENSITY_LOG2.shape[1]) ]
            self.dp.myProteinID.LIST_NORM_PARAM = est_param
            for i in range(0, self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2.shape[1]):
                flag_no_mv = self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[:,i] > 0.
                self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] = self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] + est_param[i]
                self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY[flag_no_mv, i] = np.exp2(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i])

            self.dp.myPeptideID.MATRIX_INTENSITY_LOG2, est_param = functionNorm.norm(self.dp.myPeptideID.MATRIX_INTENSITY_LOG2)
            self.dp.myPeptideID.MATRIX_INTENSITY = np.exp2(self.dp.myPeptideID.MATRIX_INTENSITY_LOG2)
            est_param = [est_param[i] if i in est_param else 0. for i in range(self.dp.myPeptideID.MATRIX_INTENSITY_LOG2.shape[1])]
            self.dp.myPeptideID.LIST_NORM_PARAM = est_param
            for i in range(0, self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2.shape[1]):
                flag_no_mv = self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[:,i] > 0.
                self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] = self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] + est_param[i]
                self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY[flag_no_mv, i] = np.exp2(self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY[flag_no_mv, i])

            if self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DIACohort']:
                self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2, est_param = functionNorm.norm(self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2)
                self.dp.myPrecursorID.MATRIX_INTENSITY = np.exp2(self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2)
                est_param = [est_param[i] if i in est_param else 0. for i in range(self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2.shape[1])]
                self.dp.myPrecursorID.LIST_NORM_PARAM = est_param
                for i in range(0, self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2.shape[1]):
                    flag_no_mv = self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2[:,i] > 0.
                    self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] = self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2[flag_no_mv, i] + est_param[i]
                    self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY[flag_no_mv, i] = np.exp2(self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY[flag_no_mv, i])

            for i in range(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)):
                list_norm = []
                list_norm_param = np.exp2(self.dp.myPeptideID.LIST_NORM_PARAM)
                for j, i_intensity in enumerate(self.dp.myIDForIRT.PRELIST8_INTENSITY[i]):
                    list_norm.append(i_intensity * list_norm_param[j])
                self.dp.myIDForIRT.PRELIST9_NORM_INTENSITY.append(list_norm)


class CTaskReport:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def __soliderClean(self):

        tmp_dir = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_PREFIX_EXPORT[2]
        list_tmp = os.listdir(tmp_dir)

        for i_tmp in list_tmp:

            os.remove(tmp_dir + '\\' + i_tmp)

    def work(self):

        functionID = CFunctionPlotI_9(self.dp)
        functionID.plot()

        functionPlotMV = CFunctionPlotM_16(self.dp)
        functionPlotMV.plot()
        
        functionPlotInt = CFunctionPlotI_22(self.dp)
        functionPlotInt.plot()
        
        functionPlotCorr = CFunctionPlotI_13(self.dp)
        functionPlotCorr.plot(flag=0, flag_norm=True)
        functionPlotCorr.plot(flag=0, flag_norm=False)
        functionPlotCorr.plot(flag=1, flag_norm=True)
        functionPlotCorr.plot(flag=1, flag_norm=False)
        
        functionPlotViolin = CFunctionPlotI_10(self.dp)
        functionPlotViolin.plot(flag=0, flag_norm=True)
        functionPlotViolin.plot(flag=0, flag_norm=False)
        functionPlotViolin.plot(flag=1, flag_norm=True)
        functionPlotViolin.plot(flag=1, flag_norm=False)
        
        functionPlotRTCorr = CFunctionPlotR_18(self.dp)
        functionPlotRTCorr.plot()
        
        functionPlotViolin = CFunctionPlotI_29(self.dp)
        functionPlotViolin.plot(flag=0, flag_norm=True)
        functionPlotViolin.plot(flag=0, flag_norm=False)
        functionPlotViolin.plot(flag=1, flag_norm=True)
        functionPlotViolin.plot(flag=1, flag_norm=False)
        
        if self.dp.myProteinID.N_PROTEIN > 1:
            functionPlotCluster = CFunctionPlotI_4(self.dp)
            functionPlotCluster.plot(flag_norm=True)
            functionPlotCluster.plot(flag_norm=False)
        
        functionPlotCV = CFunctionPlotI_12(self.dp)
        functionPlotCV.plot(flag=0, flag_norm=True)
        functionPlotCV.plot(flag=0, flag_norm=False)
        functionPlotCV.plot(flag=1, flag_norm=True)
        functionPlotCV.plot(flag=1, flag_norm=False)
        
        if self.dp.myProteinID.N_PROTEIN > 1:
            functionPlotReduction = CFunctionPlotR_7(self.dp)
            functionPlotReduction.plotPCA()
            functionPlotReduction.plotTSNE2()
        
        functionIRTPloyLine = CFunctionPlotI_2(self.dp)
        functionIRTPloyLine.plot()
        
        functionReport = CFunctionHTMLR_27(self.dp)
        functionReport.report()
        
        if self.dp.myCFG.C2_FLAG_PDF_REPORT:
            functionReportPDF = CFunctionPDFRe_3(self.dp)
            functionReportPDF.report()
        
        self.__soliderClean()

    def workDIA(self):

        if self.dp.myCFG.A1_PATH_MS1 != '':
            functionIntraScore = CFunctionIntra_11(self.dp)
            functionIntraScore.plot()
        
        functionExpScore = CFunctionPlotE_26(self.dp)
        functionExpScore.plot()

        
        functionExpOutlier = CFunctionPlotE_25(self.dp)
        functionExpOutlier.plot()

        
        functionID = CFunctionPlotI_9(self.dp)
        functionID.plotDIA_Scatter()

        
        functionPlotMV = CFunctionPlotM_16(self.dp)
        functionPlotMV.plot()
        functionPlotMV.plot_share()

        
        functionCon = CFunctionPlotC_8(self.dp)
        functionCon.plotDIA()

        if self.dp.myCFG.A1_PATH_MS1 != '':
            functionMissClv = CFunctionPlotM_21(self.dp)
            functionMissClv.plotDIA()

        
        functionPlotPeakWidth = CFunctionPlotP_15(self.dp)
        functionPlotPeakWidth.plotDIA()

        functionPlotFWHM = CFunctionPlotF_17(self.dp)
        functionPlotFWHM.plotDIA()

        functionPlotDeltaRT = CFunctionPlotD_24(self.dp)
        functionPlotDeltaRT.plotDIA()

        
        functionPlotRTCorr = CFunctionPlotR_30(self.dp)
        functionPlotRTCorr.plot()
        
        functionIRTPloyLine = CFunctionPlotI_2(self.dp)
        functionIRTPloyLine.plot()

        if self.dp.myCFG.A1_PATH_MS1 != '':
            functionPlotTIC = CFunctionPlotT_23(self.dp)
            functionPlotTIC.plotTIC()

        functionPlotProtein = CFunctionPlotP_19(self.dp)
        functionPlotProtein.plot()

        
        functionPlotCorr = CFunctionPlotI_13(self.dp)
        functionPlotCorr.plot(flag=0, flag_norm=True)
        functionPlotCorr.plot(flag=0, flag_norm=False)
        functionPlotCorr.plot(flag=1, flag_norm=True)
        functionPlotCorr.plot(flag=1, flag_norm=False)
        functionPlotCorr.plot(flag=2, flag_norm=True)
        functionPlotCorr.plot(flag=2, flag_norm=False)
        functionPlotCorr.plot_origin(flag=0, flag_norm=True)
        functionPlotCorr.plot_origin(flag=0, flag_norm=False)
        functionPlotCorr.plot_origin(flag=1, flag_norm=True)
        functionPlotCorr.plot_origin(flag=1, flag_norm=False)
        functionPlotCorr.plot_origin(flag=2, flag_norm=True)
        functionPlotCorr.plot_origin(flag=2, flag_norm=False)
        
        functionPlotViolin = CFunctionPlotI_10(self.dp)
        functionPlotViolin.plot(flag=0, flag_norm=True)
        functionPlotViolin.plot(flag=0, flag_norm=False)
        functionPlotViolin.plot(flag=1, flag_norm=True)
        functionPlotViolin.plot(flag=1, flag_norm=False)
        functionPlotViolin.plot(flag=2, flag_norm=True)
        functionPlotViolin.plot(flag=2, flag_norm=False)
        functionPlotViolin.plot_origin(flag=0, flag_norm=True)
        functionPlotViolin.plot_origin(flag=0, flag_norm=False)
        functionPlotViolin.plot_origin(flag=1, flag_norm=True)
        functionPlotViolin.plot_origin(flag=1, flag_norm=False)
        functionPlotViolin.plot_origin(flag=2, flag_norm=True)
        functionPlotViolin.plot_origin(flag=2, flag_norm=False)
        
        functionPlotViolin = CFunctionPlotI_29(self.dp)
        functionPlotViolin.plot(flag=0, flag_norm=True)
        functionPlotViolin.plot(flag=0, flag_norm=False)
        functionPlotViolin.plot(flag=1, flag_norm=True)
        functionPlotViolin.plot(flag=1, flag_norm=False)
        functionPlotViolin.plot(flag=2, flag_norm=True)
        functionPlotViolin.plot(flag=2, flag_norm=False)
        
        functionPlotCluster = CFunctionPlotI_4(self.dp)
        functionPlotCluster.plot(flag_norm=True)
        functionPlotCluster.plot(flag_norm=False)
        
        functionPlotCV = CFunctionPlotI_12(self.dp)
        functionPlotCV.plot(flag=0, flag_norm=True)
        functionPlotCV.plot(flag=0, flag_norm=False)
        functionPlotCV.plot(flag=1, flag_norm=True)
        functionPlotCV.plot(flag=1, flag_norm=False)
        functionPlotCV.plot(flag=2, flag_norm=True)
        functionPlotCV.plot(flag=2, flag_norm=False)
        
        functionPlotReduction = CFunctionPlotR_7(self.dp)
        functionPlotReduction.plotPCA(flag_norm=1)
        functionPlotReduction.plotPCA(flag_norm=0)
        functionPlotReduction.plotTSNE2(flag_norm=1)
        functionPlotReduction.plotTSNE2(flag_norm=0)

        functionPlotMS1Accuracy = CFunctionPlotM_6(self.dp)
        functionPlotMS1Accuracy.plotDIA()

        functionPlotCalMS1Accuracy = CFunctionPlotC_28(self.dp)
        functionPlotCalMS1Accuracy.plotDIA()

        functionPlotMS2Accuracy = CFunctionPlotM_31(self.dp)
        functionPlotMS2Accuracy.plotDIA()

        functionPlotCalMS2Accuracy = CFunctionPlotC_32(self.dp)
        functionPlotCalMS2Accuracy.plotDIA()

        functionPlotMS1DPPP = CFunctionPlotM_20(self.dp)
        functionPlotMS1DPPP.plotDIA()

        functionPlotMS2DPPP = CFunctionPlotM_5(self.dp)
        functionPlotMS2DPPP.plotDIA()

        
        functionReport = CFunctionHTMLR_27(self.dp)
        if self.dp.myCFG.A1_PATH_MS1 != '':
            functionReport.reportDIA()
        else:
            functionReport.reportDIA_inter()
        
        if self.dp.myCFG.C2_FLAG_PDF_REPORT:
            functionReportPDF = CFunctionPDFRe_3(self.dp)
            functionReportPDF.report()
        
        self.__soliderClean()


class CTaskExtractIRTFromMS1:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self):

        functionExtractIRT = CFunctionExtra_1(self.dp)
        maxRT = functionExtractIRT.extract()

        return maxRT


class CTaskOutputIRTIndicator:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def work(self, inputMaxRT: float):

        functionOutput = CFunctionOutIR_3(self.dp)
        functionOutput.output()
        
        functionPlotIRTVisual = CFunctionPlotI_14(self.dp)
        functionPlotIRTVisual.plotForIRTOnly(inputMaxRT)


class CTaskRefineDIA:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def __captainWriteCfg(self, raw_path):

        _, raw_name = os.path.split(raw_path)
        raw_name = raw_name.split('.')[0]
        path = self.dp.myCFG.E1_PATH_EXPORT + 'MSCohort\\'
        if os.access(path, os.F_OK):
            pass
        else:
            os.makedirs(path)

        with open(path + raw_name+'cfg.txt', 'w')as f:

            if raw_path[-4:] == '.raw':
                f.write('\n[Work Flow]'), f.write('\n')
                f.write('WORK_FLOW=' + str(self.dp.myCFG.A0_TYPE_FLOW) + '\n')

                f.write('\n[Data File]\n')
                f.write('TYPE_DATA=0'), f.write('\n')
                f.write('PATH_RAW=' + raw_path), f.write('\n')

                f.write('\n'), f.write('[Analysis results]'), f.write('\n')
                f.write('TYPE_ANALYSIS_RESULT=0'), f.write('\n')  
                f.write('PATH_ANALYSIS_RESULT=' + self.dp.myCFG.B1_PATH_ANALYSIS_RESULT), f.write('\n')  
                f.write('THRESHOLD_FDR=0.01'), f.write('\n')  

                f.write('\n'), f.write('[Setting]'), f.write('\n')
                f.write('THRESHOLD_PEAK_WIDTH_TAILING=' + str(self.dp.myCFG.C5_THRESHOLD_PEAK_WIDTH_TAILING)), f.write('\n')
                f.write('THRESHOLD_INVALID_ACQUIRING_SCAN=' + str(self.dp.myCFG.C6_THRESHOLD_INVALID_ACQUIRING_SCAN)), f.write('\n')
                f.write('FLAG_ANALYZE_FEATURE=' + str(self.dp.myCFG.C7_FLAG_ANALYZE_FEATURE)), f.write('\n')

                f.write('\n'), f.write('[Export]'), f.write('\n')
                f.write('PATH_EXPORT=' + path + '\\'), f.write('\n')
            elif '.d' in raw_path[-2:]:
                f.write('\n[Work Flow]'), f.write('\n')
                f.write('WORK_FLOW=' + str(self.dp.myCFG.A0_TYPE_FLOW) + '\n')

                f.write('\n[Data File]\n')
                f.write('TYPE_DATA=1'), f.write('\n')
                f.write('PATH_RAW=' + raw_path), f.write('\n')

                f.write('\n'), f.write('[Analysis results]'), f.write('\n')
                f.write('TYPE_ANALYSIS_RESULT=0'), f.write('\n')  
                f.write('PATH_ANALYSIS_RESULT=' + self.dp.myCFG.B1_PATH_ANALYSIS_RESULT), f.write('\n')  
                f.write('THRESHOLD_FDR=0.01'), f.write('\n')  

                f.write('\n'), f.write('[Setting]'), f.write('\n')
                f.write('THRESHOLD_PEAK_WIDTH_TAILING=' + str(self.dp.myCFG.C5_THRESHOLD_PEAK_WIDTH_TAILING)), f.write(
                    '\n')
                f.write('THRESHOLD_INVALID_ACQUIRING_SCAN=' + str(
                    self.dp.myCFG.C6_THRESHOLD_INVALID_ACQUIRING_SCAN)), f.write('\n')
                f.write('FLAG_ANALYZE_FEATURE=0'), f.write('\n')

                f.write('\n'), f.write('[Export]'), f.write('\n')
                f.write('PATH_EXPORT=' + path + '\\'), f.write('\n')
            elif '.wiff' in raw_path[-6:]:
                f.write('\n[Work Flow]'), f.write('\n')
                f.write('WORK_FLOW=' + str(self.dp.myCFG.A0_TYPE_FLOW) + '\n')

                f.write('\n[Data File]\n')
                f.write('TYPE_DATA=2'), f.write('\n')
                f.write('PATH_RAW=' + raw_path), f.write('\n')

                f.write('\n'), f.write('[Analysis results]'), f.write('\n')
                f.write('TYPE_ANALYSIS_RESULT=0'), f.write('\n')  
                f.write('PATH_ANALYSIS_RESULT=' + self.dp.myCFG.B1_PATH_ANALYSIS_RESULT), f.write('\n')  
                f.write('THRESHOLD_FDR=0.01'), f.write('\n')  

                f.write('\n'), f.write('[Setting]'), f.write('\n')
                f.write('THRESHOLD_PEAK_WIDTH_TAILING=' + str(self.dp.myCFG.C5_THRESHOLD_PEAK_WIDTH_TAILING)), f.write(
                    '\n')
                f.write('THRESHOLD_INVALID_ACQUIRING_SCAN=' + str(
                    self.dp.myCFG.C6_THRESHOLD_INVALID_ACQUIRING_SCAN)), f.write('\n')
                f.write('FLAG_ANALYZE_FEATURE=0'), f.write('\n')

                f.write('\n'), f.write('[Export]'), f.write('\n')
                f.write('PATH_EXPORT=' + path + '\\'), f.write('\n')
            else:
                print("The type of" + str(raw_name) + "data is unknown")

        return path,raw_name

    def work(self):

        LIST_PATH_RAW = []
        if self.dp.myCFG.A4_TYPE_DATA == CFG_TYPE_DATA['Thermo-Orbitrap']:
            op_FILL_LIST_PATH_MS(self.dp.myCFG.A1_PATH_MS1, LIST_PATH_RAW, [".raw"])
        elif self.dp.myCFG.A4_TYPE_DATA == CFG_TYPE_DATA['timsTOF']:
            op_FILL_LIST_PATH_MS(self.dp.myCFG.A1_PATH_MS1, LIST_PATH_RAW, [".d"])
        elif self.dp.myCFG.A4_TYPE_DATA == CFG_TYPE_DATA['SCIEX']:
            op_FILL_LIST_PATH_MS(self.dp.myCFG.A1_PATH_MS1, LIST_PATH_RAW, [".wiff"])

        for i_raw in LIST_PATH_RAW:

            path,raw_name = self.__captainWriteCfg(i_raw)
            self.dp.myCFG.E4_PATH_MSREFINE_REPORT.append(path)
            exe_MSRefineDIA = 'bin\\MSRefine_DIA.exe'
            cmd = exe_MSRefineDIA + ' {:s}'.format(path + raw_name + 'cfg.txt')

            try:
                logToUser(INFO_TO_USER_TaskParseMSRefine[0] + path+ raw_name)
                path_report = path + "MSCohort_" + raw_name + "\\Analysis_Report.html"
                if os.access(path_report, os.F_OK):
                    logToUser(INFO_TO_USER_TaskParseMSRefine[1]+path+ raw_name)
                else:
                    os.system(cmd)
            except:
                logGetError('MSRefine_DIA.exe run wrong!')

            


