
from MSStaff import CStaff
import warnings


import sys
if __name__ == "__main__":

    warnings.filterwarnings("ignore")
    staff = CStaff(sys.argv)
    staff.start()
