
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from matplotlib import pyplot as plt
import numpy as np
from math import ceil, floor
from scipy.stats import t
from sklearn.impute import KNNImputer
import pickle
import itertools
from MSFunctionEvi3 import CFunctionEvide_1
from MSFunction1 import CFunctionParse_6, CFunctionParse_10
from MSOperator import op_INIT_CSEED, op_INIT_CEVIDENCE
from MSTool import toolCalCV, toolGetNameFromPath, toolFindNeighborFromSortedList1, toolFindNeighborFromDisorderdList
from MSData import CDataPack, CFileMS1, CFileMS2, CEvidence, CSeed
from MSSystem import IO_FILENAME_EXPORT, VALUE_ILLEGAL, IO_FILENAME_TMP_EXPORT, IO_FILENAME_PIC_EXPORT, CFG_TYPE_COHORT, CFG_TYPE_MISSING_VALUE_IMPUTATION, CFG_FLAG_MISSING_VALUE_THRESHOLD


class CFunctionStatM_9:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP
        self.var_pro_2 = 0
        self.var_pro_57 = []
        self.var_pro_63 = []
        self.var_pro_46 = 0
        self.var_pro_52 = []
        self.var_pro_23 = []
        self.var_pep_30 = 0
        self.var_pep_12 = []
        self.var_pep_35 = []
        self.var_pre_55 = 0
        self.var_pre_61 = []
        self.var_pre_13 = []

    def __soliderInterpolationWithKNN(self, var_mat_1: np.ndarray, ratio: float):

        var_fla_34 = var_mat_1 > 0.
        var_lis_42 = var_fla_34.shape[1] - np.sum(var_fla_34, axis=1)  
        var_fla_40 = var_lis_42 < (var_mat_1.shape[1] * ratio)

        var_fil_39 = var_mat_1[var_fla_40]
        var_fil_39[var_fil_39 == 0.] = np.nan

        if var_fla_34.shape[0] > 10:
            n_neighbors = 10
        elif var_fla_34.shape[0] > 5:
            n_neighbors = 5
        else:
            n_neighbors = 2

        imputer = KNNImputer(n_neighbors=n_neighbors)
        var_fil_39 = imputer.fit_transform(var_fil_39)

        var_mat_1[var_fla_40] = var_fil_39

        return var_mat_1

    def __soliderMVThreshold(self, var_mat_1: np.ndarray):

        var_lis_6 = np.array(self.dp.LIST_EXPERIMENT_INT_THRESHOLD)
        var_mat_1[var_mat_1 < var_lis_6] = 0.

        return var_mat_1

    def stat(self):

        
        var_mat_1 = self.dp.myProteinID.MATRIX_INTENSITY

        if self.dp.myCFG.C16_FLAG_MISSING_VALUE_THRESHOLD == CFG_FLAG_MISSING_VALUE_THRESHOLD['Yes']:

            var_mat_1 = self.__soliderMVThreshold(var_mat_1)

        if self.dp.myCFG.C17_TYPE_MISSING_VALUE_IMPUTATION == CFG_TYPE_MISSING_VALUE_IMPUTATION['KNN']:

            var_mat_1 = self.__soliderInterpolationWithKNN(var_mat_1, 0.5)

        var_fla_34 = var_mat_1 > 0.
        self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY = np.array(var_mat_1)
        self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2 = np.array(var_mat_1)
        self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2 <= 0] = 0.
        self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2 > 0] = np.log2(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2[self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY_LOG2 > 0])

        self.var_pro_52 = var_fla_34.shape[0] - np.sum(var_fla_34, axis=0)  
        flag_no_mv = np.sum(var_fla_34, axis=1) == var_fla_34.shape[1]  
        
        self.dp.myProteinID.LIST_PROTEIN_ID = [self.dp.myProteinID.LIST_PROTEIN_ID[i] for i in
                                               range(len(self.dp.myProteinID.LIST_PROTEIN_ID)) if flag_no_mv[i]]
        var_mat_1 = var_mat_1[flag_no_mv]
        self.dp.myProteinID.MATRIX_INTENSITY = var_mat_1
        self.dp.myProteinID.MATRIX_INTENSITY_LOG2 = np.log2(var_mat_1)
        
        if len(self.dp.myProteinID.PRO4_iBAQ) > 0:

            matrix_iBAQ = self.dp.myProteinID.MATRIX_IBAQ_LOG10
            flag_matrix_iBAQ = matrix_iBAQ > 0.
            flag_no_mv = np.sum(flag_matrix_iBAQ, axis=1) == flag_matrix_iBAQ.shape[1]  
            matrix_iBAQ = matrix_iBAQ[flag_no_mv]
            self.dp.myProteinID.MATRIX_IBAQ_LOG10 = np.log10(matrix_iBAQ)

        self.var_pro_46 = len(self.dp.myProteinID.LIST_PROTEIN_ID)
        self.var_pro_23 = [self.dp.myProteinID.N_PROTEIN - self.var_pro_46 - i for i in self.var_pro_52]

        
        if self.dp.myProteinGroupID.N_PROTEIN > 0:
            var_mat_1 = self.dp.myProteinGroupID.MATRIX_INTENSITY
            var_fla_34 = var_mat_1 > 0.

            self.var_pro_57 = var_fla_34.shape[0] - np.sum(var_fla_34, axis=0)  
            flag_no_mv = np.sum(var_fla_34, axis=1) == var_fla_34.shape[1]  

            self.dp.myProteinGroupID.LIST_PROTEIN_ID = [self.dp.myProteinGroupID.LIST_PROTEIN_ID[i] for i in
                                                   range(len(self.dp.myProteinGroupID.LIST_PROTEIN_ID)) if flag_no_mv[i]]
            var_mat_1 = var_mat_1[flag_no_mv]
            self.dp.myProteinGroupID.MATRIX_INTENSITY = var_mat_1
            self.dp.myProteinGroupID.MATRIX_INTENSITY_LOG2 = np.log2(var_mat_1)
            
            if len(self.dp.myProteinGroupID.PRO4_iBAQ) > 0:
                matrix_iBAQ = self.dp.myProteinGroupID.MATRIX_IBAQ_LOG10
                flag_matrix_iBAQ = matrix_iBAQ > 0.
                flag_no_mv = np.sum(flag_matrix_iBAQ, axis=1) == flag_matrix_iBAQ.shape[1]  
                matrix_iBAQ = matrix_iBAQ[flag_no_mv]
                self.dp.myProteinGroupID.MATRIX_IBAQ_LOG10 = np.log10(matrix_iBAQ)

            self.var_pro_2 = len(self.dp.myProteinGroupID.LIST_PROTEIN_ID)
            self.var_pro_63 = [self.dp.myProteinGroupID.N_PROTEIN - self.var_pro_2 - i for i in
                                               self.var_pro_57]

        
        var_mat_1 = self.dp.myPeptideID.MATRIX_INTENSITY
        var_fla_34 = var_mat_1 > 0.
        self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY = np.array(var_mat_1)
        self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2 = np.array(var_mat_1)
        self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2 <= 0] = 0.
        self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2 > 0] = np.log2(self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2[self.dp.myPeptideID.MATRIX_ORIGIN_INTENSITY_LOG2 > 0])

        self.var_pep_12 = var_fla_34.shape[0] - np.sum(var_fla_34, axis=0)  
        flag_no_mv = np.sum(var_fla_34, axis=1) == var_fla_34.shape[1]  

        self.dp.myPeptideID.LIST_PEPTIDE_ID = [self.dp.myPeptideID.LIST_PEPTIDE_ID[i] for i in
                                               range(len(self.dp.myPeptideID.LIST_PEPTIDE_ID)) if flag_no_mv[i]]
        var_mat_1 = var_mat_1[flag_no_mv]
        self.dp.myPeptideID.MATRIX_INTENSITY = var_mat_1
        self.dp.myPeptideID.MATRIX_INTENSITY_LOG2 = np.log2(var_mat_1)

        self.var_pep_30 = len(self.dp.myPeptideID.LIST_PEPTIDE_ID)
        self.var_pep_35 = [self.dp.myPeptideID.N_PEPTIDE - self.var_pep_30 - i for i in
                                           self.var_pep_12]

        if self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DIACohort']:
            
            var_mat_1 = self.dp.myPrecursorID.MATRIX_INTENSITY
            var_fla_34 = var_mat_1 > 0.
            self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY = np.array(var_mat_1)
            self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2 = np.array(var_mat_1)
            self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2[self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2 <= 0] = 0.
            self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2[
                self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2 > 0] = np.log2(
                self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2[self.dp.myPrecursorID.MATRIX_ORIGIN_INTENSITY_LOG2 > 0])

            self.var_pre_61 = var_fla_34.shape[0] - np.sum(var_fla_34,
                                                                                axis=0)  
            flag_no_mv = np.sum(var_fla_34, axis=1) == var_fla_34.shape[1]  

            self.dp.myPrecursorID.LIST_PRECURSOR_ID_MV= [self.dp.myPrecursorID.LIST_PRECURSOR_ID[i] for i in
                                                   range(len(self.dp.myPrecursorID.LIST_PRECURSOR_ID)) if flag_no_mv[i]]
            var_mat_1 = var_mat_1[flag_no_mv]
            self.dp.myPrecursorID.MATRIX_INTENSITY= var_mat_1
            self.dp.myPrecursorID.MATRIX_INTENSITY_LOG2 = np.log2(var_mat_1)

            self.var_pre_55 = len(self.dp.myPrecursorID.LIST_PRECURSOR_ID_MV)
            self.var_pre_13 = [self.dp.myPrecursorID.N_PRECURSOR - self.var_pre_55 - i for i in
                                               self.var_pre_61]

        self.__soliderWriteIDInfo()
        self.__soliderWriteQuantInfo()

    def stat_share(self):

        var_mat_1 = self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY
        var_lis_14 = [np.sum(var_mat_1[i] != 0) for i in range(var_mat_1.shape[0])]
        list_common = [0] * len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_share = [0] * len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_sparse = [0] * len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_unique = [0] * len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        var_thr_24 = len(self.dp.myProteinID.LIST_EXPERIMENT_ID) // 2
        var_thr_29 = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)

        for i in range(len(self.dp.myProteinID.PRO1_NAME)):
            for j in range(len(self.dp.myProteinID.LIST_EXPERIMENT_ID)):
                if self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY[i][j] > 0:
                    if var_lis_14[i] == 1:
                        list_unique[j] += 1
                    elif 1 < var_lis_14[i] <= var_thr_24:
                        list_sparse[j] += 1
                    elif var_thr_24 < var_lis_14[i] < var_thr_29:
                        list_share[j] += 1
                    elif var_lis_14[i] == var_thr_29:
                        list_common[j] += 1
                    else:
                        pass

        path_pro = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[66]

        with open(path_pro, 'w')as f:

            f.write('Experiment\t' + '\t'.join(self.dp.myProteinID.LIST_EXPERIMENT_ID) + '\n')

            f.write('Common quantification\t' + '\t'.join([str(i) for i in list_common]) + '\n')

            f.write('Shared >= 50% of runs\t' + '\t'.join([str(i) for i in list_share]) + '\n')

            f.write('Sparse quantification\t' + '\t'.join([str(i) for i in list_sparse]) + '\n')

            f.write('Unique quantification\t' + '\t'.join([str(i) for i in list_unique]) + '\n')


    def __soliderWriteQuantInfo(self):

        path_pro = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[1]
        path_pep = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[23]
        path_pre = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[38]
        path_progrop = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[53]

        if self.dp.myProteinGroupID.N_PROTEIN > 0:

            with open(path_progrop, 'w') as f:
                f.write('Experiment\t' + '\t'.join(self.dp.myProteinGroupID.LIST_EXPERIMENT_ID) + '\n')

                f.write('Common quantification\t' + '\t'.join([str(self.var_pro_2)]
                                                              * len(self.dp.myProteinGroupID.LIST_EXPERIMENT_ID)) + '\n')

                f.write(
                    'Non-common quantification\t' + '\t'.join([str(i) for i in self.var_pro_63]) + '\n')

                f.write('Missing value\t' + '\t'.join([str(i) for i in self.var_pro_57]) + '\n')

        with open(path_pro, 'w')as f:

            f.write('Experiment\t' + '\t'.join(self.dp.myProteinID.LIST_EXPERIMENT_ID) + '\n')

            f.write('Common quantification\t' + '\t'.join([str(self.var_pro_46)]
                                                          * len(self.dp.myProteinID.LIST_EXPERIMENT_ID)) + '\n')

            f.write('Non-common quantification\t' + '\t'.join([str(i) for i in self.var_pro_23]) + '\n')

            f.write('Missing value\t' + '\t'.join([str(i) for i in self.var_pro_52]) + '\n')

        with open(path_pep, 'w')as f:

            f.write('Experiment\t' + '\t'.join(self.dp.myPeptideID.LIST_EXPERIMENT_ID) + '\n')

            f.write('Common quantification\t' + '\t'.join([str(self.var_pep_30)]
                                                          * len(self.dp.myPeptideID.LIST_EXPERIMENT_ID)) + '\n')

            f.write('Non-common quantification\t' + '\t'.join([str(i) for i in self.var_pep_35]) + '\n')

            f.write('Missing value\t' + '\t'.join([str(i) for i in self.var_pep_12]) + '\n')

        if self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DIACohort']:
            with open(path_pre, 'w')as f:

                f.write('Experiment\t' + '\t'.join(self.dp.myPrecursorID.LIST_EXPERIMENT_ID) + '\n')

                f.write('Common quantification\t' + '\t'.join([str(self.var_pre_55)]
                                                              * len(self.dp.myPrecursorID.LIST_EXPERIMENT_ID)) + '\n')

                f.write('Non-common quantification\t' + '\t'.join([str(i) for i in self.var_pre_13]) + '\n')

                f.write('Missing value\t' + '\t'.join([str(i) for i in self.var_pre_61]) + '\n')

    def __soliderWriteIDInfo(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[0]

        with open(path, 'w')as f:

            if self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DDACohort']:
                f.write('PSM level' + '\n')
                f.write('Count\t' + '\t'.join(self.dp.myID.LIST_EXPERIMENT_ID) + '\tAll' + '\n')
                f.write('ID\t' + '\t'.join([str(len(i)) for i in self.dp.myID.PSM_LIST_ID]) + '\t' + str(self.dp.myID.N_PSM) + '\n')

                f.write('Peptide level' + '\n')
                f.write('Count\t' + '\t'.join(self.dp.myID.LIST_EXPERIMENT_ID) + '\tAll' + '\n')
                f.write('ID\t' + '\t'.join([str(len(i)) for i in self.dp.myID.PEP_LIST_ID]) + '\t' + str(self.dp.myID.N_PEPTIDE) + '\n')

                f.write('Protein level' + '\n')
                f.write('Count\t' + '\t'.join(self.dp.myID.LIST_EXPERIMENT_ID) + '\tAll' + '\n')
                f.write('ID\t' + '\t'.join([str(len(i)) for i in self.dp.myID.PRO_LIST_ID]) + '\t' + str(self.dp.myID.N_PROTEIN) + '\n')

                f.write('ProteinGroup level' + '\n')
                f.write('Count\t' + '\t'.join(self.dp.myID.LIST_EXPERIMENT_ID) + '\tAll' + '\n')
                f.write('ID\t' + '\t'.join([str(len(i)) for i in self.dp.myID.PROGROUP_LIST_ID]) + '\t' + str(self.dp.myID.N_PROTEINGROUP) + '\n')

            elif self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['DIACohort']:

                f.write('Precursor level' + '\n')
                f.write('Count\t' + '\t'.join(self.dp.myID.LIST_EXPERIMENT_ID) + '\tAll' + '\n')
                f.write('ID\t' + '\t'.join([str(len(i)) for i in self.dp.myID.PSM_LIST_ID]) + '\t' + str(
                    self.dp.myID.N_PSM) + '\n')

                f.write('Peptide level' + '\n')
                f.write('Count\t' + '\t'.join(self.dp.myID.LIST_EXPERIMENT_ID) + '\tAll' + '\n')
                f.write('ID\t' + '\t'.join([str(len(i)) for i in self.dp.myID.PEP_LIST_ID]) + '\t' + str(
                    self.dp.myID.N_PEPTIDE) + '\n')

                f.write('ProteinGroup level' + '\n')
                f.write('Count\t' + '\t'.join(self.dp.myID.LIST_EXPERIMENT_ID) + '\tAll' + '\n')
                f.write('ID\t' + '\t'.join([str(len(i)) for i in self.dp.myID.PROGROUP_LIST_ID]) + '\t' + str(
                    self.dp.myID.N_PROTEINGROUP) + '\n')


class CFunctionCalcu_2:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP
        self.matrix_cv = []
        self.group_name = []
        self.var_gro_67 = []
        self.var_gro_19 = []

    def calculate(self, var_mat_1: np.ndarray, flag_norm, var_fil_62):

        
        
        self.group_name = [i_group[0] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_67 = [i_group[1] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_19 = [[self.dp.myProteinID.LIST_SAMPLE_ID.index(i_exp) for i_exp in i_group] for i_group in self.var_gro_67]
        self.group_name.append('GroupAll')
        self.var_gro_67.append(self.dp.myProteinID.LIST_SAMPLE_ID)
        self.var_gro_19.append(list(range(len(self.dp.myProteinID.LIST_SAMPLE_ID))))

        self.matrix_cv = np.ones(shape=[var_mat_1.shape[0], len(self.group_name)]) * -1

        for i_protein in range(var_mat_1.shape[0]):

            for i_group in range(len(self.group_name)):

                self.matrix_cv[i_protein][i_group] = toolCalCV(var_mat_1[i_protein][self.var_gro_19[i_group]])

        self.__soliderWriteInfo(flag_norm)
        self.__soliderwriteCVInfo(var_fil_62)

    def calculateForPeptide(self, var_mat_1: np.ndarray, flag_norm, var_fil_62):

        
        
        self.group_name = [i_group[0] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_67 = [i_group[1] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_19 = [[self.dp.myPeptideID.LIST_SAMPLE_ID.index(i_exp) for i_exp in i_group] for i_group in self.var_gro_67]
        self.group_name.append('GroupAll')
        self.var_gro_67.append(self.dp.myPeptideID.LIST_SAMPLE_ID)
        self.var_gro_19.append(list(range(len(self.dp.myPeptideID.LIST_SAMPLE_ID))))

        self.matrix_cv = np.zeros(shape=[var_mat_1.shape[0], len(self.group_name)])

        for i_protein in range(var_mat_1.shape[0]):

            for i_group in range(len(self.group_name)):

                self.matrix_cv[i_protein][i_group] = toolCalCV(var_mat_1[i_protein][self.var_gro_19[i_group]])

        self.__soliderWriteInfoForPeptide(flag_norm)
        self.__soliderwriteCVInfo(var_fil_62)

    def calculateForPrecursor(self, var_mat_1: np.ndarray, flag_norm, var_fil_62):

        
        
        self.group_name = [i_group[0] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_67 = [i_group[1] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_19 = [[self.dp.myPrecursorID.LIST_SAMPLE_ID.index(i_exp) for i_exp in i_group] for i_group in self.var_gro_67]
        self.group_name.append('GroupAll')
        self.var_gro_67.append(self.dp.myPrecursorID.LIST_SAMPLE_ID)
        self.var_gro_19.append(list(range(len(self.dp.myPrecursorID.LIST_SAMPLE_ID))))

        self.matrix_cv = np.zeros(shape=[var_mat_1.shape[0], len(self.group_name)])

        for i_protein in range(var_mat_1.shape[0]):

            for i_group in range(len(self.group_name)):

                self.matrix_cv[i_protein][i_group] = toolCalCV(var_mat_1[i_protein][self.var_gro_19[i_group]])

        self.__soliderWriteInfoForPrecursor(flag_norm)
        self.__soliderwriteCVInfo(var_fil_62)

    def __soliderWriteInfo(self, flag_norm):

        if flag_norm:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[10]
        else:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[4]

        with open(path, 'w')as f:

            f.write('Protein\t' + '\t'.join(self.group_name) + '\n')

            for i in range(self.matrix_cv.shape[0]):

                f.write(list(self.dp.myProteinID.DICT_PROTEIN2PEPTIDE.keys())[i] + '\t' + \
                        '\t'.join([str(i_intensity) if i_intensity != -1 else 'None' for i_intensity in self.matrix_cv[i]]) + '\n')

    def __soliderWriteInfoForPeptide(self, flag_norm):

        if flag_norm:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[33]
        else:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[32]

        with open(path, 'w')as f:

            f.write('Protein\t' + '\t'.join(self.group_name) + '\n')

            for i in range(self.matrix_cv.shape[0]):

                f.write(list(self.dp.myPeptideID.DICT_PEPTIDE2POSITION.keys())[i] + '\t' + \
                        '\t'.join([str(i_intensity) for i_intensity in self.matrix_cv[i]]) + '\n')

    def __soliderWriteInfoForPrecursor(self, flag_norm):

        if flag_norm:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[48]
        else:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[47]

        with open(path, 'w')as f:

            f.write('Protein\t' + '\t'.join(self.group_name) + '\n')

            for i in range(self.matrix_cv.shape[0]):

                f.write(self.dp.myPrecursorID.LIST_PRECURSOR_ID[i] + '\t' + \
                        '\t'.join([str(i_intensity) for i_intensity in self.matrix_cv[i]]) + '\n')

    def __soliderwriteCVInfo(self, var_fil_62):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + var_fil_62

        np.save(path, self.matrix_cv)


class CFunctionCalcu_15:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP
        self.matrix_cv = []
        self.group_name = []
        self.var_gro_67 = []
        self.var_gro_19 = []

    def calculate(self, var_mat_1: np.ndarray, flag_norm, var_fil_62):

        
        
        self.group_name = [i_group[0] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_67 = [i_group[1] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_19 = [[self.dp.myPeptideID.LIST_SAMPLE_ID.index(i_exp) for i_exp in i_group] for i_group in self.var_gro_67]
        self.group_name.append('GroupAll')
        self.var_gro_67.append(self.dp.myPeptideID.LIST_SAMPLE_ID)
        self.var_gro_19.append(list(range(len(self.dp.myPeptideID.LIST_SAMPLE_ID))))

        self.matrix_cv = np.zeros(shape=[var_mat_1.shape[0], len(self.group_name)])

        for i_protein in range(var_mat_1.shape[0]):

            for i_group in range(len(self.group_name)):

                self.matrix_cv[i_protein][i_group] = toolCalCV(var_mat_1[i_protein][self.var_gro_19[i_group]])

        self.__soliderWriteInfo(flag_norm)
        self.__soliderwriteCVInfo(var_fil_62)

    def __soliderWriteInfo(self, flag_norm):

        if flag_norm:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[33]
        else:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[32]

        with open(path, 'w')as f:

            f.write('Protein\t' + '\t'.join(self.group_name) + '\n')

            for i in range(self.matrix_cv.shape[0]):

                f.write(self.dp.myPeptideID.LIST_PEPTIDE_ID[i] + '\t' + \
                        '\t'.join([str(i_intensity) for i_intensity in self.matrix_cv[i]]) + '\n')

    def __soliderwriteCVInfo(self, var_fil_62):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + var_fil_62

        np.save(path, self.matrix_cv)


class CFunctionCalcu_14:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP
        self.transform = []
        self.ratio = []

    def __soliderInterpolationWithKNN(self, var_mat_1: np.ndarray, ratio: float):

        var_fla_34 = var_mat_1 > 0.
        var_lis_42 = var_fla_34.shape[1] - np.sum(var_fla_34, axis=1)  
        var_fla_40 = var_lis_42 < (var_mat_1.shape[1] * ratio)

        var_fil_39 = var_mat_1[var_fla_40]
        var_fil_39[var_fil_39 == 0.] = np.nan

        if var_fla_34.shape[0] > 10:
            n_neighbors = 10
        elif var_fla_34.shape[0] > 5:
            n_neighbors = 5
        else:
            n_neighbors = 2

        imputer = KNNImputer(n_neighbors=n_neighbors)
        var_fil_39 = imputer.fit_transform(var_fil_39)

        return var_fil_39

    def calculate(self, var_mat_1: np.ndarray, flag_norm):

        var_mat_27 = self.__soliderInterpolationWithKNN(var_mat_1, ratio=self.dp.myPLOT.THRESHOLD_PCA_INTERPOLATION)

        pca = PCA(n_components=2)
        var_Int_44 = np.array(var_mat_27).copy()
        
        for i in range(var_Int_44.shape[0]):
            mean = np.mean(var_Int_44[i, :])
            std_square = np.sqrt(np.std(var_Int_44[i, :]))
            var_Int_44[i, :] = (var_Int_44[i, :] - mean) / (std_square + 1e-6)
        var_Int_66 = var_Int_44.T

        
        if self.dp.myProteinID.N_PROTEIN > 1:  
            pca.fit(var_Int_66)
            self.transform = pca.transform(var_Int_66)
            self.ratio = pca.explained_variance_ratio_

            self.__soliderWriteInfo(flag_norm)

    def __soliderWriteInfo(self, flag_norm):

        if flag_norm:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[11]
        else:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[51]

        with open(path, 'w')as f:

            f.write('Experiment\tDimension1({:s})\tDimension2({:s})\n'.format(str(self.ratio[0]), str(self.ratio[1])))

            for i in range(len(self.dp.myProteinID.LIST_EXPERIMENT_ID)):

                f.write(self.dp.myProteinID.LIST_EXPERIMENT_ID[i] + '\t' + str(self.transform[i][0]) + '\t' + \
                        str(self.transform[i][1]) + '\n')


class CFunctionCalcu_5:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP
        self.transform = []

    def __soliderInterpolationWithKNN(self, var_mat_1: np.ndarray, ratio: float):

        var_fla_34 = var_mat_1 > 0.
        var_lis_42 = var_fla_34.shape[1] - np.sum(var_fla_34, axis=1)  
        var_fla_40 = var_lis_42 < (var_mat_1.shape[1] * ratio)

        var_fil_39 = var_mat_1[var_fla_40]
        var_fil_39[var_fil_39 == 0.] = np.nan

        if var_fla_34.shape[0] > 10:
            n_neighbors = 10
        elif var_fla_34.shape[0] > 5:
            n_neighbors = 5
        else:
            n_neighbors = 2

        imputer = KNNImputer(n_neighbors=n_neighbors)
        var_fil_39 = imputer.fit_transform(var_fil_39)

        return var_fil_39

    def calculate(self, var_mat_1: np.ndarray, flag_norm):

        var_mat_27 = self.__soliderInterpolationWithKNN(var_mat_1, ratio=self.dp.myPLOT.THRESHOLD_PCA_INTERPOLATION)

        tsne = TSNE(n_components=2, random_state=33, perplexity=self.dp.myPLOT.T_SNE_PERPLEXITY)
        var_Int_44 = np.array(var_mat_27).copy()
        
        for i in range(var_Int_44.shape[0]):
            mean = np.mean(var_Int_44[i, :])
            std_square = np.sqrt(np.std(var_Int_44[i, :]))
            var_Int_44[i, :] = (var_Int_44[i, :] - mean) / (std_square + 1e-6)
        var_Int_66 = var_Int_44.T

        
        if self.dp.myProteinID.N_PROTEIN > 1:  
            self.transform = tsne.fit_transform(var_Int_66)

            self.__soliderWriteInfo(flag_norm)

    def __soliderWriteInfo(self, flag_norm):

        if flag_norm:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[37]
        else:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[52]

        with open(path, 'w')as f:
            f.write('Experiment\tDimension1\tDimension2\n')
            for i in range(len(self.dp.myProteinID.LIST_EXPERIMENT_ID)):
                f.write(self.dp.myProteinID.LIST_EXPERIMENT_ID[i] + '\t' + str(self.transform[i][0]) + '\t' + \
                        str(self.transform[i][1]) + '\n')


class CFunctionRTAna_3:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP
        self.LIST_PRECURSOR_ID = []

    def analysis(self):

        
        matrix_rt = self.dp.myPrecursorID.MATRIX_RT
        matrix_rt = matrix_rt.astype(float)
        matrix_rt[matrix_rt<0]=np.nan
        
        
        
        
        
        
        
        
        self.dp.myPrecursorID.MATRIX_RT = matrix_rt

        self.__soliderWriteInfo()

    def __soliderWriteInfo(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[5]
        path_npy = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[6]

        np.save(path_npy, self.dp.myPrecursorID.MATRIX_RT)

        with open(path, 'w')as f:

            f.write('Precursor\t' + '\t'.join(self.dp.myPrecursorID.LIST_SAMPLE_ID) + '\n')

            for i in range(len(self.dp.myPrecursorID.LIST_PRECURSOR_ID)):

                f.write(self.dp.myPrecursorID.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_rt) for i_rt in self.dp.myPrecursorID.MATRIX_RT[i]]) + '\n')

    def __soliderWriteNpyInfo(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[6]

        np.save(path, self.dp.myPrecursorID.MATRIX_RT)


class CFunctionIRTAn_7:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def analysis(self):

        
        self.__soliderWriteInfo()

    def __soliderWriteInfo(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[19]

        list_str_moz = ['{:.3f}'.format(i) for i in self.dp.myIDForIRT.PRE4_MOZ_CLC]

        with open(path, 'w')as f:

            f.write('RT\n')

            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')

            for i in range(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)):

                f.write(list_str_moz[i] + 'm/z: ' + self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_rt) for i_rt in self.dp.myIDForIRT.PRELIST2_RT[i]]) + '\n')

            f.write('Intensity\n')

            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')

            for i in range(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_intensity) if i_intensity>0 else str(0.) for i_intensity in self.dp.myIDForIRT.PRELIST8_INTENSITY[i]]) + '\n')


class CFunctionIRTSu_11:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def analysis(self):

        self.__soliderWriteInfo()

    def __soliderWriteInfo(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + r'INFO19_iRT_QC_Summary.txt'

        with open(path, 'w')as f:

            f.write('iRT peptide Number\t{:d}\n'.format(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)))
            f.write('iRT peptide Retention Time[minute]\n')

            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\tMean RT\n')

            list_rt_mean = []
            for i in range(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)):

                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_rt) if i_rt != VALUE_ILLEGAL else 'None'
                     for i_rt in self.dp.myIDForIRT.PRELIST2_RT[i]]) + '\t')
                tmp_mean_rt = np.mean([i_rt for i_rt in self.dp.myIDForIRT.PRELIST2_RT[i] if i_rt != VALUE_ILLEGAL])
                f.write(str(tmp_mean_rt) + '\n')
                list_rt_mean.append(tmp_mean_rt)

            f.write('iRT peptide Retention Time Deviation(RT - Mean RT)[minute]\n')
            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')

            for i in range(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_rt-list_rt_mean[i]) if i_rt != VALUE_ILLEGAL else 'None'
                     for i_rt in self.dp.myIDForIRT.PRELIST2_RT[i]]) + '\n')


            f.write('iRT peptide FWHM[minute]\n')
            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_fwhm) if i_fwhm != VALUE_ILLEGAL else 'None'
                        for i_fwhm in self.dp.myIDForIRT.PRELIST15_FWHM[i]]) + '\n')

            f.write('iRT peptide peak width, start-stop[minute]\n')
            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(self.dp.myIDForIRT.PRELIST4_RT_END[i][j] - self.dp.myIDForIRT.PRELIST3_RT_START[i][j])
                     if self.dp.myIDForIRT.PRELIST3_RT_START[i][j] != VALUE_ILLEGAL else 'None'
                        for j in range(len(self.dp.myIDForIRT.PRELIST3_RT_START[i]))]
                ) + '\n')


            f.write('iRT MS1 Intensity\n')
            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_int) if i_int != VALUE_ILLEGAL else 'None'
                        for i_int in self.dp.myIDForIRT.PRELIST10_MS1_INTENSITY[i]]) + '\n')

            f.write('iRT MS1 Mass Accuracy\n')
            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_mass) if i_mass != VALUE_ILLEGAL else 'None'
                        for i_mass in self.dp.myIDForIRT.PRELIST11_MS1_MASS_ACCURACY[i]]) + '\n')

            f.write('iRT MS2 Intensity\n')
            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_int) if i_int != VALUE_ILLEGAL else 'None'
                     for i_int in self.dp.myIDForIRT.PRELIST_12_MS2_INTENSITY[i]]) + '\n')

            f.write('iRT MS2 Mass Accuracy\n')
            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_mass) if i_mass != VALUE_ILLEGAL else 'None'
                     for i_mass in self.dp.myIDForIRT.PRELIST_13_MS2_MASS_ACCURACY[i]]) + '\n')

            f.write('iRT data point per peak\n')
            f.write('iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + '\t'.join(
                    [str(i_point) if i_point != VALUE_ILLEGAL else 'None'
                        for i_point in self.dp.myIDForIRT.PRELIST_14_DATA_POINT_PRE_PEAK[i]]) + '\n')

            f.write('iRT Quantitation CV\n')
            f.write('iRT precursor\tMS1 CV\tMS2 CV\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                var_tmp_53 = [i_int for i_int in self.dp.myIDForIRT.PRELIST10_MS1_INTENSITY[i] if i_int != VALUE_ILLEGAL]
                var_tmp_68 = [i_int for i_int in self.dp.myIDForIRT.PRELIST_12_MS2_INTENSITY[i] if i_int != VALUE_ILLEGAL]
                if len(var_tmp_53) >= 2:
                    tmp_ms1_cv = toolCalCV(var_tmp_53)
                else:
                    tmp_ms1_cv = VALUE_ILLEGAL

                if len(var_tmp_68) >= 2:
                    tmp_ms2_cv = toolCalCV(var_tmp_68)
                else:
                    tmp_ms2_cv = VALUE_ILLEGAL
                str_ms1_cv = str(tmp_ms1_cv) if tmp_ms1_cv != VALUE_ILLEGAL else 'None'
                str_ms2_cv = str(tmp_ms2_cv) if tmp_ms2_cv != VALUE_ILLEGAL else 'None'
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' +
                        str_ms1_cv + '\t' + str_ms2_cv + '\n')


class CFunctionIRTVi_4:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def __captainGetEvidence(self, inputListEvidence, inputListSeed, inputListIndex):

        nMS1 = len(self.dp.LIST_PATH_MS1)

        for iMS1 in range(nMS1):

            pathMS1 = self.dp.LIST_PATH_MS1[iMS1]
            nameRawMS1 = toolGetNameFromPath(pathMS1)

            dataMS1 = CFileMS1()
            functionParseMS1 =CFunctionParse_6()
            dataMS1 = functionParseMS1.loadPKL(pathMS1)

            for i_Pre in range(self.dp.myIDForIRT.N_PRECURSOR):

                if nameRawMS1 in self.dp.myIDForIRT.LIST_SAMPLE_ID:

                    iIndexMS1 = self.dp.myIDForIRT.LIST_SAMPLE_ID.index(nameRawMS1)

                    if self.dp.myIDForIRT.PRELIST2_RT[i_Pre][iIndexMS1] != VALUE_ILLEGAL or \
                            self.dp.myIDForIRT.PRELIST1_SCAN_ID[i_Pre][iIndexMS1] != VALUE_ILLEGAL:  

                        tmpSeed = self.__soliderFillSeed(i_Pre, iIndexMS1, dataMS1)

                        inputListIndex.append([i_Pre, iIndexMS1])
                        inputListSeed.append(tmpSeed)

                        functionEvidence = CFunctionEvide_1(self.dp)
                        tmpEvidence = functionEvidence.fillEvidence(dataMS1, tmpSeed)

                        inputListEvidence.append(tmpEvidence)

                        tmp_FWHM, tmp_DataPoint, tmpMS1_Intensity, tmpMS1_MassAccuracy = self.__soliderCalQC(tmpEvidence, i_Pre, iIndexMS1)

                        self.dp.myIDForIRT.PRELIST10_MS1_INTENSITY[i_Pre][iIndexMS1] = tmpMS1_Intensity
                        self.dp.myIDForIRT.PRELIST11_MS1_MASS_ACCURACY[i_Pre][iIndexMS1] = tmpMS1_MassAccuracy
                        self.dp.myIDForIRT.PRELIST_14_DATA_POINT_PRE_PEAK[i_Pre][iIndexMS1] = tmp_DataPoint
                        self.dp.myIDForIRT.PRELIST15_FWHM[i_Pre][iIndexMS1] = tmp_FWHM

    def __soliderFillSeed(self, i_Pre, iMS1, dataMS1: CFileMS1):

        myseed = CSeed()
        op_INIT_CSEED(myseed)
        listMS1Scan = dataMS1.INDEX_SCAN
        listMS1RT = dataMS1.INDEX_RT

        if self.dp.myIDForIRT.PRELIST2_RT[i_Pre][iMS1] != VALUE_ILLEGAL:

            indexMS1 = toolFindNeighborFromSortedList1(listMS1RT, 60 * self.dp.myIDForIRT.PRELIST2_RT[i_Pre][iMS1])
        else:
            indexMS1 = toolFindNeighborFromSortedList1(listMS1Scan, self.dp.myIDForIRT.PRELIST1_SCAN_ID[i_Pre][iMS1])

        myseed.MID_SCAN = dataMS1.INDEX_SCAN[indexMS1]
        myseed.MID_RT = dataMS1.INDEX_RT[indexMS1]

        tmpListMoz = [self.dp.myIDForIRT.PRE4_MOZ_CLC[i_Pre] + i_iso * 1.003
                      / self.dp.myIDForIRT.PRE3_CHARGE[i_Pre] for i_iso in range(5)]
        myseed.DIS_ISO_MOZ_CLC = tmpListMoz

        return myseed

    def __soliderCalQC(self, inputEvidence: CEvidence, inputPre: int, inputIndexMS1: int):

        rt_start = self.dp.myIDForIRT.PRELIST3_RT_START[inputPre][inputIndexMS1] * 60.
        rt_end = self.dp.myIDForIRT.PRELIST4_RT_END[inputPre][inputIndexMS1] * 60.
        rt = self.dp.myIDForIRT.PRELIST2_RT[inputPre][inputIndexMS1] * 60.

        index_start = toolFindNeighborFromSortedList1(inputEvidence.LIST_RET_TIME, rt_start)
        index_end = toolFindNeighborFromSortedList1(inputEvidence.LIST_RET_TIME, rt_end)
        index_apex = toolFindNeighborFromSortedList1(inputEvidence.LIST_RET_TIME, rt)
        outDataPoint = index_end - index_start + 1

        var_lis_16 = inputEvidence.MATRIX_PROFILE[0][index_start: index_end]
        var_int_49 = np.max(var_lis_16)
        var_ind_3 = np.argmax(var_lis_16)
        index_intensity_left_FWHM = toolFindNeighborFromDisorderdList(var_lis_16[: var_ind_3], var_int_49/2)
        index_intensity_right_FWHM = var_ind_3 + toolFindNeighborFromDisorderdList(var_lis_16[var_ind_3:], var_int_49/2)
        rt_left_FWHM = inputEvidence.LIST_RET_TIME[index_start + index_intensity_left_FWHM]
        rt_right_FWHM = inputEvidence.LIST_RET_TIME[index_start + index_intensity_right_FWHM]
        outFWHM = (rt_right_FWHM - rt_left_FWHM) / 60.

        var_lis_31 = inputEvidence.MATRIX_MASS_ACCURACY[0][index_start: index_end]
        outMS1_Intensity = np.sum(var_lis_16)
        outMS1_MassAccuracy = np.mean(var_lis_31)

        return outFWHM, outDataPoint, outMS1_Intensity, outMS1_MassAccuracy

    def __captainWriteIXC(self, inputListEvidence, inputListSeed, inputListIndex):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[6]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[7]

        with open(path_out, 'wb')as f:
            pickle.dump([inputListEvidence, inputListSeed, inputListIndex], f)

        with open(path, 'w')as f:

            f.write('@number:{:d}'.format(len(inputListIndex)) + '\n')

            for i in range(len(inputListIndex)):

                index_pre, index_raw = inputListIndex[i][0], inputListIndex[i][1]
                tmp_seq = self.dp.myIDForIRT.PRE1_SEQ[index_pre]
                tmp_mod = self.dp.myIDForIRT.PRE2_MOD[index_pre]
                tmp_charge = str(self.dp.myIDForIRT.PRE3_CHARGE[index_pre])
                tmp_raw = self.dp.myIDForIRT.LIST_EXPERIMENT_ID[index_raw]
                list_moz = inputListSeed[i].DIS_ISO_MOZ_CLC
                mid_scan = str(inputListSeed[i].MID_SCAN)
                mid_rt = str(inputListSeed[i].MID_RT / 60)
                left_rt = str(self.dp.myIDForIRT.PRELIST3_RT_START[index_pre][index_raw])
                right_rt = str(self.dp.myIDForIRT.PRELIST4_RT_END[index_pre][index_raw])

                f.write('@{:d}\n'.format(i+1))
                f.write('RAW\t' + tmp_raw + '\n')
                f.write('SEQ\t' + tmp_seq + '\n')
                f.write('MOD\t' + tmp_mod + '\n')
                f.write('CHARGE\t' + tmp_charge + '\n')
                f.write('MID SCAN\t' + mid_scan + '\n')
                f.write('MID RT\t' + mid_rt + '\n')
                f.write('LEFT RT\t' + left_rt + '\n')
                f.write('RIGHT RT\t' + right_rt + '\n')
                f.write('Scan\t' + '\t'.join([str(i_scan) for i_scan in inputListEvidence[i].LIST_SCAN]) + '\n')
                f.write('RT\t' + '\t'.join([str(i_rt / 60) for i_rt in inputListEvidence[i].LIST_RET_TIME]) + '\n')
                for i_iso in range(inputListEvidence[i].MATRIX_PROFILE.shape[0]):
                    f.write('Istope{:.4f}\t'.format(list_moz[i_iso]) + '\t'.join(
                        [str(float(i_int)) for i_int in inputListEvidence[i].MATRIX_PROFILE[i_iso]]) + '\n')

    def analysis(self):

        listEvidence = []
        listSeed = []
        listIndex = []

        self.__captainGetEvidence(listEvidence, listSeed, listIndex)
        self.__captainWriteIXC(listEvidence, listSeed, listIndex)


class CFunctionVisua_8:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def __soliderExtractPrint(self, inputPath):

        with open(inputPath, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table = lines[4].split('\t')
        var_pos_59 = table.index('msType')
        position_scan = table.index('Scan')
        position_rt = table.index('RT')
        var_pos_69 = table.index('IsolationWindow')

        dic_win_info = {}
        list_scan = []
        list_rt = []
        list_window = []
        count_window = 0
        dic_win = {}
        list_win = []
        dic_win_index = {}

        for line in lines[5:]:

            if line:
                line_list = line.split('\t')
                i_type = int(line_list[var_pos_59])
                if i_type == 2:

                    i_scan = int(line_list[position_scan])
                    i_rt = float(line_list[position_rt])
                    i_window = line_list[var_pos_69]
                    var_iwi_50 = float(i_window.split('-')[0])
                    i_window_end = float(i_window.split('-')[1])

                    list_scan.append(i_scan)
                    list_rt.append(i_rt)
                    list_window.append(i_window)
                    if i_window not in dic_win:
                        count_window += 1
                        dic_win[i_window] = count_window
                        dic_win_info[count_window] = [[], []]
                        list_win.append([var_iwi_50, i_window_end, i_window])

                    dic_win_info[dic_win[i_window]][0].append(i_scan)
                    dic_win_info[dic_win[i_window]][1].append(i_rt)

        list_win.sort(key=lambda x: x[0])
        list_win = [np.array([i[0] for i in list_win]), np.array([i[1] for i in list_win]), [i[2] for i in list_win]]

        return dic_win, dic_win_info, list_win, list_rt, list_scan


    def __captainGetEvidence(self, inputListEvidence, inputListSeed, inputListIndex):

        nMS1 = len(self.dp.LIST_PATH_MS1)

        for iMS1 in range(nMS1):

            pathMS1 = self.dp.LIST_PATH_MS1[iMS1]
            nameRawMS1 = toolGetNameFromPath(pathMS1)

            dataMS1 = CFileMS1()
            functionParseMS1 =CFunctionParse_6()
            dataMS1 = functionParseMS1.loadPKL(pathMS1)

            pathPrint = pathMS1.split('.')[0] + '.print'
            dic_win, dic_win_info, list_win, list_rt_ms2, list_scan_ms2 = self.__soliderExtractPrint(pathPrint)
            dic_scan_info = {}
            dic_pre_info = {}
            dic_ms1_premz = {}
            len_win = len(list_win[0])

            for i_Pre in range(self.dp.myPrecursorID.N_PRECURSOR):

                if nameRawMS1 in self.dp.myIDForIRT.LIST_SAMPLE_ID:

                    iIndexMS1 = self.dp.myIDForIRT.LIST_SAMPLE_ID.index(nameRawMS1)

                    if self.dp.myPrecursorID.PRELIST1_RT[i_Pre][iIndexMS1] != VALUE_ILLEGAL:  

                        pre_moz = inputListSeed[i_Pre][0]
                        var_lis_36 = inputListSeed[i_Pre][1]
                        
                        if self.dp.myPrecursorID.PRELIST1_RT[i_Pre][iIndexMS1]:
                            i_rt_mid = self.dp.myPrecursorID.PRELIST1_RT[i_Pre][iIndexMS1]
                            i_rt_start = self.dp.myPrecursorID.PRELIST3_RTSTART[i_Pre][iIndexMS1] * 60
                            i_rt_end = self.dp.myPrecursorID.PRELIST4_RTEND[i_Pre][iIndexMS1] * 60
                            i_charge = int(self.dp.myPrecursorID.PRE3_CHARGE[i_Pre])
                            var_iwi_21 = np.searchsorted(list_win[0], pre_moz)
                            var_iwi_21 = min(var_iwi_21, len_win-1)
                            var_iwi_21 = var_iwi_21 if list_win[0][var_iwi_21] <= pre_moz else var_iwi_21-1
                            i_window = dic_win[list_win[2][var_iwi_21]]
                            list_rt = dic_win_info[i_window][1]
                            index_start = np.searchsorted(list_rt, i_rt_start)
                            index_end = np.searchsorted(list_rt, i_rt_end)
                            
                            var_ind_38 = np.searchsorted(dataMS1.INDEX_RT, i_rt_start)
                            index_end_ms1 = np.searchsorted(dataMS1.INDEX_RT, i_rt_end)
                            var_lis_8 = list(range(var_ind_38, index_end_ms1+1))
                            for i_index_ms1 in var_lis_8:
                                if i_index_ms1 not in dic_ms1_premz:
                                    dic_ms1_premz[i_index_ms1] = []
                                dic_ms1_premz[i_index_ms1].extend([pre_moz,pre_moz + 1.003/i_charge, pre_moz + 2*1.003/i_charge])
                            
                            list_ID_scan = dic_win_info[i_window][0][index_start: index_end]
                            if i_Pre not in dic_pre_info:
                                dic_pre_info[i_Pre] = [i_rt_mid, len(list_ID_scan), list_ID_scan[0]]
                            for i_scan in list_ID_scan:
                                if i_scan not in dic_scan_info:
                                    dic_scan_info[i_scan] = [[],[]]
                                dic_scan_info[i_scan][0].append(pre_moz)
                                dic_scan_info[i_scan][1].extend(var_lis_36)
            with open('tmp/dic_ms1_mz', 'wb')as f:
                pickle.dump(dic_ms1_premz, f)
        input('123')
        nMS2 = len(self.dp.LIST_PATH_MS2)
        del dataMS1

        for iMS2 in range(nMS2):
            pathMS2 = self.dp.LIST_PATH_MS2[iMS2]
            nameRawMS2 = toolGetNameFromPath(pathMS2)
            print(iMS2)
            dataMS2 = CFileMS2()
            functionParseMS2 = CFunctionParse_10()
            dataMS2 = functionParseMS2.loadPKL(pathMS2)
            var_lis_17 = []
            list_moz_ms21 = []
            var_lis_47 = []
            for i in dataMS2.INDEX_SCAN[dataMS2.INDEX_SCAN.index(70001):]:
                if i in dic_scan_info:
                    list_moz_ms2 = dataMS2.MATRIX_PEAK_MOZ[i]
                    list_int_ms2 = dataMS2.MATRIX_PEAK_INT[i]
                    all_int = np.sum(list_int_ms2)
                    top_int = np.sort(list_int_ms2)[-2:]
                    var_lis_4 = dic_scan_info[i][1]

                    var_lis_4 = np.array(var_lis_4).reshape(-1, )
                    var_lis_4 = np.sort(var_lis_4)

                    num_id_peak = 0
                    int_matched = 0
                    moz_index = np.searchsorted(list_moz_ms2, var_lis_4)
                    
                    for j in range(len(moz_index)):
                        i_moz_frag = var_lis_4[j]
                        if moz_index[j] == 0:
                            moz_index[j] += 1
                        elif moz_index[j] == len(list_moz_ms2):
                            moz_index[j] -= 1
                        
                        var_nei_65 = moz_index[j]-1 if i_moz_frag - list_moz_ms2[moz_index[j]-1] <= list_moz_ms2[moz_index[j]] - i_moz_frag else moz_index[j]
                        if abs(list_moz_ms2[var_nei_65] - i_moz_frag) / i_moz_frag * 1e6 <= 20:
                            
                            num_id_peak+=1
                            int_matched += list_int_ms2[var_nei_65]
                    var_lis_17.append(
                        [i, len(list_moz_ms2), num_id_peak, all_int, int_matched, top_int[0], top_int[1]])
                else:
                    list_moz_ms2 = dataMS2.MATRIX_PEAK_MOZ[i]
                    top_int = np.sort(dataMS2.MATRIX_PEAK_INT[i])[-2:]
                    num_id_peak = 0
                    all_int = np.sum(dataMS2.MATRIX_PEAK_INT[i])
                    int_matched = 0
                    var_lis_17.append([i, len(list_moz_ms2), num_id_peak, all_int, int_matched, top_int[0], top_int[1]])


            pathPrint = pathMS2.split('.')[0] + '.print'
            dic_win, dic_win_info, list_win, list_rt_ms2, list_scan_ms2 = self.__soliderExtractPrint(pathPrint)
            dic_scan_info = {}
            dic_pre_info = {}

        return dic_pre_info, dic_scan_info, list_rt_ms2, list_scan_ms2, var_lis_17

    def __captainFillAllSeed(self, inputListSeed):

        nPre = self.dp.myPrecursorID.N_PRECURSOR
        LossDic = {}

        for i_pre in range(nPre):

            
            Sequence = self.dp.myPrecursorID.PRE1_SEQ[i_pre]
            Mod_dict = self.dp.myPrecursorID.PRE2_MOD[i_pre]
            Charge = self.dp.myPrecursorID.PRE3_CHARGE[i_pre]
            

            
            tmp_b_mass = 0.0
            b_mass_list = np.zeros(shape=(len(Sequence) - 1, 1))
            var_Pre_33 = 0.

            for i, aa in enumerate(Sequence):
                tmp_b_mass += self.dp.myINI.DICT1_AA_COM[aa][1]
                if i in Mod_dict:
                    tmp_b_mass += float(self.dp.myINI.DICT2_MOD_COM[Mod_dict[i]][1])
                if i < len(Sequence) - 1:
                    b_mass_list[i] = tmp_b_mass
                else:
                    var_Pre_33 = tmp_b_mass + 1.0078246*2 + 15.9949141
            Precursor_moz = (var_Pre_33 + Charge * self.dp.myINI.MASS_PROTON_MONO) / Charge
            var_lis_36 = []
            y_mass_list = var_Pre_33 - b_mass_list
            y_mass_list = np.sort(y_mass_list.reshape([1, -1])).reshape([-1, 1])
            for tmp_charge in range(1, min(Charge + 1, 3)):
                
                var_tmp_25 = (b_mass_list + tmp_charge * self.dp.myINI.MASS_PROTON_MONO) / tmp_charge
                var_lis_36.extend(list(var_tmp_25))
                
                
                
                var_tmp_60 = (y_mass_list + tmp_charge * self.dp.myINI.MASS_PROTON_MONO) / tmp_charge
                var_lis_36.extend(list(var_tmp_60))
                
                
                
                for Loss in LossDic.keys():
                    loss_mass = LossDic[Loss]
                    var_tmp_25 = (
                                                 b_mass_list - loss_mass + tmp_charge * self.dp.myINI.MASS_PROTON_MONO) / tmp_charge
                    var_lis_36.extend(list(var_tmp_25))

                    var_tmp_60 = (
                                                 y_mass_list - loss_mass + tmp_charge * self.dp.myINI.MASS_PROTON_MONO) / tmp_charge
                    var_lis_36.extend(list(var_tmp_60))

            inputListSeed.append([Precursor_moz, var_lis_36, ])

        return inputListSeed

    def __soliderCalQC(self, inputEvidence: CEvidence, inputPre: int, inputIndexMS1: int):

        rt_start = self.dp.myIDForIRT.PRELIST3_RT_START[inputPre][inputIndexMS1] * 60.
        rt_end = self.dp.myIDForIRT.PRELIST4_RT_END[inputPre][inputIndexMS1] * 60.
        rt = self.dp.myIDForIRT.PRELIST2_RT[inputPre][inputIndexMS1] * 60.

        index_start = toolFindNeighborFromSortedList1(inputEvidence.LIST_RET_TIME, rt_start)
        index_end = toolFindNeighborFromSortedList1(inputEvidence.LIST_RET_TIME, rt_end)
        index_apex = toolFindNeighborFromSortedList1(inputEvidence.LIST_RET_TIME, rt)
        outDataPoint = index_end - index_start + 1

        var_lis_16 = inputEvidence.MATRIX_PROFILE[0][index_start: index_end]
        var_int_49 = np.max(var_lis_16)
        var_ind_3 = np.argmax(var_lis_16)
        index_intensity_left_FWHM = toolFindNeighborFromDisorderdList(var_lis_16[: var_ind_3], var_int_49/2)
        index_intensity_right_FWHM = var_ind_3 + toolFindNeighborFromDisorderdList(var_lis_16[var_ind_3:], var_int_49/2)
        rt_left_FWHM = inputEvidence.LIST_RET_TIME[index_start + index_intensity_left_FWHM]
        rt_right_FWHM = inputEvidence.LIST_RET_TIME[index_start + index_intensity_right_FWHM]
        outFWHM = (rt_right_FWHM - rt_left_FWHM) / 60.

        var_lis_31 = inputEvidence.MATRIX_MASS_ACCURACY[0][index_start: index_end]
        outMS1_Intensity = np.sum(var_lis_16)
        outMS1_MassAccuracy = np.mean(var_lis_31)

        return outFWHM, outDataPoint, outMS1_Intensity, outMS1_MassAccuracy

    def __captainWriteIXC(self, inputListEvidence, inputListSeed, inputListIndex):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[6]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[7]

        with open(path_out, 'wb')as f:
            pickle.dump([inputListEvidence, inputListSeed, inputListIndex], f)

        with open(path, 'w')as f:

            f.write('@number:{:d}'.format(len(inputListIndex)) + '\n')

            for i in range(len(inputListIndex)):

                index_pre, index_raw = inputListIndex[i][0], inputListIndex[i][1]
                tmp_seq = self.dp.myIDForIRT.PRE1_SEQ[index_pre]
                tmp_mod = self.dp.myIDForIRT.PRE2_MOD[index_pre]
                tmp_charge = str(self.dp.myIDForIRT.PRE3_CHARGE[index_pre])
                tmp_raw = self.dp.myIDForIRT.LIST_EXPERIMENT_ID[index_raw]
                list_moz = inputListSeed[i].DIS_ISO_MOZ_CLC
                mid_scan = str(inputListSeed[i].MID_SCAN)
                mid_rt = str(inputListSeed[i].MID_RT / 60)
                left_rt = str(self.dp.myIDForIRT.PRELIST3_RT_START[index_pre][index_raw])
                right_rt = str(self.dp.myIDForIRT.PRELIST4_RT_END[index_pre][index_raw])

                f.write('@{:d}\n'.format(i+1))
                f.write('RAW\t' + tmp_raw + '\n')
                f.write('SEQ\t' + tmp_seq + '\n')
                f.write('MOD\t' + tmp_mod + '\n')
                f.write('CHARGE\t' + tmp_charge + '\n')
                f.write('MID SCAN\t' + mid_scan + '\n')
                f.write('MID RT\t' + mid_rt + '\n')
                f.write('LEFT RT\t' + left_rt + '\n')
                f.write('RIGHT RT\t' + right_rt + '\n')
                f.write('Scan\t' + '\t'.join([str(i_scan) for i_scan in inputListEvidence[i].LIST_SCAN]) + '\n')
                f.write('RT\t' + '\t'.join([str(i_rt / 60) for i_rt in inputListEvidence[i].LIST_RET_TIME]) + '\n')
                for i_iso in range(inputListEvidence[i].MATRIX_PROFILE.shape[0]):
                    f.write('Istope{:.4f}\t'.format(list_moz[i_iso]) + '\t'.join(
                        [str(float(i_int)) for i_int in inputListEvidence[i].MATRIX_PROFILE[i_iso]]) + '\n')

    def __captainPlot(self, dic_pre_info, dic_scan_info, list_rt_ms2, list_scan_ms2):

        
        dic_rt_ms2 = {}
        for i in range(len(list_rt_ms2)):
            dic_rt_ms2[list_scan_ms2[i]] = list_rt_ms2[i]
        list_scan_id = list(dic_scan_info.keys())
        list_scan_id.sort()
        var_lis_7 = [0] + [i for i in range(len(list_scan_id))]
        var_lis_18 = [0] + [dic_rt_ms2[i] for i in list_scan_id]

        var_lis_26 = [0] + [dic_pre_info[i][0]*60 for i in dic_pre_info]
        var_lis_26.sort()
        list_pre_id = [i for i in range(len(var_lis_26))]
        plt.plot(list_rt_ms2, list_scan_ms2, color='#000000')
        plt.plot(var_lis_18, var_lis_7, color='#0000FF')
        plt.plot(var_lis_26, list_pre_id, color='#FF0000')
        plt.xlabel('RetTime')
        plt.ylabel('Count')
        plt.savefig('0.svg', format='svg')
        plt.close()
        var_lis_20 = []
        var_lis_37 = []
        for i in dic_pre_info:
            var_lis_20.append(dic_pre_info[i][1])
            var_lis_37.append(dic_pre_info[i][0])

        var_lis_48 = []
        list_scan = []
        for i in dic_scan_info:
            var_lis_48.append(len(dic_scan_info[i][0]))
            list_scan.append(i)


        print(np.mean(var_lis_20))
        plt.hist(var_lis_20, bins=50, color='b', edgecolor='#000000')
        plt.savefig('1.svg', format='svg')
        plt.close()
        plt.scatter(var_lis_37, var_lis_20, color='b', s=0.2)
        plt.xlim(0, 7)
        plt.savefig('2.png', format='png')
        plt.close()

        print(np.mean(var_lis_48))
        plt.hist(var_lis_48, bins=50, color='b', edgecolor='#000000')
        plt.savefig('3.svg', format='svg')
        plt.close()
        plt.scatter(list_scan, var_lis_48, color='b', s=0.2)
        
        plt.savefig('4.png', format='png')


    def analysis(self):

        listEvidence = []
        listSeed = []
        listIndex = []

        self.__captainFillAllSeed(listSeed)
        dic_pre_info, dic_scan_info, list_rt_ms2, list_scan_ms2, var_lis_17 = self.__captainGetEvidence(listEvidence, listSeed, listIndex)
        with open('ms2_peak.txt', 'a')as f:
            for i in range(len(var_lis_17)):
                f.write('\t'.join([str(j) for j in var_lis_17[i]]) + '\n')
                
                
        input('**************')
        self.__captainPlot(dic_pre_info, dic_scan_info, list_rt_ms2, list_scan_ms2)


class CFunctionIRTVi_12:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def __soliderMod2Dict(self, inputMod):

        
        
        dic_Mod = {}

        return dic_Mod

    def __captainFillAllSeed(self, inputListSeed):

        nPre = self.dp.myIDForIRT.N_PRECURSOR
        LossDic = {}

        for i_pre in range(nPre):

            myseed = CSeed()
            op_INIT_CSEED(myseed)
            
            i_seq = self.dp.myIDForIRT.PRE1_SEQ[i_pre]
            i_mod = self.dp.myIDForIRT.PRE2_MOD[i_pre]
            i_charge = self.dp.myIDForIRT.PRE3_CHARGE[i_pre]

            Sequence = self.dp.myIDForIRT.PRE1_SEQ[i_pre]
            Mod_dict = self.__soliderMod2Dict(self.dp.myIDForIRT.PRE2_MOD[i_pre])
            Charge = self.dp.myIDForIRT.PRE3_CHARGE[i_pre]
            Precursor_moz = self.dp.myIDForIRT.PRE4_MOZ_CLC[i_pre]

            
            tmp_b_mass = 0.0
            b_mass_list = np.zeros(shape=(len(Sequence) - 1, 1))
            var_Pre_33 = Precursor_moz * Charge - Charge * self.dp.myINI.MASS_PROTON_MONO
            for i, aa in enumerate(Sequence[:-1]):
                tmp_b_mass += self.dp.myINI.DICT1_AA_COM[aa][1]
                if i in Mod_dict:
                    tmp_b_mass += float(self.dp.myINI.DICT2_MOD_COM[Mod_dict[i]][1])
                b_mass_list[i] = tmp_b_mass
            y_mass_list = var_Pre_33 - b_mass_list
            y_mass_list = np.sort(y_mass_list.reshape([1, -1])).reshape([-1, 1])
            for tmp_charge in range(1, min(Charge + 1, 3)):
                
                var_tmp_25 = (b_mass_list + tmp_charge * self.dp.myINI.MASS_PROTON_MONO) / tmp_charge
                myseed.MOZ_FRAGMENT.extend(list(var_tmp_25))
                myseed.TYPE_FRAGMENT.extend([''.join(['b', str(i + 1), '+' * tmp_charge])
                                             for i in range(len(Sequence) - 1)])
                
                var_tmp_60 = (y_mass_list + tmp_charge * self.dp.myINI.MASS_PROTON_MONO) / tmp_charge
                myseed.MOZ_FRAGMENT.extend(list(var_tmp_60))
                myseed.TYPE_FRAGMENT.extend([''.join(['y', str(i + 1), '+' * tmp_charge])
                                             for i in range(len(Sequence) - 1)])
                
                for Loss in LossDic.keys():
                    loss_mass = LossDic[Loss]
                    var_tmp_25 = (b_mass_list - loss_mass + tmp_charge * self.dp.myINI.MASS_PROTON_MONO) / tmp_charge
                    myseed.MOZ_FRAGMENT.extend(list(var_tmp_25))
                    myseed.TYPE_FRAGMENT.extend([''.join(['b', str(i + 1), '+' * tmp_charge, '_' + Loss])
                                                 for i in range(len(Sequence) - 1)])
                    var_tmp_60 = (y_mass_list - loss_mass + tmp_charge * self.dp.myINI.MASS_PROTON_MONO) / tmp_charge
                    myseed.MOZ_FRAGMENT.extend(list(var_tmp_60))
                    myseed.TYPE_FRAGMENT.extend([''.join(['y', str(i + 1), '+' * tmp_charge, '_' + Loss])
                                                 for i in range(len(Sequence) - 1)])

            inputListSeed.append(myseed)

        return inputListSeed

    def __captainGetEvidence(self, inputListEvidence, inputListIndex, inputListSeed):

        nMS2 = len(self.dp.LIST_PATH_MS2)

        for iMS2 in range(nMS2):

            pathMS2 = self.dp.LIST_PATH_MS2[iMS2]
            nameRawMS2 = toolGetNameFromPath(pathMS2)

            dataMS2 = CFileMS2()
            functionParseMS2 =CFunctionParse_10()
            dataMS2 = functionParseMS2.loadPKL(pathMS2)

            for i_Pre in range(self.dp.myIDForIRT.N_PRECURSOR):

                if nameRawMS2 in self.dp.myIDForIRT.LIST_SAMPLE_ID:

                    iIndexMS2 = self.dp.myIDForIRT.LIST_SAMPLE_ID.index(nameRawMS2)

                    if self.dp.myIDForIRT.PRELIST1_SCAN_ID[i_Pre][iIndexMS2] != VALUE_ILLEGAL:  
                        
                        list_MID_SCAN = self.dp.myIDForIRT.PRELIST1_SCAN_ID[i_Pre][iIndexMS2]
                        list_PSM_FDR = self.dp.myIDForIRT.PRELIST6_SCORE0[i_Pre][iIndexMS2]
                        
                        var_lis_54 = np.argsort(list_PSM_FDR)
                        list_MID_SCAN = [list_MID_SCAN[index] for index in var_lis_54]
                        
                        list_MID_SCAN = list_MID_SCAN[:5] if len(list_MID_SCAN) > 5 else list_MID_SCAN

                        for i, tmp_MID_SCAN in enumerate(list_MID_SCAN):

                            functionEvidence = CFunctionEvide_1(self.dp)
                            tmpEvidence = functionEvidence.fillEvidenceForLabel(dataMS2, tmp_MID_SCAN)

                            inputListIndex.append([i_Pre, iIndexMS2, tmp_MID_SCAN, tmpEvidence.LIST_RET_TIME])

                            inputListEvidence.append(tmpEvidence)

                            if i == 0: 
                                
                                var_top_56, var_top_58 = self.__soliderCalTop6FragmentForPSM(tmpEvidence, inputListSeed[i_Pre])

                                if len(var_top_56) > 0 and len(var_top_58) > 0:
                                    self.dp.myIDForIRT.PRELIST_12_MS2_INTENSITY[i_Pre][iIndexMS2] = np.sum(var_top_56)
                                    self.dp.myIDForIRT.PRELIST_13_MS2_MASS_ACCURACY[i_Pre][iIndexMS2] = np.mean(var_top_58)
                                else:
                                    pass

    def __soliderCalTop6FragmentForPSM(self, inputEvidence: CEvidence, inputSeed: CSeed):

        list_pre_moz = inputSeed.MOZ_FRAGMENT
        list_ms2_moz = inputEvidence.MS2_PEAK_MOZ
        list_ms2_int = inputEvidence.MS2_PEAK_INT

        
        var_lis_32 = []
        var_lis_11 = []
        for tmp_moz in list_pre_moz:
            tmp_index = toolFindNeighborFromSortedList1(list_ms2_moz, tmp_moz)
            var_tmp_5 = abs((list_ms2_moz[tmp_index] - tmp_moz)/tmp_moz) * 1e6
            if var_tmp_5 <= self.dp.myCFG.C13_DDA_FRAGMENT_PPM_HALF_WIN_ACCURACY_PEAK:

                var_lis_32.append(tmp_index)
                var_lis_11.append(var_tmp_5)

        var_lis_45 = [list_ms2_int[i] for i in var_lis_32]
        if len(var_lis_45) > 0:
            var_lis_43 = np.argsort([-1 * i_int for i_int in var_lis_45])
            var_lis_43 = var_lis_43[:6] if len(var_lis_43) >= 6 else var_lis_43
            out_match_int = [var_lis_45[i] for i in var_lis_43]
            var_out_9 = [var_lis_11[i] for i in var_lis_43]

            return out_match_int, var_out_9
        else:
            return [], []

    def __captainWriteLabel(self, inputListEvidence, inputListSeed, inputListIndex):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[7]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[8]

        with open(path_out, 'wb')as f:
            pickle.dump([inputListEvidence, inputListSeed, inputListIndex], f)

        with open(path, 'w')as f:

            f.write('@number:{:d}'.format(len(inputListIndex)) + '\n')

            for i in range(len(inputListIndex)):

                index_pre, index_raw = inputListIndex[i][0], inputListIndex[i][1]
                tmp_seq = self.dp.myIDForIRT.PRE1_SEQ[index_pre]
                tmp_mod = self.dp.myIDForIRT.PRE2_MOD[index_pre]
                tmp_charge = str(self.dp.myIDForIRT.PRE3_CHARGE[index_pre])
                tmp_raw = self.dp.myIDForIRT.LIST_EXPERIMENT_ID[index_raw]
                mid_scan = str(self.dp.myIDForIRT.PRELIST1_SCAN_ID[index_pre][index_raw])

                f.write('@{:d}\n'.format(i + 1))
                f.write('RAW\t' + tmp_raw + '\n')
                f.write('SEQ\t' + tmp_seq + '\n')
                f.write('MOD\t' + tmp_mod + '\n')
                f.write('CHARGE\t' + tmp_charge + '\n')
                f.write('SCAN\t' + mid_scan + '\n')
                f.write('RT\t' + str(inputListEvidence[i].LIST_RET_TIME / 60.))
                f.write('TYPE FRAGMENT\t' + '\t'.join([i_type for i_type in inputListSeed[index_pre].TYPE_FRAGMENT]) + '\n')
                f.write('MOZ FRAGMENT\t' + '\t'.join([str(float(i_moz)) for i_moz in inputListSeed[index_pre].MOZ_FRAGMENT]) + '\n')
                f.write('MS2 MOZ\t' + '\t'.join([str(i_moz) for i_moz in inputListEvidence[i].MS2_PEAK_MOZ]) + '\n')
                f.write('MS2 INTENSITY\t' + '\t'.join(str(i_int) for i_int in inputListEvidence[i].MS2_PEAK_INT) + '\n')

    def analysis(self):

        listEvidence = []
        listSeed = []
        listIndex = []

        listSeed = self.__captainFillAllSeed(listSeed)
        self.__captainGetEvidence(listEvidence, listIndex, listSeed)
        self.__captainWriteLabel(listEvidence, listSeed, listIndex)


class CFunctionDiffA_13:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP
        self.group_name = []
        self.var_gro_67 = []
        self.var_gro_19 = []

        self.S0 = 0
        self.var_Fol_10 = 2
        self.FDR_threshold = 0.05

    def __captainCalFDR(self, matrix_X: np.ndarray, matrix_Y: np.ndarray, var_lis_28: list,
                        OutputPath_txt: str, OutputPaht_pic: str):

        
        v = 2 * matrix_X.shape[-1] - 2
        X_mean = np.mean(matrix_X, axis=1)
        Y_mean = np.mean(matrix_Y, axis=1)
        X_variance = np.var(matrix_X, axis=1)
        Y_variance = np.var(matrix_Y, axis=1)

        
        t_value = (-1 * abs(X_mean - Y_mean)) / (np.sqrt(2 * (X_variance + Y_variance) / v) + self.S0)
        

        pValue = (t.cdf(t_value, v)) * 2
        pValue = pValue.reshape([pValue.shape[0], -1])

        
        
        
        FDR = np.zeros(shape=pValue.shape)
        
        sort_index = np.argsort(-1 * pValue, axis=0)
        sort_index = sort_index.reshape([sort_index.shape[0]])
        pValue = pValue[sort_index]
        matrix_X = matrix_X[sort_index]
        matrix_Y = matrix_Y[sort_index]
        var_lis_28 = [var_lis_28[i] for i in sort_index]
        
        n_pvalue = pValue.shape[0]
        for i in range(pValue.shape[0]):
            FDR[i] = pValue[i] * n_pvalue / (n_pvalue - i)
            if i > 0 and FDR[i] > FDR[i - 1]:
                FDR[i] = FDR[i - 1]
        FDRValue = FDR

        
        
        LogPvalue = -1 * np.log10(pValue)
        
        
        Difference = np.mean(matrix_X, axis=1) - np.mean(matrix_Y, axis=1)
        
        if self.var_Fol_10 != 0:
            var_lab_64 = (Difference > self.var_Fol_10) + (Difference < -1 * self.var_Fol_10)
        else:
            var_lab_64 = True
        
        var_lab_51 = (FDRValue <= self.FDR_threshold).reshape([-1])
        
        labeled_index = var_lab_51 * var_lab_64

        
        
        labeled_LogPvalue = LogPvalue[labeled_index]
        var_lab_41 = Difference[labeled_index]
        labeled_ProteinName = []
        for i in range(labeled_index.shape[0]):
            if labeled_index[i] == True:
                labeled_ProteinName.append(var_lis_28[i])
        
        min_x_range = floor(min(Difference))
        max_x_range = ceil(max(Difference))
        min_y_range = floor(min(LogPvalue))
        max_y_range = ceil(max(LogPvalue))
        plt.figure(figsize=(10, 8))
        plt.scatter(Difference, LogPvalue, c='#9C9C9C', marker='s', edgecolors='#9C9C9C', norm=1, s=10)
        plt.scatter(var_lab_41, labeled_LogPvalue, c='#FF0000', marker='s', edgecolors='#FF0000', norm=1, s=10)
        for i in range(len(labeled_ProteinName)):
            plt.text(var_lab_41[i] + 0.05, labeled_LogPvalue[i] - 0.15, labeled_ProteinName[i],
                     fontdict={'color': 'r', 'size': 9})
        plt.xlabel('log2 Fold Change')
        plt.ylabel('-Log10 Pvalue')
        plt.xlim(-1 * max(abs(min_x_range), abs(max_x_range)) - 0.2, max(abs(min_x_range), abs(max_x_range)) + 0.2)
        plt.ylim(min_y_range - 0.05, max_y_range + 0.2)
        
        point_x_right = [self.var_Fol_10 for i in range(min_y_range, max_y_range + 1)]
        point_x_left = [-1 * self.var_Fol_10 for i in range(min_y_range, max_y_range + 1)]
        point_y = [i for i in range(min_y_range, max_y_range + 1)]
        plt.plot(point_x_right, point_y, linestyle=':', color='#BEBEBE')
        plt.plot(point_x_left, point_y, linestyle=':', color='#BEBEBE')
        plt.savefig(OutputPaht_pic, format="png", dpi=300)
        
        with open(OutputPath_txt, 'w')as f:
            f.write('\t'.join(
                ['protein_name', 'Difference', 'Pvalue', 'Pvalue(-log10)', 'qvalue', 'Significant_Difference']) + '\n')
            for i in range(len(var_lis_28) - 1, -1, -1):
                string_list = [var_lis_28[i], str(float(Difference[i])), str(float(10 ** (-1 * LogPvalue[i]))),
                               str(float(LogPvalue[i])), str(float(FDRValue[i])), str(labeled_index[i])]
                f.write('\t'.join(string_list) + '\n')

    def  analysis(self):

        
        
        self.group_name = [i_group[0] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_67 = [i_group[1] for i_group in self.dp.LIST_EXPERIMENT_GROUP]
        self.var_gro_19 = [[self.dp.myProteinID.LIST_SAMPLE_ID.index(i_exp) for i_exp in i_group] for i_group in
                                 self.var_gro_67]

        list_iter = list(itertools.combinations(list(range(len(self.group_name))), 2))
        for i_iter1, i_iter2 in list_iter:
            
            matrix_x = self.dp.myProteinID.MATRIX_INTENSITY_LOG2[:, self.var_gro_19[i_iter1]]
            matrix_y = self.dp.myProteinID.MATRIX_INTENSITY_LOG2[:, self.var_gro_19[i_iter2]]
            out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[36] + '_' + \
                       self.group_name[i_iter1] + '_' + self.group_name[i_iter2] + '.txt'
            out_path_pic = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[29] + '_' + \
                       self.group_name[i_iter1] + '_' + self.group_name[i_iter2] + '.png'
            self.__captainCalFDR(matrix_x, matrix_y, self.dp.myProteinID.PRO1_NAME, out_path_txt, out_path_pic)
