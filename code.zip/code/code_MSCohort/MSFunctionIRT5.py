import numpy as np
import pickle
from MSFunctionEvi3 import CFunctionEvide_1
from MSFunction1 import CFunctionParse_6
from MSOperator import op_INIT_CSEED
from MSTool import toolGetNameFromPath, toolFindNeighborFromSortedList1, toolFindNeighborFromDisorderdList
from MSData import CDataPack, CFileMS1, CSeed, CEvidence
from MSSystem import VALUE_ILLEGAL, IO_FILENAME_EXPORT, IO_FILENAME_TMP_EXPORT


class CFunctionExtra_1:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def __soliderCalIRTMOZ(self, inputPeptide: str, inputCharge: int):

        var_Pre_3 = self.dp.myINI.DICT0_ELEMENT_MASS['H'][0]*2 + self.dp.myINI.DICT0_ELEMENT_MASS['O'][0]

        for i, aa in enumerate(inputPeptide):
            var_Pre_3 += self.dp.myINI.DICT1_AA_COM[aa][1]

        Precursor_moz = (var_Pre_3 + inputCharge * self.dp.myINI.MASS_PROTON_MONO) / inputCharge

        return Precursor_moz

    def __captainGetIRTInfo(self):

        
        for tmp_group in self.dp.LIST_EXPERIMENT_GROUP:
            self.dp.myIDForIRT.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myIDForIRT.LIST_EXPERIMENT_ID.extend(tmp_group[2])

        list_sequenceIRT = self.dp.myINI.LIST_IRT_PEPTIDE
        list_chargeIRT = self.dp.myINI.LIST_IRT_CHARGE

        for i_peptide in list_sequenceIRT:
            for i_charge in list_chargeIRT:
                self.dp.myIDForIRT.PRE1_SEQ.append(i_peptide)
                self.dp.myIDForIRT.PRE2_MOD.append('')
                self.dp.myIDForIRT.PRE3_CHARGE.append(i_charge)
                self.dp.myIDForIRT.LIST_PRECURSOR_ID.append(i_peptide + '_' + str(i_charge))
                self.dp.myIDForIRT.PRE4_MOZ_CLC.append(self.__soliderCalIRTMOZ(i_peptide, i_charge))
                
                self.dp.myIDForIRT.PRELIST2_RT.append(
                    [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                self.dp.myIDForIRT.PRELIST3_RT_START.append(
                    [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                self.dp.myIDForIRT.PRELIST4_RT_END.append(
                    [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                self.dp.myIDForIRT.PRELIST10_MS1_INTENSITY.append(
                    [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                self.dp.myIDForIRT.PRELIST15_FWHM.append(
                    [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                self.dp.myIDForIRT.N_PRECURSOR += 1

    def __soliderFillSeed(self, i_Pre):

        myseed = CSeed()
        op_INIT_CSEED(myseed)

        tmpListMoz = [self.dp.myIDForIRT.PRE4_MOZ_CLC[i_Pre] + i_iso * 1.003
                      / self.dp.myIDForIRT.PRE3_CHARGE[i_Pre] for i_iso in range(5)]
        myseed.DIS_ISO_MOZ_CLC = tmpListMoz

        return myseed

    def __soliderCalIRTIndicator(self, inputEvidence: CEvidence, inputSeed: CSeed):

        out_RT = inputSeed.MID_RT / 60.
        out_RTStart = inputEvidence.LIST_RET_TIME[inputEvidence.I_START] / 60.
        out_RTEnd = inputEvidence.LIST_RET_TIME[inputEvidence.I_END] / 60.

        var_lis_1 = list(inputEvidence.MATRIX_PROFILE[0][inputEvidence.I_START: inputEvidence.I_END])

        var_int_4 = np.max(var_lis_1)

        var_ind_2 = np.argmax(var_lis_1)
        if var_ind_2 == 0:
            index_intensity_left_FWHM = 0
        else:
            index_intensity_left_FWHM = toolFindNeighborFromDisorderdList(var_lis_1[: var_ind_2],
                                                                        var_int_4 / 2)
        if var_ind_2 == len(var_lis_1)-1:
            index_intensity_right_FWHM = len(var_lis_1)-1
        else:
            index_intensity_right_FWHM = var_ind_2 + toolFindNeighborFromDisorderdList(
                var_lis_1[var_ind_2:], var_int_4 / 2)

        if max(inputEvidence.MATRIX_PROFILE[0]) == 0:
            print(var_lis_1, len(var_lis_1), max(inputEvidence.MATRIX_PROFILE[0]), index_intensity_left_FWHM, index_intensity_right_FWHM)
        rt_left_FWHM = inputEvidence.LIST_RET_TIME[inputEvidence.I_START + index_intensity_left_FWHM]
        rt_right_FWHM = inputEvidence.LIST_RET_TIME[inputEvidence.I_START + index_intensity_right_FWHM]
        out_FWHM = (rt_right_FWHM - rt_left_FWHM) / 60.

        out_MS1Intensity = np.sum(inputEvidence.MATRIX_PROFILE[0, inputEvidence.I_START: inputEvidence.I_END])

        return out_RT, out_RTStart, out_RTEnd, out_FWHM, out_MS1Intensity

    def __captainGetEvidence(self, inputListEvidence, inputListSeed, inputListIndex):

        nMS1 = len(self.dp.LIST_PATH_MS1)
        maxRT = 0.

        for iMS1 in range(nMS1):

            pathMS1 = self.dp.LIST_PATH_MS1[iMS1]
            nameRawMS1 = toolGetNameFromPath(pathMS1)

            dataMS1 = CFileMS1()
            functionParseMS1 = CFunctionParse_6()
            dataMS1 = functionParseMS1.loadPKL(pathMS1)

            
            tmp_maxRT = max(dataMS1.INDEX_RT)
            if tmp_maxRT >= maxRT:
                maxRT = tmp_maxRT

            for i_Pre in range(self.dp.myIDForIRT.N_PRECURSOR):

                if nameRawMS1 in self.dp.myIDForIRT.LIST_SAMPLE_ID:

                    iIndexMS1 = self.dp.myIDForIRT.LIST_SAMPLE_ID.index(nameRawMS1)
                    tmpSeed = self.__soliderFillSeed(i_Pre)

                    inputListIndex.append([i_Pre, iIndexMS1])
                    inputListSeed.append(tmpSeed)
                    
                    functionEvidence = CFunctionEvide_1(self.dp)
                    tmpEvidence = functionEvidence.fillEvidenceForIRT(dataMS1, tmpSeed)

                    inputListEvidence.append(tmpEvidence)
                    
                    
                    out_RT, out_RTStart, out_RTEnd, out_FWHM, out_MS1Intensity = self.__soliderCalIRTIndicator(tmpEvidence, tmpSeed)

                    self.dp.myIDForIRT.PRELIST2_RT[i_Pre][iIndexMS1] = out_RT
                    self.dp.myIDForIRT.PRELIST3_RT_START[i_Pre][iIndexMS1] = out_RTStart
                    self.dp.myIDForIRT.PRELIST4_RT_END[i_Pre][iIndexMS1] = out_RTEnd
                    self.dp.myIDForIRT.PRELIST15_FWHM[i_Pre][iIndexMS1] = out_FWHM
                    self.dp.myIDForIRT.PRELIST10_MS1_INTENSITY[i_Pre][iIndexMS1] = out_MS1Intensity

        return maxRT

    def __captainWriteIXC(self, inputListEvidence, inputListSeed, inputListIndex):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[6]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[7]

        with open(path_out, 'wb')as f:
            pickle.dump([inputListEvidence, inputListSeed, inputListIndex], f)

        with open(path, 'w')as f:

            f.write('@number:{:d}'.format(len(inputListIndex)) + '\n')

            for i in range(len(inputListIndex)):

                index_pre, index_raw = inputListIndex[i][0], inputListIndex[i][1]
                tmp_seq = self.dp.myIDForIRT.PRE1_SEQ[index_pre]
                tmp_mod = self.dp.myIDForIRT.PRE2_MOD[index_pre]
                tmp_charge = str(self.dp.myIDForIRT.PRE3_CHARGE[index_pre])
                tmp_raw = self.dp.myIDForIRT.LIST_EXPERIMENT_ID[index_raw]
                list_moz = inputListSeed[i].DIS_ISO_MOZ_CLC
                mid_scan = str(inputListSeed[i].MID_SCAN)
                mid_rt = str(inputListSeed[i].MID_RT / 60)
                left_rt = str(self.dp.myIDForIRT.PRELIST3_RT_START[index_pre][index_raw])
                right_rt = str(self.dp.myIDForIRT.PRELIST4_RT_END[index_pre][index_raw])

                f.write('@{:d}\n'.format(i + 1))
                f.write('RAW\t' + tmp_raw + '\n')
                f.write('SEQ\t' + tmp_seq + '\n')
                f.write('MOD\t' + tmp_mod + '\n')
                f.write('CHARGE\t' + tmp_charge + '\n')
                f.write('MID SCAN\t' + mid_scan + '\n')
                f.write('MID RT\t' + mid_rt + '\n')
                f.write('LEFT RT\t' + left_rt + '\n')
                f.write('RIGHT RT\t' + right_rt + '\n')
                f.write('Scan\t' + '\t'.join([str(i_scan) for i_scan in inputListEvidence[i].LIST_SCAN]) + '\n')
                f.write('RT\t' + '\t'.join([str(i_rt / 60) for i_rt in inputListEvidence[i].LIST_RET_TIME]) + '\n')
                for i_iso in range(inputListEvidence[i].MATRIX_PROFILE.shape[0]):
                    f.write('Istope{:.4f}\t'.format(list_moz[i_iso]) + '\t'.join(
                        [str(float(i_int)) for i_int in inputListEvidence[i].MATRIX_PROFILE[i_iso]]) + '\n')

    def extract(self):

        listEvidence = []
        listSeed = []
        listIndex = []

        self.__captainGetIRTInfo()
        maxRT = self.__captainGetEvidence(listEvidence, listSeed, listIndex)
        self.__captainWriteIXC(listEvidence, listSeed, listIndex)

        return maxRT / 60.


class CFunctionOutIR_3:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def output(self):
        
        
        
        
        
        
        
        self.__soliderWriteInfo()

    def __soliderWriteInfo(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + r'INFO19_iRT_QC_Summary.txt'

        with open(path, 'w')as f:

            f.write('iRT peptide Number\t{:d}\n'.format(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)))
            f.write('iRT peptide Retention Time[minute]\n')

            f.write('iRT precursor\tMOZ of iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\tMean RT\n')

            list_rt_mean = []
            for i in range(len(self.dp.myIDForIRT.LIST_PRECURSOR_ID)):

                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + str(self.dp.myIDForIRT.PRE4_MOZ_CLC[i]) + '\t' + '\t'.join(
                    [str(i_rt) if i_rt != VALUE_ILLEGAL else 'None'
                     for i_rt in self.dp.myIDForIRT.PRELIST2_RT[i]]) + '\t')
                tmp_mean_rt = np.mean([i_rt for i_rt in self.dp.myIDForIRT.PRELIST2_RT[i] if i_rt != VALUE_ILLEGAL])
                f.write(str(tmp_mean_rt) + '\n')
                list_rt_mean.append(tmp_mean_rt)

            f.write('iRT peptide peak width, start-stop[minute]\n')
            f.write('iRT precursor\tMOZ of iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + str(self.dp.myIDForIRT.PRE4_MOZ_CLC[i]) + '\t' + '\t'.join(
                    [str(self.dp.myIDForIRT.PRELIST4_RT_END[i][j] - self.dp.myIDForIRT.PRELIST3_RT_START[i][j])
                     if self.dp.myIDForIRT.PRELIST3_RT_START[i][j] != VALUE_ILLEGAL else 'None'
                     for j in range(len(self.dp.myIDForIRT.PRELIST3_RT_START[i]))]
                ) + '\n')

            f.write('iRT peptide FWHM[minute]\n')
            f.write('iRT precursor\tMOZ of iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + str(self.dp.myIDForIRT.PRE4_MOZ_CLC[i]) + '\t' + '\t'.join(
                    [str(i_fwhm) if i_fwhm != VALUE_ILLEGAL else 'None'
                        for i_fwhm in self.dp.myIDForIRT.PRELIST15_FWHM[i]]) + '\n')

            f.write('iRT MS1 Intensity\n')
            f.write('iRT precursor\tMOZ of iRT precursor\t' + '\t'.join(self.dp.myIDForIRT.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myIDForIRT.N_PRECURSOR):
                f.write(self.dp.myIDForIRT.LIST_PRECURSOR_ID[i] + '\t' + str(self.dp.myIDForIRT.PRE4_MOZ_CLC[i]) + '\t' + '\t'.join(
                    [str(i_int) if i_int != VALUE_ILLEGAL else 'None'
                        for i_int in self.dp.myIDForIRT.PRELIST10_MS1_INTENSITY[i]]) + '\n')
