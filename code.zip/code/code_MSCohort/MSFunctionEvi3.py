import numpy as np
from MSData import CDataPack, CSeed, CEvidence, CFileMS1, CFileMS2
from MSOperator import op_INIT_CEVIDENCE, opGetStartAndEndForProfile
from MSTool import toolFindNeighborFromSortedList1
from MSLogging import logGetError


class CFunctionEvide_1:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def var_cap_1(self, inputwinRT, iMid, inputdataMS1, inputSeed: CSeed):

        rtMid = inputdataMS1.INDEX_RT[iMid]

        
        
        iLeft = iMid
        borderRTLeft = max(0, rtMid - inputwinRT * 60)

        while iLeft > 0:

            if inputdataMS1.INDEX_RT[iLeft] < borderRTLeft:
                break
            else:
                iLeft = iLeft - 1

        iLeft = iLeft + 1  

        iRight = iMid
        borderRTRight = min(rtMid + inputwinRT * 60, inputdataMS1.INDEX_RT[-1])

        while iRight < len(inputdataMS1.INDEX_SCAN) - 1:

            if inputdataMS1.INDEX_RT[iRight] > borderRTRight:
                break
            else:
                iRight = iRight + 1

        iRight = iRight - 1  
        
        precursor_MOZ_list = inputSeed.DIS_ISO_MOZ_CLC
        nScan = iRight - iLeft + 1
        outputEvidence = CEvidence()
        op_INIT_CEVIDENCE(outputEvidence)

        outputEvidence.MATRIX_PROFILE = np.zeros(shape=[len(precursor_MOZ_list), nScan])
        outputEvidence.MATRIX_MASS_ACCURACY = np.zeros(shape=[len(precursor_MOZ_list), nScan])
        outputEvidence.LIST_RET_TIME = [0] * nScan
        outputEvidence.LIST_SCAN = [0] * nScan

        accuracy = self.dp.myCFG.C12_DDA_PRECURSOR_PPM_HALF_WIN_ACCURACY_REAK

        for iScan in range(iLeft, iRight + 1):

            tmp_MOZ_list = inputdataMS1.MATRIX_PEAK_MOZ[inputdataMS1.INDEX_SCAN[iScan]]
            tmp_INT_list = inputdataMS1.MATRIX_PEAK_INT[inputdataMS1.INDEX_SCAN[iScan]]

            outputEvidence.LIST_SCAN[iScan - iLeft] = inputdataMS1.INDEX_SCAN[iScan]
            outputEvidence.LIST_RET_TIME[iScan - iLeft] = inputdataMS1.INDEX_RT[iScan]

            for i in range(len(precursor_MOZ_list)):

                indexINT = toolFindNeighborFromSortedList1(tmp_MOZ_list, precursor_MOZ_list[i])
                var_tmp_2 = abs(tmp_MOZ_list[indexINT] - precursor_MOZ_list[i]) / precursor_MOZ_list[i] * 1e6
                if var_tmp_2 < accuracy:
                    outputEvidence.MATRIX_PROFILE[i, iScan - iLeft] = tmp_INT_list[indexINT]
                    outputEvidence.MATRIX_MASS_ACCURACY[i, iScan - iLeft] = var_tmp_2

        outputEvidence.I_START = 0
        outputEvidence.I_END = -1

        return outputEvidence

    def __captainfillAllRTEvidence(self, inputdataMS1, inputSeed: CSeed):

        iLeft, iRight = 0, len(inputdataMS1.INDEX_RT)-1
        
        precursor_MOZ_list = inputSeed.DIS_ISO_MOZ_CLC
        nScan = iRight - iLeft + 1
        outputEvidence = CEvidence()
        op_INIT_CEVIDENCE(outputEvidence)

        outputEvidence.MATRIX_PROFILE = np.zeros(shape=[len(precursor_MOZ_list), nScan])
        outputEvidence.MATRIX_MASS_ACCURACY = np.zeros(shape=[len(precursor_MOZ_list), nScan])
        outputEvidence.LIST_RET_TIME = [0] * nScan
        outputEvidence.LIST_SCAN = [0] * nScan

        accuracy = self.dp.myCFG.C12_DDA_PRECURSOR_PPM_HALF_WIN_ACCURACY_REAK

        for iScan in range(iLeft, iRight + 1):

            tmp_MOZ_list = inputdataMS1.MATRIX_PEAK_MOZ[inputdataMS1.INDEX_SCAN[iScan]]
            tmp_INT_list = inputdataMS1.MATRIX_PEAK_INT[inputdataMS1.INDEX_SCAN[iScan]]

            outputEvidence.LIST_SCAN[iScan - iLeft] = inputdataMS1.INDEX_SCAN[iScan]
            outputEvidence.LIST_RET_TIME[iScan - iLeft] = inputdataMS1.INDEX_RT[iScan]

            for i in range(len(precursor_MOZ_list)):

                indexINT = toolFindNeighborFromSortedList1(tmp_MOZ_list, precursor_MOZ_list[i])
                var_tmp_2 = abs(tmp_MOZ_list[indexINT] - precursor_MOZ_list[i]) / precursor_MOZ_list[i] * 1e6
                if var_tmp_2 < accuracy:
                    outputEvidence.MATRIX_PROFILE[i, iScan - iLeft] = tmp_INT_list[indexINT]
                    outputEvidence.MATRIX_MASS_ACCURACY[i, iScan - iLeft] = var_tmp_2

        outputEvidence.I_START = 0
        outputEvidence.I_END = -1

        return outputEvidence

    def fillEvidence(self, inputdataMS1:CFileMS1, inputSeed: CSeed):

        winRT = self.dp.myCFG.C11_DDA_PRECURSOR_RT_HALF_WIN_IN_MIN

        iMid = toolFindNeighborFromSortedList1(inputdataMS1.INDEX_SCAN, inputSeed.MID_SCAN)

        if inputdataMS1.INDEX_SCAN[iMid] != inputSeed.MID_SCAN:
            logGetError("MSFunctionEvidence, MK142: Can not find scan " + str(
                inputSeed.MID_SCAN) + " in inputDataMS1.INDEX_SCAN. inputDataMS1.INDEX_SCAN[iMid] is " + str(
                inputdataMS1.INDEX_SCAN[iMid]))

        
        return self.var_cap_1(winRT, iMid, inputdataMS1, inputSeed)

    def fillEvidenceForLabel(self, inputdataMS2: CFileMS2, inputMID_SCAN):

        winRT = self.dp.myCFG.C11_DDA_PRECURSOR_RT_HALF_WIN_IN_MIN

        iMid = toolFindNeighborFromSortedList1(inputdataMS2.INDEX_SCAN, inputMID_SCAN)

        if inputdataMS2.INDEX_SCAN[iMid] != inputMID_SCAN:
            logGetError("MSFunctionEvidence, MK142: Can not find scan " + str(
                inputMID_SCAN) + " in inputDataMS1.INDEX_SCAN. inputDataMS1.INDEX_SCAN[iMid] is " + str(
                inputdataMS2.INDEX_SCAN[iMid]))

        outEvidence = CEvidence()
        op_INIT_CEVIDENCE(outEvidence)

        outEvidence.MS2_PEAK_MOZ = inputdataMS2.MATRIX_PEAK_MOZ[inputdataMS2.INDEX_SCAN[iMid]]
        outEvidence.MS2_PEAK_INT = inputdataMS2.MATRIX_PEAK_INT[inputdataMS2.INDEX_SCAN[iMid]]
        outEvidence.LIST_RET_TIME = inputdataMS2.LIST_RET_TIME[inputdataMS2.INDEX_SCAN[iMid]]
        return outEvidence

    def fillEvidenceForIRT(self, inputdataMS1: CFileMS1, inputSeed: CSeed):

        allEvidence = self.__captainfillAllRTEvidence(inputdataMS1, inputSeed)
        
        index_Peak = np.argmax(allEvidence.MATRIX_PROFILE[0, :])
        inputSeed.MID_RT = allEvidence.LIST_RET_TIME[index_Peak]
        inputSeed.MID_SCAN = allEvidence.LIST_SCAN[index_Peak]
        
        listStartEnd = opGetStartAndEndForProfile(allEvidence.MATRIX_PROFILE[0,:], index_Peak+1,
                                                  self.dp.myCFG.DDA_CUTOFF_INTENSITY_IN_CMTG,
                                                  self.dp.myCFG.DDA_NUMBER_HOLE_IN_CMTG)
        allEvidence.I_START = listStartEnd[0]
        allEvidence.I_END = listStartEnd[1]

        return allEvidence