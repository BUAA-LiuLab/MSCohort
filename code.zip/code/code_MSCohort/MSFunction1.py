
import numpy as np
import math
import pickle
import os
import datetime
from MSOperator import op_INIT_CFILE_MS1, op_INIT_CFILE_MS2
from MSTool import toolGetWord, toolCountCharInString, toolStr2List, toolGetWord1
from MSData import CDataPack, Config, CFileMS1, CFileMS2
from MSSystem import VALUE_ILLEGAL, IOFILENAME_IRT_EXPORT, CFG_FLAG_MISSING_VALUE_THRESHOLD, CFG_TYPE_COHORT, UNIMOID_TO_STANDARD_MOD
from MSLogging import logGetError,INFO_TO_USER_TaskParseRaw


class CFunctionINI_5:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def file2ini(self):

        
        
        
        self.__captainFile2iRT(self.dp.myCFG.I3_INI_PATH_IRT)
        self.__captainFile2Plot(self.dp.myCFG.I4_INI_PLOT)
        self.__captainFile2Contaminant()
        self.__captainFile2ExpScore()
        self.__captainFile2GroupSetting(self.dp.myCFG.B2_PATH_EXPERIMENT_SETTING_RESULT)

        
        
        
        
        
        


    def __soliderCalMass(self, inputMolecule, inputAtonMass):  
        index = 0
        molecule_mass = 0
        atom_left = 0
        for i in inputMolecule:
            if (i == '(') | (i == '（'):
                atom_right = index
                num_left = index + 1
                atom = inputMolecule[atom_left: atom_right]
            elif (i == ')') | (i == '）'):
                atom_left = index + 1
                num_right = index
                atom_num = int(inputMolecule[num_left: num_right])
                molecule_mass = molecule_mass + atom_num * inputAtonMass[atom][0]
            index = index + 1
        return molecule_mass

    def __captainFile2iRT(self, path):

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        for line in lines:

            line = line.strip()

            if line.startswith('@'):
                continue

            elif line.startswith('charge'):
                tmp_charge = line.split('=')[1]
                tmp_charge = tmp_charge[:-1] if tmp_charge[-1] == '|' else tmp_charge
                self.dp.myINI.LIST_IRT_CHARGE = tuple([int(i) for i in tmp_charge.split('|')])

            elif line.startswith('name'):
                tmp_iRT = line.split('=')[1]
                self.dp.myINI.LIST_IRT_PEPTIDE.append(tmp_iRT)

    def __captainFile2Plot(self, path):

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        for line in lines:

            line = line.strip()

            if line.startswith('@'):
                continue

            elif line.startswith('MIN_RT_DEVIATION'):

                min_rt_dev = float(line.split('=')[1])
                self.dp.myPLOT.MIN_RT_DEVIATION = min_rt_dev

            elif line.startswith('MAX_RT_DEVIATION'):

                max_rt_dev = float(line.split('=')[1])
                self.dp.myPLOT.MAX_RT_DEVIATION = max_rt_dev

            elif line.startswith('MIN_CV_SHOW'):

                min_cv = float(line.split('=')[1])
                self.dp.myPLOT.MIN_CV_SHOW = min_cv

            elif line.startswith('MAX_CV_SHOW'):

                max_cv = float(line.split('=')[1])
                self.dp.myPLOT.MAX_CV_SHOW = max_cv

            elif line.startswith('MIN_VIOLIN_SHOW'):

                min_violin = float(line.split('=')[1])
                self.dp.myPLOT.MIN_VIOLIN_SHOW = min_violin

            elif line.startswith('MAX_VIOLIN_SHOW'):

                max_violin = float(line.split('=')[1])
                self.dp.myPLOT.MAX_VIOLIN_SHOW = max_violin

            elif line.startswith('T_SNE_PERPLEXITY'):

                t_SNE_Perplexity = float(line.split('=')[1])
                self.dp.myPLOT.T_SNE_PERPLEXITY = t_SNE_Perplexity

            elif line.startswith('THRESHOLD_PCA_INTERPOLATION'):

                var_thr_11 = float(line.split('=')[1])
                self.dp.myPLOT.THRESHOLD_PCA_INTERPOLATION = var_thr_11

            elif line.startswith('TYPE_FILTER_OUTLIER'):

                var_typ_27 = float(line.split('=')[1])
                self.dp.myPLOT.TYPE_FILTER_OUTLIER = var_typ_27

            elif line.startswith('THRESHOLD_OUTLIER_FILTER'):
                var_thr_83 = float(line.split('=')[1])
                self.dp.myPLOT.THRESHOLD_OUTLIER_FILTER = var_thr_83

    def __captainFile2Contaminant(self):
        path_contam = self.dp.myCFG.I5_INI_CONTAM

        with open(path_contam, 'rb')as f:
            lines = f.read().decode('utf-8').split('\r\n')

        tmp_contam = ''
        for line in lines:
            if line:
                if line.startswith('#'):
                    tmp_contam = line.strip().split('#')[1]
                    if tmp_contam not in self.dp.myCONTAM.DIC_CONTAM:
                        self.dp.myCONTAM.DIC_CONTAM[tmp_contam] = {}
                else:
                    i_contaminant = line.strip()
                    if i_contaminant not in self.dp.myCONTAM.DIC_CONTAM[tmp_contam]:
                        self.dp.myCONTAM.DIC_CONTAM[tmp_contam][i_contaminant] = ''

    def __captainFile2ExpScore(self):

        var_pat_92 = self.dp.myCFG.I6_INI_EXP_THRESHOLD
        var_pat_74 = self.dp.myCFG.I7_INI_EXP_WEIGHT

        with open(var_pat_92, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')
        for line in lines:
            if line:
                line_list = line.split('=')
                if line_list[0] == 'SP. Contaminant':
                    self.dp.myEXPSCORE.THRESHOLD_CONTAMINANT = float(line_list[1])
                elif line_list[0] == 'LC1. DeltaRT (predicted-measured)':
                    self.dp.myEXPSCORE.THRESHOLD_DELTART = float(line_list[1])
                elif line_list[0] == 'LC2. RT relative deviation':
                    self.dp.myEXPSCORE.THRESHOLD_RT_DEV = float(line_list[1])
                elif line_list[0] == 'MS1. The ratio of missing values of precursors':
                    self.dp.myEXPSCORE.THRESHOLD_MISSING_PRE = float(line_list[1])
                elif line_list[0] == 'MS1. Median of precursor intensity':
                    self.dp.myEXPSCORE.THRESHOLD_MEDIAN_INT_PRE = float(line_list[1])
                elif line_list[0] == 'MS3. IQR of precursor intensity':
                    self.dp.myEXPSCORE.THRESHOLD_IQR_PRE = float(line_list[1])
                elif line_list[0] == 'MS4. Robust Dev of precursor intensity':
                    self.dp.myEXPSCORE.THRESHOLD_DEV_INT_PRE = float(line_list[1])
                elif line_list[0] == 'MS5. Pearson correlation of precursor intensity':
                    self.dp.myEXPSCORE.THRESHOLD_PEARSON_INT_PRE = float(line_list[1])
                elif line_list[0] == 'MS6. Normalization coefficient of precursor intensity':
                    self.dp.myEXPSCORE.THRESHOLD_NORM_PRE = float(line_list[1])
                elif line_list[0] == 'MS7. The ratio of missing values of peptides':
                    self.dp.myEXPSCORE.THRESHOLD_MISSING_PEP = float(line_list[1])
                elif line_list[0] == 'MS8. Median of peptide intensity':
                    self.dp.myEXPSCORE.THRESHOLD_MEDIAN_INT_PEP = float(line_list[1])
                elif line_list[0] == 'MS9. IQR of peptide intensity':
                    self.dp.myEXPSCORE.THRESHOLD_IQR_PEP = float(line_list[1])
                elif line_list[0] == 'MS10. Robust Dev of peptide intensity':
                    self.dp.myEXPSCORE.THRESHOLD_DEV_INT_PEP = float(line_list[1])
                elif line_list[0] == 'MS11. Pearson correlation of peptide intensity':
                    self.dp.myEXPSCORE.THRESHOLD_PEARSON_INT_PEP = float(line_list[1])
                elif line_list[0] == 'MS12. Normalization coefficient of peptide intensity':
                    self.dp.myEXPSCORE.THRESHOLD_NORM_PEP = float(line_list[1])
                elif line_list[0] == 'MS13. The ratio of missing values of proteins':
                    self.dp.myEXPSCORE.THRESHOLD_MISSING_PRO = float(line_list[1])
                elif line_list[0] == 'MS14. Median of protein intensity':
                    self.dp.myEXPSCORE.THRESHOLD_MEDIAN_INT_PRO = float(line_list[1])
                elif line_list[0] == 'MS15. IQR of protein intensity':
                    self.dp.myEXPSCORE.THRESHOLD_IQR_PRO = float(line_list[1])
                elif line_list[0] == 'MS16. Robust Dev of protein intensity':
                    self.dp.myEXPSCORE.THRESHOLD_DEV_INT_PRO = float(line_list[1])
                elif line_list[0] == 'MS17. Pearson correlation of protein intensity':
                    self.dp.myEXPSCORE.THRESHOLD_PEARSON_INT_PRO = float(line_list[1])
                elif line_list[0] == 'MS18. Normalization coefficient of protein intensity':
                    self.dp.myEXPSCORE.THRESHOLD_NORM_PRO = float(line_list[1])

        with open(var_pat_74, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')
        for line in lines:
            if line:
                line_list = line.split('=')
                if line_list[0] == 'SP. Contaminant':
                    self.dp.myEXPSCORE.WEIGHT_CONTAMINANT = float(line_list[1])
                elif line_list[0] == 'LC1. DeltaRT (predicted-measured)':
                    self.dp.myEXPSCORE.WEIGHT_DELTART = float(line_list[1])
                elif line_list[0] == 'LC2. RT relative deviation':
                    self.dp.myEXPSCORE.WEIGHT_RT_DEV = float(line_list[1])
                elif line_list[0] == 'MS1. The ratio of missing values of precursors':
                    self.dp.myEXPSCORE.WEIGHT_MISSING_PRE = float(line_list[1])
                elif line_list[0] == 'MS1. Median of precursor intensity':
                    self.dp.myEXPSCORE.WEIGHT_MEDIAN_INT_PRE = float(line_list[1])
                elif line_list[0] == 'MS3. IQR of precursor intensity':
                    self.dp.myEXPSCORE.WEIGHT_IQR_PRE = float(line_list[1])
                elif line_list[0] == 'MS4. Robust Dev of precursor intensity':
                    self.dp.myEXPSCORE.WEIGHT_DEV_INT_PRE = float(line_list[1])
                elif line_list[0] == 'MS5. Pearson correlation of precursor intensity':
                    self.dp.myEXPSCORE.WEIGHT_PEARSON_INT_PRE = float(line_list[1])
                elif line_list[0] == 'MS6. Normalization coefficient of precursor intensity':
                    self.dp.myEXPSCORE.WEIGHT_NORM_PRE = float(line_list[1])
                elif line_list[0] == 'MS7. The ratio of missing values of peptides':
                    self.dp.myEXPSCORE.WEIGHT_MISSING_PEP = float(line_list[1])
                elif line_list[0] == 'MS8. Median of peptide intensity':
                    self.dp.myEXPSCORE.WEIGHT_MEDIAN_INT_PEP = float(line_list[1])
                elif line_list[0] == 'MS9. IQR of peptide intensity':
                    self.dp.myEXPSCORE.WEIGHT_IQR_PEP = float(line_list[1])
                elif line_list[0] == 'MS10. Robust Dev of peptide intensity':
                    self.dp.myEXPSCORE.WEIGHT_DEV_INT_PEP = float(line_list[1])
                elif line_list[0] == 'MS11. Pearson correlation of peptide intensity':
                    self.dp.myEXPSCORE.WEIGHT_PEARSON_INT_PEP = float(line_list[1])
                elif line_list[0] == 'MS12. Normalization coefficient of peptide intensity':
                    self.dp.myEXPSCORE.WEIGHT_NORM_PEP = float(line_list[1])
                elif line_list[0] == 'MS13. The ratio of missing values of proteins':
                    self.dp.myEXPSCORE.WEIGHT_MISSING_PRO = float(line_list[1])
                elif line_list[0] == 'MS14. Median of protein intensity':
                    self.dp.myEXPSCORE.WEIGHT_MEDIAN_INT_PRO = float(line_list[1])
                elif line_list[0] == 'MS15. IQR of protein intensity':
                    self.dp.myEXPSCORE.WEIGHT_IQR_PRO = float(line_list[1])
                elif line_list[0] == 'MS16. Robust Dev of protein intensity':
                    self.dp.myEXPSCORE.WEIGHT_DEV_INT_PRO = float(line_list[1])
                elif line_list[0] == 'MS17. Pearson correlation of protein intensity':
                    self.dp.myEXPSCORE.WEIGHT_PEARSON_INT_PRO = float(line_list[1])
                elif line_list[0] == 'MS18. Normalization coefficient of protein intensity':
                    self.dp.myEXPSCORE.WEIGHT_NORM_PRO = float(line_list[1])

    def __captainFile2GroupSetting(self, path):

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='gbk').split('\r\n')

        list_group = []
        list_rawfile = []
        list_rawfileID = []
        var_lis_41 = []
        list_rawfileID_train = []
        var_lis_49 = []
        list_rawfileID_test = []

        for line in lines:

            line = line.strip()

            if line.startswith('Group Name'):
                continue

            elif line:

                tmp_line_list = line.split('\t')
                flag_train = None
                if len(tmp_line_list) == 5:
                    tmp_group, tmp_rawfile, tmp_rawfileID, var_tmp_47, flag_train = line.split('\t')
                    self.dp.LIST_EXPERIMENT_INT_THRESHOLD.append(float(var_tmp_47))
                elif len(tmp_line_list) == 4:
                    tmp_group, tmp_rawfile, tmp_rawfileID, var_tmp_47 = line.split('\t')
                    self.dp.LIST_EXPERIMENT_INT_THRESHOLD.append(float(var_tmp_47))
                else:
                    tmp_group, tmp_rawfile, tmp_rawfileID = line.split('\t')
                    self.dp.LIST_EXPERIMENT_INT_THRESHOLD.append(0.)

                if tmp_group not in list_group:
                    list_group.append(tmp_group)
                    list_rawfile.append([tmp_rawfile])
                    if tmp_rawfileID == '':
                        list_rawfileID.append([tmp_rawfile])
                    else:
                        list_rawfileID.append([tmp_rawfileID])
                    
                    if flag_train == 'Yes':
                        var_lis_41.append([tmp_rawfile])
                        if tmp_rawfileID == '':
                            list_rawfileID_train.append([tmp_rawfile])
                        else:
                            list_rawfileID_train.append([tmp_rawfileID])
                        
                        var_lis_49.append([tmp_rawfile])
                        if tmp_rawfileID == '':
                            list_rawfileID_test.append([tmp_rawfile])
                        else:
                            list_rawfileID_test.append([tmp_rawfileID])
                    elif flag_train == 'No':
                        var_lis_49.append([tmp_rawfile])
                        if tmp_rawfileID == '':
                            list_rawfileID_test.append([tmp_rawfile])
                        else:
                            list_rawfileID_test.append([tmp_rawfileID])

                    self.dp.LIST_EXPERIMENT.append([list_rawfile[-1][-1], list_rawfileID[-1][-1]])
                else:
                    tmp_index = list_group.index(tmp_group)
                    list_rawfile[tmp_index].append(tmp_rawfile)
                    if tmp_rawfileID == '':
                        list_rawfileID[tmp_index].append(tmp_rawfile)
                    else:
                        list_rawfileID[tmp_index].append(tmp_rawfileID)
                    
                    if flag_train == 'Yes':
                        var_lis_41[tmp_index].append(tmp_rawfile)
                        if tmp_rawfileID == '':
                            list_rawfileID_train[tmp_index].append(tmp_rawfile)
                        else:
                            list_rawfileID_train[tmp_index].append(tmp_rawfileID)
                        
                        var_lis_49[tmp_index].append(tmp_rawfile)
                        if tmp_rawfileID == '':
                            list_rawfileID_test[tmp_index].append(tmp_rawfile)
                        else:
                            list_rawfileID_test[tmp_index].append(tmp_rawfileID)
                    elif flag_train == 'No':
                        var_lis_49[tmp_index].append(tmp_rawfile)
                        if tmp_rawfileID == '':
                            list_rawfileID_test[tmp_index].append(tmp_rawfile)
                        else:
                            list_rawfileID_test[tmp_index].append(tmp_rawfileID)

                    self.dp.LIST_EXPERIMENT.append([list_rawfile[tmp_index][-1], list_rawfileID[tmp_index][-1]])

        print(self.dp.LIST_EXPERIMENT)
        for i in range(len(list_group)):

            self.dp.LIST_EXPERIMENT_GROUP.append((list_group[i], list_rawfile[i], list_rawfileID[i]))
            if var_lis_41:
                self.dp.LIST_EXPERIMENT_GROUP_TRAIN.append([list_group[i], var_lis_41[i], list_rawfileID_train[i]])
            if var_lis_49:
                self.dp.LIST_EXPERIMENT_GROUP_TEST.append((list_group[i], var_lis_49[i], list_rawfileID_test[i]))

            
            
            
            
            
            
            
            

    def __captainFile2InsCorrSetting(self, path):

        if self.dp.myCFG.C1_TYPE_COHORT == CFG_TYPE_COHORT['InstrumentCorrelation']:
            with open(path, 'rb')as f:

                lines = f.read().decode(encoding='utf-8').split('\r\n')

            list_group = [i[0] for i in self.dp.LIST_EXPERIMENT_GROUP]

            for line in lines[1:]:
                if line:
                    line_list = line.strip().split('\t')
                    if len(line_list) == 2:
                        tmp_group0, tmp_group1 = line_list
                        var_tmp_35 = ''
                    elif len(line_list) == 3:
                        tmp_group0, tmp_group1, var_tmp_35 = line_list
                    else:
                        tmp_group0, tmp_group1, var_tmp_35 = '', '', ''
                        info = r"The parameter of PATH_INSTRUMENT_CORRECTION_SETTING is illegal."
                        logGetError(info)

                    if tmp_group0 in list_group and tmp_group1 in list_group:

                        self.dp.LIST_INSCORR_GROUP_PAIR.append([tmp_group0, tmp_group1, var_tmp_35])

                    else:

                        info = r"The parameter of PATH_INSTRUMENT_CORRECTION_SETTING is illegal, {:s}\t{:s} is not in group.".format(tmp_group0, tmp_group1)
                        logGetError(info)

    def __captainFile2Element(self, path):

        with open(path, 'r', encoding='utf8') as f:

            for line in f.readlines():

                if len(line) > 1:

                    str_name = toolGetWord(line, 0, '|')
                    str_mass = toolGetWord(line, 1, '|')
                    str_abdc = toolGetWord(line, 2, '|')

                    list_mass = toolStr2List(str_mass, ',')
                    list_abdc = toolStr2List(str_abdc, ',')

                    self.dp.myINI.DICT0_ELEMENT_MASS[str_name] = list_mass
                    self.dp.myINI.DICT0_ELEMENT_ABDC[str_name] = list_abdc

    def __captainFile2AA(self, path):

        with open(path, 'r', encoding='utf8') as f:

            for line in f.readlines():

                if len(line) > 1:

                    str_name = toolGetWord(line, 0, '|')
                    str_comp = toolGetWord(line, 1, '|')
                    str_mass = self.__soliderCalMass(str_comp, self.dp.myINI.DICT0_ELEMENT_MASS)

                    self.dp.myINI.DICT1_AA_COM[str_name] = (str_comp, str_mass)

    def __captainFile2Mod(self, path):

        with open(path, 'r', encoding='utf8') as f:
            for line in f.readlines():

                if len(line) > 1:

                    if line[-1] == '\n':

                        line = line[0:-1]  

                    if line.startswith("@"):
                        continue

                    if line.startswith("name"):

                        str_name = toolGetWord1(line, '=', ' ')

                    else:

                        nBlank = toolCountCharInString(line, ' ')

                        if nBlank > 5:

                            str_comp = toolGetWord(line, 7, ' ')

                        else:

                            str_comp = toolGetWord(line, 5, ' ')

                        str_mass = self.__soliderCalMass(str_comp, self.dp.myINI.DICT0_ELEMENT_MASS)
                        self.dp.myINI.DICT2_MOD_COM[str_name] = (str_comp, str_mass)


class CFunctionConfi_11:

    def config2file(self, path, path_setting, config: Config):

        with open(path, 'w')as f:

            f.write('\n[Work Flow]\n')
            f.write('WORK_FLOW=' + str(config.A0_TYPE_FLOW) + '\n')

            f.write('\n[Data File]\n')
            f.write('TYPE_DATA=' + str(config.A4_TYPE_DATA) + '\n')
            f.write('PATH_RAW=' + str(config.A1_PATH_MS1) + '\n')

            f.write('\n[Analysis results]\n')
            f.write('TYPE_ANALYSIS_RESULT=' + str(config.B3_TYPE_IDENTIFICATION_RESULT) + '\n')
            f.write('PATH_ANALYSIS_RESULT=' + str(config.B1_PATH_ANALYSIS_RESULT) + '\n')
            f.write('THRESHOLD_FDR=' + str(config.B4_THRESHOLD_FDR) + '\n')

            f.write('\n[Setting]\n')
            f.write('PATH_EXPERIMENT_SETTING=' + str(config.B2_PATH_EXPERIMENT_SETTING_RESULT) + '\n')
            f.write('TYPE_NORMALIZATION=' + str(config.C14_DDA_FLAG_NORMALIZATION) + '\n')
            f.write('FLAG_OUTLIERS=' + str(config.C19_FLAG_OUTLIERS) + '\n')
            f.write('FLAG_SHOW_ORDER=' + str(config.C18_FLAG_SHOW_ORDER) + '\n')
            f.write('THRESHOLD_PEAK_WIDTH_TAILING=' + str(config.C5_THRESHOLD_PEAK_WIDTH_TAILING) + '\n')
            f.write('THRESHOLD_INVALID_ACQUIRING_SCAN=' + str(config.C6_THRESHOLD_INVALID_ACQUIRING_SCAN) + '\n')
            f.write('FLAG_ANALYZE_FEATURE=' + str(config.C7_FLAG_ANALYZE_FEATURE) + '\n')

            f.write('\n[Export]\n')
            f.write('PATH_EXPORT=' + str(config.E1_PATH_EXPORT) + '\n')

        with open(path_setting, 'w')as f:
            f.write('\t'.join(['Group Name', 'Raw Name', 'Experiment','Threshold']) + '\n')

    def config2file_DDA(self, path, path_setting, config: Config):

        with open(path, 'w')as f:

            f.write('\n# [Data File]\n')
            f.write('TYPE_DATA=' + str(config.A4_TYPE_DATA) + '\n')
            f.write('PATH_RAW=' + str(config.A1_PATH_MS1) + '\n')

            f.write('\n# [Analysis results]\n')
            f.write('PATH_ANALYSIS_RESULT=' + str(config.B1_PATH_ANALYSIS_RESULT) + '\n')
            f.write('PATH_EXPERIMENT_SETTING=' + str(config.B2_PATH_EXPERIMENT_SETTING_RESULT) + '\n')
            f.write('PATH_INSTRUMENT_CORRECTION_SETTING=' + str(config.B5_INSTRUMENT_CORRECTION_SETTING) + '\n')
            f.write('TYPE_ANALYSIS_RESULT=' + str(config.B3_TYPE_IDENTIFICATION_RESULT) + '\n')
            f.write('THRESHOLD_FDR=' + str(config.B4_THRESHOLD_FDR) + '\n')

            f.write('\n# [Cohort analysis]\n')
            f.write('TYPE_FLOW=' + str(config.C1_TYPE_COHORT) + '\n')
            f.write('PRECURSOR_RT_HALF_WIN_IN_MIN=' + str(config.C11_DDA_PRECURSOR_RT_HALF_WIN_IN_MIN) + '\n')
            f.write('PRECURSOR_PPM_HALF_WIN_ACCURACY_REAK=' + str(config.C12_DDA_PRECURSOR_PPM_HALF_WIN_ACCURACY_REAK) + '\n')
            f.write('FRAGMENT_PPM_HALF_WIN_ACCURACY_PEAK=' + str(config.C13_DDA_FRAGMENT_PPM_HALF_WIN_ACCURACY_PEAK) + '\n')
            f.write('TYPE_NORMALIZATION=' + str(config.C14_DDA_FLAG_NORMALIZATION) + '\n')
            f.write('FLAG_SHOW_ORDER' + str(config.C18_FLAG_SHOW_ORDER) + '\n')
            f.write('FLAG_MISSING_VALUE_THRESHOLD=' + str(config.C16_FLAG_MISSING_VALUE_THRESHOLD) + '\n')
            f.write('TYPE_MISSING_VALUE_IMPUTATION=' + str(config.C17_TYPE_MISSING_VALUE_IMPUTATION) + '\n')
            f.write('FLAG_PDF_EXPORT=' + str(config.C2_FLAG_PDF_REPORT) + '\n')

            f.write('\n# [Export]\n')
            f.write('PATH_EXPORT=' + str(config.E1_PATH_EXPORT) + '\n')
            f.write('FLAG_CREATE_NEW_FOLDER=' + str(config.E2_FLAG_CREATE_NEW_FOLDER) + '\n')

        with open(path_setting, 'w')as f:
            f.write('\t'.join(['Group Name', 'Raw Name', 'Experiment']) + '\n')

    def file2config(self, path, config: Config):

        with open(path, 'rb') as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        for line in lines:

            if line.startswith("#") or line.startswith("["):
                continue

            p_EqualSign = line.find('=')

            if -1 == p_EqualSign:
                pass
            else:
                subLine = line.split('#')[0]  
                self.__soldierParseLine(subLine, config)

    def __soldierParseLine(self, line, cfg: Config):

        str_name, str_value = line.split('=')
        str_value = str_value.replace("\n", "")

        if "WORK_FLOW" == str_name:
            cfg.A0_TYPE_FLOW = int(str_value)

        elif "TYPE_DATA" == str_name:
            cfg.A4_TYPE_DATA = int(str_value)

        elif "PATH_RAW" == str_name:
            cfg.A1_PATH_MS1 = str_value

        elif "TYPE_ANALYSIS_RESULT" == str_name:
            cfg.B3_TYPE_IDENTIFICATION_RESULT = int(str_value)

        elif "PATH_ANALYSIS_RESULT" == str_name:
            cfg.B1_PATH_ANALYSIS_RESULT = str_value

        elif "THRESHOLD_FDR" == str_name:
            cfg.B4_THRESHOLD_FDR = float(str_value)

        elif "PATH_EXPERIMENT_SETTING" == str_name:
            cfg.B2_PATH_EXPERIMENT_SETTING_RESULT = str_value

        elif "TYPE_NORMALIZATION" == str_name:
            cfg.C14_DDA_FLAG_NORMALIZATION = int(str_value)

        elif "FLAG_OUTLIERS" == str_name:
            cfg.C19_FLAG_OUTLIERS = int(str_value)

        elif "FLAG_SHOW_ORDER" == str_name:
            cfg.C18_FLAG_SHOW_ORDER = int(str_value)

        elif "THRESHOLD_PEAK_WIDTH_TAILING" == str_name:
            cfg.C5_THRESHOLD_PEAK_WIDTH_TAILING = float(str_value)

        elif "THRESHOLD_INVALID_ACQUIRING_SCAN" == str_name:
            cfg.C6_THRESHOLD_INVALID_ACQUIRING_SCAN = float(str_value)

        elif "FLAG_ANALYZE_FEATURE" == str_name:
            cfg.C7_FLAG_ANALYZE_FEATURE = int(str_value)

        elif "PATH_EXPORT" == str_name:
            cfg.E1_PATH_EXPORT = str_value

            if cfg.E2_FLAG_CREATE_NEW_FOLDER:
                
                strTime = datetime.datetime.now().strftime('MSCohort_%Y%m%d\\')
                cfg.E1_PATH_EXPORT = cfg.E1_PATH_EXPORT + strTime

        else:

            info = "MSFunction, file2config, " + str_name + " is all right?"
            logGetError(info)


class CFunctionParse_6:

    def __init__(self):

        pass

    def loadPKL(self, pathMS1):

        pathPKL = pathMS1 + '.pkl'
        dataMS1 = CFileMS1()

        f_pkl = open(pathPKL, 'rb')
        dataMS1 = pickle.load(f_pkl)
        f_pkl.close()

        return dataMS1

    def ms1TOpkl(self, pathMS1):

        
        path_pkl = pathMS1 + ".pkl"
        if os.access(path_pkl, os.F_OK):
            pass
        else:

            
            dataMS1 = CFileMS1()
            op_INIT_CFILE_MS1(dataMS1)

            
            with open(pathMS1, 'r') as f:

                i_MS1 = -1

                for line in f.readlines():

                    len_line = len(line)
                    if len_line > 1:

                        if line.startswith("S	"):
                            i_MS1 = i_MS1 + 1
                            tmpScan = int(toolGetWord(line, 1, '	'))
                            dataMS1.INDEX_SCAN.append(tmpScan)

                            dataMS1.MATRIX_PEAK_MOZ[tmpScan] = []  
                            dataMS1.MATRIX_PEAK_INT[tmpScan] = []
                            dataMS1.MATRIX_PEAK_MARK[tmpScan] = []

                        elif line.startswith("H	"):
                            pass
                        elif line.startswith("I	"):
                            if line.startswith("I	IonInjectionTime"):
                                t = toolGetWord(line, 2, '	')
                                dataMS1.LIST_ION_INJECTION_TIME[tmpScan] = float(t)
                            elif line.startswith("I	RetTime	"):
                                t = toolGetWord(line, 2, '	')
                                dataMS1.INDEX_RT.append(float(t))
                        else:
                            dataMS1.MATRIX_PEAK_MOZ[tmpScan].append(float(toolGetWord(line, 0, ' ')))
                            dataMS1.MATRIX_PEAK_INT[tmpScan].append(float(toolGetWord(line, 1, ' ')))
                            dataMS1.MATRIX_PEAK_MARK[tmpScan].append(float(-1.0))

            
            fid_pkl = open(path_pkl, 'wb')
            pickle.dump(dataMS1, fid_pkl)
            fid_pkl.close()


class CFunctionParse_9:

    def __init__(self):

        pass

    def loadPKL(self, pathMS2):

        pathPKL = pathMS2 + '.pkl'
        dataMS2 = CFileMS2()
        pklFile = open(pathPKL, 'rb')
        dataMS2 = pickle.load(pklFile)
        pklFile.close()
        return dataMS2

    def ms2Topkl(self, pathMS2):

        
        path_pkl = pathMS2 + ".pkl"
        if os.access(path_pkl, os.F_OK):
            pass
        else:

            
            dataMS2 = CFileMS2()
            op_INIT_CFILE_MS2(dataMS2)

            
            f = open(pathMS2, 'r')
            i_MS2 = -1
            count = 0
            while True:
                line = f.readline()
                if not line:
                    break
                elif line:
                    if count % 1000 == 0:
                        print(count)
                    count += 1
                    len_line = len(line)
                    if len_line > 1:

                        if line.startswith("S	"):
                            i_MS2 = i_MS2 + 1
                            tmpScan = int(toolGetWord(line, 1, '	'))
                            if tmpScan > 80000:
                                break
                            dataMS2.INDEX_SCAN.append(tmpScan)

                            

                            dataMS2.MATRIX_PEAK_MOZ[tmpScan] = []  
                            dataMS2.MATRIX_PEAK_INT[tmpScan] = []

                        elif line.startswith("H	"):
                            pass
                        elif line.startswith("I	"):
                            if line.startswith("I	IonInjectionTime"):
                                t = line.split('\t')[2]
                                dataMS2.LIST_ION_INJECTION_TIME[tmpScan] = float(t)
                            elif line.startswith("I	RetTime	") or line.startswith("I	RTime	"):
                                t = line.split('\t')[2]
                                dataMS2.LIST_RET_TIME[tmpScan] = float(t)
                            elif line.startswith('I	ActivationCenter'):
                                t = line.split('\t')[2]
                                dataMS2.LIST_ACTIVATION_CENTER[tmpScan] = float(t)
                            elif line.startswith('I	PrecursorScan'):
                                t = line.split('\t')[2]
                                dataMS2.LIST_PRECURSOR_SCAN[tmpScan] = float(t)
                        elif line.startswith("Z	"):
                            pass
                        else:
                            if tmpScan > 70000:

                                dataMS2.MATRIX_PEAK_MOZ[tmpScan].append(float(toolGetWord(line, 0, ' ')))
                                dataMS2.MATRIX_PEAK_INT[tmpScan].append(float(toolGetWord(line, 1, ' ')))

            
            fid_pkl = open(path_pkl, 'wb')
            pickle.dump(dataMS2, fid_pkl)
            fid_pkl.close()


class CFunctionParse_10:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def raw2MS(self, inputListPathRaw):

        exe_MSFileReader = 'MSRawExport.exe'
        cfg_MSFileReader = 'MSExport.cfg'
        

        for path_raw in inputListPathRaw:
            print(INFO_TO_USER_TaskParseRaw[0] + path_raw)
            with open(cfg_MSFileReader, 'w') as f:

                f.write("[Data]\n")
                f.write("PATH_RAW=" + path_raw + '\n')

            
            if not os.path.exists(r".\lib\ThermoFisher.CommonCore.Data.dll"):
                logGetError(
                    'The specified .dll file was not found! Please check whether ThermoFisher.CommonCore.Data.dll in the lib folder of the pGlycoQuant directory exists')

            if not os.path.exists(r".\lib\ThermoFisher.CommonCore.RawFileReader.dll"):
                logGetError(
                    'The specified .dll file was not found! Please check whether ThermoFisher.CommonCore.RawFileReader.dll in the lib folder of the pGlycoQuant directory exists')

            cmd = exe_MSFileReader + ' {:s}'.format(cfg_MSFileReader)

            try:
                os.system(cmd)
            except:
                logGetError('MSExport.exe run wrong!')


class CFunctionParse_12:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def read(self, path):

        path = path[:-1] if (path[-1] == r'\\' or path[-1] == r'//') else path
        path_psm = path + r'\msmsScans.txt'
        path_protein = path + r'\proteinGroups.txt'
        path_peptide = path + r'\peptides.txt'
        path_evidence = path + r'\evidence.txt'
        path_summary = path + r'\summary.txt'

        for var_tmp_21 in self.dp.LIST_EXPERIMENT:

            self.dp.myID.LIST_SAMPLE_ID.append(var_tmp_21[0])
            self.dp.myProteinID.LIST_SAMPLE_ID.append(var_tmp_21[0])
            self.dp.myPeptideID.LIST_SAMPLE_ID.append(var_tmp_21[0])
            self.dp.myPrecursorID.LIST_SAMPLE_ID.append(var_tmp_21[0])
            self.dp.myIDForIRT.LIST_SAMPLE_ID.append(var_tmp_21[0])

            self.dp.myID.LIST_EXPERIMENT_ID.append(var_tmp_21[1])
            self.dp.myProteinID.LIST_EXPERIMENT_ID.append(var_tmp_21[1])
            self.dp.myPeptideID.LIST_EXPERIMENT_ID.append(var_tmp_21[1])
            self.dp.myPrecursorID.LIST_EXPERIMENT_ID.append(var_tmp_21[1])
            self.dp.myIDForIRT.LIST_EXPERIMENT_ID.append(var_tmp_21[1])

        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        

        
        with open(path_summary, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')
        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:-1]

        var_pos_36 = table_list.index('Raw file') if 'Raw file' in table_list else 0
        var_pos_61 = table_list.index('Experiment') if 'Experiment' in table_list else 0
        var_pos_63 = table_list.index('Fixed modifications')
        dic_Raw2Mod = {}
        dic_Raw2Experiment = {}

        for line in lines:
            if not line.startswith('Total'):
                line_list = line.split('\t')
                tmp_rawfile = line_list[var_pos_36]
                var_tmp_21 = line_list[var_pos_61]
                dic_Raw2Experiment[tmp_rawfile] = var_tmp_21
                tmp_fixMod = line_list[var_pos_63].split(';')
                var_tmp_79 = self.__soliderCreateDictFixMod(tmp_fixMod)
                if tmp_rawfile not in dic_Raw2Mod:
                    dic_Raw2Mod[tmp_rawfile] = var_tmp_79

        
        self.dp.myID.PSM_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]
        self.dp.myID.PEP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
        self.dp.myID.PRO_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
        self.dp.myID.PROGROUP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
        var_lis_67 = []
        var_lis_31 = []

        with open(path_psm, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')

        lines = lines[1:-1] if lines[-1] == '' else lines[1:]
        var_pos_54 = table_list.index('Raw file') if 'Raw file' in table_list else 0
        var_pos_29 = table_list.index('Scan number')
        var_pos_3 = table_list.index('Sequence')
        var_pos_26 = table_list.index('Proteins')

        for line in lines:

            line_list = line.split('\t')
            tmp_rawfile = line_list[var_pos_54]
            tmp_scan = int(line_list[var_pos_29])
            tmp_peptide = line_list[var_pos_3]

            if tmp_rawfile in self.dp.myID.LIST_SAMPLE_ID:

                tmp_index_raw = self.dp.myID.LIST_SAMPLE_ID.index(tmp_rawfile)
                tmp_protein = self.__soliderParsePro(line_list[var_pos_26])
                self.dp.myID.PSM_LIST_ID[tmp_index_raw].append(tmp_scan)
                self.dp.myID.PEP_LIST_ID[tmp_index_raw].append(tmp_peptide)
                self.dp.myID.PRO_LIST_ID[tmp_index_raw].extend(tmp_protein)

        for i in range(len(self.dp.myID.LIST_SAMPLE_ID)):
            var_lis_67.extend(self.dp.myID.PEP_LIST_ID[i])
            var_lis_31.extend(self.dp.myID.PRO_LIST_ID[i])

        self.dp.myID.PEP_LIST_ID = [set(i) for i in self.dp.myID.PEP_LIST_ID]
        self.dp.myID.PRO_LIST_ID = [set(i) for i in self.dp.myID.PRO_LIST_ID]
        self.dp.myID.N_PSM = sum([len(i) for i in self.dp.myID.PSM_LIST_ID])
        self.dp.myID.N_PEPTIDE = len(set(var_lis_67))
        self.dp.myID.N_PROTEIN = len(set(var_lis_31))
        var_dic_44 = {i_pep: '' for i_pep in set(var_lis_67)}
        del var_lis_67
        del var_lis_31

        
        var_dic_69 = {}  
        with open(path_protein, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_24 = table_list.index('Protein IDs') if 'Protein IDs' in table_list else 0
        var_pos_5 = table_list.index('Q-value')
        var_pos_91 = [table_list.index('LFQ intensity ' + dic_Raw2Experiment[i]) for i in self.dp.myProteinID.LIST_SAMPLE_ID]
        
        var_pos_6 = table_list.index('Reverse')
        var_pos_38 = table_list.index('Potential contaminant')
        position_iBAQ = []
        flag_iBAQ = 0 if 'iBAQ' in table_list else 0
        if flag_iBAQ:
            position_iBAQ = [table_list.index('iBAQ ' + dic_Raw2Experiment[i]) for i in self.dp.myProteinID.LIST_SAMPLE_ID]

        for line in lines:

            line_list = line.split('\t')
            tmp_protein = line_list[var_pos_24]
            tmp_reverse = line_list[var_pos_6]
            var_tmp_18 = line_list[var_pos_38]
            tmp_q_value = float(line_list[var_pos_5])

            if tmp_reverse != '+' and var_tmp_18 != '+' and tmp_q_value <= self.dp.myCFG.B4_THRESHOLD_FDR and self.__soliderParsePro(tmp_protein):

                var_dic_69[tmp_protein] = ''
                self.dp.myProteinID.PRO1_NAME.append(tmp_protein)
                self.dp.myProteinID.PRO3_SCORE0.append(tmp_q_value)
                self.dp.myProteinID.PRO2_INTENSITY.append([float(line_list[var_ipo_4])
                                                           for var_ipo_4 in var_pos_91])
                if flag_iBAQ:

                    list_iBAQ = [0 if np.isnan(float(line_list[i_position_iBAQ])) else float(line_list[i_position_iBAQ])
                                                          for i_position_iBAQ in position_iBAQ]
                    self.dp.myProteinID.PRO4_iBAQ.append(list_iBAQ)

                self.dp.myProteinID.N_PROTEIN += 1

        self.dp.myProteinID.LIST_PROTEIN_ID = self.dp.myProteinID.PRO1_NAME
        self.dp.myProteinID.MATRIX_INTENSITY = np.array(self.dp.myProteinID.PRO2_INTENSITY, dtype=np.float32)
        if flag_iBAQ:
            self.dp.myProteinID.MATRIX_IBAQ_LOG10 = np.array(self.dp.myProteinID.PRO4_iBAQ, dtype=np.float32)

        
        with open(path_peptide, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_10 = table_list.index('Sequence') if 'Sequence' in table_list else 0
        var_pos_91 = [table_list.index('Intensity ' + dic_Raw2Experiment[i]) for i in
                                  self.dp.myProteinID.LIST_SAMPLE_ID]
        var_pos_6 = table_list.index('Reverse')
        var_pos_38 = table_list.index('Potential contaminant')
        var_pos_24 = table_list.index('Proteins')
        var_pos_32 = table_list.index('Leading razor protein')
        var_dic_64 = {}

        for line in lines:

            line_list = line.split('\t')
            tmp_peptide = line_list[var_pos_10]
            tmp_reverse = line_list[var_pos_6]
            var_tmp_18 = line_list[var_pos_38]
            tmp_protein = line_list[var_pos_24]
            var_tmp_25 = line_list[var_pos_32]
            if self.__soliderParsePro(tmp_protein):
                if tmp_peptide in var_dic_44 and tmp_peptide not in var_dic_64:
                    var_dic_64[tmp_peptide] = var_tmp_25

                if tmp_reverse != '+' and var_tmp_18 != '+':

                    self.dp.myPeptideID.PEP1_SEQ.append(tmp_peptide)
                    self.dp.myPeptideID.PEPLIST1_INTENSITY.append([float(line_list[var_ipo_4])
                                                               for var_ipo_4 in var_pos_91])
                    self.dp.myPeptideID.N_PEPTIDE += 1

        self.dp.myPeptideID.LIST_PEPTIDE_ID = self.dp.myPeptideID.PEP1_SEQ
        self.dp.myPeptideID.MATRIX_INTENSITY = np.array(self.dp.myPeptideID.PEPLIST1_INTENSITY, dtype=np.float32)
        self.dp.myPeptideID.PEPLIST1_INTENSITY = []
        self.dp.myPeptideID.PEP1_SEQ = []

        var_lis_13 = []
        for i_exp in range(len(self.dp.myID.LIST_SAMPLE_ID)):
            self.dp.myID.PROGROUP_LIST_ID[i_exp] = set()
            for i_pep in self.dp.myID.PEP_LIST_ID[i_exp]:
                if i_pep in var_dic_64:
                    self.dp.myID.PROGROUP_LIST_ID[i_exp].add(var_dic_64[i_pep])
                    var_lis_13.append(var_dic_64[i_pep])
        self.dp.myID.N_PROTEINGROUP = len(set(var_lis_13))

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

    def __soliderCreateDictFixMod(self, inputListFixMod: list):

        dic_fixMod = {}

        for tmpFixMod in inputListFixMod:

            tmpFixMod = tmpFixMod.replace(' ', '')
            tmpSite = tmpFixMod.split('(')[1][:-1]

            if tmpSite != 'N-term' or tmpSite != 'C-term':  
                for i_site in tmpSite:
                    if i_site not in dic_fixMod:
                        dic_fixMod[i_site] = [tmpFixMod]
                    else:
                        dic_fixMod[i_site].append(tmpFixMod)
            else:
                if tmpSite not in dic_fixMod:
                    dic_fixMod[tmpSite] = [tmpFixMod]
                else:
                    dic_fixMod[tmpSite].append(tmpFixMod)

        return dic_fixMod

    def __soliderParseMod(self, inputMod: str, inputLength: int, inputDicFixMod: dict):

        
        dic_FixMOD = inputDicFixMod
        str_ModSequence = inputMod.strip('_')
        str_ModSequence = str_ModSequence.replace(' ', '')
        MOD_Standard = ''

        i_position = 0
        flag_mod = 0
        stack_mod = 0
        i_mod_name = ''
        if 'N-Term' in dic_FixMOD:
            i_mod_list = dic_FixMOD['N-Term']
            for i_mod_name in i_mod_list:
                MOD_Standard += str(0) + ',' + i_mod_name + ';'

        if 'C-Term' in dic_FixMOD:
            i_mod_list = dic_FixMOD['C-Term']
            for i_mod_name in i_mod_list:
                MOD_Standard += str(inputLength) + ',' + i_mod_name + ';'

        for i in range(len(str_ModSequence)):
            if str_ModSequence[i] != '(' and flag_mod == 0:
                i_AA = str_ModSequence[i]
                i_position += 1
                if i_AA in dic_FixMOD:
                    i_mod_list = dic_FixMOD[i_AA]
                    for i_mod_name in i_mod_list:
                        MOD_Standard += str(i_position) + ',' + i_mod_name + ';'
                i_mod_name = ''
            elif flag_mod == 0 and str_ModSequence[i] == '(':
                flag_mod = 1
                stack_mod += 1
            else:
                if str_ModSequence[i] == ')':
                    stack_mod -= 1
                elif str_ModSequence[i] == '(':
                    stack_mod += 1
                if stack_mod == 0:
                    flag_mod = 0
                    MOD_Standard += str(i_position) + ',' + i_mod_name + ';'
                else:
                    i_mod_name += str_ModSequence[i]

        return MOD_Standard

    def __soliderParsePro(self, inputPro: str):

        
        var_lis_57 = ['CON', 'REV']
        flag_wrong = 'sadasdqweqwqwdqdasdasd'

        if inputPro == '' or flag_wrong in inputPro:
            return []

        list_protein = inputPro.split(';')
        var_lis_75 = []

        for i_protein in list_protein:
            flag_exist = 0
            for j_flag in var_lis_57:
                if i_protein.startswith(j_flag):
                    flag_exist = 1
            if not flag_exist:
                var_lis_75.append(i_protein)

        return var_lis_75


class CFunctionParse_7:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def read(self, path):

        path = path[:-1] if (path[-1] == r'\\' or path[-1] == r'//') else path
        path_psm = path + r'\msms.txt'
        path_protein = path + r'\proteinGroups.txt'
        path_peptide = path + r'\peptides.txt'
        path_evidence = path + r'\evidence.txt'
        path_summary = path + r'\summary.txt'

        for var_tmp_21 in self.dp.LIST_EXPERIMENT:

            self.dp.myID.LIST_SAMPLE_ID.append(var_tmp_21[0])
            self.dp.myProteinID.LIST_SAMPLE_ID.append(var_tmp_21[0])
            self.dp.myPeptideID.LIST_SAMPLE_ID.append(var_tmp_21[0])
            self.dp.myPrecursorID.LIST_SAMPLE_ID.append(var_tmp_21[0])
            self.dp.myIDForIRT.LIST_SAMPLE_ID.append(var_tmp_21[0])

            self.dp.myID.LIST_EXPERIMENT_ID.append(var_tmp_21[1])
            self.dp.myProteinID.LIST_EXPERIMENT_ID.append(var_tmp_21[1])
            self.dp.myPeptideID.LIST_EXPERIMENT_ID.append(var_tmp_21[1])
            self.dp.myPrecursorID.LIST_EXPERIMENT_ID.append(var_tmp_21[1])
            self.dp.myIDForIRT.LIST_EXPERIMENT_ID.append(var_tmp_21[1])

        
        
        
        
        
        
        
        
        
        
        
        
        

        
        
        
        
        
        

        
        with open(path_summary, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')
        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:-1]

        var_pos_36 = table_list.index('Raw file')
        var_pos_61 = table_list.index('Experiment')
        var_pos_63 = table_list.index('Fixed modifications')
        dic_Raw2Mod = {}
        dic_Raw2Experiment = {}

        for line in lines:
            if not line.startswith('Total'):
                line_list = line.split('\t')
                tmp_rawfile = line_list[var_pos_36]
                var_tmp_21 = line_list[var_pos_61]
                dic_Raw2Experiment[tmp_rawfile] = var_tmp_21
                tmp_fixMod = line_list[var_pos_63].split(';')
                var_tmp_79 = self.__soliderCreateDictFixMod(tmp_fixMod)
                if tmp_rawfile not in dic_Raw2Mod:
                    dic_Raw2Mod[tmp_rawfile] = var_tmp_79

        
        self.dp.myID.PSM_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]
        self.dp.myID.PEP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
        self.dp.myID.PRO_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
        self.dp.myID.PROGROUP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
        var_lis_67 = []
        var_lis_31 = []

        with open(path_psm, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]
        var_pos_54 = table_list.index('Raw file')
        var_pos_29 = table_list.index('Scan number')
        var_pos_3 = table_list.index('Sequence')
        var_pos_26 = table_list.index('Proteins')

        for line in lines:

            line_list = line.split('\t')
            tmp_rawfile = line_list[var_pos_54]
            tmp_scan = int(line_list[var_pos_29])
            tmp_peptide = line_list[var_pos_3]

            if tmp_rawfile in self.dp.myID.LIST_SAMPLE_ID:

                tmp_index_raw = self.dp.myID.LIST_SAMPLE_ID.index(tmp_rawfile)
                tmp_protein = self.__soliderParsePro(line_list[var_pos_26])
                self.dp.myID.PSM_LIST_ID[tmp_index_raw].append(tmp_scan)
                self.dp.myID.PEP_LIST_ID[tmp_index_raw].append(tmp_peptide)
                self.dp.myID.PRO_LIST_ID[tmp_index_raw].extend(tmp_protein)

        for i in range(len(self.dp.myID.LIST_SAMPLE_ID)):
            var_lis_67.extend(self.dp.myID.PEP_LIST_ID[i])
            var_lis_31.extend(self.dp.myID.PRO_LIST_ID[i])

        self.dp.myID.PEP_LIST_ID = [set(i) for i in self.dp.myID.PEP_LIST_ID]
        self.dp.myID.PRO_LIST_ID = [set(i) for i in self.dp.myID.PRO_LIST_ID]
        self.dp.myID.N_PSM = sum([len(i) for i in self.dp.myID.PSM_LIST_ID])
        self.dp.myID.N_PEPTIDE = len(set(var_lis_67))
        self.dp.myID.N_PROTEIN = len(set(var_lis_31))
        var_dic_44 = {i_pep: '' for i_pep in set(var_lis_67)}
        del var_lis_67
        del var_lis_31

        
        var_dic_69 = {}  
        with open(path_protein, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_24 = table_list.index('Protein IDs')
        var_pos_5 = table_list.index('Q-value')
        var_pos_91 = [table_list.index('Intensity ' + dic_Raw2Experiment[i]) for i in self.dp.myProteinID.LIST_SAMPLE_ID]
        var_pos_6 = table_list.index('Reverse')
        var_pos_38 = table_list.index('Potential contaminant')
        position_iBAQ = []
        flag_iBAQ = 0 if 'iBAQ' in table_list else 0
        if flag_iBAQ:
            position_iBAQ = [table_list.index('iBAQ ' + dic_Raw2Experiment[i]) for i in self.dp.myProteinID.LIST_SAMPLE_ID]

        for line in lines:

            line_list = line.split('\t')
            tmp_protein = line_list[var_pos_24]
            tmp_reverse = line_list[var_pos_6]
            var_tmp_18 = line_list[var_pos_38]
            tmp_q_value = float(line_list[var_pos_5])

            if tmp_reverse != '+' and var_tmp_18 != '+' and tmp_q_value <= self.dp.myCFG.B4_THRESHOLD_FDR:

                var_dic_69[tmp_protein] = ''
                self.dp.myProteinID.PRO1_NAME.append(tmp_protein)
                self.dp.myProteinID.PRO3_SCORE0.append(tmp_q_value)
                self.dp.myProteinID.PRO2_INTENSITY.append([float(line_list[var_ipo_4])
                                                           for var_ipo_4 in var_pos_91])
                if flag_iBAQ:

                    list_iBAQ = [0 if np.isnan(float(line_list[i_position_iBAQ])) else float(line_list[i_position_iBAQ])
                                                          for i_position_iBAQ in position_iBAQ]
                    self.dp.myProteinID.PRO4_iBAQ.append(list_iBAQ)

                self.dp.myProteinID.N_PROTEIN += 1

        self.dp.myProteinID.LIST_PROTEIN_ID = self.dp.myProteinID.PRO1_NAME
        self.dp.myProteinID.MATRIX_INTENSITY = np.array(self.dp.myProteinID.PRO2_INTENSITY, dtype=np.float32)
        if flag_iBAQ:
            self.dp.myProteinID.MATRIX_IBAQ_LOG10 = np.array(self.dp.myProteinID.PRO4_iBAQ, dtype=np.float32)

        
        with open(path_peptide, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_10 = table_list.index('Sequence')
        var_pos_91 = [table_list.index('Intensity ' + dic_Raw2Experiment[i]) for i in
                                  self.dp.myProteinID.LIST_SAMPLE_ID]
        var_pos_6 = table_list.index('Reverse')
        var_pos_38 = table_list.index('Potential contaminant')
        var_pos_24 = table_list.index('Proteins')
        var_pos_32 = table_list.index('Leading razor protein')
        var_dic_64 = {}

        for line in lines:

            line_list = line.split('\t')
            tmp_peptide = line_list[var_pos_10]
            tmp_reverse = line_list[var_pos_6]
            var_tmp_18 = line_list[var_pos_38]
            tmp_protein = line_list[var_pos_24]
            var_tmp_25 = line_list[var_pos_32]
            if self.__soliderParsePro(tmp_protein):
                if tmp_peptide in var_dic_44 and tmp_peptide not in var_dic_64:
                    var_dic_64[tmp_peptide] = var_tmp_25

                if tmp_reverse != '+' and var_tmp_18 != '+':

                    self.dp.myPeptideID.PEP1_SEQ.append(tmp_peptide)
                    self.dp.myPeptideID.PEPLIST1_INTENSITY.append([float(line_list[var_ipo_4])
                                                               for var_ipo_4 in var_pos_91])
                    self.dp.myPeptideID.N_PEPTIDE += 1

        self.dp.myPeptideID.LIST_PEPTIDE_ID = self.dp.myPeptideID.PEP1_SEQ
        self.dp.myPeptideID.MATRIX_INTENSITY = np.array(self.dp.myPeptideID.PEPLIST1_INTENSITY, dtype=np.float32)
        self.dp.myPeptideID.PEPLIST1_INTENSITY = []
        self.dp.myPeptideID.PEP1_SEQ = []

        var_lis_13 = []
        for i_exp in range(len(self.dp.myID.LIST_SAMPLE_ID)):
            self.dp.myID.PROGROUP_LIST_ID[i_exp] = set()
            for i_pep in self.dp.myID.PEP_LIST_ID[i_exp]:
                if i_pep in var_dic_64:
                    self.dp.myID.PROGROUP_LIST_ID[i_exp].add(var_dic_64[i_pep])
                    var_lis_13.append(var_dic_64[i_pep])
        self.dp.myID.N_PROTEINGROUP = len(set(var_lis_13))

        
        with open(path_evidence, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_10 = table_list.index('Sequence')
        var_pos_62 = table_list.index('Modified sequence')
        position_mod = table_list.index('Modifications')
        var_pos_80 = table_list.index('Charge')
        var_pos_36 = table_list.index('Raw file')
        var_pos_24 = table_list.index('Proteins')
        var_pos_2 = table_list.index('MS/MS m/z')
        var_pos_30 = table_list.index('m/z')
        var_pos_68 = table_list.index('MS/MS scan number')
        position_rt = table_list.index('Calibrated retention time')
        var_pos_28 = table_list.index('Calibrated retention time start')
        var_pos_12 = table_list.index('Calibrated retention time finish')
        var_pos_8 = table_list.index('Retention time calibration')
        var_pos_19 = table_list.index('PEP')
        var_pos_45 = table_list.index('Score')
        var_pos_6 = table_list.index('Reverse')
        var_pos_38 = table_list.index('Potential contaminant')
        var_pos_22 = table_list.index('Intensity')
        var_pos_89 = table_list.index('Type')

        dic_precursorID = {}
        dic_iRTID = {}
        list_iRT_MaxIntensity = []
        list_Pre_MaxIntensity = []

        for line in lines:

            line_list = line.split('\t')
            tmp_peptide = line_list[var_pos_10]
            tmp_mod = line_list[position_mod]
            var_tmp_78 = line_list[var_pos_62]
            tmp_charge = int(line_list[var_pos_80])
            tmp_protein = line_list[var_pos_24]
            tmp_rawfile = line_list[var_pos_36]
            tmp_score0 = float(line_list[var_pos_19])
            var_tmp_55 = float(line_list[var_pos_8])
            tmp_rt = float(line_list[position_rt]) - var_tmp_55
            tmp_score1 = float(line_list[var_pos_45])
            tmp_reverse = line_list[var_pos_6]
            var_tmp_18 = line_list[var_pos_38]
            tmp_precursorID = var_tmp_78[1:-1] + str(tmp_charge)
            tmp_type_pre = line_list[var_pos_89]
            tmp_intensity = float(line_list[var_pos_22]) if line_list[var_pos_22] != '' else 0.

            var_fla_42 = tmp_rawfile in self.dp.myPrecursorID.LIST_SAMPLE_ID  

            if (tmp_score0 <= 1 or (math.isnan(tmp_score0) and (tmp_precursorID in dic_precursorID))) \
                    and (tmp_reverse != '+' and var_tmp_18 != '+') and var_fla_42 and\
                    tmp_type_pre != 'MSMS':  

                if tmp_precursorID not in dic_precursorID:

                    var_tmp_43 = self.__soliderParseMod(var_tmp_78, len(tmp_peptide),
                                                              dic_Raw2Mod[tmp_rawfile])  

                    self.dp.myPrecursorID.PRE2_MOD.append(var_tmp_43)
                    self.dp.myPrecursorID.LIST_PRECURSOR_ID.append(tmp_precursorID)
                    self.dp.myPrecursorID.PRE1_SEQ.append(tmp_peptide)
                    self.dp.myPrecursorID.PRE3_CHARGE.append(tmp_charge)

                    self.dp.myPrecursorID.PRELIST1_RT.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                    self.dp.myPrecursorID.PRELIST11_SCORE0.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                    self.dp.myPrecursorID.PRELIST12_SCORE1.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))

                    self.dp.myPrecursorID.PRELIST2_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                    list_Pre_MaxIntensity.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))

                    dic_precursorID[tmp_precursorID] = self.dp.myPrecursorID.N_PRECURSOR
                    tmp_index = self.dp.myPrecursorID.N_PRECURSOR

                    self.dp.myPrecursorID.N_PRECURSOR += 1

                else:
                    tmp_index = dic_precursorID[tmp_precursorID]

                index_raw = self.dp.myPrecursorID.LIST_SAMPLE_ID.index(tmp_rawfile)
                self.dp.myPrecursorID.PRELIST1_RT[tmp_index][index_raw] = tmp_rt
                if not math.isnan(tmp_score0):
                    self.dp.myPrecursorID.PRELIST11_SCORE0[tmp_index][index_raw] = tmp_score0
                if not math.isnan(tmp_score0):
                    self.dp.myPrecursorID.PRELIST12_SCORE1[tmp_index][index_raw] = tmp_score1

                if not math.isnan(tmp_score0):

                    if self.dp.myPrecursorID.PRELIST2_INTENSITY[tmp_index][index_raw] == VALUE_ILLEGAL:
                        self.dp.myPrecursorID.PRELIST2_INTENSITY[tmp_index][index_raw] = tmp_intensity
                        list_Pre_MaxIntensity[tmp_index][index_raw] = tmp_intensity

                    elif tmp_intensity > list_Pre_MaxIntensity[tmp_index][index_raw]:
                        self.dp.myPrecursorID.PRELIST2_INTENSITY[tmp_index][index_raw] = tmp_intensity
                        list_Pre_MaxIntensity[tmp_index][index_raw] = tmp_intensity

                    else:
                        pass

                
                if tmp_peptide in self.dp.myINI.LIST_IRT_PEPTIDE and tmp_charge in self.dp.myINI.LIST_IRT_CHARGE \
                        and tmp_mod == 'Unmodified':

                    var_tmp_78 = line_list[var_pos_62]
                    tmp_moz_clc = float(line_list[var_pos_30])
                    var_tmp_43 = self.__soliderParseMod(var_tmp_78, len(tmp_peptide),
                                                              dic_Raw2Mod[tmp_rawfile])  
                    tmp_ms2scan = line_list[var_pos_68]
                    tmp_rt_start = float(line_list[var_pos_28]) - var_tmp_55
                    tmp_rt_end = float(line_list[var_pos_12]) - var_tmp_55
                    tmp_moz_exp = float(line_list[var_pos_2]) if line_list[var_pos_2] != '' else math.nan
                    tmp_intensity = float(line_list[var_pos_22]) if line_list[var_pos_22] != '' else 0.

                    if tmp_precursorID not in dic_iRTID:

                        self.dp.myIDForIRT.LIST_PRECURSOR_ID.append(tmp_peptide + '_' + var_tmp_43 + '_' + str(tmp_charge))
                        self.dp.myIDForIRT.PRE1_SEQ.append(tmp_peptide)
                        self.dp.myIDForIRT.PRE2_MOD.append(var_tmp_43)
                        self.dp.myIDForIRT.PRE3_CHARGE.append(tmp_charge)
                        self.dp.myIDForIRT.PRE4_MOZ_CLC.append(float(tmp_moz_clc))
                        self.dp.myIDForIRT.PRE5_PROTEIN.append(tmp_protein)

                        self.dp.myIDForIRT.PRELIST1_SCAN_ID.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST2_RT.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST3_RT_START.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST4_RT_END.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST5_MOZ_EXP.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST6_SCORE0.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST7_SCORE1.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST8_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))

                        self.dp.myIDForIRT.PRELIST10_MS1_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST11_MS1_MASS_ACCURACY.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST_12_MS2_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST_13_MS2_MASS_ACCURACY.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST_14_DATA_POINT_PRE_PEAK.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST15_FWHM.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))


                        list_iRT_MaxIntensity.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))

                        iRT_index = self.dp.myIDForIRT.N_PRECURSOR
                        dic_iRTID[tmp_precursorID] = iRT_index
                        self.dp.myIDForIRT.N_PRECURSOR += 1

                    else:

                        iRT_index = dic_iRTID[tmp_precursorID]

                    index_raw = self.dp.myIDForIRT.LIST_SAMPLE_ID.index(tmp_rawfile)
                    if tmp_ms2scan != '':
                        if self.dp.myIDForIRT.PRELIST1_SCAN_ID[iRT_index][index_raw] == VALUE_ILLEGAL:
                            self.dp.myIDForIRT.PRELIST1_SCAN_ID[iRT_index][index_raw] = [int(tmp_ms2scan)]
                        else:
                            self.dp.myIDForIRT.PRELIST1_SCAN_ID[iRT_index][index_raw].append(int(tmp_ms2scan))
                        if self.dp.myIDForIRT.PRELIST6_SCORE0[iRT_index][index_raw] == VALUE_ILLEGAL:
                            self.dp.myIDForIRT.PRELIST6_SCORE0[iRT_index][index_raw] = []
                            if not math.isnan(tmp_score0):
                                self.dp.myIDForIRT.PRELIST6_SCORE0[iRT_index][index_raw].append(tmp_score0)
                            else:
                                self.dp.myIDForIRT.PRELIST6_SCORE0[iRT_index][index_raw].append(7.16)

                    if not math.isnan(tmp_moz_exp):
                        if self.dp.myIDForIRT.PRELIST5_MOZ_EXP[iRT_index][index_raw] == VALUE_ILLEGAL:
                            self.dp.myIDForIRT.PRELIST5_MOZ_EXP[iRT_index][index_raw] = [tmp_moz_exp]
                        else:
                            self.dp.myIDForIRT.PRELIST5_MOZ_EXP[iRT_index][index_raw].append(tmp_moz_exp)

                    if not math.isnan(tmp_score1):
                        self.dp.myIDForIRT.PRELIST7_SCORE1[iRT_index][index_raw] = tmp_score1

                    if self.dp.myIDForIRT.PRELIST8_INTENSITY[iRT_index][index_raw] == VALUE_ILLEGAL:
                        self.dp.myIDForIRT.PRELIST2_RT[iRT_index][index_raw] = tmp_rt
                        self.dp.myIDForIRT.PRELIST3_RT_START[iRT_index][index_raw] = tmp_rt_start
                        self.dp.myIDForIRT.PRELIST4_RT_END[iRT_index][index_raw] = tmp_rt_end
                        self.dp.myIDForIRT.PRELIST8_INTENSITY[iRT_index][index_raw] = tmp_intensity
                        list_iRT_MaxIntensity[iRT_index][index_raw] = tmp_intensity


                    elif tmp_intensity > list_iRT_MaxIntensity[iRT_index][index_raw]:
                        self.dp.myIDForIRT.PRELIST2_RT[iRT_index][index_raw] = tmp_rt
                        self.dp.myIDForIRT.PRELIST3_RT_START[iRT_index][index_raw] = tmp_rt_start
                        self.dp.myIDForIRT.PRELIST4_RT_END[iRT_index][index_raw] = tmp_rt_end
                        self.dp.myIDForIRT.PRELIST8_INTENSITY[iRT_index][index_raw] = tmp_intensity
                        list_iRT_MaxIntensity[iRT_index][index_raw] = tmp_intensity


                    else:
                        self.dp.myIDForIRT.PRELIST8_INTENSITY[iRT_index][index_raw] += tmp_intensity


        
        
        
        
        
        
        
        

        self.dp.myPrecursorID.MATRIX_RT = np.array(self.dp.myPrecursorID.PRELIST1_RT)
        self.dp.myPrecursorID.MATRIX_INTENSITY = np.array((self.dp.myPrecursorID.PRELIST2_INTENSITY))
        self.dp.myPrecursorID.MATRIX_INTENSITY[self.dp.myPrecursorID.MATRIX_INTENSITY < 0.] = 0.

    def __soliderCreateDictFixMod(self, inputListFixMod: list):

        dic_fixMod = {}

        for tmpFixMod in inputListFixMod:

            tmpFixMod = tmpFixMod.replace(' ', '')
            tmpSite = tmpFixMod.split('(')[1][:-1]

            if tmpSite != 'N-term' or tmpSite != 'C-term':  
                for i_site in tmpSite:
                    if i_site not in dic_fixMod:
                        dic_fixMod[i_site] = [tmpFixMod]
                    else:
                        dic_fixMod[i_site].append(tmpFixMod)
            else:
                if tmpSite not in dic_fixMod:
                    dic_fixMod[tmpSite] = [tmpFixMod]
                else:
                    dic_fixMod[tmpSite].append(tmpFixMod)

        return dic_fixMod

    def __soliderParseMod(self, inputMod: str, inputLength: int, inputDicFixMod: dict):

        
        dic_FixMOD = inputDicFixMod
        str_ModSequence = inputMod.strip('_')
        str_ModSequence = str_ModSequence.replace(' ', '')
        MOD_Standard = ''

        i_position = 0
        flag_mod = 0
        stack_mod = 0
        i_mod_name = ''
        if 'N-Term' in dic_FixMOD:
            i_mod_list = dic_FixMOD['N-Term']
            for i_mod_name in i_mod_list:
                MOD_Standard += str(0) + ',' + i_mod_name + ';'

        if 'C-Term' in dic_FixMOD:
            i_mod_list = dic_FixMOD['C-Term']
            for i_mod_name in i_mod_list:
                MOD_Standard += str(inputLength) + ',' + i_mod_name + ';'

        for i in range(len(str_ModSequence)):
            if str_ModSequence[i] != '(' and flag_mod == 0:
                i_AA = str_ModSequence[i]
                i_position += 1
                if i_AA in dic_FixMOD:
                    i_mod_list = dic_FixMOD[i_AA]
                    for i_mod_name in i_mod_list:
                        MOD_Standard += str(i_position) + ',' + i_mod_name + ';'
                i_mod_name = ''
            elif flag_mod == 0 and str_ModSequence[i] == '(':
                flag_mod = 1
                stack_mod += 1
            else:
                if str_ModSequence[i] == ')':
                    stack_mod -= 1
                elif str_ModSequence[i] == '(':
                    stack_mod += 1
                if stack_mod == 0:
                    flag_mod = 0
                    MOD_Standard += str(i_position) + ',' + i_mod_name + ';'
                else:
                    i_mod_name += str_ModSequence[i]

        return MOD_Standard

    def __soliderParsePro(self, inputPro: str):

        
        var_lis_57 = ['CON', 'REV']
        if inputPro == '':
            return []

        list_protein = inputPro.split(';')
        var_lis_75 = []

        for i_protein in list_protein:
            flag_exist = 0
            for j_flag in var_lis_57:
                if i_protein.startswith(j_flag):
                    flag_exist = 1
            if not flag_exist:
                var_lis_75.append(i_protein)

        return var_lis_75


class CFunctionParse_3:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def read(self, path):

        path = path[:-1] if (path[-1] == r'\\' or path[-1] == r'//') else path
        path_psm = path + r'\pQuant.spectra.list'
        path_protein = path + r'\pQuant.protein.list'
        path_peptide = path + r'\pQuant.modification.list'

        var_str_71 = 'ECOLIqweqweqweqweqe'  

        for tmp_group in self.dp.LIST_EXPERIMENT_GROUP:
            self.dp.myID.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myProteinGroupID.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myProteinID.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myPeptideID.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myPrecursorID.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myIDForIRT.LIST_SAMPLE_ID.extend(tmp_group[1])

            self.dp.myID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
            self.dp.myProteinGroupID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
            self.dp.myProteinID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
            self.dp.myPeptideID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
            self.dp.myPrecursorID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
            self.dp.myIDForIRT.LIST_EXPERIMENT_ID.extend(tmp_group[2])

            
            self.dp.myID.PSM_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]
            self.dp.myID.PEP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
            self.dp.myID.PRO_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
            self.dp.myID.PROGROUP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]
            var_lis_67 = []
            var_lis_31 = []

        with open(path_psm, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_10 = table_list.index('Sequence')
        position_mod = table_list.index('Modification')
        var_pos_80 = table_list.index('Charge')
        var_pos_36 = table_list.index('File_Name')
        var_pos_24 = table_list.index('Proteins')
        var_pos_30 = table_list.index('MZ({:s})'.format(self.dp.myPeptideID.LIST_SAMPLE_ID[0]))
        var_pos_68 = table_list.index('Scan_No')
        var_pos_28 = [table_list.index('RT_Start_Sec.({:s})'.format(i)) for i in
                             self.dp.myPeptideID.LIST_SAMPLE_ID]
        var_pos_77 = [table_list.index('RT_Length_Sec.({:s})'.format(i)) for i in
                              self.dp.myPeptideID.LIST_SAMPLE_ID]
        var_pos_22 = [table_list.index('Intensity({:s})'.format(i)) for i in
                              self.dp.myPeptideID.LIST_SAMPLE_ID]
        var_pos_19 = table_list.index('Q-value')
        var_pos_45 = table_list.index('Final_Score')

        dic_precursorID = {}
        dic_iRTID = {}
        list_iRT_MaxIntensity = []

        for line in lines:

            line_list = line.split('\t')
            tmp_peptide = line_list[var_pos_10]
            tmp_mod = line_list[position_mod]
            tmp_charge = int(line_list[var_pos_80])
            tmp_protein = line_list[var_pos_24]
            tmp_rawfile = line_list[var_pos_36].split('.')[0]
            tmp_score0 = float(line_list[var_pos_19])
            tmp_rt_start = [float(line_list[i_index]) / 60 for i_index in
                            var_pos_28]  
            tmp_rt_length = [float(line_list[i_index]) / 60 for i_index in
                             var_pos_77]  
            tmp_rt = [tmp_rt_start[i] + tmp_rt_length[i] / 2 for i in range(len(tmp_rt_start))]
            tmp_score1 = float(line_list[var_pos_45])
            tmp_precursorID = tmp_peptide + tmp_mod + str(tmp_charge)
            tmp_ms2scan = line_list[var_pos_68]

            var_tmp_51 = tmp_protein.split('/')[:-1]
            flag_rev_con = len(var_tmp_51) - sum(
                [1 if (i.startswith('CON') or i.startswith('REV') or var_str_71 in i) else 0 for i in var_tmp_51])
            var_fla_42 = tmp_rawfile in self.dp.myPrecursorID.LIST_SAMPLE_ID  

            if (tmp_score0 <= 1 or (math.isnan(tmp_score0) and (tmp_precursorID in dic_precursorID))) \
                    and flag_rev_con and var_fla_42:  

                tmp_index_raw = self.dp.myID.LIST_SAMPLE_ID.index(tmp_rawfile)
                tmp_protein = self.__soliderParsePro(tmp_protein)
                tmp_protein = [i_protein for i_protein in tmp_protein if not(i_protein.startswith('CON') or i_protein.startswith('REV') or var_str_71 not in i_protein)]

                self.dp.myID.PSM_LIST_ID[tmp_index_raw].append(tmp_ms2scan)
                self.dp.myID.PEP_LIST_ID[tmp_index_raw].append(tmp_peptide)
                self.dp.myID.PRO_LIST_ID[tmp_index_raw].extend(tmp_protein)

                if tmp_precursorID not in dic_precursorID:
                    self.dp.myPrecursorID.PRE2_MOD.append(tmp_mod)
                    self.dp.myPrecursorID.LIST_PRECURSOR_ID.append(
                        tmp_peptide + '_' + tmp_mod + '_' + str(tmp_charge))
                    self.dp.myPrecursorID.PRE1_SEQ.append(tmp_peptide)
                    self.dp.myPrecursorID.PRE3_CHARGE.append(tmp_charge)

                    self.dp.myPrecursorID.PRELIST1_RT.append(tmp_rt)
                    dic_precursorID[tmp_precursorID] = ''
                    self.dp.myPrecursorID.N_PRECURSOR += 1

                
                if tmp_peptide in self.dp.myINI.LIST_IRT_PEPTIDE and tmp_charge in self.dp.myINI.LIST_IRT_CHARGE \
                        and tmp_mod == '':

                    tmp_moz_clc = float(line_list[var_pos_30])
                    var_tmp_43 = self.__soliderParseMod(tmp_mod)  
                    tmp_ms2scan = line_list[var_pos_68]
                    tmp_rt_end = [tmp_rt_start[i] + tmp_rt_length[i] for i in range(len(tmp_rt_start))]
                    tmp_intensity = [float(line_list[i_position]) for i_position in var_pos_22]

                    if tmp_precursorID not in dic_iRTID:

                        self.dp.myIDForIRT.LIST_PRECURSOR_ID.append(
                            tmp_peptide + '_' + var_tmp_43 + '_' + str(tmp_charge))
                        self.dp.myIDForIRT.PRE1_SEQ.append(tmp_peptide)
                        self.dp.myIDForIRT.PRE2_MOD.append(var_tmp_43)
                        self.dp.myIDForIRT.PRE3_CHARGE.append(tmp_charge)
                        self.dp.myIDForIRT.PRE4_MOZ_CLC.append(float(tmp_moz_clc))
                        self.dp.myIDForIRT.PRE5_PROTEIN.append(tmp_protein)

                        self.dp.myIDForIRT.PRELIST1_SCAN_ID.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST2_RT.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST3_RT_START.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST4_RT_END.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST5_MOZ_EXP.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST6_SCORE0.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST7_SCORE1.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST8_INTENSITY.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        list_iRT_MaxIntensity.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))

                        self.dp.myIDForIRT.PRELIST10_MS1_INTENSITY.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST11_MS1_MASS_ACCURACY.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST_12_MS2_INTENSITY.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST_13_MS2_MASS_ACCURACY.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST_14_DATA_POINT_PRE_PEAK.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                        self.dp.myIDForIRT.PRELIST15_FWHM.append(
                            [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))

                        iRT_index = self.dp.myIDForIRT.N_PRECURSOR
                        dic_iRTID[tmp_precursorID] = iRT_index
                        self.dp.myIDForIRT.N_PRECURSOR += 1

                    else:

                        iRT_index = dic_iRTID[tmp_precursorID]

                    index_raw = self.dp.myIDForIRT.LIST_SAMPLE_ID.index(tmp_rawfile)

                    if tmp_ms2scan != '':
                        if self.dp.myIDForIRT.PRELIST1_SCAN_ID[iRT_index][index_raw] == VALUE_ILLEGAL:
                            self.dp.myIDForIRT.PRELIST1_SCAN_ID[iRT_index][index_raw] = [int(tmp_ms2scan)]
                        else:
                            self.dp.myIDForIRT.PRELIST1_SCAN_ID[iRT_index][index_raw].append(int(tmp_ms2scan))
                        if self.dp.myIDForIRT.PRELIST6_SCORE0[iRT_index][index_raw] == VALUE_ILLEGAL:
                            self.dp.myIDForIRT.PRELIST6_SCORE0[iRT_index][index_raw] = []
                        if not math.isnan(tmp_score0):
                            self.dp.myIDForIRT.PRELIST6_SCORE0[iRT_index][index_raw].append(tmp_score0)
                        else:
                            self.dp.myIDForIRT.PRELIST6_SCORE0[iRT_index][index_raw].append(1.)

                    
                    

                    if tmp_intensity[index_raw] > list_iRT_MaxIntensity[iRT_index][index_raw]:  

                        self.dp.myIDForIRT.PRELIST2_RT[iRT_index][index_raw] = tmp_rt[index_raw]
                        self.dp.myIDForIRT.PRELIST3_RT_START[iRT_index][index_raw] = tmp_rt_start[index_raw]
                        self.dp.myIDForIRT.PRELIST4_RT_END[iRT_index][index_raw] = tmp_rt_end[index_raw]
                        self.dp.myIDForIRT.PRELIST8_INTENSITY[iRT_index][index_raw] = tmp_intensity[index_raw]
                        list_iRT_MaxIntensity[iRT_index][index_raw] = tmp_intensity[index_raw]

                    
                    
                    
                    
                    
                    
                    

        var_lis_67 = []
        var_lis_31 = []
        for i in range(len(self.dp.myID.LIST_SAMPLE_ID)):
            var_lis_67.extend(self.dp.myID.PEP_LIST_ID[i])
            var_lis_31.extend(self.dp.myID.PRO_LIST_ID[i])

        self.dp.myID.PEP_LIST_ID = [set(i) for i in self.dp.myID.PEP_LIST_ID]
        self.dp.myID.PRO_LIST_ID = [set(i) for i in self.dp.myID.PRO_LIST_ID]
        self.dp.myID.N_PSM = sum([len(i) for i in self.dp.myID.PSM_LIST_ID])
        self.dp.myID.N_PEPTIDE = len(set(var_lis_67))
        self.dp.myID.N_PROTEIN = len(set(var_lis_31))
        var_dic_44 = {i_pep: '' for i_pep in set(var_lis_67)}
        del var_lis_67
        del var_lis_31

        with open(path_protein, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]
        var_dic_65 = {}
        var_dic_56 = {}

        var_pos_24 = table_list.index('ProteinName')
        var_pos_32 = table_list.index('GroupID')
        var_pos_22 = [table_list.index(i) for i in self.dp.myProteinID.LIST_SAMPLE_ID]

        for line in lines:

            line_list = line.split('\t')
            tmp_protein = line_list[var_pos_24]
            tmp_group = line_list[var_pos_32]

            if not(tmp_protein.startswith('CON') or tmp_protein.startswith('REV') or var_str_71 in tmp_protein):
                var_dic_65[tmp_protein] = tmp_group

                tmp_intensity = [float(line_list[i_position]) for i_position in var_pos_22]
                self.dp.myProteinID.PRO1_NAME.append(tmp_protein)
                self.dp.myProteinID.PRO2_INTENSITY.append(tmp_intensity)
                self.dp.myProteinID.N_PROTEIN += 1

            if not (tmp_group.startswith('CON') or tmp_group.startswith('REV') or var_str_71 in tmp_group):
                if tmp_group not in var_dic_56:
                    tmp_intensity = [float(line_list[i_position]) for i_position in var_pos_22]
                    self.dp.myProteinGroupID.PRO1_NAME.append(tmp_protein)
                    self.dp.myProteinGroupID.PRO2_INTENSITY.append(tmp_intensity)
                    self.dp.myProteinGroupID.N_PROTEIN += 1
                    var_dic_56[tmp_group] = 1

        self.dp.myProteinID.LIST_PROTEIN_ID = self.dp.myProteinID.PRO1_NAME
        self.dp.myProteinID.MATRIX_INTENSITY = np.array(self.dp.myProteinID.PRO2_INTENSITY)

        self.dp.myProteinGroupID.LIST_PROTEIN_ID = self.dp.myProteinGroupID.PRO1_NAME
        self.dp.myProteinGroupID.MATRIX_INTENSITY = np.array(self.dp.myProteinGroupID.PRO2_INTENSITY)

        with open(path_peptide, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_10 = table_list.index('Sequence')
        var_pos_24 = table_list.index('Protein')
        var_pos_22 = [table_list.index(i) for i in self.dp.myPeptideID.LIST_SAMPLE_ID]
        var_dic_64 = {}
        var_dic_70 = {}

        for line in lines:

            line_list = line.split('\t')
            tmp_peptide = line_list[var_pos_10]
            tmp_intensity = [float(line_list[i_position]) for i_position in var_pos_22]

            if tmp_peptide in var_dic_44:
                tmp_protein = line_list[var_pos_24]
                var_tmp_82 = tmp_protein.split('/')
                for tmp_i_protein in var_tmp_82:
                    if tmp_i_protein in var_dic_65:
                        if tmp_peptide not in var_dic_64:
                            var_dic_64[tmp_peptide] = var_dic_65[tmp_i_protein]

            if tmp_peptide not in var_dic_70:

                self.dp.myPeptideID.PEP1_SEQ.append(tmp_peptide)
                self.dp.myPeptideID.PEPLIST1_INTENSITY.append(tmp_intensity)
                var_dic_70[tmp_peptide] = self.dp.myPeptideID.N_PEPTIDE
                self.dp.myPeptideID.N_PEPTIDE += 1

            else:
                tmp_index = var_dic_70[tmp_peptide]
                self.dp.myPeptideID.PEPLIST1_INTENSITY[tmp_index] = [
                    self.dp.myPeptideID.PEPLIST1_INTENSITY[tmp_index][i_index] + tmp_intensity[i_index]
                    for i_index in range(len(tmp_intensity))]

        var_lis_13 = []
        for i_exp in range(len(self.dp.myID.LIST_SAMPLE_ID)):
            self.dp.myID.PROGROUP_LIST_ID[i_exp] = set()
            for i_pep in self.dp.myID.PEP_LIST_ID[i_exp]:
                self.dp.myID.PROGROUP_LIST_ID[i_exp].add(var_dic_64[i_pep])
                var_lis_13.append(var_dic_64[i_pep])
        
        self.dp.myID.N_PROTEINGROUP = self.dp.myProteinGroupID.N_PROTEIN

        self.dp.myPeptideID.LIST_PEPTIDE_ID = self.dp.myPeptideID.PEP1_SEQ
        self.dp.myPeptideID.MATRIX_INTENSITY = np.array(self.dp.myPeptideID.PEPLIST1_INTENSITY)
        self.dp.myPeptideID.PEP1_SEQ = []
        self.dp.myPeptideID.PEPLIST1_INTENSITY = []

        self.dp.myPrecursorID.MATRIX_RT = np.array(self.dp.myPrecursorID.PRELIST1_RT)

    def __soliderParsePro(self, inputPro):

        return inputPro.split('/')[:-1]

    def __soliderParseMod(self, inputMod):

        return inputMod


class CFunctionParse_8:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def readProteinFile(self, path):

        path_protein = path

        for tmp_group in self.dp.LIST_EXPERIMENT_GROUP:
            self.dp.myID.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myProteinID.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myPeptideID.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myPrecursorID.LIST_SAMPLE_ID.extend(tmp_group[1])
            self.dp.myIDForIRT.LIST_SAMPLE_ID.extend(tmp_group[1])

            self.dp.myID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
            self.dp.myProteinID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
            self.dp.myPeptideID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
            self.dp.myPrecursorID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
            self.dp.myIDForIRT.LIST_EXPERIMENT_ID.extend(tmp_group[2])

            
            self.dp.myID.PSM_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]
            self.dp.myID.PEP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
            self.dp.myID.PRO_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
            self.dp.myID.PROGROUP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]
            var_lis_31 = []

        with open(path_protein, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_32 = table_list.index('PG.ProteinAccessions')
        var_pos_22 = [table_list.index(i + '.PG.Quantity') for i in self.dp.myProteinID.LIST_SAMPLE_ID]

        for line in lines:

            line_list = line.split('\t')
            tmp_group = line_list[var_pos_32]

            if 'CON' not in tmp_group and 'REV' not in tmp_group:

                tmp_intensity = [float(line_list[i_position]) for i_position in var_pos_22]
                self.dp.myProteinID.PRO1_NAME.append(tmp_group)
                self.dp.myProteinID.PRO2_INTENSITY.append(tmp_intensity)
                self.dp.myProteinID.N_PROTEIN += 1

        self.dp.myProteinID.LIST_PROTEIN_ID = self.dp.myProteinID.PRO1_NAME
        self.dp.myProteinID.MATRIX_INTENSITY = np.array(self.dp.myProteinID.PRO2_INTENSITY)

        self.dp.myID.N_PROTEINGROUP = self.dp.myProteinID.N_PROTEIN

        self.dp.myPeptideID.MATRIX_INTENSITY = self.dp.myProteinID.MATRIX_INTENSITY
        self.dp.myPeptideID.MATRIX_INTENSITY_LOG2 = self.dp.myProteinID.MATRIX_INTENSITY_LOG2
        self.dp.myPeptideID.PEP1_SEQ = self.dp.myProteinID.PRO1_NAME
        self.dp.myPeptideID.PEPLIST1_INTENSITY = self.dp.myProteinID.PRO2_INTENSITY
        self.dp.myPeptideID.LIST_PEPTIDE_ID = self.dp.myProteinID.LIST_PROTEIN_ID

    def read_old(self, path):

        if not len(self.dp.myID.LIST_SAMPLE_ID):
            for tmp_group in self.dp.LIST_EXPERIMENT_GROUP:
                self.dp.myID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myProteinID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myPeptideID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myPrecursorID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myIDForIRT.LIST_SAMPLE_ID.extend(tmp_group[1])

                self.dp.myID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myProteinID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myPeptideID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myPrecursorID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myIDForIRT.LIST_EXPERIMENT_ID.extend(tmp_group[2])

                
                self.dp.myID.PSM_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]
                self.dp.myID.PEP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
                self.dp.myID.PRO_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
                self.dp.myID.PROGROUP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]

        dic_sample = {j: i for i,j in enumerate(self.dp.myProteinID.LIST_SAMPLE_ID)}
        if self.dp.myProteinID.N_PROTEIN == 0:
            self.dp.myProteinID.LIST_PROTEIN_ID = {}
        if self.dp.myPeptideID.N_PEPTIDE == 0:
            self.dp.myPeptideID.LIST_PEPTIDE_ID = {}
        if self.dp.myPrecursorID.N_PRECURSOR == 0:
            self.dp.myPrecursorID.LIST_PRECURSOR_ID = {}
        if self.dp.myIDForIRT.N_PRECURSOR == 0:
            self.dp.myIDForIRT.LIST_PRECURSOR_ID = {}

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        var_pos_39 = table_list.index('R.FileName')

        var_pos_32 = table_list.index('PG.ProteinGroups')
        var_pos_9 = table_list.index('PG.Qvalue')
        position_proteinIBAQ = table_list.index('PG.IBAQ')
        var_pos_46 = table_list.index('PG.MS1Quantity')

        var_pos_10 = table_list.index('PEP.StrippedSequence')
        var_pos_37 = table_list.index('EG.IsDecoy')
        var_pos_88 = table_list.index('PEP.Quantity')
        if 'PEP.MS1Quantity' in table_list:
            position_peptideIntensityMS1 = table_list.index('PEP.MS1Quantity')
        if 'PEP.MS2Quantity' in table_list:
            position_peptideIntensityMS2 = table_list.index('PEP.MS2Quantity')

        var_pos_84 = table_list.index('EG.PrecursorId')
        position_mod = table_list.index('EG.ModifiedPeptide')
        var_pos_80 = table_list.index('FG.Charge')
        var_pos_90 = table_list.index('EG.TotalQuantity (Settings)')
        if 'FG.MS1Quantity' in table_list:
            position_precursorIntensityMS1 = table_list.index('FG.MS1Quantity')
        if 'FG.MS2Quantity' in table_list:
            position_precursorIntensityMS2 = table_list.index('FG.MS2Quantity')
        position_precursorRT = table_list.index('EG.ApexRT')
        position_precursorRTStart = table_list.index('EG.StartRT')
        position_precursorRTEnd = table_list.index('EG.EndRT')
        
        position_precursorMOZ = table_list.index('F.FrgMz')

        var_pos_1 = table_list.index('F.FrgType')
        var_pos_60 = table_list.index('F.FrgNum')
        var_pos_66 = table_list.index('F.Charge')
        var_pos_40 = table_list.index('F.FrgLossType')
        position_fragmentMOZ = table_list.index('F.FrgMz')

        last_ID = '  '

        for line in lines:

            if line:
                line_list = line.split('\t')

                tmp_group = line_list[var_pos_32]
                tmp_decoy = line_list[var_pos_37]

                if 'CON' not in tmp_group and 'REV' not in tmp_group and (tmp_decoy == 'FALSE' or tmp_decoy == 'False'):

                    tmp_precursor = line_list[var_pos_84]
                    tmp_rawname = line_list[var_pos_39]
                    tmp_ID = tmp_rawname + '_' + tmp_group + '_' + tmp_precursor

                    var_tmp_58 = float(line_list[var_pos_9])
                    var_tmp_53 = float(line_list[var_pos_46])
                    tmp_proteinIBAQ = float(line_list[position_proteinIBAQ].split(';')[0])

                    tmp_peptide = line_list[var_pos_10]
                    var_tmp_20 = float(line_list[var_pos_88])

                    var_tmp_72 = self.__soliderParseMod(line_list[position_mod])
                    var_tmp_50 = int(line_list[var_pos_80])
                    tmp_precursorRT = float(line_list[position_precursorRT])
                    tmp_precursorRTStart = float(line_list[position_precursorRTStart])
                    tmp_precursorRTEnd = float(line_list[position_precursorRTEnd])
                    var_tmp_85 = float(line_list[var_pos_90])
                    var_tmp_52 = float(line_list[position_precursorMOZ])

                    if self.dp.myCFG.C16_FLAG_MISSING_VALUE_THRESHOLD == CFG_FLAG_MISSING_VALUE_THRESHOLD['Yes']:
                        var_tmp_53 = var_tmp_53 if var_tmp_53 > self.dp.LIST_EXPERIMENT_INT_THRESHOLD[0] else 0.
                        var_tmp_20 = var_tmp_20 if var_tmp_20 > self.dp.LIST_EXPERIMENT_INT_THRESHOLD[0] else 0.
                        var_tmp_85 = var_tmp_85 if var_tmp_85 > self.dp.LIST_EXPERIMENT_INT_THRESHOLD[0] else 0.

                    var_tmp_7 = line_list[var_pos_1]
                    var_tmp_14 = int(line_list[var_pos_60])
                    var_tmp_15 = float(line_list[position_fragmentMOZ])
                    var_tmp_33 = int(line_list[var_pos_66])
                    var_tmp_87 = line_list[var_pos_40]

                    if last_ID != tmp_ID and tmp_rawname in dic_sample:  

                        last_ID = tmp_ID
                        rawIndex = dic_sample[tmp_rawname]

                        if tmp_group not in self.dp.myProteinID.LIST_PROTEIN_ID:
                            self.dp.myProteinID.LIST_PROTEIN_ID[tmp_group] = len(self.dp.myProteinID.PRO1_NAME)
                            self.dp.myProteinID.PRO1_NAME.append(tmp_group)
                            self.dp.myProteinID.PRO2_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myProteinID.LIST_SAMPLE_ID))
                            self.dp.myProteinID.PRO3_SCORE0.append([VALUE_ILLEGAL] * len(self.dp.myProteinID.LIST_SAMPLE_ID))
                            self.dp.myProteinID.PRO4_iBAQ.append([VALUE_ILLEGAL] * len(self.dp.myProteinID.LIST_SAMPLE_ID))
                            self.dp.myProteinID.N_PROTEIN += 1

                        proteinIndex = self.dp.myProteinID.LIST_PROTEIN_ID[tmp_group]
                        self.dp.myProteinID.PRO2_INTENSITY[proteinIndex][rawIndex] = var_tmp_53
                        self.dp.myProteinID.PRO3_SCORE0[proteinIndex][rawIndex] = var_tmp_58
                        self.dp.myProteinID.PRO4_iBAQ[proteinIndex][rawIndex] = tmp_proteinIBAQ

                        self.dp.myID.PROGROUP_LIST_ID[rawIndex].append(tmp_group)

                        if tmp_peptide not in self.dp.myPeptideID.LIST_PEPTIDE_ID:
                            self.dp.myPeptideID.LIST_PEPTIDE_ID[tmp_peptide] = len(self.dp.myPeptideID.PEP1_SEQ)
                            self.dp.myPeptideID.PEP1_SEQ.append(tmp_peptide)
                            self.dp.myPeptideID.PEPLIST1_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myPeptideID.LIST_SAMPLE_ID))
                            self.dp.myPeptideID.N_PEPTIDE += 1

                        peptideIndex = self.dp.myPeptideID.LIST_PEPTIDE_ID[tmp_peptide]
                        self.dp.myPeptideID.PEPLIST1_INTENSITY[peptideIndex][rawIndex] = var_tmp_20

                        self.dp.myID.PEP_LIST_ID[rawIndex].append(tmp_peptide)

                        if tmp_precursor not in self.dp.myPrecursorID.LIST_PRECURSOR_ID:
                            self.dp.myPrecursorID.LIST_PRECURSOR_ID[tmp_precursor] = len(self.dp.myPrecursorID.PRE1_SEQ)
                            self.dp.myPrecursorID.PRE1_SEQ.append(tmp_peptide)
                            self.dp.myPrecursorID.PRE2_MOD.append(var_tmp_72)
                            self.dp.myPrecursorID.PRE3_CHARGE.append(var_tmp_50)
                            self.dp.myPrecursorID.PRELIST1_RT.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST2_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.N_PRECURSOR += 1

                        precursorIndex = self.dp.myPrecursorID.LIST_PRECURSOR_ID[tmp_precursor]
                        self.dp.myPrecursorID.PRELIST1_RT[precursorIndex][rawIndex] = tmp_precursorRT
                        self.dp.myPrecursorID.PRELIST2_INTENSITY[precursorIndex][rawIndex] = var_tmp_85

                        self.dp.myID.PSM_LIST_ID[rawIndex].append(tmp_precursor)

                        
                        if tmp_peptide in self.dp.myINI.LIST_IRT_PEPTIDE and var_tmp_50 in self.dp.myINI.LIST_IRT_CHARGE \
                                and var_tmp_72 == '':

                            if tmp_precursor not in self.dp.myIDForIRT.LIST_PRECURSOR_ID:
                                self.dp.myIDForIRT.LIST_PRECURSOR_ID[tmp_precursor] = len(self.dp.myIDForIRT.PRE1_SEQ)
                                self.dp.myIDForIRT.PRE1_SEQ.append(tmp_peptide)
                                self.dp.myIDForIRT.PRE2_MOD.append(var_tmp_72)
                                self.dp.myIDForIRT.PRE3_CHARGE.append(var_tmp_50)
                                self.dp.myIDForIRT.PRE4_MOZ_CLC.append(var_tmp_52)
                                self.dp.myIDForIRT.PRE5_PROTEIN.append(tmp_group)
                                self.dp.myIDForIRT.PRELIST2_RT.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.PRELIST3_RT_START.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.PRELIST4_RT_END.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.PRELIST8_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST1_TYPE.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST2_NUM.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST3_CHARGE.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST4_LOSS.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST5_MOZ.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.N_PRECURSOR += 1

                            precursorIRTIndex = self.dp.myIDForIRT.LIST_PRECURSOR_ID[tmp_precursor]
                            self.dp.myIDForIRT.PRELIST2_RT[precursorIRTIndex][rawIndex] = tmp_precursorRT
                            self.dp.myIDForIRT.PRELIST3_RT_START[precursorIRTIndex][rawIndex] = tmp_precursorRTStart
                            self.dp.myIDForIRT.PRELIST4_RT_END[precursorIRTIndex][rawIndex] = tmp_precursorRTEnd
                            self.dp.myIDForIRT.PRELIST8_INTENSITY[precursorIRTIndex][rawIndex] = var_tmp_85
                            self.dp.myIDForIRT.FRAGLIST1_TYPE[precursorIRTIndex][rawIndex].append(var_tmp_7)
                            self.dp.myIDForIRT.FRAGLIST2_NUM[precursorIRTIndex][rawIndex].append(var_tmp_14)
                            self.dp.myIDForIRT.FRAGLIST3_CHARGE[precursorIRTIndex][rawIndex].append(var_tmp_33)
                            self.dp.myIDForIRT.FRAGLIST4_LOSS[precursorIRTIndex][rawIndex].append(var_tmp_87)
                            self.dp.myIDForIRT.FRAGLIST5_MOZ[precursorIRTIndex][rawIndex].append(var_tmp_15)

    def read(self, path, var_lis_34 ):
        if self.dp.myCFG.C18_FLAG_SHOW_ORDER == 1:
            dic_raw2date = {}
            f = open(path, 'r')
            table_list = f.readline().split('\t')
            var_pos_59 = table_list.index('R.Run Date')
            var_pos_39 = table_list.index('R.FileName')
            while True:
                line = f.readline()
                if not line:
                    break
                elif line:
                    line_list = line.strip().split('\t')
                    tmp_rawname = line_list[var_pos_39]

                    if tmp_rawname not in dic_raw2date:
                        tmp_rundate = line_list[var_pos_59]
                        dic_raw2date[tmp_rawname] = tmp_rundate

        if not len(self.dp.myID.LIST_SAMPLE_ID):
            for tmp_group in self.dp.LIST_EXPERIMENT_GROUP:
                if self.dp.myCFG.C18_FLAG_SHOW_ORDER == 1:
                    var_lis_48 = tmp_group[1]
                    var_lis_86 = [[tmp_group[1][i], tmp_group[2][i], dic_raw2date[sample_name]] for i,sample_name in enumerate(var_lis_48)]
                    var_lis_86.sort(key=lambda x: x[2])
                    tmp_group = list(tmp_group)
                    tmp_group[1] = [i[0] for i in var_lis_86]
                    tmp_group[2] = [i[1] for i in var_lis_86]
                self.dp.myID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myProteinID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myPeptideID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myPrecursorID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myIDForIRT.LIST_SAMPLE_ID.extend(tmp_group[1])

                self.dp.myID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myProteinID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myPeptideID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myPrecursorID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myIDForIRT.LIST_EXPERIMENT_ID.extend(tmp_group[2])

                
                self.dp.myID.PSM_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]
                self.dp.myID.PEP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
                self.dp.myID.PRO_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
                self.dp.myID.PROGROUP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]

        dic_sample = {j: i for i, j in enumerate(self.dp.myProteinID.LIST_SAMPLE_ID)}
        if self.dp.myProteinID.N_PROTEIN == 0:
            self.dp.myProteinID.LIST_PROTEIN_ID = {}
        if self.dp.myPeptideID.N_PEPTIDE == 0:
            self.dp.myPeptideID.LIST_PEPTIDE_ID = {}
        if self.dp.myPrecursorID.N_PRECURSOR == 0:
            self.dp.myPrecursorID.LIST_PRECURSOR_ID = {}
        if self.dp.myIDForIRT.N_PRECURSOR == 0:
            self.dp.myIDForIRT.LIST_PRECURSOR_ID = {}

        f = open(path, 'r')

        table = f.readline()
        table_list = table.strip().split('\t')

        var_pos_39 = table_list.index('R.FileName')

        var_pos_32 = table_list.index('PG.ProteinGroups')
        var_pos_9 = table_list.index('PG.Qvalue')
        
        var_pos_46 = table_list.index('PG.Quantity')

        var_pos_10 = table_list.index('PEP.StrippedSequence')
        var_pos_37 = table_list.index('EG.IsDecoy')
        var_pos_88 = table_list.index('PEP.Quantity')
        
        
        
        

        var_pos_84 = table_list.index('EG.PrecursorId')
        position_mod = table_list.index('EG.ModifiedPeptide')
        var_pos_80 = table_list.index('FG.Charge')
        var_pos_90 = table_list.index('EG.TotalQuantity (Settings)')
        
        
        
        
        position_precursorRT = table_list.index('EG.ApexRT')
        position_precursorRTStart = table_list.index('EG.StartRT')
        position_precursorRTEnd = table_list.index('EG.EndRT')
        position_deltaRT = table_list.index('EG.DeltaRT')
        position_PeakWidth = table_list.index('EG.PeakWidth')
        position_FWHM = table_list.index('EG.FWHM')

        position_MS1_MassAccuray = table_list.index('FG.RawMassAccuracy (PPM)')
        position_MS2_MassAccuray = table_list.index('F.RawMassAccuracy (PPM)')
        if 'FG.CalibratedMassAccuracy (PPM)' in table_list:
            position_MS1_CalibratePPM = table_list.index('FG.CalibratedMassAccuracy (PPM)')
        if 'F.CalibratedMassAccuracy (PPM)' in table_list:
            position_MS2_CalibratePPM = table_list.index('F.CalibratedMassAccuracy (PPM)')

        position_MS2_datapoint = table_list.index('EG.DatapointsPerPeak')  
        position_MS1_datapoint = table_list.index('EG.DatapointsPerPeak (MS1)')

        position_precursorMOZ = table_list.index('FG.PrecMz')
        

        
        
        
        
        

        last_ID = '  '

        while True:
            line = f.readline()
            if not line:
                break
            elif line:
                line_list = line.strip().split('\t')

                tmp_group = line_list[var_pos_32]
                tmp_decoy = line_list[var_pos_37]

                if 'CON' not in tmp_group and 'REV' not in tmp_group and (tmp_decoy == 'FALSE' or tmp_decoy == 'False'):

                    tmp_precursor = line_list[var_pos_84]
                    tmp_rawname = line_list[var_pos_39]
                    tmp_ID = tmp_rawname + '_' + tmp_group + '_' + tmp_precursor

                    var_tmp_58 = float(line_list[var_pos_9])
                    var_tmp_53 = float(line_list[var_pos_46])
                    

                    tmp_peptide = line_list[var_pos_10]
                    var_tmp_20 = float(line_list[var_pos_88])

                    var_tmp_72 = self.__soliderParseMod(line_list[position_mod])
                    var_tmp_50 = int(line_list[var_pos_80])
                    tmp_precursorRT = float(line_list[position_precursorRT])
                    tmp_precursorRTStart = float(line_list[position_precursorRTStart])
                    tmp_precursorRTEnd = float(line_list[position_precursorRTEnd])
                    var_tmp_85 = float(line_list[var_pos_90])
                    var_tmp_52 = float(line_list[position_precursorMOZ])
                    tmp_peakwidth = float(line_list[position_PeakWidth])
                    tmp_deltaRT = float(line_list[position_deltaRT])
                    tmp_FWHM = float(line_list[position_FWHM].split(')')[0])     
                    tmp_MS1_MassAccuray = float(line_list[position_MS1_MassAccuray])
                    tmp_MS2_MassAccuray = float(line_list[position_MS2_MassAccuray])
                    if 'FG.CalibratedMassAccuracy (PPM)' in table_list:
                        tmp_calibrate_MS1_MassAccuracy = float(line_list[position_MS1_CalibratePPM])
                    if 'F.CalibratedMassAccuracy (PPM)' in table_list:
                        tmp_calibrate_MS2_MassAccuracy = float(line_list[position_MS2_CalibratePPM])
                    tmp_MS2_datapoint = float(line_list[position_MS2_datapoint])
                    tmp_MS1_datapoint = float(line_list[position_MS1_datapoint])


                    if tmp_rawname in dic_sample:
                        rawIndex = dic_sample[tmp_rawname]
                    else:
                        rawIndex = 0

                    if self.dp.myCFG.C16_FLAG_MISSING_VALUE_THRESHOLD == CFG_FLAG_MISSING_VALUE_THRESHOLD['Yes']:
                        var_tmp_53 = var_tmp_53 if var_tmp_53 > \
                                                                       self.dp.LIST_EXPERIMENT_INT_THRESHOLD[rawIndex] else 0.
                        var_tmp_20 = var_tmp_20 if var_tmp_20 > \
                                                                       self.dp.LIST_EXPERIMENT_INT_THRESHOLD[rawIndex] else 0.
                        var_tmp_85 = var_tmp_85 if var_tmp_85 > \
                                                                           self.dp.LIST_EXPERIMENT_INT_THRESHOLD[
                                                                               rawIndex] else 0.

                    
                    
                    
                    
                    

                    if last_ID != tmp_ID and tmp_rawname in dic_sample:  

                        last_ID = tmp_ID
                        rawIndex = dic_sample[tmp_rawname]

                        if tmp_group not in self.dp.myProteinID.LIST_PROTEIN_ID:
                            self.dp.myProteinID.LIST_PROTEIN_ID[tmp_group] = len(self.dp.myProteinID.PRO1_NAME)
                            self.dp.myProteinID.PRO1_NAME.append(tmp_group)
                            self.dp.myProteinID.PRO2_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myProteinID.LIST_SAMPLE_ID))
                            self.dp.myProteinID.PRO3_SCORE0.append([VALUE_ILLEGAL] * len(self.dp.myProteinID.LIST_SAMPLE_ID))
                            self.dp.myProteinID.PRO4_iBAQ.append([VALUE_ILLEGAL] * len(self.dp.myProteinID.LIST_SAMPLE_ID))
                            self.dp.myProteinID.DICT_PROTEIN2PEPTIDE[tmp_group] = []
                            self.dp.myProteinID.N_PROTEIN += 1

                        proteinIndex = self.dp.myProteinID.LIST_PROTEIN_ID[tmp_group]
                        self.dp.myProteinID.PRO2_INTENSITY[proteinIndex][rawIndex] = var_tmp_53
                        self.dp.myProteinID.PRO3_SCORE0[proteinIndex][rawIndex] = var_tmp_58
                        

                        self.dp.myID.PROGROUP_LIST_ID[rawIndex].append(tmp_group)

                        if tmp_peptide not in self.dp.myPeptideID.LIST_PEPTIDE_ID:
                            self.dp.myPeptideID.LIST_PEPTIDE_ID[tmp_peptide] = len(self.dp.myPeptideID.PEP1_SEQ)
                            self.dp.myPeptideID.PEP1_SEQ.append(tmp_peptide)
                            self.dp.myPeptideID.PEPLIST1_INTENSITY.append(
                                [VALUE_ILLEGAL] * len(self.dp.myPeptideID.LIST_SAMPLE_ID))
                            self.dp.myProteinID.DICT_PROTEIN2PEPTIDE[tmp_group].append(tmp_peptide)
                            self.dp.myPeptideID.N_PEPTIDE += 1

                        peptideIndex = self.dp.myPeptideID.LIST_PEPTIDE_ID[tmp_peptide]
                        self.dp.myPeptideID.PEPLIST1_INTENSITY[peptideIndex][rawIndex] = var_tmp_20

                        self.dp.myID.PEP_LIST_ID[rawIndex].append(tmp_peptide)

                        if tmp_precursor not in self.dp.myPrecursorID.LIST_PRECURSOR_ID:

                            var_lis_34.append(tmp_precursor)
                            self.dp.myPrecursorID.LIST_PRECURSOR_ID[tmp_precursor] = len(self.dp.myPrecursorID.PRE1_SEQ)
                            self.dp.myPrecursorID.PRE1_SEQ.append(tmp_peptide)
                            self.dp.myPrecursorID.PRE2_MOD.append(var_tmp_72)
                            self.dp.myPrecursorID.PRE3_CHARGE.append(var_tmp_50)
                            self.dp.myPrecursorID.PRELIST1_RT.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST2_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST5_PEAKWIDTH.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST6_DELTART.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST7_FWHM.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST8_MS1_ACCURACY.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST9_MS2_ACCURACY.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST10_MS1_DPPP.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST11_MS2_DPPP.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST13_CALIBRATE_MS1_ACCURACY.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST14_CALIBRATE_MS2_ACCURACY.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))

                            self.dp.myPrecursorID.N_PRECURSOR += 1

                        precursorIndex = self.dp.myPrecursorID.LIST_PRECURSOR_ID[tmp_precursor]
                        self.dp.myPrecursorID.PRELIST1_RT[precursorIndex][rawIndex] = tmp_precursorRT
                        self.dp.myPrecursorID.PRELIST2_INTENSITY[precursorIndex][rawIndex] = var_tmp_85
                        self.dp.myPrecursorID.PRELIST5_PEAKWIDTH[precursorIndex][rawIndex] = tmp_peakwidth
                        self.dp.myPrecursorID.PRELIST6_DELTART[precursorIndex][rawIndex] = tmp_deltaRT
                        self.dp.myPrecursorID.PRELIST7_FWHM[precursorIndex][rawIndex] = tmp_FWHM
                        self.dp.myPrecursorID.PRELIST8_MS1_ACCURACY[precursorIndex][rawIndex] = tmp_MS1_MassAccuray
                        self.dp.myPrecursorID.PRELIST9_MS2_ACCURACY[precursorIndex][rawIndex] = tmp_MS2_MassAccuray
                        self.dp.myPrecursorID.PRELIST10_MS1_DPPP[precursorIndex][rawIndex] = tmp_MS1_datapoint
                        self.dp.myPrecursorID.PRELIST11_MS2_DPPP[precursorIndex][rawIndex] = tmp_MS2_datapoint
                        if 'FG.CalibratedMassAccuracy (PPM)' in table_list:
                            self.dp.myPrecursorID.PRELIST13_CALIBRATE_MS1_ACCURACY[precursorIndex][
                                rawIndex] = tmp_calibrate_MS1_MassAccuracy
                        if 'F.CalibratedMassAccuracy (PPM)' in table_list:
                            self.dp.myPrecursorID.PRELIST14_CALIBRATE_MS2_ACCURACY[precursorIndex][
                                rawIndex] = tmp_calibrate_MS2_MassAccuracy

                        self.dp.myID.PSM_LIST_ID[rawIndex].append(tmp_precursor)

                        
                        if tmp_peptide in self.dp.myINI.LIST_IRT_PEPTIDE and var_tmp_50 in self.dp.myINI.LIST_IRT_CHARGE \
                                and var_tmp_72 == '':

                            if tmp_precursor not in self.dp.myIDForIRT.LIST_PRECURSOR_ID:
                                self.dp.myIDForIRT.LIST_PRECURSOR_ID[tmp_precursor] = len(self.dp.myIDForIRT.PRE1_SEQ)
                                self.dp.myIDForIRT.PRE1_SEQ.append(tmp_peptide)
                                self.dp.myIDForIRT.PRE2_MOD.append(var_tmp_72)
                                self.dp.myIDForIRT.PRE3_CHARGE.append(var_tmp_50)
                                self.dp.myIDForIRT.PRE4_MOZ_CLC.append(var_tmp_52)
                                self.dp.myIDForIRT.PRE5_PROTEIN.append(tmp_group)
                                self.dp.myIDForIRT.PRELIST2_RT.append(
                                    [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.PRELIST3_RT_START.append(
                                    [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.PRELIST4_RT_END.append(
                                    [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.PRELIST8_INTENSITY.append(
                                    [VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                
                                
                                
                                
                                
                                
                                self.dp.myIDForIRT.N_PRECURSOR += 1

                            precursorIRTIndex = self.dp.myIDForIRT.LIST_PRECURSOR_ID[tmp_precursor]
                            self.dp.myIDForIRT.PRELIST2_RT[precursorIRTIndex][rawIndex] = tmp_precursorRT
                            self.dp.myIDForIRT.PRELIST3_RT_START[precursorIRTIndex][rawIndex] = tmp_precursorRTStart
                            self.dp.myIDForIRT.PRELIST4_RT_END[precursorIRTIndex][rawIndex] = tmp_precursorRTEnd
                            self.dp.myIDForIRT.PRELIST8_INTENSITY[precursorIRTIndex][rawIndex] = var_tmp_85
                            
                            
                            
                            
                            

    def merge(self, var_lis_34):

        self.dp.myProteinID.LIST_PROTEIN_ID = self.dp.myProteinID.PRO1_NAME
        self.dp.myProteinID.MATRIX_INTENSITY = np.array(self.dp.myProteinID.PRO2_INTENSITY)
        self.dp.myProteinID.MATRIX_INTENSITY_LOG2 = np.log2(self.dp.myProteinID.MATRIX_INTENSITY_LOG2)
        self.dp.myProteinID.MATRIX_IBAQ_LOG10 = np.log10(np.array(self.dp.myProteinID.PRO4_iBAQ))

        self.dp.myPeptideID.PEPLIST2_INTENSITY_FORMERGE = self.dp.myPeptideID.PEPLIST1_INTENSITY
        self.dp.myPeptideID.DICT_PEPTIDE2POSITION.update(self.dp.myPeptideID.LIST_PEPTIDE_ID)
        self.dp.myPeptideID.LIST_PEPTIDE_ID = self.dp.myPeptideID.PEP1_SEQ
        self.dp.myPeptideID.MATRIX_INTENSITY = np.array(self.dp.myPeptideID.PEPLIST1_INTENSITY)
        self.dp.myPeptideID.MATRIX_INTENSITY_LOG2 = np.log2(self.dp.myPeptideID.MATRIX_INTENSITY)

        
        self.dp.myPrecursorID.LIST_PRECURSOR_ID = var_lis_34
        self.dp.myPrecursorID.MATRIX_RT = np.array(self.dp.myPrecursorID.PRELIST1_RT)
        self.dp.myPrecursorID.MATRIX_INTENSITY = np.array(self.dp.myPrecursorID.PRELIST2_INTENSITY)
        self.dp.myProteinID.MATRIX_INTENSITY_LOG2 = np.log2(self.dp.myProteinID.MATRIX_INTENSITY)
        self.dp.myIDForIRT.LIST_PRECURSOR_ID = [self.dp.myIDForIRT.PRE1_SEQ[i] + '_' + self.dp.myIDForIRT.PRE2_MOD[i] +
                                                '_' + str(self.dp.myIDForIRT.PRE3_CHARGE[i]) for i in range(len(self.dp.myIDForIRT.PRE1_SEQ))]

        self.dp.myID.N_PSM = self.dp.myPrecursorID.N_PRECURSOR
        self.dp.myID.N_PEPTIDE = self.dp.myPeptideID.N_PEPTIDE
        self.dp.myID.N_PROTEINGROUP = self.dp.myProteinID.N_PROTEIN
        self.dp.myID.PSM_LIST_ID = [set(i) for i in self.dp.myID.PSM_LIST_ID]
        self.dp.myID.PEP_LIST_ID = [set(i) for i in self.dp.myID.PEP_LIST_ID]
        self.dp.myID.PROGROUP_LIST_ID = [set(i) for i in self.dp.myID.PROGROUP_LIST_ID]

    def __soliderParseMod(self, inputMod):

        inputMod = inputMod.strip('_')
        str_mod = ''
        flag_mod = 0
        position_aa = -1

        for i in inputMod:
            if i == '[':
                str_mod += str(position_aa) + ','
                flag_mod = 1
            elif i == ']':
                flag_mod = 0
                str_mod += ';'
            elif flag_mod == 1:
                str_mod += i
            else:
                position_aa += 1

        str_mod = str_mod.replace(' ', '')
        return str_mod


class CFunctionParse_1:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def read(self, path):


        
        
        
        

        if not len(self.dp.myID.LIST_SAMPLE_ID):
            for tmp_group in self.dp.LIST_EXPERIMENT_GROUP:
                self.dp.myID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myProteinID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myPeptideID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myPrecursorID.LIST_SAMPLE_ID.extend(tmp_group[1])
                self.dp.myIDForIRT.LIST_SAMPLE_ID.extend(tmp_group[1])

                self.dp.myID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myProteinID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myPeptideID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myPrecursorID.LIST_EXPERIMENT_ID.extend(tmp_group[2])
                self.dp.myIDForIRT.LIST_EXPERIMENT_ID.extend(tmp_group[2])

                
                self.dp.myID.PSM_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]
                self.dp.myID.PEP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
                self.dp.myID.PRO_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]  
                self.dp.myID.PROGROUP_LIST_ID = [[] for _ in range(len(self.dp.myID.LIST_SAMPLE_ID))]

        dic_sample = {j: i for i,j in enumerate(self.dp.myProteinID.LIST_SAMPLE_ID)}
        if self.dp.myProteinID.N_PROTEIN == 0:
            self.dp.myProteinID.LIST_PROTEIN_ID = {}
        if self.dp.myPeptideID.N_PEPTIDE == 0:
            self.dp.myPeptideID.LIST_PEPTIDE_ID = {}
        if self.dp.myPrecursorID.N_PRECURSOR == 0:
            self.dp.myPrecursorID.LIST_PRECURSOR_ID = {}
        if self.dp.myIDForIRT.N_PRECURSOR == 0:
            self.dp.myIDForIRT.LIST_PRECURSOR_ID = {}

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]

        if 'Run' in table_list:
            var_pos_39 = table_list.index('Run')
            flag_raw_str = 0
        else:  
            var_pos_39 = table_list.index('File.Name')
            flag_raw_str = 1
        var_pos_84 = table_list.index('Precursor.Id')
        position_mod = table_list.index('Modified.Sequence')
        var_pos_80 = table_list.index('Precursor.Charge')
        var_pos_76 = table_list.index('Q.Value')
        var_pos_90 = table_list.index('Precursor.Quantity')

        position_precursorRT = table_list.index('RT')
        position_precursorRTStart = table_list.index('RT.Start')
        position_precursorRTEnd = table_list.index('RT.Stop')
        

        var_pos_32 = table_list.index('Protein.Group')
        var_pos_9 = table_list.index('PG.Q.Value')
        
        var_pos_46 = table_list.index('PG.Quantity')

        var_pos_10 = table_list.index('Stripped.Sequence')
        
        
        
        
        
        



        
        
        
        
        

        last_ID = '  '

        for line in lines:


            line_list = line.split('\t')
            tmp_group = line_list[var_pos_32]
            

            if 'CON' not in tmp_group and 'REV' not in tmp_group:

                tmp_precursor = line_list[var_pos_84]
                tmp_preqvalue = float(line_list[var_pos_76])
                tmp_rawname = line_list[var_pos_39]
                if flag_raw_str == 1:
                    tmp_rawname = tmp_rawname.split('\\')[-1].split('.')[0]
                tmp_ID = tmp_rawname + '_' + tmp_group + '_' + tmp_precursor

                var_tmp_58 = float(line_list[var_pos_9])
                var_tmp_53 = float(line_list[var_pos_46])


                tmp_peptide = line_list[var_pos_10]

                var_tmp_72 = self.__soliderParseMod(line_list[position_mod])
                var_tmp_50 = int(line_list[var_pos_80])
                tmp_precursorRT = float(line_list[position_precursorRT])
                tmp_precursorRTStart = float(line_list[position_precursorRTStart])
                tmp_precursorRTEnd = float(line_list[position_precursorRTEnd])
                var_tmp_85 = float(line_list[var_pos_90])
                
                
                
                
                
                
                

                if last_ID != tmp_ID:  

                    last_ID = tmp_ID
                    rawIndex = dic_sample[tmp_rawname]

                    if var_tmp_58 <= 0.01:
                        if tmp_group not in self.dp.myProteinID.LIST_PROTEIN_ID:
                            self.dp.myProteinID.LIST_PROTEIN_ID[tmp_group] = len(self.dp.myProteinID.PRO1_NAME)
                            self.dp.myProteinID.PRO1_NAME.append(tmp_group)
                            self.dp.myProteinID.PRO2_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myProteinID.LIST_SAMPLE_ID))
                            self.dp.myProteinID.PRO3_SCORE0.append([VALUE_ILLEGAL] * len(self.dp.myProteinID.LIST_SAMPLE_ID))
                            self.dp.myProteinID.N_PROTEIN += 1

                        proteinIndex = self.dp.myProteinID.LIST_PROTEIN_ID[tmp_group]
                        self.dp.myProteinID.PRO2_INTENSITY[proteinIndex][rawIndex] = var_tmp_53
                        self.dp.myProteinID.PRO3_SCORE0[proteinIndex][rawIndex] = var_tmp_58
                        

                        self.dp.myID.PROGROUP_LIST_ID[rawIndex].append(tmp_group)

                    if tmp_preqvalue <= 0.01:
                        if tmp_peptide not in self.dp.myPeptideID.LIST_PEPTIDE_ID:
                            self.dp.myPeptideID.LIST_PEPTIDE_ID[tmp_peptide] = len(self.dp.myPeptideID.PEP1_SEQ)
                            self.dp.myPeptideID.PEP1_SEQ.append(tmp_peptide)
                            self.dp.myPeptideID.PEPLIST1_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myPeptideID.LIST_SAMPLE_ID))
                            self.dp.myPeptideID.N_PEPTIDE += 1

                        peptideIndex = self.dp.myPeptideID.LIST_PEPTIDE_ID[tmp_peptide]
                        self.dp.myPeptideID.PEPLIST1_INTENSITY[peptideIndex][rawIndex] += var_tmp_85

                        self.dp.myID.PEP_LIST_ID[rawIndex].append(tmp_peptide)

                        if tmp_precursor not in self.dp.myPrecursorID.LIST_PRECURSOR_ID:
                            self.dp.myPrecursorID.LIST_PRECURSOR_ID[tmp_precursor] = len(self.dp.myPrecursorID.PRE1_SEQ)
                            self.dp.myPrecursorID.PRE1_SEQ.append(tmp_peptide)
                            self.dp.myPrecursorID.PRE2_MOD.append(var_tmp_72)
                            self.dp.myPrecursorID.PRE3_CHARGE.append(var_tmp_50)
                            self.dp.myPrecursorID.PRELIST1_RT.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST3_RTSTART.append(
                                [VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST4_RTEND.append(
                                [VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.PRELIST2_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myPrecursorID.LIST_SAMPLE_ID))
                            self.dp.myPrecursorID.N_PRECURSOR += 1

                        precursorIndex = self.dp.myPrecursorID.LIST_PRECURSOR_ID[tmp_precursor]
                        self.dp.myPrecursorID.PRELIST1_RT[precursorIndex][rawIndex] = tmp_precursorRT
                        self.dp.myPrecursorID.PRELIST2_INTENSITY[precursorIndex][rawIndex] = var_tmp_85
                        self.dp.myPrecursorID.PRELIST3_RTSTART[precursorIndex][rawIndex] = tmp_precursorRTStart
                        self.dp.myPrecursorID.PRELIST4_RTEND[precursorIndex][rawIndex] = tmp_precursorRTEnd

                        self.dp.myID.PSM_LIST_ID[rawIndex].append(tmp_precursor)

                        
                        if tmp_peptide in self.dp.myINI.LIST_IRT_PEPTIDE and var_tmp_50 in self.dp.myINI.LIST_IRT_CHARGE \
                                and var_tmp_72 == '':

                            if tmp_precursor not in self.dp.myIDForIRT.LIST_PRECURSOR_ID:
                                self.dp.myIDForIRT.LIST_PRECURSOR_ID[tmp_precursor] = len(self.dp.myIDForIRT.PRE1_SEQ)
                                self.dp.myIDForIRT.PRE1_SEQ.append(tmp_peptide)
                                self.dp.myIDForIRT.PRE2_MOD.append(var_tmp_72)
                                self.dp.myIDForIRT.PRE3_CHARGE.append(var_tmp_50)
                                
                                self.dp.myIDForIRT.PRE5_PROTEIN.append(tmp_group)
                                self.dp.myIDForIRT.PRELIST2_RT.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.PRELIST3_RT_START.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.PRELIST4_RT_END.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.PRELIST8_INTENSITY.append([VALUE_ILLEGAL] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST1_TYPE.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST2_NUM.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST3_CHARGE.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST4_LOSS.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.FRAGLIST5_MOZ.append([[]] * len(self.dp.myIDForIRT.LIST_SAMPLE_ID))
                                self.dp.myIDForIRT.N_PRECURSOR += 1

                            precursorIRTIndex = self.dp.myIDForIRT.LIST_PRECURSOR_ID[tmp_precursor]
                            self.dp.myIDForIRT.PRELIST2_RT[precursorIRTIndex][rawIndex] = tmp_precursorRT
                            self.dp.myIDForIRT.PRELIST3_RT_START[precursorIRTIndex][rawIndex] = tmp_precursorRTStart
                            self.dp.myIDForIRT.PRELIST4_RT_END[precursorIRTIndex][rawIndex] = tmp_precursorRTEnd
                            self.dp.myIDForIRT.PRELIST8_INTENSITY[precursorIRTIndex][rawIndex] = var_tmp_85
                            
                            
                            
                            
                            

    def merge(self):

        self.dp.myProteinID.LIST_PROTEIN_ID = self.dp.myProteinID.PRO1_NAME
        self.dp.myProteinID.MATRIX_INTENSITY = np.array(self.dp.myProteinID.PRO2_INTENSITY)
        

        self.dp.myPeptideID.LIST_PEPTIDE_ID = self.dp.myPeptideID.PEP1_SEQ
        self.dp.myPeptideID.MATRIX_INTENSITY = np.array(self.dp.myPeptideID.PEPLIST1_INTENSITY)

        self.dp.myPrecursorID.LIST_PRECURSOR_ID = self.dp.myPrecursorID.PRE1_SEQ
        self.dp.myPrecursorID.MATRIX_RT = np.array(self.dp.myPrecursorID.PRELIST1_RT)
        self.dp.myPrecursorID.MATRIX_INTENSITY = np.array(self.dp.myPrecursorID.PRELIST2_INTENSITY)
        self.dp.myIDForIRT.LIST_PRECURSOR_ID = [self.dp.myIDForIRT.PRE1_SEQ[i] + '_' + self.dp.myIDForIRT.PRE2_MOD[i] +
                                                '_' + str(self.dp.myIDForIRT.PRE3_CHARGE[i]) for i in range(len(self.dp.myIDForIRT.PRE1_SEQ))]

        self.dp.myID.N_PSM = self.dp.myPrecursorID.N_PRECURSOR
        self.dp.myID.N_PEPTIDE = self.dp.myPeptideID.N_PEPTIDE
        self.dp.myID.N_PROTEINGROUP = self.dp.myProteinID.N_PROTEIN
        self.dp.myID.PSM_LIST_ID = [set(i) for i in self.dp.myID.PSM_LIST_ID]
        self.dp.myID.PEP_LIST_ID = [set(i) for i in self.dp.myID.PEP_LIST_ID]
        self.dp.myID.PROGROUP_LIST_ID = [set(i) for i in self.dp.myID.PROGROUP_LIST_ID]

    def __soliderParseMod(self, inputStr):

        
        var_sep_16, seperator_end = '(', ')'
        mod_dic = {}
        mod_type = ''
        site_start, site_end = 0, 0
        flag_in_mod = 0
        count = 0
        for i, char in enumerate(inputStr):
            if char == var_sep_16:
                site_start = i
                flag_in_mod = 1
            elif char == seperator_end:
                site_end = i
                try:
                    mod_type = UNIMOID_TO_STANDARD_MOD[inputStr[site_start + 1:site_end]]
                except KeyError:
                    print(inputStr[site_start + 1:site_end])
                    print('wrong')
                    info = 'DIA-NN modify type has wrong, please check!'
                    logGetError(info)
                mod_dic[count] = mod_type
                flag_in_mod = 0
            elif flag_in_mod == 0:
                count = count + 1

        return mod_dic


class CFunctionID2Fe_2:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def transfer(self):

        pass