import logging
import sys

myLogPath = 'MSCohort.log'

INFO_TO_USER_Staff = (

    '\n[MSCohort] Copyright 2024 Beihang University. All rights reserved. Version 2024.01',
    '\n[MSCohort] MSCohort is expired! Please send e-mail to cliu126@126.com for the new version.',
    '\n[MSCohort] Warning! The current license will expired in 7 days. Please send e-mail to cliu126@126.com for the new version.',
    '\n[MSCohort] Writing config file in the folder...',
    '\n[MSCohort] Finished!',
    '\n[MSCohort] Writing config file...',
    '\n[MSCohort] Run MSCohort with this command: python MSCohort [parameter file]',)


INFO_TO_USER_Flow1 = (

    '\n[MSCohort] <Flow DDA Cohort> Checking the environment...',
    '\n[MSCohort] <Flow DDA Cohort> Reading ini files...',
    '\n[MSCohort] <Flow DDA Cohort> Reading MS files (The first run will take a few minutes)...',
    '\n[MSCohort] <Flow DDA Cohort> Reading result files...',
    '\n[MSCohort] <Flow DDA Cohort> Statistical missing values...',
    '\n[MSCohort] <Flow DDA Cohort> Correlation analysis...',
    '\n[MSCohort] <Flow DDA Cohort> RT deviation analysis...',
    '\n[MSCohort] <Flow DDA Cohort> iRT peptide analysis...',
    '\n[MSCohort] <Flow DDA Cohort> Normalization analysis...',
    '\n[MSCohort] <Flow DDA Cohort> Correlation analysis (after normalization)...',
    '\n[MSCohort] <Flow DDA Cohort> Report...',
)

INFO_TO_USER_Flow2 = (

    '\n[MSCohort] <Flow DIA Cohort> Checking the environment...',
    '\n[MSCohort] <Flow DIA Cohort> Reading ini files...',
    '\n[MSCohort] <Flow DIA Cohort> Reading MS files (The first run will take a few minutes)...',
    '\n[MSCohort] <Flow DIA Cohort> Intra experiment analysis...',
    '\n[MSCohort] <Flow DIA Cohort> Reading result files...',
    '\n[MSCohort] <Flow DIA Cohort> Statistical missing values...',
    '\n[MSCohort] <Flow DIA Cohort> Correlation analysis...',
    '\n[MSCohort] <Flow DIA Cohort> RT deviation analysis...',
    '\n[MSCohort] <Flow DIA Cohort> iRT peptide analysis...',
    '\n[MSCohort] <Flow DIA Cohort> Normalization analysis...',
    '\n[MSCohort] <Flow DIA Cohort> Correlation analysis (after normalization)...',
    '\n[MSCohort] <Flow DIA Cohort> Report...',
)


INFO_TO_USER_Flow3 = (

    '\n[MSCohort] <Flow iRT Indicator> Checking the environment...',
    '\n[MSCohort] <Flow iRT Indicator> Reading ini files...',
    '\n[MSCohort] <Flow iRT Indicator> Reading MS files (The first run will take a few minutes)...',
    '\n[MSCohort] <Flow iRT Indicator> Extracting iRT peptides from MS files...',
    '\n[MSCohort] <Flow iRT Indicator> Calculating and report indicator of iRT peptides (Retention Time / Peak Width / FWHM / MS1 Intensity)...',
)


INFO_TO_USER_TaskParseRaw = ('\n[MSCohort] \tCreating ms1 and ms2 file for: ',)

INFO_TO_USER_TaskParseMSRefine = ('\n[MSCohort] \tIntra experiment analysis for: ',
                                  '\n[MSCohort] \tIntra experiment analysis report are existed for: ')

INFO_TO_USER_TaskReadMS1 = (

    '\n[MSCohort] \tCreating index file for: ',

)

INFO_TO_USER_TaskReadMS2 = (

    '\n[MSCohort] \tCreating index file for: ',

)

INFO_TO_USER_TaskReadID = (

    '\n[MSCohort] \tReading ',
    '\n[MSCohort] \tTotal number of Proteins: ',
    '\n[MSCohort] \tTotal number of Peptides: ',
    '\n[MSCohort] \tTotal number of precursor: '

)

INFO_TO_USER_TaskStatMV = (

    '\n[MSCohort] \tRemoving missing value ',
    '\n[MSCohort] \tTotal number of Proteins after removing missing value: ',
    '\n[MSCohort] \tTotal number of Peptides after removing missing value: ',
    '\n[MSCohort] \tTotal number of Precursors after removing missing value: ',

)

# 也许向某个日志文件里写东西
def logToUser(strInfo):

    # if os.access(myLogPath, os.W_OK):

    try:
        print(strInfo)
        f_w = open(myLogPath, 'a', encoding='utf8')
        f_w.write(strInfo + '\n')
        f_w.close()
    except IOError:
        print("MSCohort.log is opened! Please close it and run the program again!")
        sys.exit(0)


def logGetError(strInfo):

    print(strInfo)

    logging.basicConfig(filename=myLogPath,
                        filemode='a',
                        format='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'
                        )
    logging.error(strInfo)
    sys.exit(0)


def logGetWarning(strInfo):

    print(strInfo)

    logging.basicConfig(filename=myLogPath,
                        filemode='a',
                        format='%(asctime)s - %(pathname)s[line:%(lineno)d] - %(levelname)s: %(message)s'
                        )
    logging.warning(strInfo)
