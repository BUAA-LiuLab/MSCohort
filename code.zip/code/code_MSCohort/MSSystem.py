
VALUE_MAX_SCAN = 200000
VALUE_ILLEGAL = -7.16

TIME_EXPIRATION = {'Year': 2025, 'Month': 12, 'Day': 31}

IO_NAME_FILE_CONFIG = ('MSCohort_cfg.txt',)
IO_NAME_FILE_SETTING = ('MSCohort_setting.tsv',)

IO_PREFIX_EXPORT = (
    r'\txt\\',
    r'\picture\\',
    r'\tmp_file\\',
    # r'\iRT_Visual\\',
    # r'\model_train\\',
)

IO_FILENAME_HTML_EXPORT = (
    'Cohort Analysis Report.html'
)

IO_FILENAME_PDF_EXPORT = (
    'Cohort Analysis Report.pdf'
)

IO_FILENAME_PIC_EXPORT = (
    IO_PREFIX_EXPORT[1] + 'PIC0_IDCount',
    IO_PREFIX_EXPORT[1] + 'PIC1_Pro_MissingValueHist',
    IO_PREFIX_EXPORT[1] + 'PIC2_Pro_IntensityHist',
    IO_PREFIX_EXPORT[1] + 'PIC3_Pro_LinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC4_Pro_RatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC5_Pro_Violin',
    IO_PREFIX_EXPORT[1] + 'PIC6_Pro_ClusterHotmap',
    IO_PREFIX_EXPORT[1] + 'PIC7_Pro_CoefficientVar',
    IO_PREFIX_EXPORT[1] + 'PIC8_Pro_NormedViolin',
    IO_PREFIX_EXPORT[1] + 'PIC9_Pro_NormedClusterHotmap',
    IO_PREFIX_EXPORT[1] + 'PIC10_Pro_NormedCoefficientVar',
    IO_PREFIX_EXPORT[1] + 'PIC11_Pro_NormedPCA',
    IO_PREFIX_EXPORT[1] + 'PIC12_IRT_RTPloyLine',
    IO_PREFIX_EXPORT[1] + 'PIC13_IRT_IntPloyLine',
    IO_PREFIX_EXPORT[1] + 'PIC14_RT_LinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC15_RT_Deviation',
    IO_PREFIX_EXPORT[1] + 'PIC16_Pro_iBAQ',
    IO_PREFIX_EXPORT[1] + 'PIC17_Pro_NormedLinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC18_Pro_NormedRatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC19_Pep_MissingValueHist',  # index:19
    IO_PREFIX_EXPORT[1] + 'PIC20_Pep_LinearCorrelation',  # index:20
    IO_PREFIX_EXPORT[1] + 'PIC21_Pep_NormedLinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC22_Pep_RatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC23_Pep_NormedRatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC24_Pep_Violin',
    IO_PREFIX_EXPORT[1] + 'PIC25_Pep_NormedViolin',
    IO_PREFIX_EXPORT[1] + 'PIC26_Pep_CoefficientVar',
    IO_PREFIX_EXPORT[1] + 'PIC27_Pep_NormedCoefficientVar',
    IO_PREFIX_EXPORT[1] + 'PIC28_IRT_NormedIntPloyLine',
    IO_PREFIX_EXPORT[1] + 'PIC29_Pro_Volcano_plot',
    IO_PREFIX_EXPORT[1] + 'PIC30_Pro_NormedTSNE',  # index:30
    IO_PREFIX_EXPORT[1] + 'PIC31_Pre_LinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC32_Pre_NormedLinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC33_Pre_RatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC34_Pre_NormedRatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC35_Pre_Violin',
    IO_PREFIX_EXPORT[1] + 'PIC36_Pre_NormedViolin',
    IO_PREFIX_EXPORT[1] + 'PIC37_Pre_CoefficientVar',
    IO_PREFIX_EXPORT[1] + 'PIC38_Pre_NormedCoefficientVar',
    IO_PREFIX_EXPORT[1] + 'PIC39_Pro_PCA',
    IO_PREFIX_EXPORT[1] + 'PIC40_Pro_TSNE',  # index:40
    IO_PREFIX_EXPORT[1] + 'PIC41_ProGroup_MissingValueHist',
    IO_PREFIX_EXPORT[1] + 'PIC42_Experiment_Score',
    IO_PREFIX_EXPORT[1] + 'PIC43_Intra_Experiment_Score',
    IO_PREFIX_EXPORT[1] + 'PIC44_Contaminantions',
    IO_PREFIX_EXPORT[1] + 'PIC45_Missed cleavge',
    IO_PREFIX_EXPORT[1] + 'PIC46_Peak Width',
    IO_PREFIX_EXPORT[1] + 'PIC47_DeltaRT',
    IO_PREFIX_EXPORT[1] + 'PIC48_TIC',
    IO_PREFIX_EXPORT[1] + 'PIC49_ProteinViolin',
    IO_PREFIX_EXPORT[1] + 'PIC50_PeptideViolin',
    IO_PREFIX_EXPORT[1] + 'PIC51_PrecursorViolin',
    IO_PREFIX_EXPORT[1] + 'PIC52_MS1 MassAccuracy',
    IO_PREFIX_EXPORT[1] + 'PIC53_MS2 MassAccuracy',
    IO_PREFIX_EXPORT[1] + 'PIC54_DPPP_MS1',
    IO_PREFIX_EXPORT[1] + 'PIC55_DPPP_MS2',
    IO_PREFIX_EXPORT[1] + 'PIC56_FWHM',
    IO_PREFIX_EXPORT[1] + 'PIC57_Pro_Origin_LinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC58_Pro_Origin_NormedLinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC59_Pep_Origin_LinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC60_Pep_Origin_NormedLinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC61_Pre_Origin_LinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC62_Pre_Origin_NormedLinearCorrelation',
    IO_PREFIX_EXPORT[1] + 'PIC63_Pro_Origin_RatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC64_Pro_Origin_NormedRatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC65_Pep_Origin_RatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC66_Pep_Origin_NormedRatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC67_Pre_Origin_RatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC68_Pre_Origin_NormedRatioRobustDev',
    IO_PREFIX_EXPORT[1] + 'PIC69_Pro_MissingValueHist_Share',
    IO_PREFIX_EXPORT[1] + 'PIC70_Experiment_Outlier',
    IO_PREFIX_EXPORT[1] + 'PIC71_Calibrated_MS1_MassAccuracy',
    IO_PREFIX_EXPORT[1] + 'PIC71_Calibrated_MS2_MassAccuracy'
)

IO_FILENAME_EXPORT = (
    IO_PREFIX_EXPORT[0] + 'INFO0_Identification_Count.txt',
    IO_PREFIX_EXPORT[0] + 'INFO1_Pro0_MissingValue_Count.txt',
    IO_PREFIX_EXPORT[0] + 'INFO2_Pro1_Intensity.txt',
    IO_PREFIX_EXPORT[0] + 'INFO3_Pro2_Origin_Intensity.txt',
    IO_PREFIX_EXPORT[0] + 'INFO4_Pro3_Coefficient_Var.txt',
    IO_PREFIX_EXPORT[0] + 'INFO5_Pre_RetentionTime.txt',
    IO_PREFIX_EXPORT[0] + 'INFO4_Pro3_Coefficient_Var.txt',
    IO_PREFIX_EXPORT[0] + 'INFO5_Pre_RetentionTime.txt',
    # IO_PREFIX_EXPORT[0] + 'INFO6_iRT_XICDetail.txt',
    # IO_PREFIX_EXPORT[0] + 'INFO7_iRT_LabelDetail.txt',
    IO_PREFIX_EXPORT[0] + 'INFO8_Pro4_Norm_Intensity.txt',  # index:8
    IO_PREFIX_EXPORT[0] + 'INFO9_Pro5_Origin_Norm_Intensity.txt',  # index:9
    IO_PREFIX_EXPORT[0] + 'INFO10_Pro6_Norm_Coefficient_Var.txt',
    IO_PREFIX_EXPORT[0] + 'INFO11_Pro7_Norm_PCA_Coordinate.txt',
    IO_PREFIX_EXPORT[0] + 'INFO12_Pro8_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO13_Pro9_Violin_Statistic.txt',
    IO_PREFIX_EXPORT[0] + 'INFO14_Pro10_Norm_Violin_Statistic.txt',
    IO_PREFIX_EXPORT[0] + 'INFO15_Pro11_Cluster_Hotmap.csv',
    IO_PREFIX_EXPORT[0] + 'INFO16_Pro12_Norm_Cluster_Hotmap.csv',
    IO_PREFIX_EXPORT[0] + 'INFO17_Pro13_Summary_CoefficientVar.txt',
    IO_PREFIX_EXPORT[0] + 'INFO18_Pro14_Summary_Norm_CoefficientVar.txt',
    IO_PREFIX_EXPORT[0] + 'INFO19_iRTSummary.txt',
    IO_PREFIX_EXPORT[0] + 'INFO20_Pro_Norm_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO21_Empty.txt',
    IO_PREFIX_EXPORT[0] + 'INFO22_Pro_Log10iBAQ.txt',
    IO_PREFIX_EXPORT[0] + 'INFO23_Peptide0_MissingValue_Count.txt',  # index: 23
    IO_PREFIX_EXPORT[0] + 'INFO24_Peptide1_Intensity.txt',  # index:24
    IO_PREFIX_EXPORT[0] + 'INFO25_Peptide2_Origin_Intensity.txt',  # index:25
    IO_PREFIX_EXPORT[0] + 'INFO26_Peptide3_Norm_Intensity.txt',  # index:26
    IO_PREFIX_EXPORT[0] + 'INFO27_Peptide4_Norm_Origin_Intensity.txt',  # index:27
    IO_PREFIX_EXPORT[0] + 'INFO28_Peptide5_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO29_Peptide6_Norm_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO30_Peptide7_Violin_Statistic.txt',
    IO_PREFIX_EXPORT[0] + 'INFO31_Peptide8_Norm_Violin_Statistic.txt',
    IO_PREFIX_EXPORT[0] + 'INFO32_Peptide9_CoefficientVar.txt',
    IO_PREFIX_EXPORT[0] + 'INFO33_Peptide10_Norm_CoefficientVar.txt',
    IO_PREFIX_EXPORT[0] + 'INFO34_Peptide11_Summary_CoefficientVar.txt',
    IO_PREFIX_EXPORT[0] + 'INFO35_Peptide12_Summary_Norm_CoefficientVar.txt',
    IO_PREFIX_EXPORT[0] + 'INFO36_Pro_Volcano_plot',
    IO_PREFIX_EXPORT[0] + 'INFO37_Pro15_Norm_t-SNE_Coordinate.txt',
    IO_PREFIX_EXPORT[0] + 'INFO38_Precursor0_MissingValue_Count.txt',  # index: 38
    IO_PREFIX_EXPORT[0] + 'INFO39_Precursor1_Intensity.txt',  # index:39
    IO_PREFIX_EXPORT[0] + 'INFO40_Precursor2_Origin_Intensity.txt',  # index:40
    IO_PREFIX_EXPORT[0] + 'INFO41_Precursor3_Norm_Intensity.txt',  # index:41
    IO_PREFIX_EXPORT[0] + 'INFO42_Precursor4_Norm_Origin_Intensity.txt',  # index:42
    IO_PREFIX_EXPORT[0] + 'INFO43_Precursor5_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO44_Precursor6_Norm_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO45_Precursor7_Violin_Statistic.txt',
    IO_PREFIX_EXPORT[0] + 'INFO46_Precursor8_Norm_Violin_Statistic.txt',
    IO_PREFIX_EXPORT[0] + 'INFO47_Precursor9_CoefficientVar.txt',
    IO_PREFIX_EXPORT[0] + 'INFO48_Precursor10_Norm_CoefficientVar.txt',
    IO_PREFIX_EXPORT[0] + 'INFO49_Precursor11_Summary_CoefficientVar.txt',
    IO_PREFIX_EXPORT[0] + 'INFO50_Precursor12_Summary_Norm_CoefficientVar.txt',  # index: 50
    IO_PREFIX_EXPORT[0] + 'INFO51_Pro16_PCA_Coordinate.txt',
    IO_PREFIX_EXPORT[0] + 'INFO52_Pro17__t-SNE_Coordinate.txt',
    IO_PREFIX_EXPORT[0] + 'INFO53_ProGroup_MissingValue_Count.txt',
    IO_PREFIX_EXPORT[0] + 'INFO54_Corrected_Peptide_Intensity.txt',
    IO_PREFIX_EXPORT[0] + 'INFO55_Corrected_Protein_Intensity.txt',
    IO_PREFIX_EXPORT[0] + 'INFO0_Inter_Experiment_values.txt',
    IO_PREFIX_EXPORT[0] + 'INFO0_Inter_Experiment_Scores.txt',
    IO_PREFIX_EXPORT[0] + 'INFO0_Intra_Experiment_values.txt',
    IO_PREFIX_EXPORT[0] + 'INFO0_Intra_Experiment_Scores.txt',
    IO_PREFIX_EXPORT[0] + 'INFO60_Pro_Origin_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO61_Pro_Origin_Norm_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO62_Peptide_Origin_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO63_Peptide_Origin_Norm_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO64_Precursor_Origin_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO65_Precursor_Origin_Norm_Pearson_Correlation.txt',
    IO_PREFIX_EXPORT[0] + 'INFO66_Pro0_Share_Count.txt',
    IO_PREFIX_EXPORT[0] + 'INFO0_Experiment_Outlier_Score.txt'
)

IO_FILENAME_TMP_EXPORT = (
    IO_PREFIX_EXPORT[2] + 'TMP0_Pro1_Intensity',  # index:0
    IO_PREFIX_EXPORT[2] + 'TMP1_Pro2_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP2_Pro3_Coefficient_Var',
    IO_PREFIX_EXPORT[2] + 'TMP3_Pro4_Norm_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP4_Pro5_Norm_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP5_Pro6_Norm_Coefficient_Var',  # index:5
    IO_PREFIX_EXPORT[2] + 'TMP6_Retention_Time',
    IO_PREFIX_EXPORT[2] + 'TMP7_iRT_XIC',
    IO_PREFIX_EXPORT[2] + 'TMP8_iRT_Label',
    IO_PREFIX_EXPORT[2] + 'TMP9_Log2_iBAQ',
    IO_PREFIX_EXPORT[2] + 'TMP10_Pep1_Intensity',  # index:10
    IO_PREFIX_EXPORT[2] + 'TMP11_Pep2_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP12_Pep3_Coefficient_Var',
    IO_PREFIX_EXPORT[2] + 'TMP13_Pep4_Norm_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP14_Pep5_Norm_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP15_Pep6_Norm_Coefficient_Var',  # index:15
    IO_PREFIX_EXPORT[2] + 'TMP16_Pre1_Intensity',  # index:16
    IO_PREFIX_EXPORT[2] + 'TMP17_Pre2_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP18_Pre3_Coefficient_Var',
    IO_PREFIX_EXPORT[2] + 'TMP19_Pre4_Norm_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP20_Pre5_Norm_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP21_Pre6_Norm_Coefficient_Var',  # index:21
    IO_PREFIX_EXPORT[2] + 'TMP22_Pro7_Origin_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP23_Pro8_Origin_Norm_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP24_Pep7_Origin_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP25_Pep8_Origin_Norm_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP26_Pre7_Origin_Log2_Intensity',
    IO_PREFIX_EXPORT[2] + 'TMP27_Pre8_Origin_Norm_Log2_Intensity',
)

IOFILENAME_IRT_EXPORT = (
    r'\iRT_Visual\\',
    # IO_PREFIX_EXPORT[3],
)

IO_FILENAME_MODEL_EXPORT = (

    r'\model_train\\'+ 'PIC0_Model_Train',
    r'\model_train\\' + 'MODEL_SAVE',
    r'\model_train\\' + 'PEP_CV'
    # IO_PREFIX_EXPORT[4] + 'PIC0_Model_Train',
    # IO_PREFIX_EXPORT[4] + 'MODEL_SAVE',
    # IO_PREFIX_EXPORT[4] + 'PEP_CV',
)

IO_PATH_SAVE_MODEL = ('.\lib\model_save')

CFG_IRT_COLOR = ('#0000FF', '#B8860B', '#B22222', '#00AEFF', '#FF8618', '#CEDB29', '#00A652', '#FF0000', '#8A2BE2', '#EECBAD', '#00FF7F', '#FF00FF')

PLOT_PRECURSOR_COLOR = ('#00AEFF', '#FF8618', '#CEDB29', '#00A652', '#FF0000', '#8A2BE2', '#EECBAD', '#E0EEE0', '#E0FFFF')

PLOT_GROUP_COLOR = ('#FF3030', '#87CEEB', '#3CB371', '#6A5ACD', '#FFB90F', '#FF34B3', '#DCDCDC', '#FFE4E1',
                      '#DB7093', '#DDA0DD',)  # 红 浅蓝 深绿 浅紫 橘色 品红 灰色 浅粉 深紫 浅紫

PLOT_HEATMAP_COLOR = ('#008B8B', '#8B008B', '#FFE1FF', '#9B30FF', '#FFBBFF', '#DCDCDC', '#FFE4E1',
                      '#DB7093', '#DDA0DD',)  # DarkCyan DarkMagenta Thistle1 Purple1 Plum1 品红 灰色 浅粉 深紫 浅紫

CFG_TYPE_MS = {'MS': 0, 'RAW': 1}

CFG_TYPE_COHORT = {'DDACohort': 0, 'DIACohort': 1, 'iRTOnlyIndicator': 2, 'InstrumentCorrelation': 3, 'DIA_Estimate': 4}

CFG_TYPE_ANALYSIS_RESULT = {'Spectronaut': 0, 'DIA-NN': 1, 'pQuant': 2, 'MaxQuant': 3, 'MaxQuant_with_Mod': 4, 'pGlycoQuant': 5}

CFG_TYPE_NORMALIZATION = {'DirectLFQ': 0,'MaxLFQ': 1, 'Quantile': 2}

CFG_TYPE_ACCURACY_HALF_WIN_PEAK = {'PPM': 0, 'Da': 1}

CFG_TYPE_MISSING_VALUE_IMPUTATION = {'Normal': 0, 'KNN': 1}

CFG_FLAG_MISSING_VALUE_THRESHOLD = {'Normal': 0, 'Yes': 1}

CFG_TYPE_DATA = {'Thermo-Orbitrap': 0, 'timsTOF': 1, 'SCIEX': 2, 'Thermo-FAIMS':3}

UNIMOID_TO_STANDARD_MOD = {'UniMod:4': "Carbamidomethyl[C]", 'UniMod:35': "Oxidation[AnyC-termG]", 'UniMod:1': "Acetyl[AnyN-term]",
                           'UniMod:385': "Ammonia-loss[AnyN-termC]", 'UniMod:27': "Glu->pyro-Glu[AnyN-termE]",
                           'UniMod:28': "Ammonia-loss[AnyN-termC]"}
CFG_TYPE_OUTLIER = {'SVM':0,'IsolationForest':1}