
from sklearn import svm
from sklearn.decomposition import PCA
from matplotlib.patches import Ellipse
from sklearn.ensemble import IsolationForest
from sklearn import mixture
import numpy as np
import math
import os
import matplotlib
matplotlib.use('agg')
matplotlib.use('tkagg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from matplotlib.gridspec import GridSpec
from matplotlib.pyplot import MultipleLocator
import matplotlib.transforms as transforms
from matplotlib.backends.backend_agg import FigureCanvasAgg
from PIL import Image
import itertools
import scipy.cluster.hierarchy as sch
from scipy.stats import gaussian_kde
import seaborn as sns
import pandas as pd
import pickle
import pdfkit
from MSData import CDataPack
from MSSystem import *
from MSOperator import op_Data_fill_plot,metrics_INFO,meaning_INFO
from MSTool import toolLinearRegression, toolFindNeighborFromSortedList1

plt.rcParams['axes.unicode_minus'] = False
from matplotlib import rcParams


class CFunctionPlotI_9:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def var_cap_116(self, ax, rects):
        for rect in rects:
            size = 6 if len(self.dp.myProteinID.LIST_SAMPLE_ID) > 20 else 10
            ax.text(rect.get_x() + 0.10, rect.get_height(), rect.get_height(), ha='left', va='bottom', size=size)

    def plotDIA(self):

        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[0]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[0]

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        lines_psm = lines[lines.index('Precursor level')+1: lines.index('Peptide level')]
        lines_pep = lines[lines.index('Peptide level')+1: lines.index('ProteinGroup level')]
        lines_pg = lines[lines.index('ProteinGroup level')+1:]
        x_experiment, y_count = [], []

        for line in lines_psm:
            if line.startswith('Count'):
                x_experiment = line.strip().split('\t')[1:-1]
            elif line.startswith('ID'):
                y_count = [int(i) for i in line.strip().split('\t')[1:-1]]
        x_tick = list(range(len(x_experiment)))

        fig = plt.figure(figsize=(max(int(0.5 * len(x_experiment)), 8), 15))
        ax = plt.subplot(3, 1, 1)
        plt.title('Precursor level')
        rects = plt.bar(x_tick, y_count, width=0.5, color='steelblue', tick_label=x_experiment)
        plt.axhline(y=np.median(y_count), color='g', linestyle="dashed", linewidth=2)
        plt.axhline(y=np.median(y_count) - 2 * np.std(y_count), color='r', linestyle="dashed", linewidth=2)
        self.var_cap_116(ax, rects)

        plt.xticks(rotation=90, )
        
        plt.ylabel('Number of Precursors', fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')

        for line in lines_pep:
            if line.startswith('Count'):
                x_experiment = line.strip().split('\t')[1:]
            elif line.startswith('ID'):
                y_count = [int(i) for i in line.strip().split('\t')[1:]]

        x_tick = list(range(len(x_experiment)))
        ax = plt.subplot(3, 1, 2)
        plt.title('Peptide level')
        rects = plt.bar(x_tick, y_count, width=0.5, color='steelblue', tick_label=x_experiment)
        plt.axhline(y=np.mean(y_count[0:-1]), color='g', linestyle="dashed", linewidth=2)
        plt.axhline(y=np.mean(y_count[0:-1]) - 2 * np.std(y_count[0:-1]), color='r', linestyle="dashed", linewidth=2)
        self.var_cap_116(ax, rects)

        plt.xticks(rotation=90, )
        
        plt.ylabel('Number of Peptides', fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')

        plt.xticks(rotation=90, )
        plt.xlabel('Experiment', )
        plt.ylabel('Count', )
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')

        for line in lines_pg:
            if line.startswith('Count'):
                x_experiment = line.strip().split('\t')[1:]
            elif line.startswith('ID'):
                y_count = [int(i) for i in line.strip().split('\t')[1:]]

        x_tick = list(range(len(x_experiment)))
        
        ax = plt.subplot(3, 1, 3)
        plt.title('ProteinGroup level')
        rects = plt.bar(x_tick, y_count, width=0.5, color='steelblue', tick_label=x_experiment)
        plt.axhline(y=np.mean(y_count[0:-1]), color='g', linestyle="dashed", linewidth=2)
        plt.axhline(y=np.mean(y_count[0:-1]) - 2 * np.std(y_count[0:-1]), color='r', linestyle="dashed", linewidth=2)
        self.var_cap_116(ax, rects)

        plt.xticks(rotation=90, )
        plt.xlabel('Experiment', )
        plt.ylabel('Number of Protein Groups', fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')

        plt.subplots_adjust(left=0.15, bottom=0.10, top=0.95, right=0.95, hspace=0.30, wspace=0.20)
        fig.tight_layout()
        plt.savefig(path_out + '.png', format='png')
        
        plt.close('all')

    def plotDIA_Scatter(self):
        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[0]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[0]

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        lines_psm = lines[lines.index('Precursor level') + 1: lines.index('Peptide level')]
        lines_pep = lines[lines.index('Peptide level') + 1: lines.index('ProteinGroup level')]
        lines_pg = lines[lines.index('ProteinGroup level') + 1:]
        x_experiment, y_count= [], []

        
        for line in lines_psm:
            if line.startswith('Count'):
                x_experiment = line.strip().split('\t')[1:-1]
            elif line.startswith('ID'):
                y_count = [int(i) for i in line.strip().split('\t')[1:-1]]

        
        if len(x_experiment) <= 20:
            plt.figure(figsize=(min(int(1 * len(x_experiment)), 45), 15))
        elif len(x_experiment) > 20:
            plt.figure(figsize=(max(int(0.3 * len(x_experiment)), 8), 15))
        elif len(x_experiment) > 1000:
            plt.figure(figsize=(min(int(0.3 * len(x_experiment)), 200), 15))

        
        upper_3SD = np.median(y_count) + 3 * np.std(y_count)
        upper_2SD = np.median(y_count) + 2 * np.std(y_count)
        median = np.median(y_count)
        lower_2SD = np.median(y_count) - 2 * np.std(y_count)
        lower_3SD = np.median(y_count) - 3 * np.std(y_count)

        color = ['green'] * len(x_experiment)
        for i in range(len(y_count)):
            if y_count[i] > lower_2SD and y_count[i] < upper_2SD:
                color[i] = 'green'
            elif y_count[i] < lower_2SD and y_count[i]> lower_3SD:
                color[i] = 'gold'
            elif y_count[i] > upper_2SD and y_count[i]< upper_3SD:
                color[i] = 'gold'
            elif y_count[i] > upper_3SD or y_count[i] < lower_3SD:
                color[i] = 'red'

        ax = plt.subplot(3, 1, 1)
        plt.scatter(x_experiment, y_count, c=color,s=60)
        for i, count in enumerate(y_count):
            if count < lower_2SD and count > lower_3SD:
                plt.text(i, count, f'{x_experiment[i]}\n{count}', color='goldenrod', ha='center', va='bottom', fontsize=8)
            elif count > upper_2SD and count < upper_3SD:
                plt.text(i, count, f'{x_experiment[i]}\n{count}', color='goldenrod', ha='center', va='bottom', fontsize=8)
            elif count > upper_3SD or count < lower_3SD:
                plt.text(i, count, f'{x_experiment[i]}\n{count}', color='red', ha='center', va='bottom', fontsize=8)

        plt.title('Precursor level',fontsize=20)
        plt.xticks(rotation=90, )
        plt.axhline(y=median, color='g', linestyle="dashed", linewidth=2)
        plt.axhline(y=upper_2SD, color='gold', linestyle="dashed", linewidth=2)
        plt.axhline(y=lower_2SD, color='gold', linestyle="dashed", linewidth=2)
        plt.axhline(y=lower_3SD, color='r', linestyle="dashed", linewidth=2)
        plt.axhline(y=upper_3SD, color='r', linestyle="dashed", linewidth=2)

        plt.ylabel('Number of Precursors',fontsize=20 )
        ax.set_ylim(0,max(max(y_count),upper_3SD)+1000)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')


        
        for line in lines_pep:
            if line.startswith('Count'):
                x_experiment = line.strip().split('\t')[1:]
            elif line.startswith('ID'):
                y_count = [int(i) for i in line.strip().split('\t')[1:]]

        upper_3SD = np.median(y_count[0:-1]) + 3 * np.std(y_count[0:-1])
        upper_2SD = np.median(y_count[0:-1]) + 2 * np.std(y_count[0:-1])
        median = np.median(y_count[0:-1])
        lower_2SD = np.median(y_count[0:-1]) - 2 * np.std(y_count[0:-1])
        lower_3SD = np.median(y_count[0:-1]) - 3 * np.std(y_count[0:-1])

        color = ['green'] * len(x_experiment)
        for i in range(len(y_count)-1):
            if y_count[i] > lower_2SD and y_count[i] < upper_2SD:
                color[i] = 'green'
            elif y_count[i] < lower_2SD and y_count[i] > lower_3SD:
                color[i] = 'gold'
            elif y_count[i] > upper_2SD and y_count[i] < upper_3SD:
                color[i] = 'gold'
            elif y_count[i] > upper_3SD or y_count[i] < lower_3SD:
                color[i] = 'red'

        x_tick = list(range(len(x_experiment)))
        ax = plt.subplot(3, 1, 2)
        plt.title('Peptide level',fontsize=20)
        plt.scatter(x_experiment, y_count, c=color,s=60)
        for i, count in enumerate(y_count[0:-1]):
            if count < lower_2SD and count > lower_3SD:
                plt.text(i, count, f'{x_experiment[i]}\n{count}', color='gold', ha='center', va='bottom', fontsize=8)
            elif count > upper_2SD and count < upper_3SD:
                plt.text(i, count, f'{x_experiment[i]}\n{count}', color='gold', ha='center', va='bottom', fontsize=8)
            elif count > upper_3SD or count < lower_3SD:
                plt.text(i, count, f'{x_experiment[i]}\n{count}', color='red', ha='center', va='bottom', fontsize=8)

        plt.xticks(rotation=90, )
        plt.axhline(y=median, color='g', linestyle="dashed", linewidth=2)
        plt.axhline(y=upper_2SD, color='gold', linestyle="dashed", linewidth=2)
        plt.axhline(y=lower_2SD, color='gold', linestyle="dashed", linewidth=2)
        plt.axhline(y=lower_3SD, color='r', linestyle="dashed", linewidth=2)
        plt.axhline(y=upper_3SD, color='r', linestyle="dashed", linewidth=2)

        plt.xticks(rotation=90, )
        plt.ylabel('Number of Peptides',fontsize=20 )
        ax.set_ylim(0, max(max(y_count), upper_3SD) + 1000)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')


        
        for line in lines_pg:
            if line.startswith('Count'):
                x_experiment = line.strip().split('\t')[1:]
            elif line.startswith('ID'):
                y_count = [int(i) for i in line.strip().split('\t')[1:]]

        x_tick = list(range(len(x_experiment)))
        ax = plt.subplot(3, 1, 3)
        plt.title('ProteinGroup level',fontsize=20)

        upper_3SD = np.median(y_count[0:-1]) + 3 * np.std(y_count[0:-1])
        upper_2SD = np.median(y_count[0:-1]) + 2 * np.std(y_count[0:-1])
        median = np.median(y_count[0:-1])
        lower_2SD = np.median(y_count[0:-1]) - 2 * np.std(y_count[0:-1])
        lower_3SD = np.median(y_count[0:-1]) - 3 * np.std(y_count[0:-1])

        color = ['green'] * len(x_experiment)
        for i in range(len(y_count) - 1):
            if y_count[i] > lower_2SD and y_count[i] < upper_2SD:
                color[i] = 'green'
            elif y_count[i] < lower_2SD and y_count[i] > lower_3SD:
                color[i] = 'gold'
            elif y_count[i] > upper_2SD and y_count[i] < upper_3SD:
                color[i] = 'gold'
            elif y_count[i] > upper_3SD or y_count[i] < lower_3SD:
                color[i] = 'red'

        x_tick = list(range(len(x_experiment)))
        plt.scatter(x_experiment, y_count, c=color,s=60)
        for i, count in enumerate(y_count[0:-1]):
            if count < lower_2SD and count > lower_3SD:
                plt.text(i, count, f'{x_experiment[i]}\n{count}', color='gold', ha='center', va='bottom', fontsize=8)
            elif count > upper_2SD and count < upper_3SD:
                plt.text(i, count, f'{x_experiment[i]}\n{count}', color='gold', ha='center', va='bottom', fontsize=8)
            elif count > upper_3SD or count < lower_3SD:
                plt.text(i, count, f'{x_experiment[i]}\n{count}', color='red', ha='center', va='bottom', fontsize=8)

        plt.xticks(rotation=90, )
        plt.axhline(y=median, color='g', linestyle="dashed", linewidth=2)
        plt.axhline(y=upper_2SD, color='gold', linestyle="dashed", linewidth=2)
        plt.axhline(y=lower_2SD, color='gold', linestyle="dashed", linewidth=2)
        plt.axhline(y=lower_3SD, color='r', linestyle="dashed", linewidth=2)
        plt.axhline(y=upper_3SD, color='r', linestyle="dashed", linewidth=2)

        plt.xticks(rotation=90, )
        plt.xlabel('Experiment', )
        plt.ylabel('Number of Protein Groups',fontsize=20)
        ax.set_ylim(0, max(max(y_count), upper_3SD) + 100)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')

        plt.subplots_adjust(left=0.15, bottom=0.10, top=0.95, right=0.95, hspace=0.30, wspace=0.20)
        plt.tight_layout()
        plt.savefig(path_out + '.png', format='png')
        
        plt.close('all')


class CFunctionPlotM_16:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self):

        
        list_path = [self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[1],
                     self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[23],]

        list_out_path = [self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[1],
                         self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[19],]

        if self.dp.myProteinGroupID.N_PROTEIN > 0:
            list_path.append(self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[53])
            list_out_path.append(self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[41])

        for i in range(len(list_path)):

            path = list_path[i]
            out_path = list_out_path[i]

            with open(path, 'rb')as f:
                lines = f.read().decode(encoding='utf-8').split('\r\n')

            x_experiment = lines[0].strip().split('\t')[1:]
            var_yco_155 = lines[1].strip().split('\t')[1:]
            var_yno_27 = lines[2].strip().split('\t')[1:]
            var_ymi_24 = lines[3].strip().split('\t')[1:]

            var_yco_155 = [float(i) for i in var_yco_155]
            var_yno_27 = [float(i) for i in var_yno_27]
            var_ymi_24 = [float(i) for i in var_ymi_24]
            x_tick = list(range(len(x_experiment)))

            fig = plt.figure(figsize=(min(int(1.5 * len(x_experiment)), 45), 6))

            plt.bar(x_tick, var_yco_155, width=0.5, color='steelblue', tick_label=x_experiment, label='common', edgecolor='#000000')
            plt.bar(x_tick, var_yno_27, width=0.5,  bottom=var_yco_155, color='g', label='no common', edgecolor='#000000')
            var_yno_27 = [var_yco_155[i] + var_yno_27[i] for i in range(len(var_yno_27))]
            plt.bar(x_tick, var_ymi_24, width=0.5,  bottom=var_yno_27, color='r', label='missing', edgecolor='#000000')

            plt.xticks(rotation=90, )
            plt.xlabel('Experiment', )
            plt.ylabel('Count', fontsize=20)
            plt.legend(loc='lower left')
            ax = plt.gca()
            ax.spines['right'].set_color('none')
            ax.spines['top'].set_color('none')
            plt.subplots_adjust(left=0.15, bottom=0.10, top=0.95, right=0.95, hspace=0.30, wspace=0.20)
            fig.tight_layout()
            plt.savefig(out_path + '.png', format='png', dpi=300)
            
            plt.close('all')

    def plot_share(self):

        
        list_path = [self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[66]]

        list_out_path = [self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[69]]

        for i in range(len(list_path)):

            path = list_path[i]
            out_path = list_out_path[i]

            with open(path, 'rb')as f:
                lines = f.read().decode(encoding='utf-8').split('\r\n')

            x_experiment = lines[0].strip().split('\t')[1:]
            var_yco_155 = lines[1].strip().split('\t')[1:]
            var_ysh_33 = lines[2].strip().split('\t')[1:]
            var_ysp_74 = lines[3].strip().split('\t')[1:]
            var_yun_47 = lines[4].strip().split('\t')[1:]

            var_yco_155 = [float(i) for i in var_yco_155]
            var_ysh_33 = [float(i) for i in var_ysh_33]
            var_ysp_74 = [float(i) for i in var_ysp_74]
            var_yun_47 = [float(i) for i in var_yun_47]
            x_tick = list(range(len(x_experiment)))

            fig = plt.figure(figsize=(min(int(1.5 * len(x_experiment)), 45), 6))

            plt.bar(x_tick, var_yco_155, width=0.5, color='#696969', tick_label=x_experiment, label='Common quantification', edgecolor='#000000')
            plt.bar(x_tick, var_ysh_33, width=0.5,  bottom=var_yco_155, color='#BEBEBE', label='Shared >= 50% of runs', edgecolor='#000000')
            var_ysh_33 = [var_yco_155[i] + var_ysh_33[i] for i in range(len(var_ysh_33))]
            plt.bar(x_tick, var_ysp_74, width=0.5,  bottom=var_ysh_33, color='#FFFFFF', label='Sparse quantification', edgecolor='#000000')
            var_ysp_74 = [var_ysh_33[i] + var_ysp_74[i] for i in range(len(var_ysp_74))]
            plt.bar(x_tick, var_yun_47, width=0.5, bottom=var_ysp_74, color='r', label='Unique quantification', edgecolor='#000000')

            plt.xticks(rotation=90, )
            plt.xlabel('Experiment', )
            plt.ylabel('Count', fontsize=20)
            plt.legend(loc='lower left')
            ax = plt.gca()
            ax.spines['right'].set_color('none')
            ax.spines['top'].set_color('none')
            plt.subplots_adjust(left=0.15, bottom=0.10, top=0.95, right=0.95, hspace=0.30, wspace=0.20)
            fig.tight_layout()
            plt.savefig(out_path + '.png', format='png', dpi=300)
            
            plt.close('all')

class CFunctionPlotI_22:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self):

        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[1] + '.npy'
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[2]

        var_mat_135 = np.load(path)
        var_mat_135 =  var_mat_135 / np.log2(10)
        var_max_165 = max([len(i[1]) for i in self.dp.LIST_EXPERIMENT_GROUP])
        num_group = len(self.dp.LIST_EXPERIMENT_GROUP)
        fig = plt.figure(figsize=(min(int(3 * var_max_165), 300), int(2.5 * num_group)))
        min_log2_int = np.min(var_mat_135)
        max_log2_int = np.max(var_mat_135)

        for row, tmp_group in enumerate(self.dp.LIST_EXPERIMENT_GROUP):

            var_tmp_89 = tmp_group[2]

            for col, i_experiment in enumerate(var_tmp_89):

                i_index = self.dp.myProteinID.LIST_EXPERIMENT_ID.index(i_experiment)
                i_intensity = var_mat_135[:, i_index]
                var_med_95 = np.median(i_intensity)  
                i_intensity = [float(i) for i in i_intensity]
                plt.subplot(num_group, var_max_165, row * var_max_165 + col + 1)
                plt.hist(i_intensity, bins=50, edgecolor='lightblue')
                min_y_lim, max_y_lim = plt.ylim()
                plt.vlines(var_med_95, min_y_lim, max_y_lim, colors='r', linestyle='--', label="median:{:.1f}".format(var_med_95))  
                plt.legend(loc='upper right', fontsize='10')
                plt.xlim(min_log2_int - 1, max_log2_int + 1)
                plt.title(i_experiment)
                plt.xlabel("Log10 Intensity")
                plt.ylabel("Counts")

        plt.subplots_adjust(left=0.15, bottom=0.10, top=0.95, right=0.95, hspace=0.30, wspace=0.20)
        fig.tight_layout()
        plt.savefig(out_path + '.png', format="png", dpi=100)
        
        plt.close('all')

        if len(self.dp.myProteinID.PRO4_iBAQ) > 0:


            fig = plt.figure(figsize=(min(int(3 * var_max_165), 300), int(2.5 * num_group)))
            out_path_iBAQ = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[16]
            out_path_iBAQ_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[22]

            matrix_log10_iBAQ = self.dp.myProteinID.MATRIX_IBAQ_LOG10
            list_out_iBAQ = []
            min_log10_iBAQ = np.min(matrix_log10_iBAQ)
            max_log10_iBAQ = np.max(matrix_log10_iBAQ)

            ymajorLocator = MultipleLocator(1)
            if max_log10_iBAQ - min_log10_iBAQ <= 3:
                yminorLocator = MultipleLocator(0.2)
            else:
                yminorLocator = MultipleLocator(0.5)
            ax = plt.gca()
            ax.yaxis.var_set_38(ymajorLocator)
            ax.yaxis.var_set_48(yminorLocator)
            

            for row, tmp_group in enumerate(self.dp.LIST_EXPERIMENT_GROUP):

                var_tmp_89 = tmp_group[2]

                for col, i_experiment in enumerate(var_tmp_89):
                    i_index = self.dp.myProteinID.LIST_EXPERIMENT_ID.index(i_experiment)
                    i_iBAQ = matrix_log10_iBAQ[:, i_index]
                    median_iBAQ = np.median(i_iBAQ)
                    i_iBAQ = [float(i) for i in i_iBAQ]
                    i_iBAQ.sort()
                    list_out_iBAQ.append(i_iBAQ)

                    i_count = list(range(1, len(i_iBAQ) + 1, 1))

                    plt.subplot(num_group, var_max_165, row * var_max_165 + col + 1)
                    plt.scatter(i_count, i_iBAQ, s=0.15)
                    min_x_lim, max_x_lim = plt.xlim()
                    
                    
                    plt.hlines(median_iBAQ, min_x_lim, max_x_lim, colors='r', linestyles='--', label="median:{:.1f}".format(median_iBAQ))
                    plt.legend(loc='upper left', fontsize='10')
                    plt.title(i_experiment)
                    plt.xlabel("Count")
                    plt.ylabel("Log10 iBAQ")

            plt.subplots_adjust(left=0.15, bottom=0.10, top=0.95, right=0.95, hspace=0.30, wspace=0.20)
            fig.tight_layout()
            plt.savefig(out_path_iBAQ + '.png', format="png", dpi=100)
            
            plt.close('all')

            list_out_iBAQ = np.array(list_out_iBAQ)

            with open(out_path_iBAQ_txt, 'w')as f:
                f.write('\t'.join(self.dp.myProteinID.LIST_EXPERIMENT_ID) + '\n')
                for i in range(list_out_iBAQ.shape[1]):
                    f.write('\t'.join([str(i) for i in list_out_iBAQ[:, i]]) + '\n')


class CFunctionPlotT_23:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plotTIC(self):
        
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[48]

        MS1_intensity = pd.DataFrame()
        for i in self.dp.myProteinID.LIST_SAMPLE_ID:
            path_MS1 = self.dp.myCFG.E1_PATH_EXPORT + "\\MSCohort" + "\\MSCohort_" + i + "\\INFO_MS1_PEAKS.txt"
            f = open(path_MS1, encoding='utf-8', errors='ignore')
            i_MS1 = pd.read_csv(f, sep='\t', index_col=False)
            i_value = i_MS1.iloc[0:, 3]
            MS1_intensity = pd.concat([MS1_intensity, i_value], axis=1, sort=False)
        MS1_intensity.columns = self.dp.myProteinID.LIST_EXPERIMENT_ID

        MS1_intensity = MS1_intensity.apply(pd.to_numeric, errors='coerce')  
        matrix_log10 = np.log10(MS1_intensity)

        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        if n_experiment<20:
            fig = plt.figure(figsize=(min(2 + n_experiment, 20), 6))
        elif n_experiment<400:
            fig = plt.figure(figsize=(max(2 + 0.3*n_experiment, 10), 6))
        elif n_experiment >= 400:
            fig = plt.figure(figsize=(min(2 + 0.3 * n_experiment, 200), 6))
        sns.set(style='white')

        Intensity_Violin = pd.DataFrame(matrix_log10, columns=self.dp.myProteinID.LIST_EXPERIMENT_ID)
        sns.violinplot(data=Intensity_Violin, linewidth=1, width=0.9, inter="box",palette="Blues")

        
        col_median = Intensity_Violin.median(axis=0)
        plt.axhline(y=np.median(col_median), color='g', linestyle="dashed", linewidth=2)
        plt.axhline(y=np.median(col_median)-2*np.std(col_median), color='gold', linestyle="dashed", linewidth=2)
        plt.axhline(y=np.median(col_median) - 3 * np.std(col_median), color='r', linestyle="dashed", linewidth=2)

        plt.ylabel('Log10 MS1 TIC',fontsize=20)
        plt.xticks(rotation=90, fontsize=18)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)

        fig.tight_layout()
        plt.savefig(out_path + '.png', format="png", dpi=100)
        
        plt.close('all')


class CFunctionPlotP_19:
    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self):

        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[1] + '.npy'
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[49]

        var_mat_135 = np.load(path)
        var_mat_143 = var_mat_135 / np.log2(10)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        if n_experiment < 20:
            fig = plt.figure(figsize=(min(2 + n_experiment, 20), 6))
        else:
            fig = plt.figure(figsize=(max(2 + 0.3 * n_experiment, 10), 6))
        sns.set(style='white')

        Intensity_Violin = pd.DataFrame(var_mat_143, columns=self.dp.myProteinID.LIST_EXPERIMENT_ID)
        sns.violinplot(data=Intensity_Violin, linewidth=1, width=0.9, inter="box",palette="Blues")
        plt.ylabel('Log10 Protein Intensity',fontsize=20)
        plt.xticks(rotation=90,fontsize=18 )
        plt.grid(linestyle="--", alpha=0.5)

        fig.tight_layout()
        plt.savefig(out_path + '.png', format="png", dpi=100)
        
        plt.close('all')


class CFunctionPlotI_13:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self, flag, flag_norm):

        if flag == 0:  
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[4] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[17]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[20]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[1] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[3]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[12]
        elif flag == 1:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[14] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[21]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[29]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[11] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[20]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[28]

        elif flag == 2:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[20] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[32]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[44]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[17] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[31]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[43]


        var_mat_135 = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_pearson = []
        if n_experiment <= 100 and self.dp.myPrecursorID.N_PRECURSOR <= 150000:
            self.__captainPlot(path, flag_norm, out_path, out_path_list)
        else:
            self.__captainHeatMap(path, flag_norm, out_path, out_path_list)

    def plot_origin(self, flag, flag_norm):  

        if flag == 0:  
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[23] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[58]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[61]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[22] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[57]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[60]
        elif flag == 1:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[25] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[60]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[63]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[24] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[59]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[62]

        elif flag == 2:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[27] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[62]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[65]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[26] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[61]
                out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[64]


        var_mat_135 = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_pearson = []
        if n_experiment <= 100:
            self.__captainPlot(path, flag_norm, out_path, out_path_list, flag_origin=1)
        else:
            self.__captainHeatMap(path, flag_norm, out_path, out_path_list)

    def __soliderDelMissingValue(self, var_lis_8: np.ndarray, var_lis_66: np.ndarray):

        var_fla_71 = var_lis_8 > 0.
        var_fla_110 = var_lis_66 > 0.
        flag_no_mv = var_fla_71 * var_fla_110
        var_lis_8 = var_lis_8[flag_no_mv]
        var_lis_66 = var_lis_66[flag_no_mv]

        return var_lis_8, var_lis_66

    def __captainPlot(self, path, flag_norm, out_path, out_path_list, flag_origin=0):

        var_mat_135 = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_pearson = []
        dpi = 100 if n_experiment <= 20 else 50 if n_experiment <= 100 else 10
        fig = plt.figure(figsize=(3 + 3 * n_experiment, 3 + 3 * n_experiment), dpi=dpi)

        cmp1 = plt.cm.get_cmap('Blues')

        labelsize = 20 if n_experiment < 16 else 25 if n_experiment < 20 else 30
        ax = plt.subplot(n_experiment + 1, n_experiment + 1, 2)
        ylabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[0]
        plt.xticks([])
        plt.yticks([])
        plt.ylabel(ylabel + '  ' * len(ylabel) + '   ', fontsize=labelsize, rotation='horizontal', labelpad=5)
        ax.spines['top'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        ax = plt.subplot(n_experiment + 1, n_experiment + 1, (n_experiment + 1) * n_experiment)
        xlabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[n_experiment - 1]
        plt.xlabel(xlabel + ' ', fontsize=labelsize, rotation=90, labelpad=8)
        plt.xticks([])
        plt.yticks([])
        ax.spines['top'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(False)

        canvas = FigureCanvasAgg(fig)
        canvas.draw()
        buf = canvas.buffer_rgba()
        data_all = np.asarray(buf)
        del buf
        Image.MAX_IMAGE_PIXELS = int(1024 * 1024 * 1024 * 1024 * 1024 // 4 // 3)  
        count_subplot = 0
        var_thr_156 = 1000

        for i in range(n_experiment):

            if (count_subplot >= var_thr_156) or (i == n_experiment - 1):
                
                canvas = FigureCanvasAgg(fig)
                canvas.draw()
                buf = canvas.buffer_rgba()
                data_i = np.asarray(buf)
                data_all = 255 - ((255 - data_all) + (255 - data_i))  
                
                
                del buf, data_i
                plt.clf()  
                count_subplot = 0

            for j in range(i + 1, n_experiment):

                count_subplot += 1

                XArray = var_mat_135[:, i]
                YArray = var_mat_135[:, j]
                if flag_origin:
                    XArray, YArray = self.__soliderDelMissingValue(XArray, YArray)
                slope, pearson = toolLinearRegression(XArray, YArray)

                str_pearson = "%.3f" % pearson
                list_pearson.append(
                    [self.dp.myProteinID.LIST_EXPERIMENT_ID[i], self.dp.myProteinID.LIST_EXPERIMENT_ID[j], pearson])

                plot_index = j * (n_experiment + 1) + i + 2  
                pear_index = i * (n_experiment + 1) + j + 2
                ax = plt.subplot(n_experiment + 1, n_experiment + 1, plot_index)
                plt.axis('equal')  
                plt.plot(XArray, YArray, "ro", color="black", markersize=2)
                if i == 0:  
                    ylabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[j] if self.dp.myProteinID.LIST_EXPERIMENT_ID[j] else \
                        self.dp.myProteinID.LIST_SAMPLE_ID[j]
                    plt.ylabel(ylabel + '  ' * len(ylabel), fontsize=labelsize, rotation='horizontal', labelpad=5)

                if j == n_experiment - 1:
                    xlabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[i] if self.dp.myProteinID.LIST_EXPERIMENT_ID[i] else \
                        self.dp.myProteinID.LIST_SAMPLE_ID[i]
                    plt.xlabel(xlabel, fontsize=labelsize, rotation=90, labelpad=5)
                
                ax = plt.subplot(n_experiment + 1, n_experiment + 1, pear_index)
                plt.axis("equal")  
                plt.xticks([])
                plt.yticks([])
                if pearson >= 0.93:
                    plt.text(0.1, 0.4, str_pearson, size=40, color='#FFFFFF')
                else:
                    plt.text(0.1, 0.4, str_pearson, size=40, )
                pearson_plot = max((pearson-0.75) * 4, 0.)
                list_c = cmp1(pearson_plot, bytes=True)[:-1]

                list_hex_c = [str(hex(i))[2:] for i in list_c]
                list_hex_c = [i if len(i) == 2 else '0' + i for i in list_hex_c]
                str_c = '#' + ''.join(list_hex_c)
                ax.patch.set_facecolor(str_c)
                

        matplotlib.image.imsave(out_path + '.png', data_all)
        
        
        plt.close('all')

        with open(out_path_list, 'w')as f:

            f.write('\t'.join(["Experiment1", "Experiment2", "Pearson"]) + '\n')

            for i_list in list_pearson:
                f.write('\t'.join([str(i) for i in i_list]) + '\n')

    def __captainHeatMap(self, path, flag_norm, out_path, out_path_list, flag_origin=0):

        var_mat_135 = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)

        dpi = 30
        fig = plt.figure(figsize=(3 + int(1.5 * n_experiment), 3 + int(1.5 * n_experiment)), dpi=dpi)
        if flag_norm:
            plt.title('After Normalization')
        else:
            plt.title('Before Normalization')

        df = pd.DataFrame(var_mat_135, columns=self.dp.myProteinID.LIST_EXPERIMENT_ID)
        if flag_origin:
            corr_matrix = pd.DataFrame(var_mat_135[0], columns=self.dp.myProteinID.LIST_EXPERIMENT_ID).corr(method='pearson')
            for i in range(var_mat_135.shape[1]):
                for j in range(i+1, var_mat_135.shape[1]):
                    XArray = var_mat_135[:, i]
                    YArray = var_mat_135[:, j]
                    if flag_origin:
                        XArray, YArray = self.__soliderDelMissingValue(XArray, YArray)
                    slope, pearson = toolLinearRegression(XArray, YArray)
                    corr_matrix.values[j][i] = pearson
        else:
            corr_matrix = df.corr(method='pearson')
        corr_matrix.head()
        mask = np.zeros_like(corr_matrix, dtype=np.bool)
        
        mask[np.triu_indices_from(mask)] = True
        h = sns.heatmap(corr_matrix, mask=mask, square=True, annot=True, annot_kws={"size": 23}, cbar=False, cmap='RdBu', vmin=-1, vmax=1)
        cb = h.figure.colorbar(h.collections[0])
        cb.ax.tick_params(labelsize=n_experiment*2)
        plt.tick_params(labelsize=20)
        plt.xticks(rotation=90)
        plt.yticks(rotation=0)
        
        bottom, top = h.get_ylim()
        h.set_ylim(bottom + 0.5, top - 0.5)

        plt.savefig(out_path + '.png', format='png')
        
        plt.close()

        with open(out_path_list, 'w')as f:

            f.write('\t'.join(["Experiment1", "Experiment2", "Pearson"]) + '\n')
            for i in range(n_experiment):
                for j in range(i+1, n_experiment):
                    str_pearson = '\t'.join([self.dp.myProteinID.LIST_EXPERIMENT_ID[i], self.dp.myProteinID.LIST_EXPERIMENT_ID[j],
                                             str(corr_matrix.iloc[i][j])])
                    f.write(str_pearson + '\n')


class CFunctionIntra_11:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plot(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[43]
        var_out_13 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[58]
        var_out_106 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[59]
        values = pd.DataFrame()
        scores = pd.DataFrame()
        n=0
        for i in self.dp.myProteinID.LIST_SAMPLE_ID:
            path_summary = self.dp.myCFG.E1_PATH_EXPORT + "\\MSCohort" + "\\MSCohort_" + i + "\\IFNO_Summary.txt"

            with open(path_summary, encoding='utf-8', errors='ignore') as f:

                if not os.path.getsize(path_summary):
                    print("The IFNO_Summary.txt for "+ i + " is empty")
                    continue
                else:
                    i_summary = pd.read_csv(f, sep='\t', index_col=0)
                    i_value = i_summary.iloc[1:, 0]
                    i_score = i_summary.iloc[1:, 1]
                    i_value = pd.Series(data=i_value,name=self.dp.myProteinID.LIST_EXPERIMENT_ID[n])
                    i_score = pd.Series(data=i_score, name=self.dp.myProteinID.LIST_EXPERIMENT_ID[n])
                    values = pd.concat([values, i_value], axis=1, sort=False) 
                    scores = pd.concat([scores, i_score], axis=1, sort=False)

                    
                    
            n=n+1
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)

        values.to_csv(var_out_13, sep='\t')
        scores.to_csv(var_out_106, sep='\t')

        scores1 = scores.apply(pd.to_numeric, errors='coerce')  

        fig = plt.figure(figsize=(10 + int(0.6 * n_experiment), 5 + int(1.7 * 15)), dpi=100)
        h = sns.heatmap(scores1, square=True, annot=True, fmt='.1f', linewidths=1.5, linecolor='#000000',
                        annot_kws={"size": 15}, cbar=False, cmap='RdYlGn', vmin=0, vmax=5)
        
        cb = h.figure.colorbar(h.collections[0])
        cb.ax.tick_params(labelsize=15)
        plt.tick_params(labelsize=18)
        plt.xticks(rotation=90)
        plt.yticks(rotation=0)
        plt.ylabel('')
        plt.tight_layout()
        
        bottom, top = h.get_ylim()
        h.set_ylim(bottom + 0.5, top - 0.5)

        plt.savefig(out_path + '.png', format='png')
        


class CFunctionPlotE_26:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP
        self.var_lis_82 = self.dp.myProteinID.LIST_EXPERIMENT_ID
        self.score_rt_std = [[[0.] * len(self.var_lis_82)]]
        self.var_sco_37 = [[[0.] * len(self.var_lis_82)]]
        self.score_deltaRT = [[[0.] * len(self.var_lis_82)]]
        self.count_protein = [[[0.] * len(self.var_lis_82)]]
        self.var_sco_107 = {}

        self.var_sco_36 = [[[0.] * len(self.var_lis_82)]] * 3
        self.var_sco_94 = [[0.]*len(self.var_lis_82)] * 3
        self.score_int_IQR = [[0.]*len(self.var_lis_82)] * 3
        self.var_sco_85 = [[0.]*len(self.var_lis_82)] * 3
        self.score_int_std = [[0.]*len(self.var_lis_82)] * 3
        self.var_sco_78 = [[0.]*len(self.var_lis_82)] * 3


    def __captainCalIntScore(self, var_mat_35: np.ndarray, flag):

        n_experiment = len(self.var_lis_82)
        var_lis_58 = []
        var_lis_113 = []

        var_mat_35[var_mat_35==0] = np.nan
        self.var_sco_94[flag] = list(np.nanmedian(var_mat_35, axis=0))
        self.score_int_IQR[flag] = list(np.nanpercentile(var_mat_35, 75, axis=0) - np.nanpercentile(var_mat_35, 25, axis=0))

        df = pd.DataFrame(var_mat_35, columns=self.dp.myProteinID.LIST_EXPERIMENT_ID)
        corr_matrix = df.corr(method='pearson')
        corr_matrix = corr_matrix.values
        var_lis_58 = [(np.sum(corr_matrix[:,i])-1.)/ (n_experiment-1) for i in range(n_experiment)]

        cv_matrix = np.ones([n_experiment, n_experiment]) * -1
        for i in range(n_experiment):
            for j in range(n_experiment):
                if i == j:
                    continue
                XArray = var_mat_35[:, i]
                YArray = var_mat_35[:, j]
                data = XArray - YArray
                var_per_52 = np.nanpercentile(data, 15.87)
                var_per_41 = np.nanpercentile(data, 84.13)
                dev = (var_per_41 - var_per_52) / 2
                cv_matrix[i][j] = dev
        var_lis_113 = [(np.sum(cv_matrix[:,i])+1)/(n_experiment-1) for i in range(n_experiment)]

        self.var_sco_85[flag] = var_lis_58
        self.score_int_std[flag] = var_lis_113

    def __captrainCalRTScore(self, var_mat_35: np.ndarray, flag):

        n_experiment = len(self.var_lis_82)
        var_lis_81 = []

        std_matrix = np.ones([n_experiment, n_experiment]) * -1
        for i in range(n_experiment):
            for j in range(n_experiment):
                if i == j:
                    continue
                XArray = var_mat_35[:, i]
                YArray = var_mat_35[:, j]
                data = XArray - YArray
                medianRT = np.nanmedian(data)
                var_per_52 = np.nanpercentile(data, 15.87)
                var_per_41 = np.nanpercentile(data, 84.13)
                dev = (var_per_41 - var_per_52) / 2
                std_matrix[i][j] = dev
        var_lis_81 = [(np.sum(std_matrix[:, i]) + 1) / (n_experiment - 1) for i in range(n_experiment)]

        self.score_rt_std = var_lis_81

    def __captrainCalIRTScore(self):

        N_IRT_PEPTIDE = len(self.dp.myINI.LIST_IRT_PEPTIDE)
        var_lis_157 = [[0.] * len(self.var_lis_82)]
        for i in range(len(self.dp.myIDForIRT.PRELIST8_INTENSITY)):
            tmp_list_int = np.array(self.dp.myIDForIRT.PRELIST8_INTENSITY[i])
            var_lis_157 += (tmp_list_int != VALUE_ILLEGAL)
        var_lis_148 = [i / N_IRT_PEPTIDE for i in var_lis_157]
        self.var_sco_37 = list(var_lis_148[0])

    def __captrainCalDeltaRTScore(self):
        matrix_deltaRT = self.dp.myPrecursorID.PRELIST6_DELTART
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        matrix_deltaRT_array = np.array(matrix_deltaRT)
        matrix_deltaRT_array[matrix_deltaRT_array == VALUE_ILLEGAL] = np.nan
        df = pd.DataFrame(matrix_deltaRT_array, columns=var_lis_82)
        self.score_deltaRT = list(df.median())

    def __captainCalConScore(self):

        self.dp.myCONTAM.CON_RATIO = [[[0.] * len(self.var_lis_82)]] * len(self.dp.myCONTAM.DIC_CONTAM)
        for i_index,tmp_con in enumerate(self.dp.myCONTAM.DIC_CONTAM):
            list_count = [[0.]*len(self.var_lis_82)]
            for i in range(len(self.dp.myProteinID.PRO1_NAME)):
                list_i = self.dp.myProteinID.PRO1_NAME[i].split(';')
                for j in list_i:
                    if j in self.dp.myCONTAM.DIC_CONTAM[tmp_con]:
                        list_count += (self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY[i])
                        break
            list_count = [list_count[i] / np.sum(self.dp.myProteinID.MATRIX_ORIGIN_INTENSITY,axis=0) for i in range(len(list_count))]
            self.var_sco_107[tmp_con] = list_count[0]
            self.dp.myCONTAM.CON_RATIO[i_index] = list_count[0]
            
            

    def __captainCalMissingValueScore(self):

        
        var_lis_157 = [[0.]*len(self.var_lis_82)]
        for i in range(len(self.dp.myPrecursorID.PRELIST2_INTENSITY)):
            tmp_list_int = np.array(self.dp.myPrecursorID.PRELIST2_INTENSITY[i])
            var_lis_157 += (tmp_list_int == VALUE_ILLEGAL)
        list_count = [self.dp.myPrecursorID.N_PRECURSOR-i for i in var_lis_157]
        self.var_sco_36[2] = list(list_count[0])

        
        var_lis_157 = [[0.] * len(self.var_lis_82)]
        for i in range(len(self.dp.myPeptideID.PEPLIST1_INTENSITY)):
            tmp_list_int = np.array(self.dp.myPeptideID.PEPLIST1_INTENSITY[i])
            var_lis_157 += (tmp_list_int == VALUE_ILLEGAL)
        var_lis_148 = [self.dp.myPeptideID.N_PEPTIDE-i for i in var_lis_157]
        self.var_sco_36[1] = list(var_lis_148[0])

        
        var_lis_157 = [[0.] * len(self.var_lis_82)]
        for i in range(len(self.dp.myProteinID.PRO2_INTENSITY)):
            tmp_list_int = np.array(self.dp.myProteinID.PRO2_INTENSITY[i])
            var_lis_157 += (tmp_list_int == VALUE_ILLEGAL)
        var_lis_148 = [self.dp.myProteinID.N_PROTEIN-i for i in var_lis_157]
        self.count_protein = [self.dp.myProteinID.N_PROTEIN - i for i in var_lis_157]
        self.var_sco_36[0] = list(var_lis_148[0])

    def __captainCalNormScore(self):

        
        list_norm = self.dp.myPrecursorID.LIST_NORM_PARAM
        self.var_sco_78[2] = list_norm
        
        list_norm = self.dp.myPeptideID.LIST_NORM_PARAM
        self.var_sco_78[1] = list_norm
        
        list_norm = self.dp.myProteinID.LIST_NORM_PARAM
        self.var_sco_78[0] = list_norm

    def __captainScoreIndex(self):

        var_lis_18 = self.var_sco_107
        for i in var_lis_18:
            var_ili_127 = var_lis_18[i]
            var_con_6, var_con_17 = np.median(var_ili_127), np.std(var_ili_127)
            var_ili_127 = [j - var_con_6 for j in var_ili_127]
            var_ili_127 = [5 if j <= 0 else self.dp.myEXPSCORE.THRESHOLD_CONTAMINANT * (self.dp.myEXPSCORE.THRESHOLD_CONTAMINANT * var_con_17 - j) / var_con_17 + 1 for j in var_ili_127]
            var_ili_127 = [0 if j < 0 else j for j in var_ili_127]
            self.var_sco_107[i] = var_ili_127    

        var_lis_5 = self.var_sco_37
        for i in range(len(var_lis_5)):
                tmp_score = var_lis_5[i] * 5
                var_lis_5[i] = tmp_score

        list_score_deltaRT = self.score_deltaRT
        deltaRT_median, deltaRT_std = np.median(list_score_deltaRT), np.std(list_score_deltaRT)
        list_score_deltaRT = [abs(j - deltaRT_median) for j in list_score_deltaRT]
        list_score_deltaRT = [1 if j > self.dp.myEXPSCORE.THRESHOLD_DELTART * deltaRT_std else self.dp.myEXPSCORE.THRESHOLD_DELTART * (self.dp.myEXPSCORE.THRESHOLD_DELTART * deltaRT_std - j) / deltaRT_std + 1 for j in list_score_deltaRT]
        self.score_deltaRT = list_score_deltaRT

        var_lis_11 = self.score_rt_std
        rt_median, rt_std = np.median(var_lis_11), np.std(var_lis_11)
        var_lis_11 = [abs(i - rt_median) for i in var_lis_11]
        var_lis_11 = [1 if i > self.dp.myEXPSCORE.THRESHOLD_RT_DEV * rt_std else self.dp.myEXPSCORE.THRESHOLD_RT_DEV * (self.dp.myEXPSCORE.THRESHOLD_RT_DEV * rt_std - i) / rt_std + 1 for i in var_lis_11]
        self.score_rt_std = var_lis_11    

        var_lis_59 = self.var_sco_36
        for i in range(len(var_lis_59)):
            var_ili_122 = var_lis_59[i]
            miss_median, miss_std = np.median(var_ili_122), np.std(var_ili_122)
            var_ili_122 = [j - miss_median for j in var_ili_122]
            var_thr_99 = [self.dp.myEXPSCORE.THRESHOLD_MISSING_PRE, self.dp.myEXPSCORE.THRESHOLD_MISSING_PEP, self.dp.myEXPSCORE.THRESHOLD_MISSING_PRO][i]
            var_ili_122 = [5 if j > 0 else var_thr_99 * (var_thr_99 * miss_std - abs(j)) / miss_std + 1 for j in var_ili_122]
            var_ili_122 = [0 if j < 0 else j for j in var_ili_122]
            self.var_sco_36[i] = var_ili_122   

        var_lis_118 = self.var_sco_94
        for i in range(len(var_lis_118)):
            var_ili_103 = var_lis_118[i]
            median_median, median_std = np.median(var_ili_103), np.std(var_ili_103)
            var_ili_103 = [abs(j - median_median) for j in var_ili_103]
            var_thr_53 = [self.dp.myEXPSCORE.THRESHOLD_MEDIAN_INT_PRE, self.dp.myEXPSCORE.THRESHOLD_MEDIAN_INT_PEP, self.dp.myEXPSCORE.THRESHOLD_MEDIAN_INT_PRO][i]
            var_ili_103 = [1 if j > var_thr_53 * median_std else var_thr_53 * (var_thr_53 * median_std - j) / median_std + 1 for j in var_ili_103]
            self.var_sco_94[i] = var_ili_103  

        list_score_int_IQR = self.score_int_IQR
        for i in range(len(list_score_int_IQR)):
            i_list_score_IQR = list_score_int_IQR[i]
            IQR_median, IQR_std = np.median(i_list_score_IQR), np.std(i_list_score_IQR)
            threshold_IQR = [self.dp.myEXPSCORE.THRESHOLD_IQR_PRE, self.dp.myEXPSCORE.THRESHOLD_IQR_PEP, self.dp.myEXPSCORE.THRESHOLD_IQR_PRO][i]
            i_list_score_IQR = [abs(j - IQR_median) for j in i_list_score_IQR]
            i_list_score_IQR = [1 if j > threshold_IQR * IQR_std else threshold_IQR * (threshold_IQR * IQR_std - j) / IQR_std + 1 for j in i_list_score_IQR]
            self.score_int_IQR[i] = i_list_score_IQR    

        var_lis_113 = self.score_int_std
        for i in range(len(var_lis_113)):
            var_ili_43 = var_lis_113[i]
            std_median, std_std = np.median(var_ili_43), np.std(var_ili_43)
            threshold_std = [self.dp.myEXPSCORE.THRESHOLD_DEV_INT_PRE, self.dp.myEXPSCORE.THRESHOLD_DEV_INT_PEP, self.dp.myEXPSCORE.THRESHOLD_DEV_INT_PRO][i]
            var_ili_43 = [j - std_median for j in var_ili_43]
            var_ili_43 = [5 if j < 0 else threshold_std * (threshold_std * std_std - j) / std_std + 1 for j in var_ili_43]
            var_ili_43 = [0 if j < 0 else j for j in var_ili_43]
            self.score_int_std[i] = var_ili_43    

        var_lis_58 = self.var_sco_85
        for i in range(len(var_lis_58)):
            var_ili_124 = var_lis_58[i]
            var_pea_23, pearson_std = np.median(var_ili_124), np.std(var_ili_124)
            var_thr_86 = [self.dp.myEXPSCORE.THRESHOLD_PEARSON_INT_PRE, self.dp.myEXPSCORE.THRESHOLD_PEARSON_INT_PEP, self.dp.myEXPSCORE.THRESHOLD_PEARSON_INT_PRO][i]
            var_ili_124 = [j - var_pea_23 for j in var_ili_124]
            var_ili_124 = [5 if j > 0 else var_thr_86 * (var_thr_86 * pearson_std - abs(j)) / pearson_std + 1 for j in var_ili_124]
            var_ili_124 = [0 if j < 0 else j for j in var_ili_124]
            self.var_sco_85[i] = var_ili_124    

        var_lis_16 = self.var_sco_78
        for i in range(len(var_lis_16)):
            var_ili_96 = var_lis_16[i]
            norm_mean, norm_std = np.mean(var_ili_96), np.std(var_ili_96)
            var_thr_26 = [self.dp.myEXPSCORE.THRESHOLD_NORM_PRE, self.dp.myEXPSCORE.THRESHOLD_NORM_PEP, self.dp.myEXPSCORE.THRESHOLD_NORM_PRO][i]
            var_ili_96 = [abs(j - norm_mean) for j in var_ili_96]
            var_ili_96 = [1 if j > var_thr_26 * norm_std else var_thr_26 * (var_thr_26 * norm_std - j) / norm_std + 1 for j in var_ili_96]
            self.var_sco_78[i] = var_ili_96


    def plot(self):

        
        self.__captainCalMissingValueScore()
        self.__captainCalConScore()
        self.__captrainCalDeltaRTScore()
        self.__captainCalNormScore()
        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[22] + '.npy'
        var_mat_135 = np.load(path)
        self.__captainCalIntScore(var_mat_135, 0)   
        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[24] + '.npy'
        var_mat_135 = np.load(path)
        self.__captainCalIntScore(var_mat_135, 1)
        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[26] + '.npy'
        var_mat_135 = np.load(path)
        self.__captainCalIntScore(var_mat_135, 2)
        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[6] + '.npy'
        matrix_rt = np.load(path)
        self.__captrainCalRTScore(matrix_rt, 0)

        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[42]
        out_path_list = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[56]
        var_out_119 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[57]

        self.__captainWriteInfo(out_path_list)
        self.__captainScoreIndex()
        self.__captainWriteInfo(var_out_119)
        self.__captainHeatMap(path, out_path, var_out_119)

    def __captainWriteInfo(self, out_path_list):

        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)

        var_lis_163 = self.var_sco_107
        list_score_deltaRT = self.score_deltaRT
        list_score_rt = self.score_rt_std
        var_lis_34 = [self.var_sco_36[0], self.var_sco_94[0], self.score_int_IQR[0], self.score_int_std[0], self.var_sco_85[0], self.var_sco_78[0]]
        var_lis_39 = [self.var_sco_36[1], self.var_sco_94[1], self.score_int_IQR[1], self.score_int_std[1], self.var_sco_85[1], self.var_sco_78[1]]
        var_lis_54 = [self.var_sco_36[2], self.var_sco_94[2], self.score_int_IQR[2], self.score_int_std[2], self.var_sco_85[2], self.var_sco_78[2]]

        total_score = []
        for i in range(n_experiment):
            
            
            i_con_score = sum([var_lis_163[i_con][i] for i_con in var_lis_163])
            if self.dp.myCFG.C14_DDA_FLAG_NORMALIZATION != CFG_TYPE_NORMALIZATION['Quantile']:
                i_total_score = self.dp.myEXPSCORE.WEIGHT_CONTAMINANT * i_con_score + \
                                self.dp.myEXPSCORE.WEIGHT_DELTART * list_score_deltaRT[i] + \
                                self.dp.myEXPSCORE.WEIGHT_RT_DEV * list_score_rt[i] + \
                                self.dp.myEXPSCORE.WEIGHT_MISSING_PRE * var_lis_54[0][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MEDIAN_INT_PRE * var_lis_54[1][i] + \
                                self.dp.myEXPSCORE.WEIGHT_IQR_PRE * var_lis_54[2][i] + \
                                self.dp.myEXPSCORE.WEIGHT_DEV_INT_PRE * var_lis_54[3][i] + \
                                self.dp.myEXPSCORE.WEIGHT_PEARSON_INT_PRE * var_lis_54[4][i] + \
                                self.dp.myEXPSCORE.WEIGHT_NORM_PRE * var_lis_54[5][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MISSING_PEP * var_lis_39[0][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MEDIAN_INT_PEP * var_lis_39[1][i] + \
                                self.dp.myEXPSCORE.WEIGHT_IQR_PEP * var_lis_39[2][i] + \
                                self.dp.myEXPSCORE.WEIGHT_DEV_INT_PEP * var_lis_39[3][i] + \
                                self.dp.myEXPSCORE.WEIGHT_PEARSON_INT_PEP * var_lis_39[4][i] + \
                                self.dp.myEXPSCORE.WEIGHT_NORM_PEP * var_lis_39[5][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MISSING_PRO * var_lis_34[0][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MEDIAN_INT_PRO * var_lis_34[1][i] + \
                                self.dp.myEXPSCORE.WEIGHT_IQR_PRO * var_lis_34[2][i] + \
                                self.dp.myEXPSCORE.WEIGHT_DEV_INT_PRO * var_lis_34[3][i] + \
                                self.dp.myEXPSCORE.WEIGHT_PEARSON_INT_PRO * var_lis_34[4][i] + \
                                self.dp.myEXPSCORE.WEIGHT_NORM_PRO * var_lis_34[5][i]
                total_score.append(i_total_score / (len(var_lis_163) + 20))
            else:
                i_total_score = self.dp.myEXPSCORE.WEIGHT_CONTAMINANT * i_con_score + \
                                self.dp.myEXPSCORE.WEIGHT_DELTART * list_score_deltaRT[i] + \
                                self.dp.myEXPSCORE.WEIGHT_RT_DEV * list_score_rt[i] + \
                                self.dp.myEXPSCORE.WEIGHT_MISSING_PRE * var_lis_54[0][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MEDIAN_INT_PRE * var_lis_54[1][i] + \
                                self.dp.myEXPSCORE.WEIGHT_IQR_PRE * var_lis_54[2][i] + \
                                self.dp.myEXPSCORE.WEIGHT_DEV_INT_PRE * var_lis_54[3][i] + \
                                self.dp.myEXPSCORE.WEIGHT_PEARSON_INT_PRE * var_lis_54[4][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MISSING_PEP * var_lis_39[0][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MEDIAN_INT_PEP * var_lis_39[1][i] + \
                                self.dp.myEXPSCORE.WEIGHT_IQR_PEP * var_lis_39[2][i] + \
                                self.dp.myEXPSCORE.WEIGHT_DEV_INT_PEP * var_lis_39[3][i] + \
                                self.dp.myEXPSCORE.WEIGHT_PEARSON_INT_PEP * var_lis_39[4][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MISSING_PRO * var_lis_34[0][i] + \
                                self.dp.myEXPSCORE.WEIGHT_MEDIAN_INT_PRO * var_lis_34[1][i] + \
                                self.dp.myEXPSCORE.WEIGHT_IQR_PRO * var_lis_34[2][i] + \
                                self.dp.myEXPSCORE.WEIGHT_DEV_INT_PRO * var_lis_34[3][i] + \
                                self.dp.myEXPSCORE.WEIGHT_PEARSON_INT_PRO * var_lis_34[4][i]
                total_score.append(i_total_score / (len(var_lis_163) + 17))

        var_lis_55 = [str(i) for i in total_score]
        var_lis_163 = self.var_sco_107
        list_score_deltaRT = [str(i) for i in list_score_deltaRT]
        list_score_rt = [str(i) for i in list_score_rt]
        var_lis_54 = [[str(j) for j in i] for i in var_lis_54]
        var_lis_39 = [[str(j) for j in i] for i in var_lis_39]
        var_lis_34 = [[str(j) for j in i] for i in var_lis_34]

        with open(out_path_list, 'w') as f:
            f.write('\t'.join(["Experiment"] + self.var_lis_82) + '\n')
            f.write('Total Score\t' + '\t'.join(var_lis_55)+ '\n')
            for i, tmp_con in enumerate(var_lis_163):
                list_str = [str(j) for j in var_lis_163[tmp_con]]
                f.write('SP{:d}. Contaminants{:d}-{:s}\t'.format(i + 1, i, tmp_con) + '\t'.join(list_str) + '\n')
            f.write('LC1. DeltaRT (predicted-measured)\t' + '\t'.join(list_score_deltaRT) + '\n')
            f.write('LC2. RT relative deviation\t' + '\t'.join(list_score_rt) + '\n')
            f.write('MS1. The number of identified precursors\t' + '\t'.join(var_lis_54[0]) + '\n')
            f.write('MS2. Median of precursor intensity\t' + '\t'.join(var_lis_54[1]) + '\n')
            f.write('MS3. IQR of precursor intensity\t' + '\t'.join(var_lis_54[2]) + '\n')
            f.write('MS4. Robust Dev of precursor intensity\t' + '\t'.join(var_lis_54[3]) + '\n')
            f.write('MS5. Pearson correlation of precursor intensity\t' + '\t'.join(var_lis_54[4]) + '\n')
            f.write('MS6. Normalization factor of precursor intensity\t' + '\t'.join(var_lis_54[5]) + '\n')
            f.write('MS7. The number of identified peptides\t' + '\t'.join(var_lis_39[0]) + '\n')
            f.write('MS8. Median of peptide intensity\t' + '\t'.join(var_lis_39[1]) + '\n')
            f.write('MS9. IQR of peptide intensity\t' + '\t'.join(var_lis_39[2]) + '\n')
            f.write('MS10. Robust Dev of peptide intensity\t' + '\t'.join(var_lis_39[3]) + '\n')
            f.write('MS11. Pearson correlation of peptide intensity\t' + '\t'.join(var_lis_39[4]) + '\n')
            f.write('MS12. Normalization factor of peptide intensity\t' + '\t'.join(var_lis_39[5]) + '\n')
            f.write('MS13. The number of identified proteins\t' + '\t'.join(var_lis_34[0]) + '\n')
            f.write('MS14. Median of protein intensity\t' + '\t'.join(var_lis_34[1]) + '\n')
            f.write('MS15. IQR of protein intensity\t' + '\t'.join(var_lis_34[2]) + '\n')
            f.write('MS16. Robust Dev of protein intensity\t' + '\t'.join(var_lis_34[3]) + '\n')
            f.write('MS17. Pearson correlation of protein intensity\t' + '\t'.join(var_lis_34[4]) + '\n')
            f.write('MS18. Normalization factor of protein intensity\t' + '\t'.join(var_lis_34[5]) + '\n')


    def __captainHeatMap(self, path, out_path, out_path_list):

        var_mat_135 = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)

        dpi = 100
        plt.figure(figsize=(10 + int(0.6 * n_experiment), 5 + int(1.7 * 7)), dpi=dpi)

        
        
        
        score_matrix = pd.read_csv(out_path_list, sep='\t', index_col=0)
        
        df = pd.DataFrame(score_matrix)
        
        h = sns.heatmap(score_matrix, square=True, annot=True, fmt='.1f', linewidths=1.5, linecolor='#000000', annot_kws={"size": 15}, cbar=False, cmap='RdYlGn', vmin=0, vmax=5)
        
        cb = h.figure.colorbar(h.collections[0])
        cb.ax.tick_params(labelsize=15)
        plt.tick_params(labelsize=15)
        plt.xticks(rotation=90)
        plt.yticks(rotation=0)
        plt.ylabel('')
        plt.tight_layout()
        
        bottom, top = h.get_ylim()
        h.set_ylim(bottom + 0.5, top - 0.5)

        plt.savefig(out_path + '.png', format='png')
        
        plt.close()


class CFunctionPlotE_25:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def __captainReadScore(self):

        score_all = []

        
        var_pat_65 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[56]
        var_pds_42 = pd.read_csv(var_pat_65, sep='\t', index_col=0)
        score_all = var_pds_42.values
        score_all = score_all[~np.isnan(score_all).any(axis=1)]

        
        
        
        
        
        
        
        
        
        
        
        
        
        return score_all

    def __captainWriteSummary(self, list_score, var_lis_82, list_label):

        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' +IO_FILENAME_EXPORT[67]

        list_label = ['Inliers' if abs(i-1) < 1e4 else 'outlier' for i in list_label]

        with open(path_out, 'w') as f:
            f.write('experiment\tscore\tlabel\n')
            for i in range(len(list_score)):
                f.write(str(var_lis_82[i]) + '\t' + str(list_score[i]) + '\t' + str(list_label[i]) + '\n')

    def __captainIsolationForest_score(self, list_score, threshold=-0.05):

        matrix_score = np.array(list_score).T
        clf = IsolationForest(max_samples=0.8, contamination=0.1)
        clf.fit(matrix_score)
        
        scores_pred = clf.decision_function(matrix_score)
        labels = [1 if i > threshold else -1 for i in scores_pred]

        scores_pred = list(scores_pred)
        list_labels = list(labels)

        return scores_pred, list_labels

    def __captainSVM_OneClass(self, list_score, threshold=-1):

        matrix_score = np.array(list_score).T
        
        clf = svm.OneClassSVM(nu=0.2, kernel="rbf", gamma=0.2)
        clf.fit(matrix_score)
        
        
        
        score = clf.decision_function(matrix_score)
        
        labels = np.array([1 if i > threshold else -1 for i in score])

        score_pred = list(score)
        list_labels = list(labels)

        return score_pred, list_labels

    def plot(self):

        list_score = self.__captainReadScore()
        var_lis_82 = self.dp.myProteinID.LIST_EXPERIMENT_ID

        if self.dp.myPLOT.TYPE_FILTER_OUTLIER == CFG_TYPE_OUTLIER['SVM']:
            var_lis_60, list_label = self.__captainSVM_OneClass(list_score,
                                                                      threshold=self.dp.myPLOT.THRESHOLD_OUTLIER_FILTER)
        elif self.dp.myPLOT.TYPE_FILTER_OUTLIER == CFG_TYPE_OUTLIER['IsolationForest']:
            var_lis_60, list_label = self.__captainIsolationForest_score(list_score,
                                                                               threshold=self.dp.myPLOT.THRESHOLD_OUTLIER_FILTER)

        self.__captainWriteSummary(var_lis_60, var_lis_82, list_label)

        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[70]
        plt.figure(figsize=(max(0.15 * len(var_lis_82),3), 6))
        x_range = list(range(len(var_lis_60)))
        normal_index = [i for i in range(len(list_label)) if list_label[i] > 0]
        wrong_index = [i for i in range(len(list_label)) if list_label[i] <= 0]
        var_xra_126 = [x_range[i] for i in normal_index]
        var_lis_7 = [var_lis_60[i] for i in normal_index]
        x_range_wrong = [x_range[i] for i in wrong_index]
        var_lis_92 = [var_lis_60[i] for i in wrong_index]
        plt.scatter(var_xra_126, var_lis_7, marker='v', color='g', label='normal')
        plt.scatter(x_range_wrong, var_lis_92, marker='x', color='r', label='outlier')
        for i, count in enumerate(x_range_wrong):
            plt.text(count, var_lis_92[i], var_lis_82[count], color='red', ha='center', va='bottom', fontsize=8)
        plt.xticks(x_range, var_lis_82, rotation=90)
        plt.tight_layout()
        plt.legend()
        plt.savefig(out_path + '.png', format='png')


class CFunctionPlotI_10:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self, flag, flag_norm):

        path, out_path = '', ''
        if flag == 0:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[4] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[18]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[1] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[4]
        elif flag == 1:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[14] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[23]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[11] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[22]

        elif flag == 2:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[20] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[34]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[17] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[33]

        var_mat_135 = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_dev = []
        if n_experiment <= 100:
            self.__captainPlot(flag_norm, path, out_path)
        else:
            self.__captainHeatMap(flag_norm, path, out_path)

    def plot_origin(self, flag, flag_norm):

        path, out_path = '', ''
        if flag == 0:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[23] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[64]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[22] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[63]
        elif flag == 1:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[25] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[66]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[24] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[65]

        elif flag == 2:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[27] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[68]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[26] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[67]

        var_mat_135 = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_dev = []
        if n_experiment <= 100:
            self.__captainPlot(flag_norm, path, out_path, flag_origin=1)
        else:
            self.__captainHeatMap(flag_norm, path, out_path, flag_origin=1)


    def __soliderDelMissingValue(self, var_lis_8: np.ndarray, var_lis_66: np.ndarray):

        var_fla_71 = var_lis_8 > 0.
        var_fla_110 = var_lis_66 > 0.
        flag_no_mv = var_fla_71 * var_fla_110
        var_lis_8 = var_lis_8[flag_no_mv]
        var_lis_66 = var_lis_66[flag_no_mv]

        return var_lis_8, var_lis_66

    def __captainPlot(self, flag_norm, path, out_path, flag_origin=0):

        var_mat_135 = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_dev = []
        dpi = 100 if n_experiment <= 20 else 50 if n_experiment <= 100 else 10
        fig = plt.figure(figsize=(3 + 3 * n_experiment, 3 + 3 * n_experiment), dpi=dpi)
        if flag_norm:
            plt.title('After Normalization')
        else:
            plt.title('Before Normalization')

        cmp1 = plt.cm.get_cmap('Blues_r')

        
        
        
        labelsize = 20 if n_experiment < 16 else 25 if n_experiment < 20 else 30
        ax = plt.subplot(n_experiment + 1, n_experiment + 1, 2)
        ylabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[0]
        plt.xticks([])
        plt.yticks([])
        plt.ylabel(ylabel + '  ' * len(ylabel) + '   ', fontsize=labelsize, rotation='horizontal', labelpad=5)
        ax.spines['top'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        ax = plt.subplot(n_experiment + 1, n_experiment + 1, (n_experiment + 1) * n_experiment)
        xlabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[n_experiment - 1]
        plt.xlabel(xlabel + ' ', fontsize=labelsize, rotation=90, labelpad=8)
        plt.xticks([])
        plt.yticks([])
        ax.spines['top'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(False)

        canvas = FigureCanvasAgg(fig)
        canvas.draw()
        buf = canvas.buffer_rgba()
        data_all = np.asarray(buf)
        del buf
        Image.MAX_IMAGE_PIXELS = int(1024 * 1024 * 1024 * 1024 * 1024 // 4 // 3)  
        count_subplot = 0
        var_thr_156 = 1000

        for i in range(n_experiment):

            if (count_subplot >= var_thr_156) or (i == n_experiment - 1):
                
                if n_experiment <= 100:
                    canvas = FigureCanvasAgg(fig)
                    canvas.draw()
                    buf = canvas.buffer_rgba()
                    data_i = np.asarray(buf)
                    data_all = 255 - ((255 - data_all) + (255 - data_i))  
                    
                    
                    del buf, data_i
                    plt.clf()  
                count_subplot = 0

            for j in range(i + 1, n_experiment):

                XArray = var_mat_135[:, i]
                YArray = var_mat_135[:, j]
                if flag_origin:
                    XArray, YArray = self.__soliderDelMissingValue(XArray, YArray)
                data = XArray - YArray
                var_per_52 = np.percentile(data, 15.87)
                var_per_41 = np.percentile(data, 84.13)
                dev = (var_per_41 - var_per_52) / 2

                str_dev = "%.3f" % dev
                list_dev.append(
                    [self.dp.myProteinID.LIST_EXPERIMENT_ID[i], self.dp.myProteinID.LIST_EXPERIMENT_ID[j], dev])

                plot_index = j * (n_experiment + 1) + i + 2  
                pear_index = i * (n_experiment + 1) + j + 2
                if n_experiment <= 100:
                    ax = plt.subplot(n_experiment + 1, n_experiment + 1, plot_index)
                    plt.grid(linestyle='--', color='grey')
                    data_violin = pd.DataFrame(data.T)
                    sns.violinplot(y=data_violin, linewidth=1, width=0.9, inter="box", palette=["gray"],
                                   color="skyblue")
                    plt.plot([-0.08, 0.08], [var_per_52, var_per_52], 'r')
                    plt.plot([-0.08, 0.08], [var_per_41, var_per_41], 'r')
                    plt.yticks([-2, -1, 0, 1, 2], ['-2', '-1', '0', '1', '2'])
                    plt.ylim(-2, 2)

                if i == 0:  
                    ylabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[j] if self.dp.myProteinID.LIST_EXPERIMENT_ID[j] else \
                        self.dp.myProteinID.LIST_SAMPLE_ID[j]
                    plt.ylabel(ylabel + '  ' * len(ylabel), fontsize=labelsize, rotation='horizontal', labelpad=5)
                if j == n_experiment - 1:
                    xlabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[i] if self.dp.myProteinID.LIST_EXPERIMENT_ID[i] else \
                        self.dp.myProteinID.LIST_SAMPLE_ID[i]
                    plt.xlabel(xlabel, fontsize=labelsize, rotation=90, labelpad=5)
                ax = plt.subplot(n_experiment + 1, n_experiment + 1, pear_index)
                plt.axis("equal")  
                plt.xticks([])
                plt.yticks([])
                if dev <= 0.3:
                    plt.text(0.1, 0.4, str_dev, size=40, color='#FFFFFF')
                else:
                    plt.text(0.1, 0.4, str_dev, size=40, )
                list_c = cmp1(dev, bytes=True)[:-1]

                list_hex_c = [str(hex(i))[2:] for i in list_c]
                list_hex_c = [i if len(i) == 2 else '0' + i for i in list_hex_c]
                str_c = '#' + ''.join(list_hex_c)
                ax.patch.set_facecolor(str_c)
                
                
                
                
                
                
                
                
                
                
                
        if n_experiment <= 100:
            matplotlib.image.imsave(out_path + '.png', data_all)
        else:
            plt.savefig(out_path + '.png', format='png')
            
        plt.close('all')

    def __captainHeatMap(self, flag_norm, path, out_path, flag_origin=0):

        var_mat_135 = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_dev = []
        dpi = 30
        fig = plt.figure(figsize=(3 + int(1.7 * n_experiment), 3 + int(1.5 * n_experiment)), dpi=dpi)
        if flag_norm:
            plt.title('After Normalization')
        else:
            plt.title('Before Normalization')

        cv_matrix = np.ones([n_experiment, n_experiment]) * -1
        for i in range(n_experiment):
            for j in range(0, i):
                XArray = var_mat_135[:, i]
                YArray = var_mat_135[:, j]
                if flag_origin:
                    XArray, YArray = self.__soliderDelMissingValue(XArray, YArray)
                data = XArray - YArray
                var_per_52 = np.percentile(data, 15.87)
                var_per_41 = np.percentile(data, 84.13)
                dev = (var_per_41 - var_per_52) / 2
                cv_matrix[i][j] = dev
        max_cv = np.max(cv_matrix)
        cv_matrix = pd.DataFrame(cv_matrix, columns=self.dp.myProteinID.LIST_EXPERIMENT_ID)
        cv_matrix.head()
        mask = np.zeros_like(cv_matrix, dtype=np.bool)
        
        mask[np.triu_indices_from(mask)] = True
        h = sns.heatmap(cv_matrix, mask=mask, annot=True, annot_kws={"size": 30}, cbar=False, cmap='RdBu', vmin=0, vmax=max(1,max_cv))
        cb = h.figure.colorbar(h.collections[0])
        cb.ax.tick_params(labelsize=n_experiment * 2)
        plt.tick_params(labelsize=33)
        
        bottom, top = h.get_ylim()
        h.set_ylim(bottom + 0.5, top - 0.5)

        plt.savefig(out_path + '.png', format='png')
        plt.close()


class CFunctionPlotI_29:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self, flag, flag_norm):

        if flag == 0:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[3] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[8]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[14]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[0] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[5]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[13]
        elif flag == 1:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[13] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[25]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[31]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[10] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[24]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[30]
        elif flag == 2:
            
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[19] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[36]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[46]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[16] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[35]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[45]

        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        if self.dp.myProteinID.LIST_EXPERIMENT_ID.count('') > 0:
            var_lis_82 = self.dp.myProteinID.LIST_SAMPLE_ID
        else:
            var_lis_82 = self.dp.myProteinID.LIST_EXPERIMENT_ID

        if n_experiment<20:
            fig = plt.figure(figsize=((2 + 1 * n_experiment), 6))
        else:
            fig = plt.figure(figsize=((2 + 0.3 * n_experiment), 6))

        sns.set(style='white')

        var_mat_135 = np.load(path)
        var_mat_14 = []
        for i in range(len(var_mat_135)):
            var_mat_14.append(np.log2(var_mat_135[i] / np.mean(var_mat_135[i])))
        var_mat_14 = np.array(var_mat_14)

        with open(out_path_txt, 'w')as f:

            f.write('SampleID\tmedian_value\t5% Percentile\t25% Percentile\t 75% Percentile\t 95% Percentile\n')
            for i_sample in range(n_experiment):
                i_Intensity_Violin = var_mat_14[:, i_sample: i_sample + 1]
                var_ime_70 = np.median(i_Intensity_Violin)
                var_ili_72 = np.percentile(i_Intensity_Violin, [5, 25, 75, 95])
                var_ist_145 = '\t'.join(
                    [str(var_ipe_137) for var_ipe_137 in var_ili_72])
                f.write(
                    str(var_lis_82[i_sample]) + '\t' + str(var_ime_70) + '\t' + var_ist_145 + '\n')

        plt.hlines(y=0, xmin=-0.5, xmax=n_experiment - 0.5, color='g', linestyles='-.', linewidth=2)

        Intensity_Violin = pd.DataFrame(var_mat_14.T, index=var_lis_82,
                                        columns=list(range(var_mat_14.shape[0])))
        Intensity_Violin = Intensity_Violin.stack()
        Intensity_Violin.index = Intensity_Violin.index.rename('Raws', level=0)
        Intensity_Violin.name = "Intensity"
        Intensity_Violin = Intensity_Violin.reset_index()
        
        
        sns.violinplot(x='Raws', y='Intensity', data=Intensity_Violin, linewidth=1, width=0.9, inter="box", palette="Blues")

        plt.ylim(self.dp.myPLOT.MIN_VIOLIN_SHOW, self.dp.myPLOT.MAX_VIOLIN_SHOW)
        plt.xlabel("Experiment", fontsize=20)
        plt.ylabel("Log2 (Intensity / mean(Intensity))", fontsize=20)
        plt.xticks(rotation=90, fontsize=18)
        plt.yticks(fontsize=15)

        fig.tight_layout()
        plt.savefig(out_path + '.png', format='png', dpi=100)
        
        plt.close('all')


class CFunctionPlotI_4:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self, flag_norm):

        n_experiment = len(self.dp.myProteinID.LIST_SAMPLE_ID)
        var_lis_82 = self.dp.myProteinID.LIST_EXPERIMENT_ID

        f, ax = plt.subplots(figsize=(12 + n_experiment // 10, 12))
        sns.set(context='paper', style='darkgrid', palette='deep', font='sans-serif', font_scale=3, color_codes=False,
                rc=None)
        cmap = sns.cubehelix_palette(dark=0, light=1, as_cmap=True)  
        y_tick = np.array(var_lis_82)
        x_tick = [''] * len(self.dp.myProteinID.LIST_PROTEIN_ID)  

        
        if flag_norm:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[4] + '.npy'
            out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[9]
            out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[16]
        else:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[1] + '.npy'
            out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[6]
            out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[15]

        var_mat_135 = np.load(path)

        Intensity_Hotmap_o = pd.DataFrame(var_mat_135 , columns=y_tick,
                                          index=x_tick)  
        Intensity_Hotmap = Intensity_Hotmap_o.apply(
            lambda x: (x - np.min(x)) / (np.max(x) - np.min(x)))  
        list_color = []

        str_title = "After Normalization" if flag_norm else "Before Normalization"
        plt.title("{:s}".format(str_title))
        
        
        
        
        var_dic_121 = {}
        var_dic_120 = {}
        for i in self.dp.LIST_EXPERIMENT:
            var_dic_120[i[0]] = i[1]
        for i, tmp_group in enumerate(self.dp.LIST_EXPERIMENT_GROUP):
            for j in tmp_group[1]:
                var_dic_121[var_dic_120[j]] = i
        
        
        list_raw = self.dp.myProteinID.LIST_EXPERIMENT_ID
        list_color = [PLOT_HEATMAP_COLOR[var_dic_121[i]] for i in list_raw]
        

        g = sns.clustermap(Intensity_Hotmap_o, standard_scale=1, method="ward", col_cluster=True,
                           cmap='rainbow', col_colors=list_color, colors_ratio=0.03,
                           xticklabels=1)  
        
        
        
        
        
        g.fig.set_size_inches(12 + n_experiment // 10, 12)
        bar = plt.gcf().axes[-1]
        bar.tick_params(labelsize=10)
        plt.xticks(rotation=90)

        ward_result = sch.linkage(Intensity_Hotmap, method='ward')
        cluster = sch.fcluster(ward_result, t=1, criterion='inconsistent')
        var_pro_132 = pd.DataFrame(index=x_tick, columns=None)

        var_pro_132["Class"] = cluster
        var_pro_132[y_tick] = Intensity_Hotmap

        var_add_20 = Intensity_Hotmap_o.mean(axis=1)
        var_pro_132["Mean_LOG2Intensity"] = var_add_20

        var_add_50 = Intensity_Hotmap.mean(axis=1)
        var_pro_132["MEAN_Normalized_Intensity"] = var_add_50
        var_pro_132.to_csv(out_path_txt, sep=',', index=1, header=1)

        plt.savefig(out_path + '.png', format='png')
        
        plt.close('all')


class CFunctionPlotI_12:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self, flag, flag_norm):

        if flag == 0:
            column = self.dp.myProteinID.PRO1_NAME
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[5] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[10]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[18]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[2] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[7]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[17]
        elif flag == 1:
            column = self.dp.myPeptideID.PEP1_SEQ
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[15] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[27]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[35]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[12] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[26]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[34]
        elif flag == 2:
            column = self.dp.myPrecursorID.PRE1_SEQ
            if flag_norm:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[21] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[38]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[50]
            else:
                path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[18] + '.npy'
                out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[37]
                out_path_txt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[49]

        n_group = len(self.dp.LIST_EXPERIMENT_GROUP) + 1
        list_group = [i[0] for i in self.dp.LIST_EXPERIMENT_GROUP] + ['ALL']
        plt.figure(figsize=(min(2 + n_group, 20), 6))
        sns.set(style='white')

        matrix_cv = np.load(path)

        Intensity_Violin = pd.DataFrame(matrix_cv.T, index=list_group, columns=column)
        Intensity_Violin = Intensity_Violin.stack()
        Intensity_Violin.index = Intensity_Violin.index.rename('Group', level=0)
        Intensity_Violin.name = "CV value"
        Intensity_Violin = Intensity_Violin.reset_index()

        list_cv_all = list(Intensity_Violin.values[:, 2])  
        var_lis_22 = [index for index in range(len(list_cv_all)) if list_cv_all[index] < 0.]
        Intensity_Violin.drop(var_lis_22)

        sns.boxplot(x='Group', y='CV value', data=Intensity_Violin, showfliers=False, showmeans=False, meanline=False,
                    meanprops={'marker': '^', 'fillstyle': 'none', 'markerfacecolor': '#FFFFFF', 'color': '#FFFFFF',
                               'markersize': 6},
                    linewidth=3, palette='Set1')
        ax = plt.gca()
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        
        
        plt.ylim(self.dp.myPLOT.MIN_CV_SHOW - 0.02, self.dp.myPLOT.MAX_CV_SHOW + 0.55)
        plt.xticks(rotation=90, fontsize=12)
        plt.yticks(fontsize=10)
        plt.xlabel('Group', fontsize=20)
        plt.ylabel('CV value', fontsize=20)
        plt.grid(linestyle="--", alpha=0.3)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=300)
        
        plt.clf()
        plt.close('all')

        list_median = list(np.median(matrix_cv, axis=0))
        list_Q1 = list(np.percentile(matrix_cv, q=25, axis=0))
        list_Q3 = list(np.percentile(matrix_cv, q=75, axis=0))

        with open(out_path_txt, 'w') as f:

            f.write('Group\t' + '\t'.join(list_group) + '\n')
            f.write('Median\t' + '\t'.join([str(i) for i in list_median]) + '\n')
            f.write('first quartile Q1\t' + '\t'.join([str(i) for i in list_Q1]) + '\n')
            f.write('third quartile Q3\t' + '\t'.join([str(i) for i in list_Q3]) + '\n')


class CFunctionPlotR_7:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def var_sol_45(self, x, y, ax, n_std=2.0, facecolor='none', **kwargs):

        if x.size != y.size:
            raise ValueError("x and y must be the same size")

        cov = np.cov(x, y)
        pearson = cov[0, 1]/np.sqrt(cov[0, 0] * cov[1, 1])
        
        
        ell_radius_x = np.sqrt(1 + pearson)
        ell_radius_y = np.sqrt(1 - pearson)
        ellipse = Ellipse((0, 0), width=ell_radius_x * 2, height=ell_radius_y * 2,
                          facecolor=facecolor, **kwargs)

        
        
        
        scale_x = np.sqrt(cov[0, 0]) * n_std
        mean_x = np.mean(x)

        
        scale_y = np.sqrt(cov[1, 1]) * n_std
        mean_y = np.mean(y)

        transf = transforms.Affine2D() \
            .rotate_deg(45) \
            .scale(scale_x, scale_y) \
            .translate(mean_x, mean_y)

        ellipse.set_transform(transf + ax.transData)
        return ax.add_patch(ellipse)

    def plotTSNE(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[37]
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[30]

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')
        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]
        list_pca = []
        for line in lines:
            line_list = line.split('\t')
            list_pca.append([float(i) for i in line_list[1:3]])
        var_Int_69 = np.array(list_pca)
        count = 0

        list_color = PLOT_GROUP_COLOR  
        fig, ax_kwargs = plt.subplots(figsize=(8, 8))
        plt.grid(linestyle='--', color='grey')

        for i in range(len(self.dp.LIST_EXPERIMENT_GROUP)):

            tmp_group = self.dp.LIST_EXPERIMENT_GROUP[i]
            if tmp_group[2].count('') > 0:
                tmp_list_exp = tmp_group[1]
            else:
                tmp_list_exp = tmp_group[2]

            x = var_Int_69[count: count + len(tmp_list_exp), 0]
            y = var_Int_69[count: count + len(tmp_list_exp), 1]
            count += len(tmp_list_exp)
            
            
            self.var_sol_45(x, y, ax_kwargs, alpha=0.25, facecolor=list_color[i % len(list_color)],
                                             edgecolor=list_color[i % len(list_color)], zorder=0)

            plt.scatter(x, y, s=160, linewidth=0.3, edgecolor='#000000', marker='.',
                        label=tmp_group[0], color=list_color[i % len(list_color)])

        plt.yticks(fontproperties='Times New Roman', weight='bold')  
        plt.xticks(fontproperties='Times New Roman', weight='bold')
        ax_kwargs.spines['right'].set_visible(False)
        ax_kwargs.spines['top'].set_visible(False)
        plt.rcParams.update({'font.size': 7.5})
        legend_font = {
            'family': 'Times New Roman',
            'weight': "bold",  
        }
        ax_kwargs.legend(frameon=False, prop=legend_font, loc=1)
        ax_kwargs.set_title('T-SNE')
        ax_kwargs.set_xlabel('Dim 1')
        ax_kwargs.set_ylabel('Dim 2')
        ax_kwargs.legend()
        fig.subplots_adjust(hspace=0.25)
        plt.tight_layout()
        plt.savefig(out_path + '.png', format='png', dpi=300)
        
        plt.close('all')

    def plotTSNE2(self, flag_norm=1):

        config = {
            "font.family": 'Times New Roman',  
            "font.size": 13,
            
        }
        rcParams.update(config)

        if flag_norm:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[37]
            out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[30]
        else:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[52]
            out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[40]

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')
        table_list = lines[0].split('\t')
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]
        list_pca = []
        var_lis_82 = []
        for line in lines:
            line_list = line.split('\t')
            var_lis_82.append(line_list[0])
            list_pca.append([float(i) for i in line_list[1:3]])
        var_Int_69 = np.array(list_pca)

        list_color = PLOT_GROUP_COLOR  
        fig, ax_kwargs = plt.subplots(figsize=(5, 5))
        

        for i in range(len(self.dp.LIST_EXPERIMENT_GROUP)):

            tmp_group = self.dp.LIST_EXPERIMENT_GROUP[i]
            if tmp_group[2].count('') > 0:
                tmp_list_exp = tmp_group[1]
            else:
                tmp_list_exp = tmp_group[2]
            list_index = [var_lis_82.index(i) for i in tmp_list_exp]

            x = var_Int_69[list_index, 0]
            y = var_Int_69[list_index, 1]

            
            
            self.var_sol_45(x, y, ax_kwargs, alpha=0.25, facecolor=list_color[i % len(list_color)],
                                             edgecolor=list_color[i % len(list_color)], zorder=0)

            plt.scatter(x, y, s=160, linewidth=0.3, edgecolor='#000000', marker='.',
                        label=tmp_group[0], color=list_color[i % len(list_color)])
        plt.yticks(fontproperties='Times New Roman', weight='bold')  
        plt.xticks(fontproperties='Times New Roman', weight='bold')
        plt.xlabel('Dimention 1', fontweight='bold')
        plt.ylabel('Dimention 2', fontweight='bold', labelpad=1)
        
        
        ax_kwargs.set_title('T-SNE Analysis')
        ax_kwargs.spines['right'].set_visible(False)
        ax_kwargs.spines['top'].set_visible(False)
        plt.rcParams.update({'font.size': 7.5})
        legend_font = {
            'family': 'Times New Roman',
            'weight': "bold",  
        }
        ax_kwargs.legend(frameon=False, prop=legend_font, loc=1)
        fig.subplots_adjust(hspace=0.25)
        plt.tight_layout()
        plt.savefig(out_path + '.png', format='png', dpi=300)
        
        plt.close('all')


    def plotPCA(self, flag_norm=1):

        config = {
            "font.family": 'Times New Roman',  
            "font.size": 13,
            
        }
        rcParams.update(config)

        if flag_norm:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[11]
            out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[11]
        else:
            path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[51]
            out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[39]

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')
        table_list = lines[0].split('\t')
        Ratio = [float(i.split('(')[1][:-1]) for i in table_list[1:]]
        lines = lines[1:-1] if lines[-1] == '' else lines[1:]
        list_pca = []
        var_lis_82 = []
        for line in lines:
            line_list = line.split('\t')
            var_lis_82.append(line_list[0])
            list_pca.append([float(i) for i in line_list[1:3]])
        var_Int_69 = np.array(list_pca)

        list_color = PLOT_GROUP_COLOR  
        fig, ax_kwargs = plt.subplots(figsize=(5, 5))
        

        for i in range(len(self.dp.LIST_EXPERIMENT_GROUP)):

            tmp_group = self.dp.LIST_EXPERIMENT_GROUP[i]
            if tmp_group[2].count('') > 0:
                tmp_list_exp = tmp_group[1]
            else:
                tmp_list_exp = tmp_group[2]
            list_index = [var_lis_82.index(i) for i in tmp_list_exp]

            x = var_Int_69[list_index, 0]
            y = var_Int_69[list_index, 1]
            
            
            self.var_sol_45(x, y, ax_kwargs, alpha=0.25, facecolor=list_color[i % len(list_color)],
                               edgecolor=list_color[i % len(list_color)], zorder=0)

            plt.scatter(x, y, s=160, linewidth=0.3, edgecolor='#000000', marker='.',
                        label=tmp_group[0], color=list_color[i % len(list_color)])
        ax_kwargs.set_title('Principal Component Analysis')
        ax_kwargs.set_xlabel('PC 1({:.1f}%)'.format(Ratio[0] * 100))
        ax_kwargs.set_ylabel('PC 2({:.1f}%)'.format(Ratio[1] * 100))

        plt.yticks(fontproperties='Times New Roman', weight='bold')  
        plt.xticks(fontproperties='Times New Roman', weight='bold')
        plt.ticklabel_format(style='sci', scilimits=(0, 0))
        ax_kwargs.spines['right'].set_visible(False)
        ax_kwargs.spines['top'].set_visible(False)
        plt.rcParams.update({'font.size': 7.5})
        legend_font = {
            'family': 'Times New Roman',
            'weight': "bold",  
        }
        ax_kwargs.legend(frameon=False, prop=legend_font, loc=1)
        fig.subplots_adjust(hspace=0.25)
        plt.tight_layout()
        plt.savefig(out_path + '.png', format='png', dpi=300)
        
        plt.close('all')


class CFunctionPlotR_18:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self):
        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[6] + '.npy'
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[14]
        var_out_146 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[15]

        matrix_rt = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_pearson = []

        if n_experiment <= 100:
            self.__captainPlot(path, out_path)
        else:
            self.__captainHeatMap(path, out_path)

        fig = plt.figure(figsize=(10, 4))
        plt.subplot(1, 2, 1)

        list_index_rt = list(range(matrix_rt.shape[1]))
        list_index_rt = list(itertools.combinations(list_index_rt, 2))
        var_lis_83 = [i[0] for i in list_index_rt]
        var_lis_9 = [i[1] for i in list_index_rt]
        var_mat_62 = matrix_rt[:, var_lis_83] - matrix_rt[:, var_lis_9]
        var_lis_152 = list([float(i) for i in var_mat_62.reshape(-1, )])
        var_mat_1 = matrix_rt[:, var_lis_83]
        list_rt = list(np.array(var_mat_1).reshape(-1, ))

        min_rt_dev = self.dp.myPLOT.MIN_RT_DEVIATION
        max_rt_dev = self.dp.myPLOT.MAX_RT_DEVIATION
        lambda_range = lambda x: x if min_rt_dev <= x <= max_rt_dev else min_rt_dev if x < min_rt_dev else max_rt_dev
        var_lis_32 = [lambda_range(i) for i in var_lis_152]
        plt.hist(var_lis_32, bins=50, edgecolor='#000000', log=False)
        plt.xlabel("RT Deviation(min)")
        plt.ylabel("Count")
        plt.title("RT Deviation Distribution")
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')

        plt.subplot(1, 2, 2)
        plt.scatter(list_rt, var_lis_152, s=0.6, alpha=0.2)
        plt.xlabel("RT (min)")
        plt.ylabel("RT Deviation (min)")
        plt.title("Relationship between RT Deviation and RT")
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')

        plt.savefig(var_out_146 + '.png', format='png', dpi=300)
        
        plt.close('all')


    def __captainPlot(self, path, out_path):

        matrix_rt = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_pearson = []
        dpi = 300
        fig = plt.figure(figsize=(3 + 3 * n_experiment, 3 + 3 * n_experiment), dpi=dpi)
        
        labelsize = 30 if n_experiment < 16 else 35 if n_experiment < 20 else 40
        labelsize += 5
        ax = plt.subplot(n_experiment + 1, n_experiment + 1, 2)
        ylabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[0]
        plt.xticks([])
        plt.yticks([])
        plt.ylabel(ylabel + '  ' * len(ylabel) + '   ', fontsize=labelsize, rotation='horizontal', labelpad=5)
        ax.spines['top'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        ax = plt.subplot(n_experiment + 1, n_experiment + 1, (n_experiment + 1) * n_experiment)
        xlabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[n_experiment - 1]
        plt.xlabel(xlabel + ' ', fontsize=labelsize, rotation=90, labelpad=8)
        plt.xticks([])
        plt.yticks([])
        ax.spines['top'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(False)

        canvas = FigureCanvasAgg(fig)
        canvas.draw()
        buf = canvas.buffer_rgba()
        data_all = np.asarray(buf)
        del buf
        Image.MAX_IMAGE_PIXELS = int(1024 * 1024 * 1024 * 1024 * 1024 // 4 // 3)  
        count_subplot = 0
        var_thr_156 = 1000

        for i in range(n_experiment):

            if (count_subplot >= var_thr_156) or (i == n_experiment - 1):
                
                canvas = FigureCanvasAgg(fig)
                canvas.draw()
                buf = canvas.buffer_rgba()
                data_i = np.asarray(buf)
                data_all = 255 - ((255 - data_all) + (255 - data_i))  
                
                
                del buf, data_i
                plt.clf()  
                count_subplot = 0

            for j in range(i + 1, n_experiment):

                XArray = matrix_rt[:, i]
                YArray = matrix_rt[:, j]
                Y = XArray - YArray
                slope, pearson = toolLinearRegression(XArray, YArray)

                str_pearson = "%.3f" % pearson
                list_pearson.append(
                    [self.dp.myProteinID.LIST_EXPERIMENT_ID[i], self.dp.myProteinID.LIST_EXPERIMENT_ID[j], pearson])

                plot_index = j * (n_experiment + 1) + i + 2  
                pear_index = i * (n_experiment + 1) + j + 2
                ax = plt.subplot(n_experiment + 1, n_experiment + 1, plot_index)
                plt.axis("equal")  
                plt.plot(XArray, Y, "ro", color="steelblue", markersize=2)
                plt.axhline(y=0, color="g", linestyle="dashed",linewidth=3)
                if i == 0:  
                    ylabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[j] if self.dp.myProteinID.LIST_EXPERIMENT_ID[j] else \
                        self.dp.myProteinID.LIST_SAMPLE_ID[j]
                    plt.ylabel(ylabel + '  ' * len(ylabel), fontsize=labelsize, rotation='horizontal', labelpad=5)
                if j == n_experiment - 1:
                    xlabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[i] if self.dp.myProteinID.LIST_EXPERIMENT_ID[i] else \
                        self.dp.myProteinID.LIST_SAMPLE_ID[i]
                    plt.xlabel(xlabel, fontsize=labelsize, rotation=90, labelpad=5)
                ax = plt.subplot(n_experiment + 1, n_experiment + 1, pear_index)
                plt.axis("equal")  
                plt.xticks([])
                plt.yticks([])
                plt.text(0.1, 0.4, str_pearson, size=40)
                
                
                
                
                
                
                
                
                
                
                
        matplotlib.image.imsave(out_path + '.png', data_all)
        
        
        plt.close('all')



    def __captainHeatMap(self, path, out_path):

        matrix_rt = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_dev = []
        dpi = 30
        fig = plt.figure(figsize=(3 + int(1.7 * n_experiment), 3 + int(1.5 * n_experiment)), dpi=dpi)

        df = pd.DataFrame(matrix_rt, columns=self.dp.myProteinID.LIST_EXPERIMENT_ID)
        corr_matrix = df.corr(method='pearson')
        corr_matrix.head()
        mask = np.zeros_like(corr_matrix, dtype=np.bool)
        
        mask[np.triu_indices_from(mask)] = True
        h = sns.heatmap(corr_matrix, mask=mask, annot=True, annot_kws={"size": 30}, cbar=False, cmap='PuOr', vmin=-1, vmax=1)
        cb = h.figure.colorbar(h.collections[0])
        cb.ax.tick_params(labelsize=n_experiment * 2)
        plt.tick_params(labelsize=33)
        
        bottom, top = h.get_ylim()
        h.set_ylim(bottom + 0.5, top - 0.5)
        plt.savefig(out_path + '.png', format='png')
        plt.close()


class CFunctionPlotR_30:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self):
        
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[6] + '.npy'
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[14]
        var_out_146 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[15]

        matrix_rt = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_pearson = []

        if n_experiment <= 100:
            self.__captainPlot(path, out_path)
        else:
            self.__captainPlotMSE(path, out_path)

    def __captainPlot(self, path, out_path):

        matrix_rt = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)
        list_pearson = []
        dpi = 300
        fig = plt.figure(figsize=(3 + 3 * n_experiment, 3 + 3 * n_experiment), dpi=dpi)
        
        labelsize = 30 if n_experiment < 16 else 35 if n_experiment < 20 else 40
        labelsize += 5
        ax = plt.subplot(n_experiment + 1, n_experiment + 1, 2)
        ylabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[0]
        plt.xticks([])
        plt.yticks([])
        plt.ylabel(ylabel + '  ' * len(ylabel) + '   ', fontsize=labelsize, rotation='horizontal', labelpad=5)
        ax.spines['top'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(False)
        
        ax = plt.subplot(n_experiment + 1, n_experiment + 1, (n_experiment + 1) * n_experiment)
        xlabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[n_experiment - 1]
        plt.xlabel(xlabel + ' ', fontsize=labelsize, rotation=90, labelpad=8)
        plt.xticks([])
        plt.yticks([])
        ax.spines['top'].set_visible(False)
        ax.spines['bottom'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(False)

        canvas = FigureCanvasAgg(fig)
        canvas.draw()
        buf = canvas.buffer_rgba()
        data_all = np.asarray(buf)
        del buf
        Image.MAX_IMAGE_PIXELS = int(1024 * 1024 * 1024 * 1024 * 1024 // 4 // 3)  
        count_subplot = 0
        var_thr_156 = 1000

        for i in range(n_experiment):

            if (count_subplot >= var_thr_156) or (i == n_experiment - 1):
                
                canvas = FigureCanvasAgg(fig)
                canvas.draw()
                buf = canvas.buffer_rgba()
                data_i = np.asarray(buf)
                data_all = 255 - ((255 - data_all) + (255 - data_i))  
                
                
                del buf, data_i
                plt.clf()  
                count_subplot = 0

            for j in range(i + 1, n_experiment):

                XArray = matrix_rt[:, i]
                YArray = matrix_rt[:, j]
                Y = XArray - YArray
                slope, pearson = toolLinearRegression(XArray, YArray)
                MSE = np.nanmean((XArray - YArray)**2)

                str_MSE = "%.3f" % MSE
                list_pearson.append(
                    [self.dp.myProteinID.LIST_EXPERIMENT_ID[i], self.dp.myProteinID.LIST_EXPERIMENT_ID[j], MSE])

                plot_index = j * (n_experiment + 1) + i + 2  
                pear_index = i * (n_experiment + 1) + j + 2
                ax = plt.subplot(n_experiment + 1, n_experiment + 1, plot_index)
                plt.axis("equal")  
                plt.plot(XArray, Y, "ro", color="steelblue", markersize=2)
                plt.axhline(y=0, color="g", linestyle="dashed",linewidth=3)
                if i == 0:  
                    ylabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[j] if self.dp.myProteinID.LIST_EXPERIMENT_ID[j] else \
                        self.dp.myProteinID.LIST_SAMPLE_ID[j]
                    plt.ylabel(ylabel + '  ' * len(ylabel), fontsize=labelsize, rotation='horizontal', labelpad=5)
                if j == n_experiment - 1:
                    xlabel = self.dp.myProteinID.LIST_EXPERIMENT_ID[i] if self.dp.myProteinID.LIST_EXPERIMENT_ID[i] else \
                        self.dp.myProteinID.LIST_SAMPLE_ID[i]
                    plt.xlabel(xlabel, fontsize=labelsize, rotation=90, labelpad=5)
                ax = plt.subplot(n_experiment + 1, n_experiment + 1, pear_index)
                plt.axis("equal")  
                plt.xticks([])
                plt.yticks([])
                plt.text(0.1, 0.4, str_MSE, size=40)
                
                
                
                
                
                
                
                
                
                
                
        matplotlib.image.imsave(out_path + '.png', data_all)
        
        
        plt.close('all')

    def __captainPlotMSE(self, path, out_path):

        matrix_rt = np.load(path)
        n_experiment = len(self.dp.myProteinID.LIST_EXPERIMENT_ID)

        fig = plt.figure(figsize=(2 + 0.3 * n_experiment, 6))

        list_MSE = []
        matrix_RT_Rev = []

        for i in range(matrix_rt.shape[1]):
            matrix_RT_Rev.append(matrix_rt[:, 0] - matrix_rt[:, i])
        matrix_RT_Rev = np.array(matrix_RT_Rev)

        
        
        
        
        
        

        plt.hlines(y=0, xmin=-0.5, xmax=n_experiment - 0.5, color='r', linestyles='-.', linewidth=0.5)
        RT_violin = pd.DataFrame(matrix_RT_Rev.T,columns=self.dp.myProteinID.LIST_EXPERIMENT_ID)

        sns.violinplot(data=RT_violin, linewidth=1, width=0.9, inter="box",palette="Blues")
        plt.xlabel("Experiment", fontsize=15)
        plt.ylabel("RT relative dev", fontsize=15)
        plt.xticks(rotation=90, fontsize=12)
        plt.yticks(fontsize=10)

        fig.tight_layout()

        plt.savefig(out_path + '.png', format='png')
        
        plt.close('all')


class CFunctionPlotI_2:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[19]
        out_path_rt = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[12]
        out_path_int = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[13]
        var_out_164 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[28]

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        index_rt = lines.index('RT')
        var_ind_88 = lines.index('Intensity')
        
        lines_rt = lines[index_rt + 1: var_ind_88]
        lines_int = lines[var_ind_88 + 1: ]
        
        

        if self.dp.myProteinID.LIST_EXPERIMENT_ID.count('') > 0:
            var_lis_82 = self.dp.myProteinID.LIST_SAMPLE_ID
        else:
            var_lis_82 = self.dp.myProteinID.LIST_EXPERIMENT_ID

        var_yrt_166 = []
        y_rt_list = []
        var_yin_131 = []
        y_int_list = []
        
        
        x_index = list(range(len(var_lis_82)))

        for line in lines_rt[1:]:
            line = line.strip()
            if line:
                var_yrt_166.append(line.split('\t')[0])
                y_rt_list.append([float(i) for i in line.split('\t')[1:]])

        for line in lines_int[1:]:
            line = line.strip()
            if line:
                var_yin_131.append(line.split('\t')[0])
                y_int_list.append([float(i) for i in line.split('\t')[1:]])

        
        
        
        
        

        plt.figure(figsize=(max(10 + 0.3*len(var_lis_82), 12), 6))
        sns.set(context='paper', style='darkgrid', palette='deep', font='sans-serif', font_scale=1, color_codes=False,
                rc=None)
        ax = plt.gca()
        
        
        

        for i_pre in range(len(var_yrt_166)):
            flag_label = 0
            for i_exp in range(len(x_index) - 1):
                if y_rt_list[i_pre][i_exp] != VALUE_ILLEGAL and y_rt_list[i_pre][i_exp+1] != VALUE_ILLEGAL:
                    if not flag_label:
                        plt.plot([i_exp, i_exp+1], [y_rt_list[i_pre][i_exp], y_rt_list[i_pre][i_exp+1]],
                                 marker='o', color=CFG_IRT_COLOR[i_pre], label=var_yrt_166[i_pre])
                        flag_label = 1
                    else:
                        plt.plot([i_exp, i_exp + 1], [y_rt_list[i_pre][i_exp], y_rt_list[i_pre][i_exp + 1]],
                                 marker='o', color=CFG_IRT_COLOR[i_pre])
                elif y_rt_list[i_pre][i_exp] != VALUE_ILLEGAL:
                    if not flag_label:
                        plt.scatter([i_exp], [y_rt_list[i_pre][i_exp]],
                                 marker='o', color=CFG_IRT_COLOR[i_pre], label=var_yrt_166[i_pre])
                        flag_label = 1
                    else:
                        plt.scatter([i_exp], [y_rt_list[i_pre][i_exp]],
                                 marker='o', color=CFG_IRT_COLOR[i_pre])
        if self.dp.myIDForIRT.N_PRECURSOR > 0:  
            plt.legend(bbox_to_anchor=(1.05, 0), loc=3, borderaxespad=0)
        plt.xticks(x_index, var_lis_82, rotation=90)
        plt.xlabel('Experiment')
        plt.ylabel('Retention Time')
        plt.tight_layout()
        
        plt.savefig(out_path_rt + '.png', format='png', dpi=300)
        
        plt.close('all')


        fig = plt.figure(figsize=(max(10 + 0.5*len(var_lis_82), 12), 6))
        sns.set(context='paper', style='darkgrid', palette='deep', font='sans-serif', font_scale=1, color_codes=False,
                rc=None)
        ax = plt.gca()
        
        

        for i_pre in range(len(var_yrt_166)):
            flag_label = 0
            for i_exp in range(len(x_index) - 1):
                if y_int_list[i_pre][i_exp] != 0 and y_int_list[i_pre][i_exp + 1] != 0:
                    if not flag_label:
                        plt.plot([i_exp, i_exp + 1], [y_int_list[i_pre][i_exp], y_int_list[i_pre][i_exp + 1]],
                                 marker='o', color=CFG_IRT_COLOR[i_pre], label=var_yrt_166[i_pre])
                        flag_label = 1
                    else:
                        plt.plot([i_exp, i_exp + 1], [y_int_list[i_pre][i_exp], y_int_list[i_pre][i_exp + 1]],
                                 marker='o', color=CFG_IRT_COLOR[i_pre])
                elif y_int_list[i_pre][i_exp] != 0:
                    if not flag_label:
                        plt.scatter([i_exp], [y_int_list[i_pre][i_exp]],
                                 marker='o', color=CFG_IRT_COLOR[i_pre], label=var_yrt_166[i_pre])
                        flag_label = 1
                    else:
                        plt.scatter([i_exp], [y_int_list[i_pre][i_exp]], marker='o', color=CFG_IRT_COLOR[i_pre])
        if self.dp.myIDForIRT.N_PRECURSOR > 0:  
            plt.legend(bbox_to_anchor=(1.05, 0), loc=3, borderaxespad=0)
        plt.xticks(x_index, var_lis_82, rotation=90)
        plt.xlabel('Experiment')
        plt.ylabel('Intensity')
        min_y_lim, max_y_lim = plt.ylim()
        plt.ylim(min_y_lim, max_y_lim * 1.15)
        plt.tight_layout()
        
        plt.savefig(out_path_int + '.png', format='png', dpi=300)
        
        plt.close('all')

        fig = plt.figure(figsize=(12 + len(self.dp.myProteinID.LIST_EXPERIMENT_ID) * 0.1, 5))
        sns.set(context='paper', style='darkgrid', palette='deep', font='sans-serif', font_scale=1, color_codes=False,
                rc=None)
        ax = plt.gca()
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        


class CFunctionPlotI_14:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def plot(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[7]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IOFILENAME_IRT_EXPORT[0]

        with open(path, 'rb')as f:
            inputList = pickle.load(f)

        ListEvidence, ListSeed, listIndex = inputList[0], inputList[1], inputList[2]

        
        plt.figure(figsize=(15, 7))

        gs = GridSpec(15, 14)
        var_tex_93 = 'Base Peak:'
        var_tex_67 = 'Sequence:'
        var_tex_153 = 'Raw File:'
        var_tex_3 = 'Charge:'
        var_tex_151 = 'Modification:'
        var_tex_76 = 'Mid Scan:'

        for i in range(len(listIndex)):

            i_pre, i_raw = listIndex[i][0], listIndex[i][1]
            tmp_precursorID = self.dp.myIDForIRT.LIST_PRECURSOR_ID[i_pre]
            tmp_seq = self.dp.myIDForIRT.PRE1_SEQ[i_pre]
            tmp_mod = self.dp.myIDForIRT.PRE2_MOD[i_pre]
            tmp_charge = self.dp.myIDForIRT.PRE3_CHARGE[i_pre]
            tmp_raw = self.dp.myIDForIRT.LIST_EXPERIMENT_ID[i_raw]
            tmp_leftRT = self.dp.myIDForIRT.PRELIST3_RT_START[i_pre][i_raw]
            tmp_rightRT = self.dp.myIDForIRT.PRELIST4_RT_END[i_pre][i_raw]
            tmp_midScan = ListSeed[i].MID_SCAN
            tmp_listIsotopeMoz = ListSeed[i].DIS_ISO_MOZ_CLC
            tmp_listRT = ListEvidence[i].LIST_RET_TIME
            var_tmp_98 = ListEvidence[i].MATRIX_PROFILE
            tmp_nIsotope = len(tmp_listIsotopeMoz)

            
            
            
            
            x_list = [i / 60 for i in tmp_listRT]
            
            
            
            
            
            
            var_bas_105 = np.max(var_tmp_98)
            var_mat_138 = var_tmp_98 / max(var_bas_105, 1)

            ax = plt.subplot(gs[3:6, 0:])

            var_tex_2 = tmp_raw
            var_len_123 = len(var_tex_2)
            var_tex_117 = tmp_midScan

            plt.xlim((0, 200))
            plt.ylim((0, 10))
            plt.xticks([])
            plt.yticks([])
            plt.text(2, 5, var_tex_153, fontdict={'size': 10, 'color': 'black'})
            plt.text(14, 5, var_tex_2, fontdict={'size': 10, 'color': 'red'})
            plt.text(42 - 5 + var_len_123, 5, var_tex_76, fontdict={'size': 10, 'color': 'black'})
            plt.text(55 - 5 + var_len_123, 5, var_tex_117, fontdict={'size': 10, 'color': 'red'})

            plt.axis('off')

            ax2 = plt.subplot(gs[6:, 0:])
            for i in range(tmp_nIsotope):
                plt.plot([], [], label=format(tmp_listIsotopeMoz[i], '.2f')+'m/z', color=PLOT_PRECURSOR_COLOR[i],)
                
            plt.legend(loc=3, frameon=False, bbox_to_anchor=(0.85, 1.1), borderaxespad=0)

            for i in range(tmp_nIsotope - 1, -1, -1):
                x_list = [i / 60 for i in tmp_listRT]
                
                
                y_list = var_mat_138[i]
                
                
                plt.plot(x_list, y_list, color=PLOT_PRECURSOR_COLOR[i], alpha=0.75, linewidth=1.5)

            
            
            if tmp_leftRT != VALUE_ILLEGAL and tmp_rightRT != VALUE_ILLEGAL:
                rt_start = tmp_leftRT
                rt_end = tmp_rightRT
                plt.plot([rt_start, rt_start], [0.0, 0.1], color='#FF0000', linestyle='--')
                plt.plot([rt_end, rt_end], [0.0, 0.1], color='#FF0000', linestyle='--')

            plt.yticks([0, 0.5, 1], ['0%', '50%', '100%'])
            plt.ylim(0., 1.)
            x_limit = [min(tmp_listRT) / 60,
                       max(tmp_listRT) / 60]
            plt.xlim(x_limit)
            plt.xlabel('RT(minute)')
            plt.ylabel('Intensity (%)')
            ax2.spines['top'].set_visible(False)
            ax2.spines['right'].set_visible(False)

            ax = plt.subplot(gs[0:3, 0:])
            var_tex_15 = format(var_bas_105, '.2e')
            var_tex_90 = tmp_seq
            var_tex_31 = str(int(tmp_charge))
            var_tex_12 = tmp_mod

            if len(var_tex_12) == 0:
                var_tex_12 = 'None'
            plt.xlim((0, 200))
            plt.ylim((0, 10))
            plt.axis('off')
            plt.xticks([])
            plt.yticks([])
            plt.text(2, 5, var_tex_93, fontdict={'size': 10, 'color': 'black'})
            plt.text(16, 5, var_tex_15, fontdict={'size': 10, 'color': 'red'})
            plt.text(2, 0, var_tex_67, fontdict={'size': 10, 'color': 'black'})
            plt.text(14, 0, var_tex_90, fontdict={'size': 10, 'color': 'red'})
            plt.text(38, 5, var_tex_3, fontdict={'size': 10, 'color': 'black'})
            plt.text(49, 5, var_tex_31, fontdict={'size': 10, 'color': 'red'})
            plt.text(42 - 5 + var_len_123, 0, var_tex_151, fontdict={'size': 10, 'color': 'black'})
            plt.text(57 - 5 + var_len_123, 0, var_tex_12, fontdict={'size': 10, 'color': 'red'})

            plt.savefig(path_out + '\\' + tmp_raw + '\\' + 'XIC_' + tmp_precursorID + '.png', format='png')
            
            plt.clf()
        plt.close('all')

    def plotForIRTOnly(self, inputMaxRT: float):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[7]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IOFILENAME_IRT_EXPORT[0]

        with open(path, 'rb')as f:
            inputList = pickle.load(f)

        ListEvidence, ListSeed, listIndex = inputList[0], inputList[1], inputList[2]

        
        plt.figure(figsize=(inputMaxRT * 2.5, 7))

        gs = GridSpec(15, 14)
        var_tex_93 = 'Base Peak:'
        var_tex_67 = 'Sequence:'
        var_tex_153 = 'Raw File:'
        var_tex_3 = 'Charge:'
        var_tex_151 = 'Modification:'
        var_tex_76 = 'Mid Scan:'

        for i in range(len(listIndex)):

            i_pre, i_raw = listIndex[i][0], listIndex[i][1]
            tmp_precursorID = self.dp.myIDForIRT.LIST_PRECURSOR_ID[i_pre]
            tmp_seq = self.dp.myIDForIRT.PRE1_SEQ[i_pre]
            tmp_mod = self.dp.myIDForIRT.PRE2_MOD[i_pre]
            tmp_charge = self.dp.myIDForIRT.PRE3_CHARGE[i_pre]
            tmp_raw = self.dp.myIDForIRT.LIST_EXPERIMENT_ID[i_raw]
            tmp_leftRT = self.dp.myIDForIRT.PRELIST3_RT_START[i_pre][i_raw]
            tmp_rightRT = self.dp.myIDForIRT.PRELIST4_RT_END[i_pre][i_raw]
            tmp_midScan = ListSeed[i].MID_SCAN
            tmp_listIsotopeMoz = ListSeed[i].DIS_ISO_MOZ_CLC
            tmp_listRT = ListEvidence[i].LIST_RET_TIME
            var_tmp_98 = ListEvidence[i].MATRIX_PROFILE
            tmp_nIsotope = len(tmp_listIsotopeMoz)

            
            
            
            
            x_list = [i / 60 for i in tmp_listRT]
            
            
            
            
            
            
            var_bas_105 = np.max(var_tmp_98)
            var_mat_138 = var_tmp_98 / max(var_bas_105, 1)

            ax = plt.subplot(gs[3:6, 0:])

            var_tex_2 = tmp_raw
            var_len_123 = len(var_tex_2)
            var_tex_117 = tmp_midScan

            plt.xlim((0, 200))
            plt.ylim((0, 10))
            plt.xticks([])
            plt.yticks([])
            plt.text(2, 5, var_tex_153, fontdict={'size': 10, 'color': 'black'})
            plt.text(14, 5, var_tex_2, fontdict={'size': 10, 'color': 'red'})
            plt.text(42 - 5 + var_len_123, 5, var_tex_76, fontdict={'size': 10, 'color': 'black'})
            plt.text(55 - 5 + var_len_123, 5, var_tex_117, fontdict={'size': 10, 'color': 'red'})

            plt.axis('off')

            ax2 = plt.subplot(gs[6:, 0:])
            for i in range(tmp_nIsotope):
                plt.plot([], [], label=format(tmp_listIsotopeMoz[i], '.2f') + 'm/z', color=PLOT_PRECURSOR_COLOR[i], )
                
            plt.legend(loc=3, frameon=False, bbox_to_anchor=(0.85, 1.1), borderaxespad=0)

            for i in range(tmp_nIsotope - 1, -1, -1):
                x_list = [i / 60 for i in tmp_listRT]
                
                
                y_list = var_mat_138[i]
                
                
                plt.plot(x_list, y_list, color=PLOT_PRECURSOR_COLOR[i], alpha=0.75, linewidth=1.5)

            
            
            if tmp_leftRT != VALUE_ILLEGAL and tmp_rightRT != VALUE_ILLEGAL:
                rt_start = tmp_leftRT
                rt_end = tmp_rightRT
                plt.plot([rt_start, rt_start], [0.0, 0.3], color='#FF0000', linestyle='--',linewidth=1.5)
                plt.plot([rt_end, rt_end], [0.0, 0.3], color='#FF0000', linestyle='--',linewidth=1.5)

            plt.yticks([0, 0.5, 1], ['0%', '50%', '100%'])
            plt.ylim(0., 1.)
            x_limit = [min(tmp_listRT) / 60,
                       max(tmp_listRT) / 60]
            plt.xlim(x_limit)
            x_ticks = np.arange(0, math.ceil(max(tmp_listRT)/ 60.), 1)
            plt.xticks(x_ticks)
            plt.xlabel('RT(minute)')
            plt.ylabel('Intensity (%)')
            ax2.spines['top'].set_visible(False)
            ax2.spines['right'].set_visible(False)

            ax = plt.subplot(gs[0:3, 0:])
            var_tex_15 = format(var_bas_105, '.2e')
            var_tex_90 = tmp_seq
            var_tex_31 = str(int(tmp_charge))
            var_tex_12 = tmp_mod

            if len(var_tex_12) == 0:
                var_tex_12 = 'None'
            plt.xlim((0, 200))
            plt.ylim((0, 10))
            plt.axis('off')
            plt.xticks([])
            plt.yticks([])
            plt.text(2, 5, var_tex_93, fontdict={'size': 10, 'color': 'black'})
            plt.text(16, 5, var_tex_15, fontdict={'size': 10, 'color': 'red'})
            plt.text(2, 0, var_tex_67, fontdict={'size': 10, 'color': 'black'})
            plt.text(14, 0, var_tex_90, fontdict={'size': 10, 'color': 'red'})
            plt.text(38, 5, var_tex_3, fontdict={'size': 10, 'color': 'black'})
            plt.text(49, 5, var_tex_31, fontdict={'size': 10, 'color': 'red'})
            plt.text(42 - 5 + var_len_123, 0, var_tex_151, fontdict={'size': 10, 'color': 'black'})
            plt.text(57 - 5 + var_len_123, 0, var_tex_12, fontdict={'size': 10, 'color': 'red'})

            plt.savefig(path_out + '\\' + tmp_raw + '\\' + 'XIC_' + tmp_precursorID + '.png', format='png')
            
            plt.clf()
        plt.close('all')

class CFunctionPlotI_1:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def __soliderMod2Dict(self, inputMod: str):

        
        
        if not inputMod:
            return {}

        dic_Mod = {}
        list_mod = inputMod.split(';')

        for i in list_mod:
            i_mod_info = i.split(',')
            i_site, i_mod = i_mod_info[0], i_mod_info[1]
            if i_site not in dic_Mod:
                dic_Mod[i_site] = [i_mod]
            else:
                dic_Mod[i_site].append(i_mod)

        return dic_Mod

    def __GetPlotPepText(self, clc_pep, mod_dic: dict):
        
        pep_text = ''
        pep_mod_text = ''
        for pep_index in range(len(clc_pep)):
            if pep_index < (len(clc_pep) - 1):
                if pep_index + 1 in mod_dic.keys():
                    pep_text = pep_text + ' ' + ' | '
                    pep_mod_text = pep_mod_text + clc_pep[pep_index] + '   '
                else:
                    pep_text = pep_text + clc_pep[pep_index] + ' | '
                    pep_mod_text = pep_mod_text + ' ' + '   '
            else:
                pep_text = pep_text + clc_pep[pep_index]
                pep_mod_text = pep_mod_text + ' '
        return pep_text, pep_mod_text

    def plot(self):

        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_TMP_EXPORT[8]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IOFILENAME_IRT_EXPORT[0]

        with open(path, 'rb')as f:
            inputList = pickle.load(f)

        ListEvidence, ListSeed, ListIndex = inputList[0], inputList[1], inputList[2]

        Y1_NAME = 'Relative Intensity(%)'  
        Y2_NAME = 'ppm'  
        X_NAME = 'm/z'  

        
        
        fig = plt.figure(figsize=(15, 5))  

        gs = GridSpec(17, 12)

        for i in range(len(ListIndex)):

            i_Pre, i_Raw, i_Scan, i_RT = ListIndex[i][0], ListIndex[i][1], ListIndex[i][2], ListIndex[i][3]
            clc_moz = [float(i_moz) for i_moz in ListSeed[i_Pre].MOZ_FRAGMENT]
            clc_tag = ListSeed[i_Pre].TYPE_FRAGMENT
            exp_moz = np.array(ListEvidence[i].MS2_PEAK_MOZ)
            exp_int = np.array(ListEvidence[i].MS2_PEAK_INT)
            max_int = max(exp_int)
            
            if self.dp.myCFG.C15_DDA_FRAGMENT_INT_NUM == -1:
                exp_int = list(exp_int)
                exp_moz = list(exp_moz)
            elif len(exp_moz) > self.dp.myCFG.C15_DDA_FRAGMENT_INT_NUM:
                top_num_flag = np.sort(exp_int)[len(exp_moz) - self.dp.myCFG.C15_DDA_FRAGMENT_INT_NUM - 1]
                flag_list = exp_int >= top_num_flag
                exp_int = list(exp_int[flag_list])
                exp_moz = list(exp_moz[flag_list])
            else:
                exp_int = list(exp_int)
                exp_moz = list(exp_moz)
            
            ax1 = plt.subplot(gs[0:2, :])
            plt.xlim((0, 110))
            plt.ylim((0, 20))
            plt.xticks([])
            plt.yticks([])

            ax1.spines['top'].set_visible(False)
            ax1.spines['right'].set_visible(False)
            ax1.spines['bottom'].set_visible(False)
            ax1.spines['left'].set_visible(False)

            info_scan = i_Scan
            info_rt = i_RT
            info_raw_name = self.dp.myIDForIRT.LIST_EXPERIMENT_ID[i_Raw]
            var_inf_40 = '{:.3g}'.format(max_int)
            info_moz = '{:.3f}'.format(self.dp.myIDForIRT.PRE4_MOZ_CLC[i_Pre])
            mod_dic = self.__soliderMod2Dict(self.dp.myIDForIRT.PRE2_MOD[i_Pre])
            tmp_precursorID = self.dp.myIDForIRT.LIST_PRECURSOR_ID[i_Pre]
            plt.text(0, 15, 'Title:', color='black', fontsize=10)
            plt.text(4, 15, info_raw_name, color='red', fontsize=10)
            plt.text(50, 5, 'RT:', color='black', fontsize=10)
            plt.text(55, 5, info_rt, color='red', fontsize=10)
            plt.text(17, 5, 'Moz:', color='black', fontsize=10)
            plt.text(21, 5, info_moz, color='red', fontsize=10)
            plt.text(40, 5, 'Scan', color='black', fontsize=10)
            plt.text(44, 5, info_scan, color='red', fontsize=10)

            
            ax2 = plt.subplot(gs[2:4, :])
            plt.xlim((0, 2500))
            plt.ylim((0, 30))
            plt.xticks([])
            plt.yticks([])

            ax2.spines['top'].set_visible(False)
            ax2.spines['right'].set_visible(False)
            ax2.spines['bottom'].set_visible(False)
            ax2.spines['left'].set_visible(False)

            info_pep = self.dp.myIDForIRT.PRE1_SEQ[i_Pre]
            info_charge = self.dp.myIDForIRT.PRE3_CHARGE[i_Pre]

            
            font1 = {'family': 'SimHei',
                     'color': 'black',
                     'weight': 'normal',
                     'size': 10,
                     }
            font2 = {'family': 'SimHei',
                     'color': 'red',
                     'weight': 'normal',
                     'size': 10,
                     }

            pep_text, pep_mod_text = self.__GetPlotPepText(info_pep, mod_dic)

            plt.text(100, 15, pep_text, fontdict=font1)  
            plt.text(95, 15, pep_mod_text, fontdict=font2)  
            plt.text(10, 25, str(info_charge) + '+', color='red', fontsize=10)  

            
            ax3 = plt.subplot(gs[4:16, 0:])
            plt.yticks([])
            x_axis_max = (math.ceil(max(exp_moz) / 100) + 1) * 100  
            if x_axis_max > 2500:
                x_axis_max = 2500
            plt.xlim((0, x_axis_max))
            plt.xticks([])
            
            

            ax3.spines['top'].set_visible(False)
            ax3.spines['right'].set_visible(False)

            
            
            
            
            
            plt.xlim((0, x_axis_max))
            plt.xticks([])
            plt.ylim((0, 120))
            plt.yticks([0, 20, 40, 60, 80, 100])
            plt.ylabel(Y1_NAME)
            

            
            ax4 = plt.subplot(gs[16:, 0:])
            plt.xlim((0, x_axis_max))
            
            ax = plt.gca()
            var_xma_140 = MultipleLocator(100)
            var_xmi_25 = MultipleLocator(10)
            ax.xaxis.var_set_48(var_xmi_25)
            ax.xaxis.var_set_38(var_xma_140)
            var_inf_46 = 0
            info_bias = float(self.dp.myCFG.C13_DDA_FRAGMENT_PPM_HALF_WIN_ACCURACY_PEAK)

            if var_inf_46 == 0:  
                ax4_y = info_bias
            else:
                ax4_y = 20

            plt.ylim((-ax4_y, ax4_y))

            plt.xlabel(X_NAME)
            plt.ylabel(Y2_NAME)

            pep_moz_start = ''
            type_pep = 'single'

            op_Data_fill_plot(clc_moz, clc_tag, exp_moz, exp_int, var_inf_46, info_bias, ax1,
                              ax2, ax3, ax4, pep_moz_start, type_pep, [])

            plt.savefig(path_out + '\\' + info_raw_name + '\\' + 'Label_' + tmp_precursorID + '_Scan_' + str(info_scan) + '.png', format='png', dpi=300)
            

            plt.clf()

        plt.close('all')


class CFunctionPlotC_8:
    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def var_cap_116(self, ax, rects):
        for rect in rects:
            size = 6 if len(self.dp.myProteinID.LIST_SAMPLE_ID) > 20 else 10
            ax.text(rect.get_x() + 0.10, rect.get_height(), rect.get_height(), ha='left', va='bottom', size=size)

    def plotDIA(self):
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[44]
        x_experiment = self.dp.myProteinID.LIST_EXPERIMENT_ID
        x_tick = list(range(len(x_experiment)))

        fig = plt.figure(figsize=(max(int(0.3 * len(x_experiment)), 8), 18))

        for i in range(len(self.dp.myCONTAM.CON_RATIO)):
            y_count = self.dp.myCONTAM.CON_RATIO[i]
            y_count = [round(j*100,2) for j in y_count]

            ax = plt.subplot(3, 1, i+1)
            plt.title('The Ratio of Contaminant '+str(list(self.dp.myCONTAM.DIC_CONTAM.keys())[i]))
            rects = plt.bar(x_tick, y_count, width=0.5, color='steelblue', tick_label=x_experiment)
            plt.axhline(y=np.median(y_count),color="g", linestyle="dashed",linewidth=2)
            
            plt.axhline(y=np.median(y_count)+2*np.std(y_count), color="gold", linestyle="dashed",linewidth=2)
            plt.axhline(y=np.median(y_count) + 3 * np.std(y_count), color="red", linestyle="dashed", linewidth=2)
            
            self.var_cap_116(ax, rects)

            plt.xticks(rotation=90, )
            
            plt.ylabel('Ratio (%)', fontsize=15)
            ax = plt.gca()
            ax.spines['right'].set_color('none')
            ax.spines['top'].set_color('none')

        plt.subplots_adjust(left=0.15, bottom=0.10, top=0.95, right=0.95, hspace=0.30, wspace=0.20)
        fig.tight_layout()
        plt.savefig(path_out + '.png', format='png')
        
        plt.close('all')


class CFunctionPlotM_21:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def var_cap_116(self, ax, rects):
        for rect in rects:
            size = 6 if len(self.dp.myProteinID.LIST_SAMPLE_ID) > 20 else 10
            ax.text(rect.get_x() + 0.10, rect.get_height(), rect.get_height(), ha='left', va='bottom', size=size)

    def plotDIA(self):
        path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[58]
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[45]

        f = open(path, encoding='utf-8', errors='ignore')
        metrics_value = pd.read_csv(f, sep='\t', index_col=0)
        miss_ratio = metrics_value.iloc[1, :]
        p_float = miss_ratio.str.strip("%").astype(float) / 100
        value = p_float.round(decimals=2)
        value = [round(j * 100, 2) for j in value]
        x_experiment = self.dp.myProteinID.LIST_EXPERIMENT_ID
        x_tick = list(range(len(x_experiment)))

        fig = plt.figure(figsize=(max(int(0.3 * len(x_experiment)), 10), 6))
        plt.title('The Ratio of 0 missed cleavage(%)' )
        rects = plt.bar(x_tick, value, width=0.5, color='steelblue', tick_label=x_experiment)
        plt.axhline(y=np.median(value), color="g", linestyle="dashed")
        
        plt.axhline(y=np.mean(value) + 2 * np.std(value), color="r", linestyle="dashed")
        
        plt.xticks(rotation=90, fontsize=20)
        plt.ylabel('Ratio(%)', fontsize=20)
        plt.ylim(ymin=0,ymax=100)
        self.var_cap_116(fig, rects)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')

        fig.tight_layout()
        plt.savefig(path_out + '.png', format='png')
        
        plt.close('all')


class CFunctionPlotP_15:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plotDIA(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[46]
        matrix_pw = self.dp.myPrecursorID.PRELIST5_PEAKWIDTH
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        var_mat_162 = np.array(matrix_pw)
        var_mat_162[var_mat_162 == VALUE_ILLEGAL] = np.nan
        df = pd.DataFrame(var_mat_162, columns=var_lis_82)

        if len(var_lis_82) < 400:
            plt.figure(figsize=(max(2 + 0.3*len(var_lis_82), 10), 6))
        elif len(var_lis_82) >= 400:
            plt.figure(figsize=(min(2 + 0.3 * len(var_lis_82), 200), 6))
        sns.set(style='white')
        sns.boxplot(data=df,showfliers=False,meanline=True, linewidth=2, palette='Set1')
        plt.xticks(rotation=90, fontsize=15)
        plt.yticks(fontsize=15)
        plt.xlabel('Experiment',fontsize=20)
        plt.ylabel('Peak Width',fontsize=20)
        q3_values = max(df.quantile(0.75))
        if q3_values < 0.3:
            plt.ylim(0, 0.5)
        else:
            plt.ylim(0, 1)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=300)
        
        plt.clf()
        plt.close('all')


class CFunctionPlotF_17:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plotDIA(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[56]
        matrix_fwhm = self.dp.myPrecursorID.PRELIST7_FWHM
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        var_mat_73 = np.array(matrix_fwhm)
        var_mat_73[var_mat_73 == VALUE_ILLEGAL] = np.nan
        df = pd.DataFrame(var_mat_73, columns=var_lis_82)

        if len(var_lis_82) < 400:
            plt.figure(figsize=(max(2 + 0.3 * len(var_lis_82), 10), 6))
        elif len(var_lis_82) >= 400:
            plt.figure(figsize=(min(2 + 0.3 * len(var_lis_82), 200), 6))
        sns.set(style='white')
        sns.boxplot(data=df,showfliers=False,meanline=True, linewidth=2, palette='Set1')
        plt.xticks(rotation=90, fontsize=15)
        plt.yticks(fontsize=15)
        plt.xlabel('Experiment',fontsize=20)
        plt.ylabel('FWHM',fontsize=20)
        q3_values = max(df.quantile(0.75))
        if q3_values<0.2:
            plt.ylim(0, 0.4)
        else:
            plt.ylim(0, 0.6)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=300)
        
        plt.clf()
        plt.close('all')


class CFunctionPlotM_6:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plotDIA(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[52]
        var_mat_149 = self.dp.myPrecursorID.PRELIST8_MS1_ACCURACY
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        var_mat_75 = np.array(var_mat_149)
        var_mat_75[var_mat_75 == VALUE_ILLEGAL] = np.nan
        df = pd.DataFrame(var_mat_75, columns=var_lis_82)

        plt.figure(figsize=(max(2 + 0.3*len(var_lis_82), 10), 6))
        sns.set(style='white')
        sns.boxplot(data=df,showfliers=False,meanline=True, linewidth=2, palette='Set1')
        plt.xticks(rotation=90, fontsize=15)
        plt.yticks(fontsize=15)
        
        plt.ylabel('MS1 Raw Mass Accuracy (ppm)',fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=300)
        
        plt.clf()
        plt.close('all')


class CFunctionPlotC_28:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plotDIA(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[71]
        var_mat_149 = self.dp.myPrecursorID.PRELIST13_CALIBRATE_MS1_ACCURACY
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        var_mat_75 = np.array(var_mat_149)
        var_mat_75[var_mat_75 == VALUE_ILLEGAL] = np.nan
        df = pd.DataFrame(var_mat_75, columns=var_lis_82)

        plt.figure(figsize=(max(2 + 0.3*len(var_lis_82), 10), 6))
        sns.set(style='white')
        sns.boxplot(data=df,showfliers=False,meanline=True, linewidth=2, palette='Set1')
        plt.xticks(rotation=90, fontsize=15)
        plt.yticks(fontsize=15)
        
        plt.ylabel('Calibrated MS1 Mass Accuracy (ppm)',fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=300)
        
        plt.clf()
        plt.close('all')


class CFunctionPlotC_32:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plotDIA(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[72]
        var_mat_51 = self.dp.myPrecursorID.PRELIST14_CALIBRATE_MS2_ACCURACY
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        var_mat_150 = np.array(var_mat_51)
        var_mat_150[var_mat_150 == VALUE_ILLEGAL] = np.nan
        df = pd.DataFrame(var_mat_150, columns=var_lis_82)

        plt.figure(figsize=(max(2 + 0.3*len(var_lis_82), 10), 6))
        sns.set(style='white')
        sns.boxplot(data=df,showfliers=False,meanline=True, linewidth=2, palette='Set1')
        plt.xticks(rotation=90, fontsize=15)
        plt.yticks(fontsize=15)
        
        plt.ylabel('Calibrated MS2 Mass Accuracy (ppm)',fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=300)
        
        plt.clf()
        plt.close('all')


class CFunctionPlotM_31:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plotDIA(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[53]
        var_mat_51 = self.dp.myPrecursorID.PRELIST9_MS2_ACCURACY
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        var_mat_150 = np.array(var_mat_51)
        var_mat_150[var_mat_150 == VALUE_ILLEGAL] = np.nan
        var_mat_150[var_mat_150 == "NaN"] = np.nan
        df = pd.DataFrame(var_mat_150, columns=var_lis_82)

        plt.figure(figsize=(max(2 + 0.3*len(var_lis_82), 10), 6))
        sns.set(style='white')
        sns.boxplot(data=df,showfliers=False,meanline=True, linewidth=2, palette='Set1')
        plt.xticks(rotation=90, fontsize=15)
        plt.yticks(fontsize=15)
        plt.xlabel('Experiment')
        plt.ylabel('MS2 Raw Mass Accuracy (ppm)',fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=300)
        
        plt.clf()
        plt.close('all')


class CFunctionPlotD_24:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plotDIA(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[47]
        matrix_pw = self.dp.myPrecursorID.PRELIST6_DELTART
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        var_mat_162 = np.array(matrix_pw)
        var_mat_162[var_mat_162 == VALUE_ILLEGAL] = np.nan
        df = pd.DataFrame(var_mat_162, columns=var_lis_82)
        if len(var_lis_82) < 400:
            plt.figure(figsize=(max(2 + 0.3 * len(var_lis_82), 10), 6))
        elif len(var_lis_82) >= 400:
            plt.figure(figsize=(min(2 + 0.3 * len(var_lis_82), 200), 6))
        sns.set(style='white')
        sns.boxplot(data=df,showfliers=False,meanline=True, linewidth=2, palette='Set1')
        plt.xticks(rotation=90, fontsize=13)
        plt.yticks(fontsize=15)
        plt.xlabel('Experiment', fontsize=20)
        plt.ylabel('DeltaRT', fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=100)
        
        plt.clf()
        plt.close('all')


class CFunctionPlotM_20:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plotDIA(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[54]
        matrix_ms1_DPPP = self.dp.myPrecursorID.PRELIST10_MS1_DPPP
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        matrix_ms1_DPPP_array = np.array(matrix_ms1_DPPP)
        matrix_ms1_DPPP_array[matrix_ms1_DPPP_array == VALUE_ILLEGAL] = np.nan
        df = pd.DataFrame(matrix_ms1_DPPP_array, columns=var_lis_82)
        plt.figure(figsize=(max(2 + 0.3*len(var_lis_82), 10), 6))
        sns.set(style='white')
        sns.violinplot(data=df,linewidth=1, width=0.9, inter="box",palette="Blues")
        if df.max().max() > 10:
            plt.ylim(0,15)
        plt.xticks(rotation=90, fontsize=13)
        plt.yticks(fontsize=15)
        plt.xlabel('Experiment',fontsize=20)
        plt.ylabel('MS1 Data Point per Peak (DPPP)', fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=300)
        
        plt.clf()
        plt.close('all')


class CFunctionPlotM_5:
    def __init__(self, inputDP: CDataPack):
        self.dp = inputDP

    def plotDIA(self):
        out_path = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PIC_EXPORT[55]
        matrix_ms2_DPPP = self.dp.myPrecursorID.PRELIST11_MS2_DPPP
        var_lis_82 = self.dp.myPrecursorID.LIST_EXPERIMENT_ID
        matrix_ms2_DPPP_array = np.array(matrix_ms2_DPPP)
        matrix_ms2_DPPP_array[matrix_ms2_DPPP_array == VALUE_ILLEGAL] = np.nan
        df = pd.DataFrame(matrix_ms2_DPPP_array, columns=var_lis_82)
        plt.figure(figsize=(max(2 + 0.3*len(var_lis_82), 10), 6))
        sns.set(style='white')
        sns.violinplot(data=df, linewidth=1, width=0.9, inter="box",palette="Blues")
        if df.max().max() > 10:
            plt.ylim(0,10)
        plt.xticks(rotation=90, fontsize=13)
        plt.yticks(fontsize=15)
        plt.xlabel('Experiment',fontsize=20)
        plt.ylabel('MS2 Data Point per Peak (DPPP)', fontsize=20)
        ax = plt.gca()
        ax.spines['right'].set_color('none')
        ax.spines['top'].set_color('none')
        plt.grid(linestyle="--", alpha=0.5)
        plt.tight_layout()

        plt.savefig(out_path + '.png', format="png", dpi=300)
        
        plt.clf()
        plt.close('all')


class CFunctionHTMLR_27:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP
        self.Metrics_Title = []
        self.Metrics_Infor = []

        self.head_str = \
            "<html>\n" \
            "<head>\n" \
            "<meta name='generator' content='MSCohort'/>\n" \
            "<meta http-equiv='content-Type' content='text/html'>\n" \
            "<title> MSCohort Report</title>\n" \
            "<style>\n" \
            "body {font-family: Times New Roman, serif, Garamond; font-size: 20.0pt;}\n" \
            '.title1 {text-align:center;font-size:28.0pt;font-weight:bold}\n' \
            '.version1 {text-align:center;font-size:15.0pt;font-style:italic;}\n' \
            '.section1 {text-align:left;font-size:24.0pt;font-weight:bold;}\n' \
            '.section2 {text-align:left;font-size:16.0pt;font-weight:bold;}\n' \
            '.section3 {text-align:left;font-size:12.0pt;font-weight:bold;}\n' \
            '.figure_legend1 {text-align:center;font-size:12.0pt;}\n' \
            '.table_legend1 {text-align:center;font-size:12.0pt;}\n' \
            '.table1 {border-collapse:collapse;border:none;font-size:12.0pt;}\n' \
            '.table_head1 {border:solid black 1.0pt;background:#8DB3E2;padding:3pt 10pt 3pt 10pt;text-align:center;color:white;font-weight:bold;}\n' \
            '.table_head2 {border:solid black 1.0pt;background:#8DB3E2;padding:3pt 10pt 3pt 10pt;text-align:center;color:white;font-weight:bold;Word-break: break-all;}\n' \
 \
            '.table2 {border-collapse:collapse;border:none;font-size:10.0pt;}\n' \
            '.table_data1 {border:solid black 1.0pt; padding:3pt 10pt 3pt 10pt;text-align:center;}\n' \
            '.table_data2 {border:0 1.0pt; padding:3pt 10pt 3pt 10pt;text-align:center;}\n'\
            '.Reference1 {font-style:italic;}\n' \
            "</style>\n" \
            "</head>\n" \
            "<body>\n"

        self.tail_str = \
            "</body>\n" \
            "</html>\n"

        self.var_hea_114 = \
            "<div align=center>\n"

        self.var_tai_87 = \
            "</div>\n"
        self.var_tab_129 = "<p class=section1>"

    def var_sol_79(self):

        str_flow = [i for i in CFG_TYPE_COHORT if CFG_TYPE_COHORT[i] == self.dp.myCFG.C1_TYPE_COHORT][0]

        title_str = "<div align=center>\n"
        title_str += "<p class = 'title1'><b>Cohort analysis report ({:s})</b></p>\n".format(str_flow)
        
        title_str += "</div>\n"

        return title_str

    def var_sol_56(self, width, height):

        var_lis_68 = ['Group Name', 'Raw Name', 'Experiment']
        var_lis_21 = self.dp.LIST_EXPERIMENT_GROUP
        list_rowspan = [len(i[1]) for i in var_lis_21]

        table_str = "<p class=section1>Experiment Setting (Number of Raw: {:d})</p >\n".format(len(self.dp.myProteinID.LIST_EXPERIMENT_ID))
        table_str += "<p class='table_legend1'>" + "</p >\n"
        table_str += "<div align=center>\n<table class='table1' width='{:d}' height='{:d}'>\n".format(width, height)
        table_str += "<tr>"
        for head in var_lis_68:
            table_str += "\n<td class='table_head1'>" + head + "</td>"
        table_str += "\n</tr>"

        for index, v_list in enumerate(var_lis_21):

            i_rowspan = list_rowspan[index]
            i_group = v_list[0]
            var_ili_63 = v_list[1]
            i_list_rawID = v_list[2]

            for i_index, v in enumerate(var_ili_63):
                table_str += "\n<tr>"
                if i_index == 0:
                    table_str += "\n<td class='table_data1' rowspan=" + str(i_rowspan) + '>' + str(i_group) + "</td>"
                table_str += "\n<td class='table_data1'>" + str(v) + "</td>"
                table_str += "\n<td class='table_data1'>" + str(i_list_rawID[i_index]) + "</td>"
                table_str += "\n</tr>"

        table_str += "\n</table>\n"

        return table_str

    def var_sol_100(self, var_pat_161):

        
        path = var_pat_161

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        x_experiment = lines[0].strip().split('\t')[1:]
        var_yco_155 = lines[1].strip().split('\t')[1:]
        var_yno_27 = lines[2].strip().split('\t')[1:]
        var_ymi_24 = lines[3].strip().split('\t')[1:]

        x_experiment = ['Experiment'] + x_experiment
        var_yco_155 = ['Common'] + var_yco_155
        var_yno_27 = ['No Common'] + var_yno_27
        var_ymi_24 = ['Missing Value'] + var_ymi_24

        table_str = "<p class='table_legend1'>" + "</p >\n"
        table_str += "<div align=center>\n<table class='table2' width='{:d}' height='{:d}'>\n".format(min(120 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 4500), 150)
        table_str += "<tr>"
        for head in x_experiment:
            table_str += "\n<td class='table_head2'>" + head + "</td>"
        table_str += "\n</tr>"
        table_str += "\n<tr>"
        for head in var_ymi_24:
            table_str += "\n<td class='table_data1'>" + head + "</td>"
        table_str += "\n</tr>"
        table_str += "\n<tr>"
        for head in var_yno_27:
            table_str += "\n<td class='table_data1'>" + head + "</td>"
        table_str += "\n</tr>"
        table_str += "\n<tr>"
        for head in var_yco_155:
            table_str += "\n<td class='table_data1'>" + head + "</td>"
        table_str += "\n</tr>\n</table>\n"
        return table_str

    def __solider_draw_table_missingValue_Share(self, var_pat_28):

        
        path = var_pat_28

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        x_experiment = lines[0].strip().split('\t')[1:]
        var_yco_155 = lines[1].strip().split('\t')[1:]
        var_ysh_77 = lines[2].strip().split('\t')[1:]
        var_ysp_74 = lines[3].strip().split('\t')[1:]
        var_yun_47 = lines[4].strip().split('\t')[1:]

        x_experiment = ['Experiment'] + x_experiment
        var_yco_155 = ['Common quantification'] + var_yco_155
        var_ysh_77 = ['Shared>=50% of runs'] + var_ysh_77
        var_ysp_74 = ['Sparse quantification'] + var_ysp_74
        var_yun_47 = ['Unique quantification'] + var_yun_47


        table_str = "<p class='table_legend1'>" + "</p >\n"
        table_str += "<div align=center>\n<table class='table2' width='{:d}' height='{:d}'>\n".format(min(150 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 4500), 150)
        table_str += "<tr>"
        for head in x_experiment:
            table_str += "\n<td class='table_head2'>" + head + "</td>"
        table_str += "\n</tr>"
        table_str += "\n<tr>"
        for head in var_yco_155:
            table_str += "\n<td class='table_data1'>" + head + "</td>"
        table_str += "\n</tr>"
        table_str += "\n<tr>"
        for head in var_ysh_77:
            table_str += "\n<td class='table_data1'>" + head + "</td>"
        table_str += "\n</tr>"
        table_str += "\n<tr>"
        for head in var_ysp_74:
            table_str += "\n<td class='table_data1'>" + head + "</td>"
        table_str += "\n</tr>"
        table_str += "\n<tr>"
        for head in var_yun_47:
            table_str += "\n<td class='table_data1'>" + head + "</td>"
        table_str += "\n</tr>\n</table>\n"
        return table_str

    def var_sol_30(self, path_score):

        
        path = path_score

        with open(path, 'rb')as f:
            lines = f.read().decode(encoding='utf-8').split('\r\n')

        x_experiment = lines[0].strip().split('\t')[1:]
        var_ysc_80 = lines[1].strip().split('\t')[1:]
        var_ysc_115 = lines[2].strip().split('\t')[1:]
        var_ysc_19 = lines[3].strip().split('\t')[1:]
        var_ysc_101 = lines[4].strip().split('\t')[1:]
        var_ysc_57 = lines[5].strip().split('\t')[1:]
        var_ysc_147 = lines[6].strip().split('\t')[1:]
        var_ysc_112 = lines[6].strip().split('\t')[1:]

        x_experiment = ['Experiment'] + x_experiment
        var_ysc_80 = ['Protein_corr'] + var_ysc_80
        var_ysc_115 = ['Peptide_corr'] + var_ysc_115
        var_ysc_19 = ['Precursor_corr'] + var_ysc_19
        var_ysc_101 = ['Protein_std'] + var_ysc_101
        var_ysc_57 = ['Peptide_std'] + var_ysc_57
        var_ysc_147 = ['Precursor_std'] + var_ysc_147
        var_ysc_112 = ['Precursor_rt'] + var_ysc_112

        table_str = "<p class='table_legend1'>" + "</p >\n"
        table_str += "<div align=center>\n<table class='table2' width='{:d}' height='{:d}'>\n".format(min(120 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 4500), 150)
        table_str += "<tr>"
        for head in x_experiment:
            table_str += "\n<td class='table_head2'>" + head + "</td>"
        table_str += "\n</tr>"
        for i_list_score in [var_ysc_80, var_ysc_115, var_ysc_19, var_ysc_101, var_ysc_57, var_ysc_147, var_ysc_112]:
            table_str += "\n<tr>"
            for head in i_list_score:
                table_str += "\n<td class='table_data1'>" + head + "</td>"
            table_str += "\n</tr>"
        table_str += "\n</tr>\n</table>\n"
        return table_str

    def var_sol_134(self):
        linertitle = ["Category", "Inter-experiment metrics", "Description"]
        lineTotal = ["Total score",metrics_INFO.Total, meaning_INFO.Total]
        lineS1 = ["1. Sample Preparation", metrics_INFO.SP, meaning_INFO.SP + "<b>Score 5</b>: < the overall median;" + " <b>Score 1 </b>: >= median + 2*SD."]
        lineLC1 = ['2. Liquid Chromatography', metrics_INFO.LC1, meaning_INFO.LC1 + "<b>Score 5</b>: < the overall median;" + " <b>Score 1 </b>: >= median + 2*SD."]
        lineLC2 = [metrics_INFO.LC2, meaning_INFO.LC2 + "<b>Score 5</b>: < the overall median;" + " <b>Score 1 </b>: >= median + 2*SD."]
        lineMS1 = ['3. Precursor-level Results', metrics_INFO.MS1, meaning_INFO.MS1 + "<b>Score 5</b>: > the overall median;" + " <b>Score 1 </b>: <= median - 2*SD."]
        lineMS2 = [metrics_INFO.MS2, meaning_INFO.MS2 + "<b>Score 5</b>: > the overall median;" + " <b>Score 1 </b>: <= median - 2*SD."]
        lineMS3 = [metrics_INFO.MS3, meaning_INFO.MS3 + "<b>Score 5</b>: < the overall median;" + " <b>Score 1 </b>: >= median + 2*SD."]
        lineMS4 = [metrics_INFO.MS4, meaning_INFO.MS4 + "<b>Score 5</b>: close to 0;" + " <b>Score 1 </b>: >= median + 2*SD."]
        lineMS5 = [metrics_INFO.MS5, meaning_INFO.MS5 + "<b>Score 5</b>: > the overall median;" + " <b>Score 1 </b>: <= median - 2*SD."]
        lineMS6 = [metrics_INFO.MS6, meaning_INFO.MS6 + "<b>Score 5</b>: close to 0;" + " <b>Score 1 </b>: >= median + 2*SD."]
        lineMS7 = ['4. Peptide-level Results', metrics_INFO.MS7, meaning_INFO.MS7 + "<b>Score 5</b>: > the overall median;" + " <b>Score 1 </b>: <= median - 2*SD."]
        lineMS8 = [metrics_INFO.MS8, meaning_INFO.MS8 + "<b>Score 5</b>: > the overall median;" + " <b>Score 1 </b>: <= median - 2*SD."]
        lineMS9 = [metrics_INFO.MS9, meaning_INFO.MS9 + "<b>Score 5</b>: < the overall median;" + " <b>Score 1 </b>: >= median + 2*SD"]
        lineMS10 = [metrics_INFO.MS10, meaning_INFO.MS10 + "<b>Score 5</b>: close to 0;" + " <b>Score 1 </b>: >= median + 2*SD"]
        lineMS11 = [metrics_INFO.MS11, meaning_INFO.MS11 + "<b>Score 5</b>: > the overall median;" + " <b>Score 1 </b>: <= median - 2*SD."]
        lineMS12 = [metrics_INFO.MS12, meaning_INFO.MS12 + "<b>Score 5</b>: close to 0;" + " <b>Score 1 </b>: >= median + 2*SD."]
        lineMS13 = ['5. Protein group-level Results', metrics_INFO.MS13,meaning_INFO.MS13 + "<b>Score 5</b>: > the overall median;" + " <b>Score 1 </b>: <= median + 2*SD."]
        lineMS14 = [metrics_INFO.MS14,meaning_INFO.MS14 + "<b>Score 5</b>: > the overall median;" + " <b>Score 1 </b>: <= median - 2*SD."]
        lineMS15 = [metrics_INFO.MS15,meaning_INFO.MS15 + "<b>Score 5</b>: < the overall median;" + " <b>Score 1 </b>: >= median + 2*SD."]
        lineMS16 = [metrics_INFO.MS16,meaning_INFO.MS16 + "<b>Score 5</b>: close to 0;" + " <b>Score 1 </b>: >= median + 2*SD."]
        lineMS17 = [metrics_INFO.MS17,meaning_INFO.MS17 + "<b>Score 5</b>: > the overall median;" + " <b>Score 1 </b>: <= median - 2*SD."]
        lineMS18 = [metrics_INFO.MS18,meaning_INFO.MS18 + "<b>Score 5</b>: close to 0;" + " <b>Score 1 </b>: >= median + 2*SD."]

        var_lin_64 = [lineTotal,lineS1,lineLC1,lineLC2,lineMS1,lineMS2,lineMS3,lineMS4,lineMS5,lineMS6,lineMS7,lineMS8,lineMS9,lineMS10,lineMS11,lineMS12,lineMS13,lineMS14,lineMS15,lineMS16,lineMS17,lineMS18]
        self.Metrics_Title = linertitle
        self.Metrics_Infor = var_lin_64

    def var_dra_10(self, class_title, headers, values, rowspan1, rowspan2, rowspan3, rowspan4, rowspan5,rowspan6):
        table_str = self.var_tab_129 + class_title + "</p >\n"
        table_str += "<p class='table_legend1'>" + "</p >\n"
        table_str += "<div align=center>\n<table class='table1'>"
        table_str += "\n<tr>"
        for head in headers:
            table_str += "\n<td class='table_head1'>" + head + "</td>"
        table_str += "\n</tr>"

        for index, v_list in enumerate(values):
            table_str += "\n<tr>"
            if index == 0:
                for index, v in enumerate(v_list):
                    if index == 0:
                        table_str += "\n<td class='table_data1' rowspan=" + str(rowspan1) + '>' + str(v) + "</td>"
                    else:
                        table_str += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1:
                for index, v in enumerate(v_list):
                    if index == 0:
                        table_str += "\n<td class='table_data1' rowspan=" + str(rowspan2) + '>' + str(v) + "</td>"
                    else:
                        table_str += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1 + rowspan2:
                for index, v in enumerate(v_list):
                    if index == 0:
                        table_str += "\n<td class='table_data1' rowspan=" + str(rowspan3) + '>' + str(v) + "</td>"
                    else:
                        table_str += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1 + rowspan2 + rowspan3:
                for index, v in enumerate(v_list):
                    if index == 0:
                        table_str += "\n<td class='table_data1' rowspan=" + str(rowspan4) + '>' + str(v) + "</td>"
                    else:
                        table_str += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1 + rowspan2 + rowspan3 + rowspan4:
                for index, v in enumerate(v_list):
                    if index == 0:
                        table_str += "\n<td class='table_data1' rowspan=" + str(rowspan5) + '>' + str(v) + "</td>"
                    else:
                        table_str += "\n<td class='table_data1'>" + str(v) + "</td>"
            elif index == rowspan1 + rowspan2 + rowspan3 + rowspan4 + rowspan5:
                for index, v in enumerate(v_list):
                    if index == 0:
                        table_str += "\n<td class='table_data1' rowspan=" + str(rowspan6) + '>' + str(v) + "</td>"
                    else:
                        table_str += "\n<td class='table_data1'>" + str(v) + "</td>"
            else:
                for v in v_list:
                    table_str += "\n<td class='table_data1'>" + str(v) + "</td>"
            table_str += "\n</tr>"
        table_str += "\n</table>\n"
        return table_str

    def var_sol_133(self, title_pic, file_pic, info_pic):

        path_pic = file_pic[1:]

        pic_str = "<div align=center>\n<p class=section1>" + title_pic + "</p>\n"
        pic_str += '<img src="' + path_pic + '" alt="Could not Find ' + info_pic + '"></img>\n'
        pic_str += "</div>\n"
        return pic_str

    def var_sol_141(self, title_pic, file_pic, info_pic, width, height):

        path_pic = file_pic[1:]

        pic_str = "<div align=center>\n<p class=section2>" + title_pic + "</p>\n"
        pic_str += '<img src="' + path_pic + '" width"{:d}" height="{:d}" alt="Could not Find '.format(width, height)\
                   + info_pic + '"></img>\n'
        pic_str += "</div>\n"
        return pic_str

    def var_sol_97(self, title_pic, file_pic1, file_pic2, info_pic, width, height):

        path_pic1 = file_pic1[1:]
        path_pic2 = file_pic2[1:]

        pic_str = "<div align=center>\n<p class=section1>" + title_pic + "</p>\n"
        pic_str += "<table><tr>"
        pic_str += "\n<td class='table_data2'>" + "Before Normalization" + "</td>"
        pic_str += "\n<td class='table_data2'>" + "After Normalization" + "</td>"
        pic_str += "\n</tr>"
        pic_str += "<tr>\n" +\
                   "<td><img src='{:s}' width'{:d}' height='{:d}' border=0></td>\n".format(path_pic1, width, height) +\
                   "<td><img src='{:s}' width'{:d}' height='{:d}' border=0></td>\n".format(path_pic2, width, height) +\
                   "</tr></table>\n"
        return pic_str

    def var_sol_84(self, title_pic, file_pic1, file_pic2, info_pic, width, height):

        path_pic1 = file_pic1[1:]
        path_pic2 = file_pic2[1:]

        pic_str = "<div align=center>\n<p class=section1>" + title_pic + "</p>\n"
        pic_str += "<table><tr>"
        pic_str += "\n</tr>"
        pic_str += "<tr>\n" + \
                   "<td><img src='{:s}' width'{:d}' height='{:d}' border=0></td>\n".format(path_pic1, width, height) + \
                   "<td><img src='{:s}' width'{:d}' height='{:d}' border=0></td>\n".format(path_pic2, width, height) + \
                   "</tr></table>\n"
        return pic_str

    def report(self):

        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_HTML_EXPORT

        with open(path_out, 'w')as f:

            f.write(self.head_str)
            
            f.write(self.var_sol_79())
            
            f.write(self.var_sol_56(width=600, height=20 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID)))
            
            
            
            
            
            
            
            
            f.write(self.var_sol_141("1. Identification Count", IO_FILENAME_PIC_EXPORT[0] + '.png',
                                            "bar figure for Protein", 500 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 1200))
            
            f.write("<p class=section1>2. Quantification Count for Protein</p >\n")
            var_pat_139 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[1]
            f.write(self.var_sol_100(var_pat_139))
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[1] + '.png',
                                            "bar figure for Protein", 300 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            if self.dp.myProteinGroupID.N_PROTEIN > 0:
                f.write("<p class=section1>2. Quantification Count for ProteinGroup</p >\n")
                var_pat_139 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[53]
                f.write(self.var_sol_100(var_pat_139))
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[41] + '.png',
                                                    "bar figure for Protein",
                                                    300 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            
            
            
            
            
            
            
            f.write(self.var_sol_141("3. Intensity Distribution for Protein", IO_FILENAME_PIC_EXPORT[2] + '.png',
                                            "hist figure for Protein", 200 * len(self.dp.LIST_EXPERIMENT_GROUP[0][1]),
                                            180 * len(self.dp.LIST_EXPERIMENT_GROUP)))
            
            if len(self.dp.myProteinID.PRO4_iBAQ) > 0:
                f.write(self.var_sol_141("4. Dynamic Range for Protein iBAQ", IO_FILENAME_PIC_EXPORT[16] + '.png',
                                                    'scatter figure for Protein', 200 * len(self.dp.LIST_EXPERIMENT_GROUP[0][1]),
                                            180 * len(self.dp.LIST_EXPERIMENT_GROUP)))
            
            f.write("<p class=section1>5. Intensity Linear Correlation</p >\n")
            
            f.write("<p class=section2>5.1. protein level</p >\n")
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[3] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[17] + '.png', "scatter figure for Protein",
                                                    700, 700 if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 20 else
                                                    700 + (len(self.dp.myProteinID.LIST_EXPERIMENT_ID)-20) * 10))
            
            f.write("<p class=section2>5.2. peptide level</p >\n")
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[20] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[21] + '.png', "scatter figure for Peptide",
                                                    700, 700 if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 20 else
                                                    700 + (len(self.dp.myProteinID.LIST_EXPERIMENT_ID)-20) * 10))

            
            f.write("<p class=section1>6. Robust Dev for Ratio of Protein</p >\n")
            
            f.write("<p class=section2>6.1. protein level</p >\n")
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[4] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[18] + '.png', "violin figure for Protein",
                                                    700, 700 if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 20 else
                                                    700 + (len(self.dp.myProteinID.LIST_EXPERIMENT_ID)-20) * 10))
            
            f.write("<p class=section2>6.2. peptide level</p >\n")
            f.write(self.var_sol_97("",
                                                    IO_FILENAME_PIC_EXPORT[22] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[23] + '.png', "violin figure for Peptide",
                                                    700, 700 if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 20 else
                                                    700 + (len(self.dp.myProteinID.LIST_EXPERIMENT_ID)-20) * 10))
            
            f.write("<p class=section1>7. Violin</p >\n")
            
            f.write("<p class=section2>7.1. protein level</p >\n")
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[5] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[8] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 25 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>7.2. peptide level</p >\n")
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[24] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[25] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 25 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section1>8. CV plot for Protein</p >\n")
            
            f.write("<p class=section2>8.1. protein level</p >\n")
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[7] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[10] + '.png',
                                                    "boxplot figure for Protein",
                                                    200 + 100 * len(self.dp.LIST_EXPERIMENT_GROUP), 500))
            
            f.write("<p class=section2>8.2. peptide level</p >\n")
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[26] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[27] + '.png',
                                                    "boxplot figure for Protein",
                                                    200 + 100 * len(self.dp.LIST_EXPERIMENT_GROUP), 500))
            
            f.write(self.var_sol_97("9. Cluster Heatmap for Protein", IO_FILENAME_PIC_EXPORT[6] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[9] + '.png',
                                                    "hotmap figure for Protein", 700, 700 if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 20 else
                                                    700 + (len(self.dp.myProteinID.LIST_EXPERIMENT_ID)-20) * 10))
            
            f.write(self.var_sol_84("10. Dimensionality reduction plot(after normalization)", IO_FILENAME_PIC_EXPORT[11] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[30] + '.png',
                                                "scatter figure", 750, 750))
            
            f.write("<p class=section1>11. RT Analysis</p >\n")
            
            f.write("<p class=section2>11.1. Linear Correlation for RT of Precursor</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[14] + '.png',
                                            "scatter figure for Precursor", 700, 700))
            
            f.write("<p class=section2>11.2. RT Deviation Analysis</p >\n")
            f.write(
                "<p class=section3>The reason for the large retention time deviation (>2) in the right figure is because"
                " the MaxQuant software identify precursor at different retention time of each data and used it as"
                " retention time of precursor. First, the precursor identified in each experiment is used as the retention time,"
                " and the match between runs algorithm is executed only for the precursor that is not identified in the experiment.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[15] + '.png',
                                            "scatter figure for Precursor", 1000, 450))

            
            f.write(self.var_sol_141("12. PloyLine of Retention Time For iRT", IO_FILENAME_PIC_EXPORT[12] + '.png',
                                            "ployline figure for iRT", 1200, 500))
            f.write(self.var_sol_141("13. PloyLine of Intensity For iRT", IO_FILENAME_PIC_EXPORT[13] + '.png',
                                            "ployline figure for iRT", 1200, 500))
            f.write(self.var_sol_141("14. PloyLine of Normalized Intensity For iRT", IO_FILENAME_PIC_EXPORT[28] + '.png',
                                            "ployline figure for iRT", 1200, 500))
            f.write(self.tail_str)

    def reportDIA(self):

        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_HTML_EXPORT
        print("Generating Webpage ......")

        with open(path_out, 'w')as f:

            f.write(self.head_str)
            
            f.write(self.var_sol_79())
            
            if len(self.dp.myProteinID.LIST_EXPERIMENT_ID)<100:
                f.write(self.var_sol_56(width=800, height=20 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID)))
            
            f.write("<p class=section1>1. Overview of Dataset</p >\n")
            
            f.write("<p class=section2>1.1 Score of Intra-experiment Metrics</p >\n")
            f.write("<p class=section3> Intra-experiment metrics give information about an individual DIA experiment and are computed at the level of individual LC-MS experiment."
                    "The detailed information for each metric and a detailed report for each sample are provided under the MSCohort folder.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[43] + '.png',
                                                "Heatmap for Intra-experiment Score",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 1000))

            
            
            
            f.write("<p class=section2>1.2 Score of Inter-experiment Metrics</p >\n")
            f.write("<p class=section3> Inter-experiment metrics are computed across multiple experiments to assess the quality for the whole cohort and detect low-quality data.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[42] + '.png',
                                                "Heatmap for Inter-experiment Score",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            f.write("<p class=section2> Outliers Detection</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[70] + '.png',
                                                "Scatter plot for Outlier Score",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>1.3 Detailed Information of Inter-experiment Metrics</p >\n")
            self.var_sol_134() 
            table_metrics = self.var_dra_10("",self.Metrics_Title, self.Metrics_Infor, 1, 1, 2, 6, 6, 6)
            f.write(table_metrics)


            
            f.write("<p class=section2>1.4 Identification Count</p >\n")
            f.write("<p class=section3>The green dashed lines represents the Median number, the yellow dashed lines represents the Median ± 2*SD,"
                    " and the red dashed lines represents the Median ± 3*SD.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[0] + '.png',"bar figure for Protein", 200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 900))
            
            f.write("<p class=section2>1.5 Quantification Count for Protein</p >\n")
            var_pat_139 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[1]
            var_pat_61 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[66]
            
            
            
            f.write(self.__solider_draw_table_missingValue_Share(var_pat_61))
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[69] + '.png',
                                                "bar figure for Protein",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            
            
            
            
            
            
            
            
            
            f.write("<p class=section1>2 Sample Peaparation</p >\n")
            f.write("<p class=section2>2.1 The Ratio of Contamination</p >\n")
            f.write("<p class=section3>The green dashed lines represents the Median number, the yellow dashed lines represents the Median ± 2*SD,"
                " and the red dashed lines represents the Median ± 3*SD.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[44] + '.png',
                                                "bar figure for contaminations",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 900))

            
            if self.dp.myCFG.A1_PATH_MS1 != '':
                f.write("<p class=section2>2.2 The Ratio of Missed Cleavage</p >\n")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[45] + '.png',
                                                    "bar figure for missed cleavage",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            
            f.write("<p class=section1>3 Liquid Chromatography(LC)</p >\n")
            f.write("<p class=section2>3.1 Peak Width</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[46] + '.png',
                                                "Boxplot figure for Peak Width",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section2>3.2 Full Width at Half Maximum (FWHM)</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[56] + '.png',
                                                "Boxplot figure for FWHM",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>3.3 Delta RT (predicted - measured)</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[47] + '.png',
                                                "Boxplot figure for Delta RT",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>3.4 RT Deviation Analysis</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[14] + '.png',
                                                "RT Deviation Analysis", 200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write(self.var_sol_141("3.5 PloyLine of Retention Time For iRT",
                                                IO_FILENAME_PIC_EXPORT[12] + '.png',
                                                "ployline figure for iRT", 200 + 50 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            
            
            

            
            
            f.write("<p class=section1>4 Mass spectrometry(MS)</p >\n")
            f.write("<p class=section1>4.1 Intensity Distribution</p >\n")
            f.write("<p class=section2>4.1.1 Total ion current(TIC)</p >\n")
            f.write("<p class=section3>The green dashed line represents the Median, and the red dashed line represents the Median-2*SD.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[48] + '.png', "Violin figure for TIC",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            f.write(self.var_sol_141("4.1.2 Intensity Distribution for Protein", IO_FILENAME_PIC_EXPORT[49] + '.png',
                                            "Intensity Distribution for Protein", 200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>4.2 Intensity Linear Correlation</p >\n")
            
            f.write("<p class=section2>4.2.1 protein level</p >\n")
            
            
            
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[57] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[58] + '.png', "scatter figure for Protein",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>4.2.2 peptide level</p >\n")
            
            
            
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[59] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[60] + '.png', "scatter figure for Peptide",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>4.2.3 precursor level</p >\n")
            
            
            
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[61] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[62] + '.png', "scatter figure for Precursor",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section1>4.3 Robust Standard Deviation</p >\n")
            f.write("<p class=section3> Robust standard deviation is computed based on log2-transformed quantitation ratios of two runs. Robust standard deviation = (the 84.13% percentiles - 15.87% percentiles) / 2. "
                    "The Robust Standard Deviation is a statistical measure that provides a robust or resistant measure of the variability in a dataset, particularly in the presence of outliers.")
            
            f.write("<p class=section2>4.3.1 protein level</p >\n")
            
            
            
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[63] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[64] + '.png', "violin figure for Protein",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>4.3.2 peptide level</p >\n")
            
            
            
            
            f.write(self.var_sol_97("",
                                                    IO_FILENAME_PIC_EXPORT[65] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[66] + '.png', "violin figure for Peptide",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>4.3.3 precursor level</p >\n")
            
            
            
            
            f.write(self.var_sol_97("",
                                                    IO_FILENAME_PIC_EXPORT[67] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[68] + '.png', "violin figure for Precursor",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section1>4.4 Intensity ratio distribution</p >\n")
            f.write("<p class=section3>The intensity ratios are computed by dividing the log2 intensity of each protein/peptide/precursor by the mean log2 intensity of that protein/peptide/precursor across all samples.")
            
            f.write("<p class=section2>4.4.1 protein level</p >\n")
            if len(self.dp.myProteinID.LIST_EXPERIMENT_ID)<50:
                f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[5] + '.png',
                                                        IO_FILENAME_PIC_EXPORT[8] + '.png',
                                                        "violin figure for Protein",
                                                        200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            else:
                f.write("<p class=section3> Before normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[5] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
                f.write("<p class=section3> After normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[8] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section2>4.4.2 peptide level</p >\n")
            if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 50:
                f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[24] + '.png',
                                                        IO_FILENAME_PIC_EXPORT[25] + '.png',
                                                        "violin figure for Protein",
                                                        200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            else:
                f.write("<p class=section3> Before normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[24] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
                f.write("<p class=section3> After normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[25] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section2>4.4.3 precursor level</p >\n")
            if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 50:
                f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[35] + '.png',
                                                        IO_FILENAME_PIC_EXPORT[36] + '.png',
                                                        "violin figure for Protein",
                                                        200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            else:
                f.write("<p class=section3> Before normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[35] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
                f.write("<p class=section3> After normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[36] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>4.5 Mass Accuracy</p >\n")
            f.write("<p class=section2>4.5.1 MS1 Mass Accuracy</p >\n")
            f.write("<p class=section3> Raw MS1 Mass Accuracy.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[52] + '.png',"Violin figure for MS1 Mass Accuracy",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            f.write("<p class=section3> Calibrated MS1 Mass Accuracy.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[71] + '.png',
                                                "Violin figure for Calibrated MS1 Mass Accuracy",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            f.write("<p class=section2>4.5.2 MS2 Mass Accuracy</p >\n")
            f.write("<p class=section3> Raw MS2 Mass Accuracy.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[53] + '.png',"Violinplot figure for MS2 Mass Accuracy",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            f.write("<p class=section3> Calibrated MS2 Mass Accuracy.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[72] + '.png',
                                                "Violinplot figure for Calibrated MS2 Mass Accuracy",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>4.6 Data Point per Peak (DPPP)</p >\n")
            f.write("<p class=section2>4.6.1 MS1 DPPP</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[54] + '.png', "Violin figure for MS1 DPPP",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            f.write("<p class=section2>4.6.2 MS2 DPPP</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[55] + '.png', "Violinplot figure for MS2 DPPP",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>4.7 CV plot for Protein</p >\n")
            
            f.write("<p class=section2>4.7.1 protein level</p >\n")
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[7] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[10] + '.png',
                                                    "boxplot figure for Protein",
                                                    100 + 100 * len(self.dp.LIST_EXPERIMENT_GROUP), 300))
            
            
            
            
            
            
            
            
            
            
            
            
            
            f.write("<p class=section2>5 cluster analysis</p >\n")
            f.write(self.var_sol_97("5.1 Cluster Heatmap for Protein", IO_FILENAME_PIC_EXPORT[6] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[9] + '.png',
                                                    "hotmap figure for Protein", 400 if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 20 else
                                                    400 + (len(self.dp.myProteinID.LIST_EXPERIMENT_ID)-20) * 10, 400))
            
            f.write(self.var_sol_84("5.2 Unsupervised cluster analysis(before normalization)",
                                                     IO_FILENAME_PIC_EXPORT[39] + '.png',
                                                     IO_FILENAME_PIC_EXPORT[40] + '.png',
                                                     "scatter figure", 400, 400))
            f.write(self.var_sol_84("5.3 Unsupervised cluster analysis(after normalization)", IO_FILENAME_PIC_EXPORT[11] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[30] + '.png',
                                                "scatter figure", 400, 400))

            
            
            f.write(self.tail_str)

    def reportDIA_inter(self):

        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_HTML_EXPORT
        print("Generating Webpage ......")

        with open(path_out, 'w')as f:

            f.write(self.head_str)
            
            f.write(self.var_sol_79())
            
            if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 100:
                f.write(self.var_sol_56(width=800,
                                                             height=20 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID)))
            
            f.write("<p class=section1>1. Overview of Dataset</p >\n")
            
            
            
            
            
            
            
            

            
            
            
            f.write("<p class=section2>1.1 Score of Inter-experiment Metrics</p >\n")
            f.write(
                "<p class=section3> Inter-experiment metrics are computed across multiple experiments to assess the quality for the whole cohort and detect low-quality data.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[42] + '.png',
                                                "Heatmap for Inter-experiment Score",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            f.write("<p class=section2> Outliers Detection</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[70] + '.png',
                                                "Scatter plot for Outlier Score",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>1.2 Detailed Information of Inter-experiment Metrics</p >\n")
            self.var_sol_134()  
            table_metrics = self.var_dra_10("", self.Metrics_Title, self.Metrics_Infor, 1, 1, 2, 6, 6, 6)
            f.write(table_metrics)

            
            f.write("<p class=section2>1.3 Identification Count</p >\n")
            f.write(
                "<p class=section3>The green dashed lines represents the Median number, the yellow dashed lines represents the Median ± 2*SD,"
                " and the red dashed lines represents the Median ± 3*SD.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[0] + '.png', "bar figure for Protein",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 900))
            
            f.write("<p class=section2>1.4 Quantification Count for Protein</p >\n")
            var_pat_139 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[1]
            var_pat_61 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[66]
            
            
            
            f.write(self.__solider_draw_table_missingValue_Share(var_pat_61))
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[69] + '.png',
                                                "bar figure for Protein",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            
            
            
            
            
            
            
            
            
            f.write("<p class=section1>2 Sample Peaparation</p >\n")
            f.write("<p class=section2>2.1 The Ratio of Contamination</p >\n")
            f.write(
                "<p class=section3>The green dashed lines represents the Median number, the red dashed lines represents the Median + 2*SD.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[44] + '.png',
                                                "bar figure for contaminations",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 900))

            
            
            
            
            
            

            
            
            f.write("<p class=section1>3 Liquid Chromatography(LC)</p >\n")
            f.write("<p class=section2>3.1 Peak Width</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[46] + '.png',
                                                "Boxplot figure for Peak Width",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section2>3.2 Full Width at Half Maximum (FWHM)</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[56] + '.png',
                                                "Boxplot figure for FWHM",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>3.3 Delta RT (predicted - measured)</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[47] + '.png',
                                                "Boxplot figure for Delta RT",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>3.4 RT Deviation Analysis</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[14] + '.png',
                                                "RT Deviation Analysis",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write(self.var_sol_141("3.5 PloyLine of Retention Time For iRT",
                                                IO_FILENAME_PIC_EXPORT[12] + '.png',
                                                "ployline figure for iRT",
                                                200 + 50 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            
            
            

            
            
            f.write("<p class=section1>4 Mass spectrometry(MS)</p >\n")
            f.write("<p class=section1>4.1 Intensity Distribution for Protein</p >\n")
            
            
            
            
            

            f.write(self.var_sol_141("",
                                                IO_FILENAME_PIC_EXPORT[49] + '.png',
                                                "Intensity Distribution for Protein",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>4.2 Intensity Linear Correlation</p >\n")
            
            f.write("<p class=section2>4.2.1 protein level</p >\n")
            
            
            
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[57] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[58] + '.png', "scatter figure for Protein",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>4.2.2 peptide level</p >\n")
            
            
            
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[59] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[60] + '.png', "scatter figure for Peptide",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>4.2.3 precursor level</p >\n")
            
            
            
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[61] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[62] + '.png', "scatter figure for Precursor",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section1>4.3 Robust Standard Deviation</p >\n")
            f.write(
                "<p class=section3> Robust standard deviation is computed based on log2-transformed quantitation ratios of two runs. Robust standard deviation = (the 84.13% percentiles - 15.87% percentiles) / 2. "
                "The Robust Standard Deviation is a statistical measure that provides a robust or resistant measure of the variability in a dataset, particularly in the presence of outliers.")
            
            f.write("<p class=section2>4.3.1 protein level</p >\n")
            
            
            
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[63] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[64] + '.png', "violin figure for Protein",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>4.3.2 peptide level</p >\n")
            
            
            
            
            f.write(self.var_sol_97("",
                                                    IO_FILENAME_PIC_EXPORT[65] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[66] + '.png', "violin figure for Peptide",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section2>4.3.3 precursor level</p >\n")
            
            
            
            
            f.write(self.var_sol_97("",
                                                    IO_FILENAME_PIC_EXPORT[67] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[68] + '.png', "violin figure for Precursor",
                                                    200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 500))
            
            f.write("<p class=section1>4.4 Intensity ratio distribution</p >\n")
            f.write(
                "<p class=section3>The intensity ratios are computed by dividing the log2 intensity of each protein/peptide/precursor by the mean log2 intensity of that protein/peptide/precursor across all samples.")
            
            f.write("<p class=section2>4.4.1 protein level</p >\n")
            if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 50:
                f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[5] + '.png',
                                                        IO_FILENAME_PIC_EXPORT[8] + '.png',
                                                        "violin figure for Protein",
                                                        200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            else:
                f.write("<p class=section3> Before normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[5] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
                f.write("<p class=section3> After normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[8] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section2>4.4.2 peptide level</p >\n")
            if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 50:
                f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[24] + '.png',
                                                        IO_FILENAME_PIC_EXPORT[25] + '.png',
                                                        "violin figure for Protein",
                                                        200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            else:
                f.write("<p class=section3> Before normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[24] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
                f.write("<p class=section3> After normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[25] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section2>4.4.3 precursor level</p >\n")
            if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 50:
                f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[35] + '.png',
                                                        IO_FILENAME_PIC_EXPORT[36] + '.png',
                                                        "violin figure for Protein",
                                                        200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            else:
                f.write("<p class=section3> Before normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[35] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
                f.write("<p class=section3> After normalization.")
                f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[36] + '.png',
                                                    "violin figure for Protein",
                                                    200 + 15 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>4.5 Mass Accuracy</p >\n")
            f.write("<p class=section2>4.5.1 MS1 Mass Accuracy</p >\n")
            f.write("<p class=section3> Raw MS1 Mass Accuracy.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[52] + '.png',
                                                "Violin figure for MS1 Mass Accuracy",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            f.write("<p class=section3> Calibrated MS1 Mass Accuracy.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[71] + '.png',
                                                "Violin figure for Calibrated MS1 Mass Accuracy",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            f.write("<p class=section2>4.5.2 MS2 Mass Accuracy</p >\n")
            f.write("<p class=section3> Raw MS2 Mass Accuracy.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[53] + '.png',
                                                "Violinplot figure for MS2 Mass Accuracy",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))
            f.write("<p class=section3> Calibrated MS2 Mass Accuracy.")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[72] + '.png',
                                                "Violinplot figure for Calibrated MS2 Mass Accuracy",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>4.6 Data Point per Peak (DPPP)</p >\n")
            f.write("<p class=section2>4.6.1 MS1 DPPP</p >\n")
            f.write(self.var_sol_141("", IO_FILENAME_PIC_EXPORT[54] + '.png', "Violin figure for MS1 DPPP",
                                                200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            f.write("<p class=section2>4.6.2 MS2 DPPP</p >\n")
            f.write(
                self.var_sol_141("", IO_FILENAME_PIC_EXPORT[55] + '.png', "Violinplot figure for MS2 DPPP",
                                            200 + 100 * len(self.dp.myProteinID.LIST_EXPERIMENT_ID), 300))

            
            f.write("<p class=section1>4.7 CV plot for Protein</p >\n")
            
            f.write("<p class=section2>4.7.1 protein level</p >\n")
            f.write(self.var_sol_97("", IO_FILENAME_PIC_EXPORT[7] + '.png',
                                                    IO_FILENAME_PIC_EXPORT[10] + '.png',
                                                    "boxplot figure for Protein",
                                                    100 + 100 * len(self.dp.LIST_EXPERIMENT_GROUP), 300))
            
            
            
            
            
            
            
            
            
            
            
            
            
            f.write("<p class=section2>5 cluster analysis</p >\n")
            f.write(
                self.var_sol_97("5.1 Cluster Heatmap for Protein", IO_FILENAME_PIC_EXPORT[6] + '.png',
                                                IO_FILENAME_PIC_EXPORT[9] + '.png',
                                                "hotmap figure for Protein",
                                                400 if len(self.dp.myProteinID.LIST_EXPERIMENT_ID) < 20 else
                                                400 + (len(self.dp.myProteinID.LIST_EXPERIMENT_ID) - 20) * 10, 400))
            
            f.write(self.var_sol_84("5.2 Unsupervised cluster analysis(before normalization)",
                                                     IO_FILENAME_PIC_EXPORT[39] + '.png',
                                                     IO_FILENAME_PIC_EXPORT[40] + '.png',
                                                     "scatter figure", 400, 400))
            f.write(self.var_sol_84("5.3 Unsupervised cluster analysis(after normalization)",
                                                     IO_FILENAME_PIC_EXPORT[11] + '.png',
                                                     IO_FILENAME_PIC_EXPORT[30] + '.png',
                                                     "scatter figure", 400, 400))

            
            
            f.write(self.tail_str)

class CFunctionPDFRe_3:

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def __soliderURL2PDF(self, url, to_file, option):
        '''将网页url生成pdf文件'''
        
        var_pat_125 = r'\bin\wkhtmltopdf\bin\wkhtmltopdf.exe'
        config = pdfkit.configuration(wkhtmltopdf=var_pat_125)
        
        pdfkit.from_url(url, to_file, configuration=config, options=option)

    def __soliderHTML2PDF(self, html, to_file, option):
        '''将html文件生成pdf文件'''
        
        var_pat_125 = r'.\bin\wkhtmltopdf\bin\wkhtmltopdf.exe'
        config = pdfkit.configuration(wkhtmltopdf=var_pat_125)
        
        pdfkit.from_url(html, to_file, configuration=config, options=option)

    def __soliderSTR2PDF(string, to_file):
        '''将字符串生成pdf文件'''
        
        var_pat_125 = r'.\bin\wkhtmltopdf\bin\wkhtmltopdf.exe'
        config = pdfkit.configuration(wkhtmltopdf=var_pat_125)
        
        pdfkit.from_string(string, to_file, configuration=config)

    def report(self):

        path_input = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_HTML_EXPORT
        path_out = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_PDF_EXPORT

        n_experiment = 226
        width_pdf = 8.5 if n_experiment < 20 else 8.5 + (n_experiment - 20) * 0.13

        var_wkh_154 = {
            'enable-local-file-access': None,
            'page-width': width_pdf * 14.0,
            'page-height': width_pdf * 1.3 * 72.0,
            'no-outline': None,
            'image-dpi': 1000,
            'image-quality': 200,
        }


        self.__soliderHTML2PDF(path_input, path_out, var_wkh_154)


