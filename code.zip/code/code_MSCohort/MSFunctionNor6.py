
import numpy as np
import pandas as pd
from numba import njit
from math import ceil
from MSData import CDataPack
from MSSystem import IO_FILENAME_EXPORT

class CFunctionNormU_1:

    def __init__(self):

        self.tao = 1e-3
        self.var_thr_9 = 1e-15
        self.var_thr_15 = 1e-15
        self.var_thr_16 = 1e-15
        self.num_iter = 100  

    def var_lin_28(self, inputIntensityX: np.ndarray, inputIntensityY: np.ndarray):
        Array_len = inputIntensityX.shape[0]
        X_mean = inputIntensityX.sum() / Array_len
        Y_mean = inputIntensityY.sum() / Array_len
        slope = np.dot(inputIntensityX, inputIntensityY) / np.dot(inputIntensityX, inputIntensityX)
        pearson = np.dot(inputIntensityX - X_mean, inputIntensityX - Y_mean) / np.sqrt(
            np.dot(inputIntensityX - X_mean, inputIntensityX - X_mean) * np.dot(inputIntensityY - Y_mean, inputIntensityY - Y_mean))

        return slope, pearson

    def __dataFilterProcess(self, inputIntensityMatrix: np.ndarray):
        '''
        :param var_inp_36: input intensity matrix, np.array type, shape=(n_intensity, n_sample)
        :return: out_intensity: output intensity matrix
        '''
        var_rat_21 = inputIntensityMatrix.copy()
        n_intensity = inputIntensityMatrix.shape[0]
        n_sample = inputIntensityMatrix.shape[1]
        
        params = np.zeros(shape=[inputIntensityMatrix.shape[1], 1])
        for i in range(inputIntensityMatrix.shape[1]):
            if i == 0:
                params[i, 0] = 1.0
            else:
                x, y = inputIntensityMatrix[:, 0], inputIntensityMatrix[:, i]
                params[i, 0], _ = self.var_lin_28(x, y)
        params = 1 / params
        for i in range(inputIntensityMatrix.shape[1]):
            var_rat_21[:, i] = inputIntensityMatrix[:, i] * params[i, 0]

        list_ratio = np.zeros(shape=[n_intensity, ])
        for i in range(n_sample):
            for j in range(i + 1, n_sample):
                tmp_ratio = abs(np.log2((var_rat_21[:, i] / var_rat_21[:, j]))) ** 2
                list_ratio += tmp_ratio
        list_ratio /= n_sample * (n_sample - 1) / 2

        list_change = list_ratio
        sort_index_cv = np.argsort(list_change)
        out_intensity = inputIntensityMatrix[sort_index_cv[int(len(sort_index_cv) * 0.): ceil(len(sort_index_cv) * 0.7)]]

        return out_intensity

    def __calLossAll(self, param, input_data):

        num_sample = input_data.shape[1]

        loss_all = np.zeros(shape=(input_data.shape[0], 1))
        param = [1.] + list(param[:, 0])

        for tmp_i in range(num_sample):
            for tmp_j in range(tmp_i + 1, num_sample, 1):
                h_a = param[tmp_i]
                h_b = param[tmp_j]

                data_a = input_data[:, tmp_i: tmp_i + 1]
                data_b = input_data[:, tmp_j: tmp_j + 1]

                
                loss_all += abs(np.log2((h_a * data_a) / (h_b * data_b)))

        return loss_all

    def __calResidual(self, params, input_data):
        
        var_dat_33 = 0 - self.__calLossAll(params, input_data)
        residual = var_dat_33
        return residual

    def __calDerive(self, params, input_data, param_index):
        params1 = params.copy()
        params2 = params.copy()
        params1[param_index, 0] += 0.0000001
        params2[param_index, 0] -= 0.0000001
        var_dat_8 = self.__calLossAll(params1, input_data)
        var_dat_50 = self.__calLossAll(params2, input_data)
        
        return (var_dat_8 - var_dat_50) / 0.0000002

    def __calJacobian(self, params, input_data):
        num_params = np.shape(params)[0]
        num_data = np.shape(input_data)[0]
        J = np.zeros((num_data, num_params))
        for i in range(0, num_params):
            J[:, i] = list(self.__calDerive(params, input_data, i))
        return J

    def __getInitU(self, A, tao):
        m = np.shape(A)[0]
        Aii = []
        for i in range(0, m):
            Aii.append(A[i, i])
        u = tao * max(Aii)
        return u

    def __AlgorithmLM(self, params, input_data):
        
        num_params = np.shape(params)[0]  
        
        residual = self.__calResidual(params, input_data)  
        
        
        Jacobian = self.__calJacobian(params, input_data)
        
        A = Jacobian.T.dot(Jacobian)  
        g = Jacobian.T.dot(residual)  
        stop = (np.linalg.norm(g, ord=np.inf) <= self.var_thr_9)  
        u = self.__getInitU(A, self.tao)  
        v = 2  
        rou = 0  
        k = 0  

        while (not stop) and (k < self.num_iter):
            k += 1
            while True:
                
                Hessian_LM = A + u * np.eye(num_params)  
                
                step = np.linalg.inv(Hessian_LM).dot(g)  
                if np.linalg.norm(step) <= self.var_thr_15:
                    
                    stop = True
                else:

                    new_params = params + step  
                    
                    
                    new_residual = self.__calResidual(new_params, input_data)  

                    rou = (np.linalg.norm(residual) ** 2 - np.linalg.norm(new_residual) ** 2) / (
                        step.T.dot(u * step + g))
                    if rou > 0:
                        params = new_params
                        residual = new_residual
                        
                        Jacobian = self.__calJacobian(params, input_data)  
                        A = Jacobian.T.dot(Jacobian)  
                        g = Jacobian.T.dot(residual)  
                        stop = (np.linalg.norm(g, ord=np.inf) <= self.var_thr_9) or (
                                np.linalg.norm(residual) ** 2 <= self.var_thr_16)
                        u = u * max(1 / 3, 1 - (2 * rou - 1) ** 3)
                        v = 2
                    else:
                        u = u * v
                        v = 2 * v
                if rou > 0 or stop:
                    break
        
        return params

    def norm(self, inputIntensityMatrix: np.ndarray):

        len_param = inputIntensityMatrix.shape[1]

        if len_param <= 1:
            return None

        
        params_norm = np.zeros((len_param, 1))
        valuedIntensityMatrix = inputIntensityMatrix[np.prod(inputIntensityMatrix > 0, axis=1) == True]
        filterIntensityMatrix = self.__dataFilterProcess(valuedIntensityMatrix)

        
        for i in range(params_norm.shape[0]):
            if i == 0:
                params_norm[i, 0] = 1.0
            else:
                x, y = filterIntensityMatrix[:, 0], filterIntensityMatrix[:, i]
                params_norm[i, 0], _ = self.var_lin_28(x, y)
        params_norm = 1 / params_norm[1:]

        for i in range(1, inputIntensityMatrix.shape[1]):

            filterIntensityMatrix[:, i] = filterIntensityMatrix[:, i] * params_norm[i - 1]

        
        var_par_24 = np.ones((len_param, 1))
        est_params = self.__AlgorithmLM(var_par_24, filterIntensityMatrix)

        
        outputIntensityMatrix = inputIntensityMatrix.copy()
        
        for i in range(1, inputIntensityMatrix.shape[1]):

            outputIntensityMatrix[:, i] = inputIntensityMatrix[:, i] * est_params[i - 1] * params_norm[i - 1]
            

        
        est_params = est_params[:-1]
        return outputIntensityMatrix, est_params * params_norm


class CFunctionNormU_2:

    def __init__(self, inputType=0):

        self.type = inputType
        self.dicType = {'mean': 0, 'median': 1}

    def norm(self, inputMatrix: np.ndarray):

        matrixArgsort = np.zeros(shape=inputMatrix.shape, dtype=np.int)
        matrixOrder = inputMatrix.copy()
        matrixOut = inputMatrix.copy()

        for i_col in range(matrixOrder.shape[1]):
            matrixArgsort[:, i_col] = np.argsort(inputMatrix[:, i_col])
            matrixOrder[:, i_col] = np.sort(matrixOrder[:, i_col])
        
        if self.type == self.dicType['mean']:
            listMean = np.mean(matrixOrder, axis=1)
        else:
            listMean = np.median(matrixOrder, axis=1)

        for i_col in range(matrixOut.shape[1]):
            matrixOut[:, i_col][matrixArgsort[:, i_col]] = listMean

        return matrixOut


class CFunctionNormU_3:

    def __init__(self):

        pass

    def __solider_calculate_fraction_with_no_NAs(self, df, df_nonnans):
        return len(df_nonnans.columns) / len(df.columns)

    def var_cap_11(self, df):
        df_nonans = df.dropna(axis=1)
        var_fra_40 = self.__solider_calculate_fraction_with_no_NAs(df, df_nonans)
        num_nonans = len(df_nonans.columns)
        if num_nonans < 1000 or var_fra_40 < 0.001:
            print('to few values for normalization without missing values. Including missing values')
            return df
        else:
            return df_nonans

    def var_sol_18(self, samples):
        for idx in range(len(samples)):
            sample = samples[idx]
            if sum(~np.isnan(sample)) < 2:
                sample[:] = np.nan

    
    def var_wea_17(self, fcdist):
        return np.nanvar(fcdist)

    
    def var_wea_26(self, fcdist):
        return np.nanmedian(fcdist)

    def var_wea_22(self, logvals_rep1, logvals_rep2):
        dist = np.subtract(logvals_rep1, logvals_rep2)
        return dist

    def var_wea_37(self, metric, samples_1, samples_2):
        res = None

        if metric == 'median':
            res = self.var_wea_26(self.var_wea_22(samples_1,
                                               samples_2))  
        if (metric == 'variance'):
            fcdist = self.var_wea_22(samples_1, samples_2)
            
            
            res = self.var_wea_17(fcdist)
        if metric == 'overlap':
            fcdist = self.var_wea_22(samples_1, samples_2)
            res = sum(~np.isnan(fcdist))
        if res == None:
            raise Exception(f"distance metric {metric} not implemented")
        if (np.isnan(res)):
            return np.inf
        else:
            return res

    def var_sol_7(self, samples, metric='median'):
        num_samples = samples.shape[0]
        var_dis_29 = np.full((num_samples, num_samples), np.inf)
        for i in range(num_samples):
            for j in range(i + 1, num_samples):  
                var_dis_29[i, j] = self.var_wea_37(metric, samples[i], samples[
                    j])  

        return var_dis_29

    def var_wea_45(self, sample2counts, i_min, j_min, min_distance):
        counts_i = sample2counts[i_min]
        counts_j = sample2counts[j_min]
        anchor_idx = i_min if counts_i >= counts_j else j_min
        shift_idx = j_min if anchor_idx == i_min else i_min
        flip = 1 if anchor_idx == i_min else -1
        return anchor_idx, shift_idx, flip * min_distance

    def var_sol_3(self, var_dis_29, var_var_2, sample2counts):

        i, j = np.unravel_index(np.argmin(var_var_2, axis=None), var_var_2.shape)
        min_distance = var_dis_29[i, j]
        
        if (min_distance == np.inf):
            return None, None, None
        anchor_idx, shift_idx, min_distance = self.var_wea_45(sample2counts, i, j,
                                                                                min_distance)  
        return anchor_idx, shift_idx, min_distance

    def var_sol_10(self, var_anc_48, var_shi_6, var_cou_46, var_cou_32):

        res = np.zeros(len(var_anc_48))

        nans_anchor = np.isnan(var_anc_48)
        nans_shifted = np.isnan(var_shi_6)
        var_nan_5 = nans_anchor & nans_shifted
        var_nan_12 = nans_anchor & ~nans_shifted
        var_nan_39 = nans_shifted & ~nans_anchor
        no_nans = ~nans_anchor & ~nans_shifted

        var_idx_42 = np.where(var_nan_5)
        var_idx_34 = np.where(var_nan_12)
        var_idx_27 = np.where(var_nan_39)
        idx_no_nans = np.where(no_nans)

        res[var_idx_42] = np.nan
        res[var_idx_34] = var_shi_6[var_idx_34]
        res[var_idx_27] = var_anc_48[var_idx_27]
        res[idx_no_nans] = (var_anc_48[idx_no_nans] * var_cou_46 + var_shi_6[
            idx_no_nans] * var_cou_32) / (var_cou_46 + var_cou_32)
        return res

    def var_sol_43(self, var_dis_29, var_mer_4, var_mer_19, shift_idx, metric='median'):
        for i in range(0, var_mer_19):  
            if var_dis_29[i, var_mer_19] == np.inf:  
                continue
            distance = self.var_wea_37(metric, var_mer_4[i], var_mer_4[var_mer_19])
            var_dis_29[i, var_mer_19] = distance

        for j in range(var_mer_19 + 1, var_mer_4.shape[0]):  
            if var_dis_29[var_mer_19, j] == np.inf:
                continue
            distance = self.var_wea_37(metric, var_mer_4[var_mer_19], var_mer_4[j])
            var_dis_29[var_mer_19, j] = distance

        var_dis_29[shift_idx] = np.inf  
        var_dis_29[:, shift_idx] = np.inf

    def var_sol_20(self, sampleidx2anchoridx, sample2shift, sample_idx):

        total_shift = 0.0

        while (True):
            total_shift += sample2shift[sample_idx]
            if sample_idx not in sampleidx2anchoridx:  
                break
            sample_idx = sampleidx2anchoridx[sample_idx]

        return total_shift

    def var_cap_30(self, samples):  

        self.var_sol_18(samples)
        num_samples = samples.shape[0]
        mergedsamples = np.copy(samples)  
        sampleidx2shift = dict(zip(range(num_samples),
                                   np.zeros(num_samples)))  
        sampleidx2counts = dict(
            zip(range(num_samples), np.ones(num_samples)))  
        sampleidx2anchoridx = {}  
        exclusion_set = set()  
        var_dis_29 = self.var_sol_7(samples)
        var_var_2 = self.var_sol_7(samples, metric='variance')
        

        for rep in range(num_samples - 1):
            
            
            anchor_idx, shift_idx, min_distance = self.var_sol_3(var_dis_29, var_var_2, sampleidx2counts)
            
            
            

            if (anchor_idx == None):
                break
            sampleidx2anchoridx.update({shift_idx: anchor_idx})
            sampleidx2shift.update({shift_idx: min_distance})
            exclusion_set.add(shift_idx)

            anchor_sample = mergedsamples[anchor_idx]
            shift_sample = samples[shift_idx]
            var_shi_47 = shift_sample + min_distance

            merged_sample = self.var_sol_10(anchor_sample, var_shi_47, sampleidx2counts[anchor_idx],
                                           sampleidx2counts[shift_idx])
            mergedsamples[anchor_idx] = merged_sample

            self.var_sol_43(var_var_2, mergedsamples, anchor_idx, shift_idx, metric='variance')
            self.var_sol_43(var_dis_29, mergedsamples, anchor_idx, shift_idx)

            
            sampleidx2counts[anchor_idx] += 1

        sampleidx2totalshift = {}
        for i in exclusion_set:
            shift = self.var_sol_20(sampleidx2anchoridx, sampleidx2shift, i)
            sampleidx2totalshift[i] = shift
            
        return sampleidx2totalshift
        

    def var_cap_41(self, var_int_14: np.ndarray):

        return var_int_14

    def norm(self, inputIntensityMatrix: np.ndarray):

        var_mat_1 = inputIntensityMatrix.copy().T
        df_intensity = pd.DataFrame(var_mat_1)
        var_mat_1 = self.var_cap_11(df_intensity).to_numpy()
        
        sample2shift = self.var_cap_30(var_mat_1)
        
        
        for idx in sample2shift.keys():
            inputIntensityMatrix[:,idx] = inputIntensityMatrix[:,idx] + sample2shift.get(idx)

        return inputIntensityMatrix, sample2shift


class CFunctionProte_4:

    def __init__(self, inputDP: CDataPack, method='average'):

        self.dp = inputDP
        self.cal_method = method

    def __captrainOutputIntensity(self):

        var_out_25 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[54]
        var_out_49 = self.dp.myCFG.E1_PATH_EXPORT + '\\' + IO_FILENAME_EXPORT[55]

        with open(var_out_25, 'w')as f:
            f.write('\t'.join(['peptide']+self.dp.myPeptideID.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myPeptideID.N_PEPTIDE):
                print(i)
                f.write(self.dp.myPeptideID.PEP1_SEQ[i] + '\t' + '\t'.join([str(j) for j in self.dp.myPeptideID.PEPLIST2_INTENSITY_FORMERGE[i]]) + '\n')

        with open(var_out_49, 'w')as f:
            f.write('\t'.join(['Protein'] + self.dp.myProteinID.LIST_EXPERIMENT_ID) + '\n')
            for i in range(self.dp.myProteinID.N_PROTEIN):
                print(i)
                f.write(self.dp.myProteinID.PRO1_NAME[i] + '\t' + '\t'.join([str(j) for j in self.dp.myProteinID.PRO2_INTENSITY[i]]) + '\n')

    def merge(self):

        n_protein = self.dp.myProteinID.N_PROTEIN
        var_mat_44 = np.array(self.dp.myPeptideID.PEPLIST2_INTENSITY_FORMERGE)
        var_mat_44[var_mat_44 < 0] = 0
        print(n_protein)
        for i in range(n_protein):

            i_protein = self.dp.myProteinID.PRO1_NAME[i]
            list_peptide = self.dp.myProteinID.DICT_PROTEIN2PEPTIDE[i_protein]
            var_lis_35 = [self.dp.myPeptideID.DICT_PEPTIDE2POSITION[i] for i in list_peptide]
            var_mat_1 = var_mat_44[var_lis_35]
            print(i, len(list_peptide), var_mat_1.shape)

            if self.cal_method == 'average':
                list_count = np.sum(var_mat_1 > 0, axis=0)
                list_count[list_count == 0] = 1
                var_lis_31 = np.sum(var_mat_1, axis=0) / list_count
                self.dp.myProteinID.PRO2_INTENSITY[i] = list(var_lis_31)
            elif self.cal_method == 'sum':
                var_lis_31 = np.sum(var_mat_1, axis=0)
                self.dp.myProteinID.PRO2_INTENSITY[i] = list(var_lis_31)
            else:  
                pass

        for i in range(self.dp.myPeptideID.N_PEPTIDE):
            self.dp.myPeptideID.PEPLIST2_INTENSITY_FORMERGE[i] = list(var_mat_44[i])

        
        self.__captrainOutputIntensity()