import os
from PIL import Image
import glob

import pdfkit


def url_to_pdf(url, to_file, option):

    path_wkthmltopdf = r'bin/wkhtmltopdf\bin\wkhtmltopdf.exe'
    config = pdfkit.configuration(wkhtmltopdf=path_wkthmltopdf)

    pdfkit.from_url(url, to_file, configuration=config, options=option)
    print('完成')


def html_to_pdf(html, to_file, option):

    path_wkthmltopdf = r'bin/wkhtmltopdf\bin\wkhtmltopdf.exe'
    config = pdfkit.configuration(wkhtmltopdf=path_wkthmltopdf)

    pdfkit.from_file(html, to_file, configuration=config, options=option)
    print('完成')


def str_to_pdf(string, to_file):

    path_wkthmltopdf = r'bin/wkhtmltopdf\bin\wkhtmltopdf.exe'
    config = pdfkit.configuration(wkhtmltopdf=path_wkthmltopdf)

    pdfkit.from_string(string, to_file, configuration=config)
    print('完成')

n_experiment = 1
width_pdf = 8.5 if n_experiment < 20 else 8.5 + (n_experiment - 20) * 0.07
print(width_pdf)

wkhtmltopdf_options = {
    'enable-local-file-access': None,
    'page-width': width_pdf * 72.0,
    'page-height': width_pdf * 1.4 * 72.0,
    'no-outline': None,
    'image-dpi': 1000,
    'image-quality': 200,
}

path_input_html = r'D:\RAW\Dimethyl_label_data\pFind\20211216\MSMonitor_report\Analysis_Report.html'
path_out_pdf = r'D:\RAW\Dimethyl_label_data\pFind\20211216\MSMonitor_report\out_1.pdf'

html_to_pdf(path_input_html, path_out_pdf, wkhtmltopdf_options)
