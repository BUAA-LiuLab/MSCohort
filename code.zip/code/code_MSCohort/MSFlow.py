from MSData import CDataPack, Config
from MSTask import CTaskReadINI, CTaskCheck, CTaskReadMS, CTaskReadID, CTaskStatMV, \
    CTaskCorrAnalysis, CTaskRTDevAnalysis, CTaskVisualForIRT, CTaskNormalization, CTaskReport, CTaskVisualForIRTDDA,\
    CTaskExtractIRTFromMS1, CTaskOutputIRTIndicator, CTaskRefineDIA
from MSFunction1 import CFunctionConfi_11
from MSSystem import IO_NAME_FILE_CONFIG, IO_NAME_FILE_SETTING
from MSLogging import INFO_TO_USER_Flow1, INFO_TO_USER_Flow2, INFO_TO_USER_Flow3, logToUser
import time


class CFlow0:  

    def run(self):

        config = Config()

        FunctionConfig = CFunctionConfi_11()
        FunctionConfig.config2file(IO_NAME_FILE_CONFIG[0], IO_NAME_FILE_SETTING[0], config)


class CFlow1:  

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def run(self):

        logToUser(INFO_TO_USER_Flow1[0])
        taskCheck = CTaskCheck(self.dp)
        taskCheck.work()

        logToUser(INFO_TO_USER_Flow1[1])
        taskReadINI = CTaskReadINI(self.dp)
        taskReadINI.work()

        logToUser(INFO_TO_USER_Flow1[2])
        taskReadMS1 = CTaskReadMS(self.dp)
        taskReadMS1.work()

        logToUser(INFO_TO_USER_Flow1[3])
        taskReadID = CTaskReadID(self.dp)
        taskReadID.work()

        logToUser(INFO_TO_USER_Flow1[4])
        taskStatMV = CTaskStatMV(self.dp)
        taskStatMV.work()

        logToUser(INFO_TO_USER_Flow1[5])
        taskCorrlation = CTaskCorrAnalysis(self.dp)
        taskCorrlation.work(flag_norm=False)

        logToUser(INFO_TO_USER_Flow1[8])
        taskNormalization = CTaskNormalization(self.dp)
        taskNormalization.work()

        logToUser(INFO_TO_USER_Flow1[7])
        taskvisualForiRT = CTaskVisualForIRTDDA(self.dp)
        taskvisualForiRT.work()

        logToUser(INFO_TO_USER_Flow1[9])
        taskCorrlation = CTaskCorrAnalysis(self.dp)
        taskCorrlation.work(flag_norm=True)

        logToUser(INFO_TO_USER_Flow1[10])
        taskReport = CTaskReport(self.dp)
        taskReport.work()


class CFlow2:  

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def run(self):
        logToUser(INFO_TO_USER_Flow2[0])
        taskCheck = CTaskCheck(self.dp)
        taskCheck.work()

        logToUser(INFO_TO_USER_Flow2[1])
        taskReadINI = CTaskReadINI(self.dp)
        taskReadINI.work()

        if self.dp.myCFG.A1_PATH_MS1 != '':
            logToUser(INFO_TO_USER_Flow2[3])
            taskRefine = CTaskRefineDIA(self.dp)
            taskRefine.work()

        logToUser(INFO_TO_USER_Flow2[4])
        taskReadID = CTaskReadID(self.dp)
        taskReadID.work()

        logToUser(INFO_TO_USER_Flow2[5])
        taskStatMV = CTaskStatMV(self.dp)
        taskStatMV.work()

        logToUser(INFO_TO_USER_Flow2[6])
        taskCorrlation = CTaskCorrAnalysis(self.dp)
        taskCorrlation.work(flag_norm=False)

        logToUser(INFO_TO_USER_Flow2[7])
        taskRTanalysis = CTaskRTDevAnalysis(self.dp)
        taskRTanalysis.work()

        logToUser(INFO_TO_USER_Flow2[9])
        time_start = time.time()
        taskNormalization = CTaskNormalization(self.dp)
        taskNormalization.work()
        print("Normalization analysis time:"+ str(round(time.time() - time_start,4)))

        logToUser(INFO_TO_USER_Flow2[8])
        taskvisualForiRT = CTaskVisualForIRT(self.dp)
        taskvisualForiRT.work()

        logToUser(INFO_TO_USER_Flow2[10])
        taskCorrlation = CTaskCorrAnalysis(self.dp)
        taskCorrlation.work(flag_norm=True)

        logToUser(INFO_TO_USER_Flow2[11])
        taskReport = CTaskReport(self.dp)
        taskReport.workDIA()


class CFlow3:  

    def __init__(self, inputDP: CDataPack):

        self.dp = inputDP

    def run(self):

        logToUser(INFO_TO_USER_Flow3[0])
        taskCheck = CTaskCheck(self.dp)
        taskCheck.work()

        logToUser(INFO_TO_USER_Flow3[1])
        taskReadINI = CTaskReadINI(self.dp)
        taskReadINI.work()

        logToUser(INFO_TO_USER_Flow3[2])
        taskReadMS1 = CTaskReadMS(self.dp)
        taskReadMS1.work()

        logToUser(INFO_TO_USER_Flow3[3])
        taskExtractIRT = CTaskExtractIRTFromMS1(self.dp)
        maxRT = taskExtractIRT.work()

        logToUser(INFO_TO_USER_Flow3[4])
        taskCalIRTIndicator = CTaskOutputIRTIndicator(self.dp)
        taskCalIRTIndicator.work(maxRT)
